import discord
from discord.ext import commands
import math
import asyncio

async def send_paginated_embed(ctx, data, items_per_page, format_function, title, color, loading_message=None):
    """Send a paginated embed with navigation buttons"""
    if not data:
        embed = discord.Embed(
            title=title,
            description="No data found.",
            color=color
        )
        if loading_message:
            await loading_message.edit(embed=embed)
        else:
            await ctx.send(embed=embed)
        return

    total_pages = math.ceil(len(data) / items_per_page)
    current_page = 0

    def get_page_data(page):
        start = page * items_per_page
        end = start + items_per_page
        return data[start:end]

    def create_embed(page):
        page_data = get_page_data(page)
        embed = format_function(page_data, page, total_pages, title, color)
        # Add page footer
        embed.set_footer(text=f"Page {page + 1} of {total_pages}")
        return embed

    # Create initial embed
    embed = create_embed(current_page)

    # Always show pagination buttons for consistency (even if only 1 page)
    view = PaginationView(current_page, total_pages, create_embed, ctx.author)

    if loading_message:
        await loading_message.edit(embed=embed, view=view)
    else:
        await ctx.send(embed=embed, view=view)

class PaginationView(discord.ui.View):
    def __init__(self, current_page, total_pages, create_embed_func, author):
        super().__init__(timeout=300)
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_embed = create_embed_func
        self.author = author

        # Update button states
        self.update_button_states()

    def update_button_states(self):
        """Update button disabled states based on current page"""
        # First page and previous page buttons
        self.first_page.disabled = self.current_page == 0
        self.previous_page.disabled = self.current_page == 0

        # Last page and next page buttons  
        self.next_page.disabled = self.current_page == self.total_pages - 1
        self.last_page.disabled = self.current_page == self.total_pages - 1

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message(
                "You cannot interact with this menu.", 
                ephemeral=True
            )
            return False
        return True

    @discord.ui.button(emoji='<:jo1ntrx_doubleleft:1405095487710691449>', style=discord.ButtonStyle.gray, row=0)
    async def first_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to first page"""
        self.current_page = 0
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji='<:jo1ntrx_left:1405095378231099464>', style=discord.ButtonStyle.gray, row=0)
    async def previous_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to previous page"""
        self.current_page -= 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji='<:jo1ntrx_delete:1405095625795702895>', style=discord.ButtonStyle.red, row=0)
    async def delete_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Delete the paginated message"""
        await interaction.response.edit_message(content="Message deleted.", embed=None, view=None)

    @discord.ui.button(emoji='<:jo1ntrx_right:1405095312456024127>', style=discord.ButtonStyle.gray, row=0)
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to next page"""
        self.current_page += 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji='<:jo1ntrx_doubleright:1405095454395465790>', style=discord.ButtonStyle.gray, row=0)
    async def last_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to last page"""
        self.current_page = self.total_pages - 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    async def on_timeout(self):
        # Disable all buttons when timeout occurs
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True


async def send_paginated_layout_view(ctx, data, items_per_page, format_function, title, color, loading_message=None):
    """Send a paginated layout view with navigation buttons inside the container"""
    from discord import ui
    
    if not data:
        view = ui.LayoutView(timeout=300)
        content = f"""## <:jo1ntrx_invite:1405093146358190233> {title}
> No data found."""
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        if loading_message:
            await loading_message.edit(embed=None, view=view)
        else:
            await ctx.send(view=view)
        return

    total_pages = math.ceil(len(data) / items_per_page)
    current_page = 0

    def get_page_data(page):
        start = page * items_per_page
        end = start + items_per_page
        return data[start:end]

    def create_view(page):
        page_data = get_page_data(page)
        return format_function(page_data, page, total_pages, title, color)

    view = LayoutPaginationView(current_page, total_pages, create_view, ctx.author, get_page_data, format_function, title, color)

    if loading_message:
        await loading_message.edit(embed=None, view=view)
    else:
        await ctx.send(view=view)


class LayoutPaginationView(discord.ui.LayoutView):
    def __init__(self, current_page, total_pages, create_view_func, author, get_page_data, format_function, title, color):
        super().__init__(timeout=300)
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_view = create_view_func
        self.author = author
        self.get_page_data = get_page_data
        self.format_function = format_function
        self.title = title
        self.color = color
        self._setup_view()
    
    def _setup_view(self):
        from discord import ui
        
        page_data = self.get_page_data(self.current_page)
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        temp_view = self.format_function(page_data, self.current_page, self.total_pages, self.title, self.color)
        
        for item in temp_view.children:
            if isinstance(item, ui.Container):
                for child in item.children:
                    if isinstance(child, ui.TextDisplay):
                        text_display = ui.TextDisplay(child.content)
                        
                        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
                        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
                        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
                        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
                        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
                        
                        async def first_callback(interaction: discord.Interaction):
                            if interaction.user != self.author:
                                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
                            self.current_page = 0
                            new_view = LayoutPaginationView(self.current_page, self.total_pages, self.create_view, self.author, self.get_page_data, self.format_function, self.title, self.color)
                            await interaction.response.edit_message(view=new_view)
                        
                        async def prev_callback(interaction: discord.Interaction):
                            if interaction.user != self.author:
                                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
                            self.current_page = max(0, self.current_page - 1)
                            new_view = LayoutPaginationView(self.current_page, self.total_pages, self.create_view, self.author, self.get_page_data, self.format_function, self.title, self.color)
                            await interaction.response.edit_message(view=new_view)
                        
                        async def delete_callback(interaction: discord.Interaction):
                            if interaction.user != self.author:
                                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
                            await interaction.message.delete()
                        
                        async def next_callback(interaction: discord.Interaction):
                            if interaction.user != self.author:
                                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
                            self.current_page = min(self.total_pages - 1, self.current_page + 1)
                            new_view = LayoutPaginationView(self.current_page, self.total_pages, self.create_view, self.author, self.get_page_data, self.format_function, self.title, self.color)
                            await interaction.response.edit_message(view=new_view)
                        
                        async def last_callback(interaction: discord.Interaction):
                            if interaction.user != self.author:
                                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
                            self.current_page = self.total_pages - 1
                            new_view = LayoutPaginationView(self.current_page, self.total_pages, self.create_view, self.author, self.get_page_data, self.format_function, self.title, self.color)
                            await interaction.response.edit_message(view=new_view)
                        
                        first_btn.callback = first_callback
                        prev_btn.callback = prev_callback
                        delete_btn.callback = delete_callback
                        next_btn.callback = next_callback
                        last_btn.callback = last_callback
                        
                        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
                        container = ui.Container(text_display, button_row)
                        self.add_item(container)
                        return
        
        content = f"## {self.title}\n> Page {self.current_page + 1} of {self.total_pages}"
        text_display = discord.ui.TextDisplay(content)
        container = discord.ui.Container(text_display)
        self.add_item(container)
