import json
import os

class EmojiManager:
    def __init__(self):
        self.emojis = {}
        self.load_emojis()
    
    def load_emojis(self):
        """Load emojis from the JSON file"""
        try:
            with open('Jo1nTrX/core/emojis.json', 'r') as f:
                self.emojis = json.load(f)
        except FileNotFoundError:
            print("Warning: emojis.json file not found")
            self.emojis = {}
    
    def get(self, category, name):
        """Get an emoji by category and name"""
        try:
            return self.emojis.get(category, {}).get(name, "")
        except:
            return ""
    
    def get_animated(self, name):
        """Get an animated emoji"""
        return self.get('animated', name)
    
    def get_static(self, name):
        """Get a static emoji"""
        return self.get('static', name)
    
    def get_category(self, name):
        """Get a category emoji"""
        return self.get('category', name)
    
    def get_special(self, name):
        """Get a special emoji"""
        return self.get('special', name)
    
    # Quick access properties for commonly used emojis
    @property
    def loading(self):
        return self.get_animated('loading')
    
    @property
    def tick(self):
        return self.get_static('tick')
    
    @property
    def cross(self):
        return self.get_static('cross')
    
    @property
    def animated_tick(self):
        return self.get_animated('tick')
    
    @property
    def animated_cross(self):
        return self.get_animated('cross')
    
    @property
    def arrow(self):
        return "<a:pheonix_pz_arrow_right:1393868357123575962>"
    
    @property
    def right_arrow(self):
        return self.get_static('right_arrow')

# Create a global instance
emoji = EmojiManager()