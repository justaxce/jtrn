#!/usr/bin/env python3
"""
Migration script to update all bot files to use the centralized component.py
This script will:
1. Replace create_embed() with EmbedFactory.create()
2. Update discord.ui.View to BaseView
3. Update discord.ui.Select to BaseSelect
4. Update discord.ui.Button to BaseButton
5. Add the correct imports from component.py
"""

import os
import re
from pathlib import Path

COGS_DIR = Path(__file__).parent.parent / "cogs"

COMPONENT_IMPORT = """from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)"""

EMOJI_REPLACEMENTS = {
    '"<:jo1ntrx_tick:1405094860398194720>"': 'bot_emoji.tick',
    '"<:jo1ntrx_cross:1405094857336217672>"': 'bot_emoji.cross',
    '"<:jo1ntrx_cross:1405094904568483880>"': 'bot_emoji.cross',
    '"<a:Jo1nTrX_loading:1405188056067067966>"': 'bot_emoji.loading',
    '"<a:jo1ntrx_loading:1405094057499295806>"': 'bot_emoji.loading',
    '"<:jo1ntrx_left:1405095378231099464>"': 'bot_emoji.left',
    '"<:jo1ntrx_right:1405095312456024127>"': 'bot_emoji.right',
    '"<:jo1ntrx_doubleleft:1405095487710691449>"': 'bot_emoji.double_left',
    '"<:jo1ntrx_doubleright:1405095454395465790>"': 'bot_emoji.double_right',
    '"<:jo1ntrx_delete:1405095625795702895>"': 'bot_emoji.delete',
    '"<:Jo1nTrX_giveaway:1411471234922971298>"': 'bot_emoji.giveaway',
    '"<:jo1ntrX_giveawayreact:1405187284109889647>"': 'bot_emoji.giveaway_react',
    '"<:jo1ntrX_member:1405208565500739607>"': 'bot_emoji.member',
    '"<:Jo1nTrX_antinuke:1438450620402237542>"': 'bot_emoji.antinuke',
    '"<:Jo1nTrX_automod:1439086767293861998>"': 'bot_emoji.automod',
    '"<:jo1ntrx_index:1405093893799677963>"': 'bot_emoji.index',
    '"<:jo1ntrx_invite:1405093146358190233>"': 'bot_emoji.invite',
    '"<:jo1ntrx_utility:1405096322872246323>"': 'bot_emoji.utility',
    '"<:jo1ntrx_moderation:1405093582863339591>"': 'bot_emoji.moderation',
    '"<:Jo1nTrX_channels:1420433174949003294>"': 'bot_emoji.channels',
    '"<:Jo1nTrX_welcome:1408686831415066715>"': 'bot_emoji.welcome',
    '"<:Jo1nTrX_message:1411471191834890354>"': 'bot_emoji.message',
    '"<:jo1ntrx_vanity:1406543809969389669>"': 'bot_emoji.vanity',
    '"<:Jo1nTrX_custom_role:1414269165241372712>"': 'bot_emoji.custom_role',
    '"<:Jo1nTrX_embed:1410862725751509083>"': 'bot_emoji.embed',
    '"<:Jo1nTrX_autoaction:1410988700799598602>"': 'bot_emoji.autoaction',
    '"<:Jo1nTrX_Currency:1416791338879553690>"': 'bot_emoji.currency',
    '"<:Jo1nTrX_ticket:1412649169801187429>"': 'bot_emoji.ticket',
    '"<:Jo1nTrX_fun:1423584274648399873>"': 'bot_emoji.fun',
    '"<:Jo1nTrX_misc:1422793178746060812>"': 'bot_emoji.misc',
    '"<:Jo1nTrX_logs:1430762798606061621>"': 'bot_emoji.logs',
    '"<:jo1ntrx_support:1405178991786201219>"': 'bot_emoji.support',
    '"<:Jo1nTrX_lock_1:1412701461749563463>"': 'bot_emoji.lock',
    '"<a:Jo1nTrX_Dotz:1415025958251003994>"': 'bot_emoji.dots',
    '"<:Jo1nTrX_arrow2:1415026780783247420>"': 'bot_emoji.arrow',
    
    "'<:jo1ntrx_tick:1405094860398194720>'": 'bot_emoji.tick',
    "'<:jo1ntrx_cross:1405094857336217672>'": 'bot_emoji.cross',
    "'<:jo1ntrx_cross:1405094904568483880>'": 'bot_emoji.cross',
    "'<a:Jo1nTrX_loading:1405188056067067966>'": 'bot_emoji.loading',
    "'<a:jo1ntrx_loading:1405094057499295806>'": 'bot_emoji.loading',
    "'<:jo1ntrx_left:1405095378231099464>'": 'bot_emoji.left',
    "'<:jo1ntrx_right:1405095312456024127>'": 'bot_emoji.right',
    "'<:jo1ntrx_doubleleft:1405095487710691449>'": 'bot_emoji.double_left',
    "'<:jo1ntrx_doubleright:1405095454395465790>'": 'bot_emoji.double_right',
    "'<:jo1ntrx_delete:1405095625795702895>'": 'bot_emoji.delete',
    "'<:Jo1nTrX_giveaway:1411471234922971298>'": 'bot_emoji.giveaway',
    "'<:jo1ntrX_giveawayreact:1405187284109889647>'": 'bot_emoji.giveaway_react',
    "'<:jo1ntrX_member:1405208565500739607>'": 'bot_emoji.member',
    "'<:Jo1nTrX_antinuke:1438450620402237542>'": 'bot_emoji.antinuke',
    "'<:Jo1nTrX_automod:1439086767293861998>'": 'bot_emoji.automod',
    "'<:jo1ntrx_index:1405093893799677963>'": 'bot_emoji.index',
    "'<:jo1ntrx_invite:1405093146358190233>'": 'bot_emoji.invite',
    "'<:jo1ntrx_utility:1405096322872246323>'": 'bot_emoji.utility',
    "'<:jo1ntrx_moderation:1405093582863339591>'": 'bot_emoji.moderation',
    "'<:Jo1nTrX_channels:1420433174949003294>'": 'bot_emoji.channels',
    "'<:Jo1nTrX_welcome:1408686831415066715>'": 'bot_emoji.welcome',
    "'<:Jo1nTrX_message:1411471191834890354>'": 'bot_emoji.message',
    "'<:jo1ntrx_vanity:1406543809969389669>'": 'bot_emoji.vanity',
    "'<:Jo1nTrX_custom_role:1414269165241372712>'": 'bot_emoji.custom_role',
    "'<:Jo1nTrX_embed:1410862725751509083>'": 'bot_emoji.embed',
    "'<:Jo1nTrX_autoaction:1410988700799598602>'": 'bot_emoji.autoaction',
    "'<:Jo1nTrX_Currency:1416791338879553690>'": 'bot_emoji.currency',
    "'<:Jo1nTrX_ticket:1412649169801187429>'": 'bot_emoji.ticket',
    "'<:Jo1nTrX_fun:1423584274648399873>'": 'bot_emoji.fun',
    "'<:Jo1nTrX_misc:1422793178746060812>'": 'bot_emoji.misc',
    "'<:Jo1nTrX_logs:1430762798606061621>'": 'bot_emoji.logs',
    "'<:jo1ntrx_support:1405178991786201219>'": 'bot_emoji.support',
    "'<:Jo1nTrX_lock_1:1412701461749563463>'": 'bot_emoji.lock',
    "'<a:Jo1nTrX_Dotz:1415025958251003994>'": 'bot_emoji.dots',
    "'<:Jo1nTrX_arrow2:1415026780783247420>'": 'bot_emoji.arrow',
}

FILES_TO_MIGRATE = [
    "antinuke/antinuke_commands.py",
    "antinuke/beastmode_commands.py",
    "automod/automod_commands.py",
    "admin/utility.py",
    "admin_commands.py",
    "misc_command.py",
    "giveaway.py",
]

def has_component_import(content):
    return "from Jo1nTrX.utils.component import" in content

def add_component_import(content):
    if has_component_import(content):
        return content
    
    lines = content.split('\n')
    insert_idx = 0
    
    for i, line in enumerate(lines):
        if line.startswith('import ') or line.startswith('from '):
            insert_idx = i + 1
        elif line.strip() and not line.startswith('#') and insert_idx > 0:
            break
    
    lines.insert(insert_idx, COMPONENT_IMPORT)
    return '\n'.join(lines)

def replace_create_embed(content):
    content = re.sub(r'\bcreate_embed\s*\(', 'EmbedFactory.create(', content)
    return content

def replace_class_inheritance(content):
    content = re.sub(r'class\s+(\w+)\s*\(\s*discord\.ui\.View\s*\)', r'class \1(BaseView)', content)
    content = re.sub(r'class\s+(\w+)\s*\(\s*discord\.ui\.Select\s*\)', r'class \1(BaseSelect)', content)
    content = re.sub(r'class\s+(\w+)\s*\(\s*discord\.ui\.Button\s*\)', r'class \1(BaseButton)', content)
    return content

def replace_emojis(content):
    for old_emoji, new_emoji in EMOJI_REPLACEMENTS.items():
        if old_emoji in content:
            if old_emoji.startswith('"') or old_emoji.startswith("'"):
                content = content.replace(old_emoji, new_emoji)
    return content

def replace_emoji_in_fstrings(content):
    for old_emoji, new_emoji in EMOJI_REPLACEMENTS.items():
        bare_emoji = old_emoji[1:-1]
        pattern = re.escape(bare_emoji)
        content = re.sub(rf'(["\']){pattern}', rf'{new_emoji} + \1', content)
    return content

def update_super_init(content):
    content = re.sub(
        r'super\(\).__init__\(timeout=(\d+)\)',
        r'super().__init__(timeout=\1, author=None)',
        content
    )
    return content

def migrate_file(filepath):
    print(f"Migrating: {filepath}")
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original = content
    
    content = add_component_import(content)
    content = replace_create_embed(content)
    content = replace_class_inheritance(content)
    content = replace_emojis(content)
    content = update_super_init(content)
    
    if content != original:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"  Updated: {filepath}")
        return True
    else:
        print(f"  No changes needed: {filepath}")
        return False

def find_files_with_create_embed():
    files = []
    for root, dirs, filenames in os.walk(COGS_DIR):
        dirs[:] = [d for d in dirs if d != '__pycache__']
        for filename in filenames:
            if filename.endswith('.py'):
                filepath = os.path.join(root, filename)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                if 'create_embed(' in content or 'discord.ui.View' in content or 'discord.ui.Select' in content:
                    files.append(filepath)
    return files

def main():
    print("=" * 60)
    print("Bot Component Migration Script")
    print("=" * 60)
    print()
    
    files = find_files_with_create_embed()
    
    print(f"Found {len(files)} files that may need migration:")
    for f in files:
        print(f"  - {f}")
    print()
    
    migrated = 0
    for filepath in files:
        if migrate_file(filepath):
            migrated += 1
    
    print()
    print("=" * 60)
    print(f"Migration complete! Updated {migrated} files.")
    print("=" * 60)

if __name__ == "__main__":
    main()
