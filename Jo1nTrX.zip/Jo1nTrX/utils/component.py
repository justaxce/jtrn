import discord
from discord import ui
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Callable, Any, Union
import math
import uuid
import json
import os


class BotEmoji:
    def __init__(self):
        self._load_emojis()
    
    def _load_emojis(self):
        try:
            emoji_path = os.path.join(os.path.dirname(__file__), '..', 'core', 'emojis.json')
            with open(emoji_path, 'r') as f:
                emoji_data = json.load(f)
            
            for category, emojis in emoji_data.items():
                for name, value in emojis.items():
                    setattr(self, name, value)
        except Exception as e:
            print(f"Error loading emojis from JSON: {e}")
    
    arrow = "<a:purple_dot_Jo1nTrX:1435911247630700605>"
    tick = "<:jo1ntrx_tick:1405094860398194720>"
    cross = "<:jo1ntrx_cross:1405094904568483880>"
    loading = "<a:Jo1nTrX_loading:1405188056067067966>"
    left = "<:jo1ntrx_left:1405095378231099464>"
    right = "<:jo1ntrx_right:1405095312456024127>"
    double_left = "<:jo1ntrx_doubleleft:1405095487710691449>"
    double_right = "<:jo1ntrx_doubleright:1405095454395465790>"
    delete = "<:jo1ntrx_delete:1405095625795702895>"
    giveaway = "<:Jo1nTrX_giveaway:1411471234922971298>"
    giveaway_react = "<:jo1ntrX_giveawayreact:1405187284109889647>"
    member = "<:jo1ntrX_member:1405208565500739607>"
    antinuke = "<:Jo1nTrX_antinuke:1438450620402237542>"
    automod = "<:Jo1nTrX_automod:1439086767293861998>"
    index = "<:jo1ntrx_index:1405093893799677963>"
    invite = "<:jo1ntrx_invite:1405093146358190233>"
    utility = "<:jo1ntrx_utility:1405096322872246323>"
    moderation = "<:jo1ntrx_moderation:1405093582863339591>"
    channels = "<:Jo1nTrX_channels:1420433174949003294>"
    welcome = "<:Jo1nTrX_welcome:1408686831415066715>"
    message = "<:Jo1nTrX_message:1411471191834890354>"
    vanity = "<:jo1ntrx_vanity:1406543809969389669>"
    custom_role = "<:Jo1nTrX_custom_role:1414269165241372712>"
    embed = "<:Jo1nTrX_embed:1410862725751509083>"
    autoaction = "<:Jo1nTrX_autoaction:1410988700799598602>"
    currency = "<:Jo1nTrX_Currency:1416791338879553690>"
    ticket = "<:Jo1nTrX_ticket:1412649169801187429>"
    fun = "<:Jo1nTrX_fun:1423584274648399873>"
    misc = "<:Jo1nTrX_misc:1422793178746060812>"
    logs = "<:Jo1nTrX_logs:1430762798606061621>"
    support = "<:jo1ntrx_support:1405178991786201219>"
    lock = "<:Jo1nTrX_lock_1:1412701461749563463>"
    dots = "<a:Jo1nTrX_Dotz:1415025958251003994>"


bot_emoji = BotEmoji()


class LayoutViewFactory:
    @staticmethod
    def get_ist_time():
        ist_timezone = timezone(timedelta(hours=5, minutes=30))
        ist_time = datetime.now(ist_timezone)
        time_12hr = ist_time.strftime("%I:%M %p").lower()
        if time_12hr.startswith('0'):
            time_12hr = time_12hr[1:]
        return time_12hr

    @classmethod
    def create(cls, title: Optional[str] = None, description: Optional[str] = None, 
               timestamp: bool = True, user: Optional[discord.User] = None, timeout: int = 300) -> ui.LayoutView:
        parts = []
        if title:
            parts.append(f"## {title}")
        if description:
            parts.append(description)
        if timestamp:
            time_str = cls.get_ist_time()
            footer = f"Executed by {user.name} | {time_str}" if user else f"Executed by Bot | {time_str}"
            parts.append(f"\n> {footer}")
        
        content = "\n\n".join(parts) if parts else ""
        view = ui.LayoutView(timeout=timeout)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        return view

    @classmethod
    def error(cls, message: str, title: Optional[str] = None, user: Optional[discord.User] = None) -> ui.LayoutView:
        if title is None:
            title = f"{bot_emoji.cross} Error"
        return cls.create(title=title, description=message, user=user)

    @classmethod
    def success(cls, message: str, title: Optional[str] = None, user: Optional[discord.User] = None) -> ui.LayoutView:
        if title is None:
            title = f"{bot_emoji.tick} Success"
        return cls.create(title=title, description=message, user=user)

    @classmethod
    def warning(cls, message: str, title: Optional[str] = None, user: Optional[discord.User] = None) -> ui.LayoutView:
        if title is None:
            title = f"{bot_emoji.cross} Warning"
        return cls.create(title=title, description=message, user=user)

    @classmethod
    def info(cls, message: str, title: Optional[str] = None, user: Optional[discord.User] = None) -> ui.LayoutView:
        if title is None:
            title = f"{bot_emoji.loading} Information"
        return cls.create(title=title, description=message, user=user)

    @classmethod
    def format_guidance(cls, command_name: str, correct_format: str, description: Optional[str] = None) -> ui.LayoutView:
        title = f"{bot_emoji.cross} Incorrect Command Format"
        message = f"**Command:** `{command_name}`\n**Correct Format:** `{correct_format}`"
        if description:
            message += f"\n**Description:** {description}"
        message += f"\n\n{bot_emoji.loading} **Tip:** Use comma `, ` to separate multiple values where applicable!"
        return cls.create(title=title, description=message)


class EmbedFactory:
    DEFAULT_COLOR = 0x7c28eb
    ERROR_COLOR = 0xff0000
    SUCCESS_COLOR = 0x00ff00
    WARNING_COLOR = 0xffff00
    INFO_COLOR = 0x3498db
    ENDED_COLOR = 0x808080
    PAUSED_COLOR = 0xffaa00
    
    @staticmethod
    def get_ist_time():
        ist_timezone = timezone(timedelta(hours=5, minutes=30))
        ist_time = datetime.now(ist_timezone)
        time_12hr = ist_time.strftime("%I:%M %p").lower()
        if time_12hr.startswith('0'):
            time_12hr = time_12hr[1:]
        return time_12hr
    
    @classmethod
    def create(cls, title: Optional[str] = None, description: Optional[str] = None, color: Optional[int] = None, 
               timestamp: bool = True, user: Optional[discord.User] = None) -> discord.Embed:
        if color is None:
            color = cls.DEFAULT_COLOR
        embed = discord.Embed(title=title, description=description, color=color)
        if timestamp:
            time_str = cls.get_ist_time()
            if user:
                embed.set_footer(text=f"Executed by {user.name} | {time_str}")
            else:
                embed.set_footer(text=f"Executed by Bot | {time_str}")
        return embed
    
    @classmethod
    def error(cls, message: str, title: Optional[str] = None, user: Optional[discord.User] = None) -> discord.Embed:
        if title is None:
            title = f"{bot_emoji.cross} Error"
        return cls.create(title=title, description=message, color=cls.ERROR_COLOR, user=user)
    
    @classmethod
    def success(cls, message: str, title: Optional[str] = None, user: Optional[discord.User] = None) -> discord.Embed:
        if title is None:
            title = f"{bot_emoji.tick} Success"
        return cls.create(title=title, description=message, color=cls.SUCCESS_COLOR, user=user)
    
    @classmethod
    def warning(cls, message: str, title: Optional[str] = None, user: Optional[discord.User] = None) -> discord.Embed:
        if title is None:
            title = f"{bot_emoji.cross} Warning"
        return cls.create(title=title, description=message, color=cls.WARNING_COLOR, user=user)
    
    @classmethod
    def info(cls, message: str, title: Optional[str] = None, user: Optional[discord.User] = None) -> discord.Embed:
        if title is None:
            title = f"{bot_emoji.loading} Information"
        return cls.create(title=title, description=message, color=cls.INFO_COLOR, user=user)
    
    @classmethod
    def format_guidance(cls, command_name: str, correct_format: str, description: Optional[str] = None) -> discord.Embed:
        title = f"{bot_emoji.cross} Incorrect Command Format"
        message = f"**Command:** `{command_name}`\n**Correct Format:** `{correct_format}`"
        if description:
            message += f"\n**Description:** {description}"
        message += f"\n\n{bot_emoji.loading} **Tip:** Use comma `, ` to separate multiple values where applicable!"
        return cls.create(title=title, description=message, color=0xff6b6b)


    @classmethod
    def antinuke_log(cls, guild, user, action, target, extra_info=None):
        embed = discord.Embed(
            title="🛡️ Anti-Nuke Action Taken",
            color=0xff0000,
            timestamp=datetime.now(timezone.utc)
        )
        embed.add_field(name="User", value=f"{user.mention} ({user.id})", inline=False)
        embed.add_field(name="Action", value=action, inline=True)
        embed.add_field(name="Target", value=target, inline=True)
        if extra_info:
            embed.add_field(name="Additional Info", value=extra_info, inline=False)
        embed.set_footer(text=f"Server: {guild.name}")
        return embed
    
    @classmethod
    def antinuke_logs_comp_v2(cls, action, user, target, status="Success", extra=None, response_time=None):
        """Standardized AntiNuke Log Component V2"""
        color = 0x2ecc71 if status == "Success" else 0xe74c3c
        emoji_status = bot_emoji.tick if status == "Success" else bot_emoji.cross
        
        embed = discord.Embed(
            title=f"{bot_emoji.antinuke} Anti-Nuke Security Alert",
            color=color,
            timestamp=datetime.now(timezone.utc)
        )
        
        arrow = "<:arw1_Jo1nTrX:1447806399697518593>"
        description = [
            f"{arrow} **Action:** {action}",
            f"{arrow} **User:** {user.mention} (`{user.id}`)",
            f"{arrow} **Target:** {target}",
            f"{arrow} **Status:** {emoji_status} {status}"
        ]
        
        if extra:
            description.append(f"{arrow} **Details:** {extra}")
        
        if response_time:
            description.append(f"{arrow} **Response Time:** {response_time}")
            
        embed.description = "\n".join(description)
        return embed


def create_antinuke_log_view(guild, event_type, executor, target, action_taken, response_time):
    """Standardized view for Anti-Nuke logs"""
    embed = EmbedFactory.antinuke_logs_comp_v2(
        action=event_type,
        user=executor,
        target=target.name if hasattr(target, 'name') else str(target),
        status="Success" if action_taken else "Failed",
        response_time=response_time
    )
    
    view = ui.View(timeout=None)
    return view, embed

class BaseButton(ui.Button):
    def __init__(self, label: Optional[str] = None, style: discord.ButtonStyle = discord.ButtonStyle.secondary,
                 emoji: Optional[str] = None, custom_id: Optional[str] = None, disabled: bool = False, row: Optional[int] = None):
        super().__init__(label=label, style=style, emoji=emoji, custom_id=custom_id, disabled=disabled, row=row)
    
    async def callback(self, interaction: discord.Interaction):
        pass


class ConfirmButton(BaseButton):
    def __init__(self, label: str = "Confirm", emoji: str = "✅", style: discord.ButtonStyle = discord.ButtonStyle.blurple):
        super().__init__(label=label, emoji=emoji, style=style)
    
    async def callback(self, interaction: discord.Interaction):
        if hasattr(self.view, 'on_confirm'):
            await self.view.on_confirm(interaction)  # type: ignore


class CancelButton(BaseButton):
    def __init__(self, label: str = "Cancel", emoji: str = "❌", style: discord.ButtonStyle = discord.ButtonStyle.red):
        super().__init__(label=label, emoji=emoji, style=style)
    
    async def callback(self, interaction: discord.Interaction):
        if hasattr(self.view, 'on_cancel'):
            await self.view.on_cancel(interaction)  # type: ignore


class DeleteButton(BaseButton):
    def __init__(self, label: Optional[str] = None, emoji: Optional[str] = None, style: discord.ButtonStyle = discord.ButtonStyle.red, row: int = 0):
        if emoji is None:
            emoji = bot_emoji.delete
        super().__init__(label=label, emoji=emoji, style=style, row=row)
    
    async def callback(self, interaction: discord.Interaction):
        if hasattr(self.view, 'on_delete'):
            await self.view.on_delete(interaction)  # type: ignore
        else:
            await interaction.response.edit_message(content="Message deleted.", embed=None, view=None)


class PaginationButton(BaseButton):
    def __init__(self, action: str, emoji: Optional[str] = None, style: discord.ButtonStyle = discord.ButtonStyle.gray, row: int = 0):
        self.action = action
        if emoji is None:
            emoji_map = {
                'first': bot_emoji.double_left,
                'previous': bot_emoji.left,
                'next': bot_emoji.right,
                'last': bot_emoji.double_right,
                'delete': bot_emoji.delete
            }
            emoji = emoji_map.get(action, "▶️")
        if action == 'delete':
            style = discord.ButtonStyle.red
        super().__init__(emoji=emoji, style=style, row=row)
    
    async def callback(self, interaction: discord.Interaction):
        if hasattr(self.view, 'handle_pagination'):
            await self.view.handle_pagination(interaction, self.action)  # type: ignore


class BaseSelect(ui.Select):
    def __init__(self, placeholder: str = "Select an option...", options: Optional[List[discord.SelectOption]] = None,
                 min_values: int = 1, max_values: int = 1, custom_id: Optional[str] = None, row: Optional[int] = None):
        if options is None:
            options = []
        if custom_id is None:
            custom_id = str(uuid.uuid4())
        super().__init__(placeholder=placeholder, options=options, min_values=min_values, 
                         max_values=max_values, custom_id=custom_id, row=row)
    
    async def callback(self, interaction: discord.Interaction):
        pass


class BaseView(ui.View):
    def __init__(self, timeout: int = 180, author: Optional[discord.User] = None):
        super().__init__(timeout=timeout)
        self.author = author
        self.message: Optional[discord.Message] = None
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if self.author and interaction.user.id != self.author.id:
            await interaction.response.send_message("You cannot use this menu!", ephemeral=True)
            return False
        return True
    
    async def on_timeout(self):
        for item in self.children:
            if hasattr(item, 'disabled'):
                item.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except:
                pass
    
    def disable_all(self) -> None:
        for item in self.children:
            if hasattr(item, 'disabled'):
                item.disabled = True  # type: ignore


class ConfirmationView(BaseView):
    def __init__(self, author: Optional[discord.User] = None, timeout: int = 60):
        super().__init__(timeout=timeout, author=author)
        self.value = None
        self.add_item(ConfirmButton())
        self.add_item(CancelButton())
    
    async def on_confirm(self, interaction: discord.Interaction):
        self.value = True
        self.disable_all()
        await interaction.response.edit_message(view=self)
        self.stop()
    
    async def on_cancel(self, interaction: discord.Interaction):
        self.value = False
        self.disable_all()
        await interaction.response.edit_message(view=self)
        self.stop()


class PaginationView(BaseView):
    def __init__(self, pages: List[discord.Embed], author: Optional[discord.User] = None, timeout: int = 300):
        super().__init__(timeout=timeout, author=author)
        self.pages = pages
        self.current_page = 0
        self.total_pages = len(pages)
        
        self.first_btn = PaginationButton('first')
        self.prev_btn = PaginationButton('previous')
        self.delete_btn = PaginationButton('delete')
        self.next_btn = PaginationButton('next')
        self.last_btn = PaginationButton('last')
        
        self.add_item(self.first_btn)
        self.add_item(self.prev_btn)
        self.add_item(self.delete_btn)
        self.add_item(self.next_btn)
        self.add_item(self.last_btn)
        
        self.update_button_states()
    
    def update_button_states(self):
        self.first_btn.disabled = self.current_page == 0
        self.prev_btn.disabled = self.current_page == 0
        self.next_btn.disabled = self.current_page >= self.total_pages - 1
        self.last_btn.disabled = self.current_page >= self.total_pages - 1
    
    async def handle_pagination(self, interaction: discord.Interaction, action: str):
        if action == 'first':
            self.current_page = 0
        elif action == 'previous':
            self.current_page = max(0, self.current_page - 1)
        elif action == 'next':
            self.current_page = min(self.total_pages - 1, self.current_page + 1)
        elif action == 'last':
            self.current_page = self.total_pages - 1
        elif action == 'delete':
            await interaction.response.edit_message(content="Message deleted.", embed=None, view=None)
            return
        
        self.update_button_states()
        await interaction.response.edit_message(embed=self.pages[self.current_page], view=self)


class ItemPaginationView(BaseView):
    def __init__(self, items: List[Any], items_per_page: int = 10, author: Optional[discord.User] = None,
                 embed_title: str = "Items", embed_color: int = 0x7c28eb, 
                 format_item: Optional[Callable[[int, Any], str]] = None, timeout: int = 300):
        super().__init__(timeout=timeout, author=author)
        self.items = items
        self.items_per_page = items_per_page
        self.current_page = 0
        self.total_pages = max(1, math.ceil(len(items) / items_per_page))
        self.embed_title = embed_title
        self.embed_color = embed_color
        self.format_item = format_item or (lambda i, item: f"{i}. {item}")
        
        self.first_btn = PaginationButton('first')
        self.prev_btn = PaginationButton('previous')
        self.delete_btn = PaginationButton('delete')
        self.next_btn = PaginationButton('next')
        self.last_btn = PaginationButton('last')
        
        self.add_item(self.first_btn)
        self.add_item(self.prev_btn)
        self.add_item(self.delete_btn)
        self.add_item(self.next_btn)
        self.add_item(self.last_btn)
        
        self.update_button_states()
    
    def update_button_states(self):
        self.first_btn.disabled = self.current_page == 0
        self.prev_btn.disabled = self.current_page == 0
        self.next_btn.disabled = self.current_page >= self.total_pages - 1
        self.last_btn.disabled = self.current_page >= self.total_pages - 1
    
    def create_embed(self) -> discord.Embed:
        start = self.current_page * self.items_per_page
        end = start + self.items_per_page
        page_items = self.items[start:end]
        
        lines = []
        for i, item in enumerate(page_items, start + 1):
            lines.append(self.format_item(i, item))
        
        embed = EmbedFactory.create(
            title=self.embed_title,
            description="\n".join(lines) if lines else "No items found.",
            color=self.embed_color
        )
        embed.set_footer(text=f"Page {self.current_page + 1} of {self.total_pages} • Total: {len(self.items)}")
        return embed
    
    async def handle_pagination(self, interaction: discord.Interaction, action: str):
        if action == 'first':
            self.current_page = 0
        elif action == 'previous':
            self.current_page = max(0, self.current_page - 1)
        elif action == 'next':
            self.current_page = min(self.total_pages - 1, self.current_page + 1)
        elif action == 'last':
            self.current_page = self.total_pages - 1
        elif action == 'delete':
            await interaction.response.edit_message(content="Message deleted.", embed=None, view=None)
            return
        
        self.update_button_states()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)


class MenuSelect(BaseSelect):
    def __init__(self, options: List[dict], placeholder: str = "Choose a category...", callback_handler: Optional[Callable] = None):
        select_options = []
        for opt in options:
            select_options.append(discord.SelectOption(
                label=opt.get('label', 'Option'),
                value=opt.get('value', 'option'),
                description=opt.get('description'),
                emoji=opt.get('emoji')
            ))
        super().__init__(placeholder=placeholder, options=select_options)
        self._callback_handler = callback_handler
    
    async def callback(self, interaction: discord.Interaction):
        if self._callback_handler:
            await self._callback_handler(interaction, self.values[0])  # type: ignore
        elif hasattr(self.view, 'on_select'):
            await self.view.on_select(interaction, self.values[0])  # type: ignore


class MenuView(BaseView):
    def __init__(self, menu_options: List[dict], embed_creators: Optional[dict] = None, 
                 default_embed: Optional[discord.Embed] = None, author: Optional[discord.User] = None, timeout: int = 300):
        super().__init__(timeout=timeout, author=author)
        self.embed_creators = embed_creators or {}
        self.default_embed = default_embed
        
        self.select = MenuSelect(options=menu_options, callback_handler=self._handle_selection)
        self.add_item(self.select)
    
    async def _handle_selection(self, interaction: discord.Interaction, value: str):
        if value in self.embed_creators:
            embed = self.embed_creators[value](interaction.user)  # type: ignore
            await interaction.response.edit_message(embed=embed, view=self)
        elif hasattr(self, 'on_select'):
            await self.on_select(interaction, value)  # type: ignore
        else:
            await interaction.response.defer()


class MultiSelectView(BaseView):
    def __init__(self, options: List[discord.SelectOption], author: Optional[discord.User] = None, 
                 placeholder: str = "Select options...", min_values: int = 1, max_values: Optional[int] = None,
                 confirm_label: str = "Confirm", timeout: int = 180):
        super().__init__(timeout=timeout, author=author)
        self.selected_values = []
        self.confirmed = False
        
        if max_values is None:
            max_values = len(options)
        
        select = BaseSelect(placeholder=placeholder, options=options, min_values=min_values, max_values=max_values)
        select.callback = self._on_select
        self.add_item(select)
        
        confirm_btn = ConfirmButton(label=confirm_label)
        confirm_btn.disabled = True
        self.confirm_button = confirm_btn
        self.add_item(confirm_btn)
    
    async def _on_select(self, interaction: discord.Interaction):
        self.selected_values = self.children[0].values  # type: ignore
        self.confirm_button.disabled = len(self.selected_values) == 0
        await interaction.response.edit_message(view=self)
    
    async def on_confirm(self, interaction: discord.Interaction):
        self.confirmed = True
        self.disable_all()
        await interaction.response.edit_message(view=self)
        self.stop()


class ModuleSelectView(BaseView):  # type: ignore
    ANTINUKE_MODULES = [
        {"label": "Anti Ban", "value": "ban", "description": "Whitelist from ban module"},
        {"label": "Anti Kick", "value": "kick", "description": "Whitelist from kick module"},
        {"label": "Anti Channel Create", "value": "chcr", "description": "Whitelist from channel create"},
        {"label": "Anti Channel Delete", "value": "chdl", "description": "Whitelist from channel delete"},
        {"label": "Anti Channel Update", "value": "chup", "description": "Whitelist from channel update"},
        {"label": "Anti Role Create", "value": "rlcr", "description": "Whitelist from role create"},
        {"label": "Anti Role Delete", "value": "rldl", "description": "Whitelist from role delete"},
        {"label": "Anti Role Update", "value": "rlup", "description": "Whitelist from role update"},
        {"label": "Anti Bot Add", "value": "botadd", "description": "Whitelist from bot add"},
        {"label": "Anti Webhook Create", "value": "mngweb", "description": "Whitelist from webhook management"},
        {"label": "Anti Guild Update", "value": "serverup", "description": "Whitelist from server update"},
        {"label": "Anti Everyone Mention", "value": "meneve", "description": "Whitelist from everyone mention"},
        {"label": "Anti Member Prune", "value": "prune", "description": "Whitelist from member prune"},
        {"label": "Anti Emoji Create", "value": "emcr", "description": "Whitelist from emoji create"},
        {"label": "Anti Emoji Delete", "value": "emdl", "description": "Whitelist from emoji delete"},
    ]
    
    MODULE_NAMES = {
        "ban": "Anti Ban", "kick": "Anti Kick", "chcr": "Anti Channel Create",
        "chdl": "Anti Channel Delete", "chup": "Anti Channel Update",
        "rlcr": "Anti Role Create", "rldl": "Anti Role Delete", "rlup": "Anti Role Update",
        "botadd": "Anti Bot Add", "mngweb": "Anti Webhook Create",
        "serverup": "Anti Guild Update", "meneve": "Anti Everyone Mention",
        "prune": "Anti Member Prune", "emcr": "Anti Emoji Create", "emdl": "Anti Emoji Delete"
    }
    
    def __init__(self, ctx, entity, bot, current_permissions: Optional[dict] = None, mode: str = "add", timeout: int = 180):
        super().__init__(timeout=timeout, author=ctx.author)
        self.ctx = ctx
        self.entity = entity
        self.bot = bot
        self.mode = mode
        self.current_permissions = current_permissions or {}
        self.selected_modules = []
        
        if mode == "remove":
            self.selected_modules = [perm for perm, is_wl in current_permissions.items() if is_wl]  # type: ignore
        
        self._setup_components()
    
    def _get_arrow_emoji(self):
        try:
            arrow = self.bot.get_emoji(1415026780783247420)
            return arrow if arrow else "▶️"
        except:
            return "▶️"
    
    def _setup_components(self):
        arrow = self._get_arrow_emoji()
        options = []
        
        for mod in self.ANTINUKE_MODULES:
            opt = discord.SelectOption(
                label=mod["label"],
                value=mod["value"],
                description=mod["description"],
                emoji=arrow,
                default=self.current_permissions.get(mod["value"], False) if self.mode == "remove" else False
            )
            options.append(opt)
        
        placeholder = "Select modules to whitelist..." if self.mode == "add" else "Select modules to keep..."
        select = BaseSelect(placeholder=placeholder, options=options, min_values=1, max_values=len(options))
        select.callback = self._on_module_select
        self.add_item(select)
        
        if self.mode == "add":
            all_btn = BaseButton(label="Whitelist All Modules", style=discord.ButtonStyle.green, emoji="✅")
            all_btn.callback = self._whitelist_all  # type: ignore
            self.add_item(all_btn)
            
            confirm_btn = BaseButton(label="Confirm Whitelist", style=discord.ButtonStyle.blurple, emoji="✅", disabled=True)
        else:
            all_btn = BaseButton(label="Remove From All Modules", style=discord.ButtonStyle.red, emoji="❌")
            all_btn.callback = self._remove_all  # type: ignore
            self.add_item(all_btn)
            
            confirm_btn = BaseButton(label="Confirm Removal", style=discord.ButtonStyle.blurple, emoji="✅")
        
        confirm_btn.callback = self._confirm_action  # type: ignore
        self.confirm_button = confirm_btn
        self.add_item(confirm_btn)
    
    async def _on_module_select(self, interaction: discord.Interaction):
        self.selected_modules = self.children[0].values  # type: ignore
        self.confirm_button.disabled = len(self.selected_modules) == 0
        
        selected_names = [self.MODULE_NAMES.get(m, m) for m in self.selected_modules]
        entity_type = "Role" if isinstance(self.entity, discord.Role) else "User"
        
        if self.mode == "add":
            embed = discord.Embed(
                title=f"{bot_emoji.antinuke} Whitelist Configuration",
                description=f"**{entity_type}:** {self.entity.mention}\n\n"
                           f"**Selected Modules ({len(selected_names)}):**\n"
                           + ("\n".join([f"• {name}" for name in selected_names]) if selected_names else "None") +
                           "\n\n**Click 'Confirm Whitelist' to save.**",
                color=0x7c28eb
            )
        else:
            embed = discord.Embed(
                title=f"{bot_emoji.antinuke} Whitelist Removal Configuration",
                description=f"**{entity_type}:** {self.entity.mention}\n\n"
                           f"**Selected to Keep ({len(selected_names)}):**\n"
                           + ("\n".join([f"• {name}" for name in selected_names]) if selected_names else "None - Will be removed from all modules") +
                           "\n\n**Click 'Confirm Removal' to save changes.**",
                color=0x7c28eb
            )
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def _whitelist_all(self, interaction: discord.Interaction):
        self.selected_modules = [mod["value"] for mod in self.ANTINUKE_MODULES]
        self.confirm_button.disabled = False
        
        entity_type = "Role" if isinstance(self.entity, discord.Role) else "User"
        embed = discord.Embed(
            title=f"{bot_emoji.antinuke} Whitelist Configuration",
            description=f"**{entity_type}:** {self.entity.mention}\n\n"
                       f"**All modules selected ({len(self.selected_modules)})**\n\n"
                       "Click 'Confirm Whitelist' to save.",
            color=0x7c28eb
        )
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def _remove_all(self, interaction: discord.Interaction):
        self.selected_modules = []
        entity_type = "Role" if isinstance(self.entity, discord.Role) else "User"
        embed = discord.Embed(
            title=f"{bot_emoji.antinuke} Whitelist Removal",
            description=f"**{entity_type}:** {self.entity.mention}\n\n"
                       "**Removing from all modules...**",
            color=0x7c28eb
        )
        await interaction.response.edit_message(embed=embed, view=self)
        
        if hasattr(self, 'on_remove_all'):
            await self.on_remove_all(interaction)
    
    async def _confirm_action(self, interaction: discord.Interaction):
        self.disable_all()
        await interaction.response.edit_message(view=self)
        
        if hasattr(self, 'on_confirm'):
            await self.on_confirm(interaction, self.selected_modules)
        self.stop()


class GiveawayJoinButton(BaseButton):
    def __init__(self, giveaway_id: int):
        super().__init__(
            label="Join",
            emoji=bot_emoji.giveaway_react,
            style=discord.ButtonStyle.green,
            custom_id=f"giveaway_join_{giveaway_id}"
        )
        self.giveaway_id = giveaway_id


class GiveawayParticipantsButton(BaseButton):
    def __init__(self, giveaway_id: int):
        super().__init__(
            label="Participants",
            emoji=bot_emoji.member,
            style=discord.ButtonStyle.secondary,
            custom_id=f"giveaway_participants_{giveaway_id}"
        )
        self.giveaway_id = giveaway_id


class GiveawayView(BaseView):
    def __init__(self, giveaway_id: int, bot, timeout: int = None):
        super().__init__(timeout=timeout)
        self.giveaway_id = giveaway_id
        self.bot = bot
        
        self.join_button = GiveawayJoinButton(giveaway_id)
        self.join_button.callback = self._join_giveaway
        self.add_item(self.join_button)
        
        self.participants_button = GiveawayParticipantsButton(giveaway_id)
        self.participants_button.callback = self._view_participants
        self.add_item(self.participants_button)
    
    async def _join_giveaway(self, interaction: discord.Interaction):
        if hasattr(self, 'on_join'):
            await self.on_join(interaction)
    
    async def _view_participants(self, interaction: discord.Interaction):
        if hasattr(self, 'on_view_participants'):
            await self.on_view_participants(interaction)


class HelpMenuOptions:
    OPTIONS = [
        {"label": "Index", "value": "index", "description": "Go back to the main help page", "emoji": bot_emoji.index},
        {"label": "Anti-Nuke", "value": "antinuke", "description": "Server protection and security system", "emoji": bot_emoji.antinuke},
        {"label": "Automod", "value": "automod", "description": "Automated moderation and content filtering", "emoji": bot_emoji.automod},
        {"label": "Invite Tracking", "value": "tracking", "description": "Commands for tracking and viewing invites", "emoji": bot_emoji.invite},
        {"label": "Utility", "value": "utility", "description": "Utility commands and tools", "emoji": bot_emoji.utility},
        {"label": "Moderation", "value": "moderation", "description": "Administrative and moderation commands", "emoji": bot_emoji.moderation},
        {"label": "Channels Management", "value": "channels", "description": "Channel & category related commands", "emoji": bot_emoji.channels},
        {"label": "Welcome", "value": "welcome", "description": "Welcome/leave channel and message configuration", "emoji": bot_emoji.welcome},
        {"label": "Message", "value": "message", "description": "Message tracking commands and leaderboards", "emoji": bot_emoji.message},
        {"label": "Giveaway", "value": "giveaway", "description": "Giveaway management and commands", "emoji": bot_emoji.giveaway},
        {"label": "Vanity Roles", "value": "vanity", "description": "Automatic role assignment based on user bio/status", "emoji": bot_emoji.vanity},
        {"label": "Custom Roles", "value": "custom_roles", "description": "Setup and manage custom role assignments", "emoji": bot_emoji.custom_role},
        {"label": "Embed Configuration", "value": "embed", "description": "Create and manage custom embeds", "emoji": bot_emoji.embed},
        {"label": "Auto Actions", "value": "auto_actions", "description": "Auto reactions and auto responses", "emoji": bot_emoji.autoaction},
        {"label": "Crypto 'n Currency", "value": "crypto", "description": "Currency exchange and calculator commands", "emoji": bot_emoji.currency},
        {"label": "Tickets", "value": "tickets", "description": "Create and manage support tickets", "emoji": bot_emoji.ticket},
        {"label": "Fun 'n Games", "value": "fun", "description": "Fun commands including confessions", "emoji": bot_emoji.fun},
        {"label": "Misc", "value": "misc", "description": "Different type of commands", "emoji": bot_emoji.misc},
        {"label": "Logging", "value": "logging", "description": "Server activity logging system", "emoji": bot_emoji.logs},
        {"label": "Contact", "value": "contact", "description": "Support and contact information", "emoji": bot_emoji.support},
    ]


class ActivityTypeSelect(BaseSelect):
    def __init__(self):
        options = [
            discord.SelectOption(label="Playing", value="playing", emoji="🎮"),
            discord.SelectOption(label="Watching", value="watching", emoji="👀"),
            discord.SelectOption(label="Listening", value="listening", emoji="🎵"),
            discord.SelectOption(label="Streaming", value="streaming", emoji="📺"),
            discord.SelectOption(label="Competing", value="competing", emoji="🏆"),
        ]
        super().__init__(placeholder="Select activity type...", options=options)


class AutomodModuleSelect(BaseSelect):
    MODULES = [
        {"label": "Anti Spam", "value": "antispam", "description": "Prevent message spam"},
        {"label": "Anti Links", "value": "antilinks", "description": "Block external links"},
        {"label": "Anti Invites", "value": "antiinvites", "description": "Block Discord invites"},
        {"label": "Anti Caps", "value": "anticaps", "description": "Prevent excessive caps"},
        {"label": "Anti Mention Spam", "value": "antimention", "description": "Prevent mention spam"},
        {"label": "Anti Emoji Spam", "value": "antiemoji", "description": "Prevent emoji spam"},
        {"label": "Anti Attachment Spam", "value": "antiattachment", "description": "Prevent attachment spam"},
    ]
    
    def __init__(self, bot=None):
        options = []
        for mod in self.MODULES:
            options.append(discord.SelectOption(
                label=mod["label"],
                value=mod["value"],
                description=mod["description"],
                emoji="⚙️"
            ))
        super().__init__(placeholder="Select automod module...", options=options)


class TicketCategorySelect(BaseSelect):
    def __init__(self, categories: List[dict], placeholder: str = "Select a category..."):
        options = []
        for cat in categories[:25]:
            options.append(discord.SelectOption(
                label=cat.get('name', 'Unknown'),
                value=str(cat.get('category_order', 0)),
                description=cat.get('description', ''),
                emoji=cat.get('emoji', '🎫')
            ))
        if not options:
            options.append(discord.SelectOption(label="No categories", value="none"))
        super().__init__(placeholder=placeholder, options=options)


class TicketActionView(BaseView):
    def __init__(self, ticket_channel_id: int, author: Optional[discord.User] = None, timeout: Optional[int] = None):
        super().__init__(timeout=timeout, author=author)
        self.ticket_channel_id = ticket_channel_id
        
        close_btn = BaseButton(label="Close Ticket", style=discord.ButtonStyle.red, emoji=bot_emoji.lock, 
                               custom_id=f"ticket_close_{ticket_channel_id}")
        close_btn.callback = self._close_ticket
        self.add_item(close_btn)
        
        claim_btn = BaseButton(label="Claim", style=discord.ButtonStyle.green, emoji="✋",
                               custom_id=f"ticket_claim_{ticket_channel_id}")
        claim_btn.callback = self._claim_ticket
        self.add_item(claim_btn)
    
    async def _close_ticket(self, interaction: discord.Interaction):
        if hasattr(self, 'on_close'):
            await self.on_close(interaction)  # type: ignore
    
    async def _claim_ticket(self, interaction: discord.Interaction):
        if hasattr(self, 'on_claim'):
            await self.on_claim(interaction)  # type: ignore


class ClosedTicketView(BaseView):
    def __init__(self, ticket_channel_id: int, timeout: Optional[int] = None):
        super().__init__(timeout=timeout)
        self.ticket_channel_id = ticket_channel_id
        
        reopen_btn = BaseButton(label="Reopen", style=discord.ButtonStyle.green, emoji="🔓",
                                custom_id=f"ticket_reopen_{ticket_channel_id}")
        reopen_btn.callback = self._reopen_ticket
        self.add_item(reopen_btn)
        
        delete_btn = BaseButton(label="Delete", style=discord.ButtonStyle.red, emoji="🗑️",
                                custom_id=f"ticket_delete_{ticket_channel_id}")
        delete_btn.callback = self._delete_ticket
        self.add_item(delete_btn)
        
        transcript_btn = BaseButton(label="Transcript", style=discord.ButtonStyle.secondary, emoji="📜",
                                    custom_id=f"ticket_transcript_{ticket_channel_id}")
        transcript_btn.callback = self._get_transcript
        self.add_item(transcript_btn)
    
    async def _reopen_ticket(self, interaction: discord.Interaction):
        if hasattr(self, 'on_reopen'):
            await self.on_reopen(interaction)  # type: ignore
    
    async def _delete_ticket(self, interaction: discord.Interaction):
        if hasattr(self, 'on_delete'):
            await self.on_delete(interaction)  # type: ignore
    
    async def _get_transcript(self, interaction: discord.Interaction):
        if hasattr(self, 'on_transcript'):
            await self.on_transcript(interaction)  # type: ignore


class ServerInfoView(BaseView):
    def __init__(self, guild: discord.Guild, author: Optional[discord.User] = None, timeout: int = 120):
        super().__init__(timeout=timeout, author=author)
        self.guild = guild
        self.current_page = "overview"
        
        self._setup_buttons()
    
    def _setup_buttons(self):
        overview_btn = BaseButton(label="Overview", style=discord.ButtonStyle.blurple, emoji="📊")
        overview_btn.callback = lambda i: self._switch_page(i, "overview")  # type: ignore
        self.add_item(overview_btn)
        
        members_btn = BaseButton(label="Members", style=discord.ButtonStyle.gray, emoji="👥")
        members_btn.callback = lambda i: self._switch_page(i, "members")  # type: ignore
        self.add_item(members_btn)
        
        roles_btn = BaseButton(label="Roles", style=discord.ButtonStyle.gray, emoji="🎭")
        roles_btn.callback = lambda i: self._switch_page(i, "roles")  # type: ignore
        self.add_item(roles_btn)
        
        channels_btn = BaseButton(label="Channels", style=discord.ButtonStyle.gray, emoji="📁")
        channels_btn.callback = lambda i: self._switch_page(i, "channels")  # type: ignore
        self.add_item(channels_btn)
    
    async def _switch_page(self, interaction: discord.Interaction, page: str):
        self.current_page = page
        if hasattr(self, 'get_embed'):
            embed = await self.get_embed(page)  # type: ignore
            await interaction.response.edit_message(embed=embed, view=self)


class ReactionRoleView(BaseView):
    def __init__(self, roles: List[dict], timeout: Optional[int] = None):
        super().__init__(timeout=timeout)
        
        for role_data in roles[:25]:
            btn = BaseButton(
                label=role_data.get('label', 'Role'),  # type: ignore
                style=role_data.get('style', discord.ButtonStyle.secondary),  # type: ignore
                emoji=role_data.get('emoji'),  # type: ignore
                custom_id=f"rr_{role_data.get('role_id')}"  # type: ignore
            )
            btn.callback = self._toggle_role  # type: ignore
            self.add_item(btn)
    
    async def _toggle_role(self, interaction: discord.Interaction):
        if hasattr(self, 'on_role_toggle'):
            role_id = int(interaction.data['custom_id'].split('_')[1])  # type: ignore
            await self.on_role_toggle(interaction, role_id)  # type: ignore


class PanelTypeSelect(BaseSelect):
    def __init__(self):
        options = [
            discord.SelectOption(label="Button Panel", value="button", description="Users click buttons to create tickets", emoji="🔘"),
            discord.SelectOption(label="Dropdown Panel", value="dropdown", description="Users select from dropdown menu", emoji="📋"),
        ]
        super().__init__(placeholder="Select panel type...", options=options)


class LogTypeSelect(BaseSelect):
    LOG_TYPES = [
        {"label": "Message Logs", "value": "message", "emoji": "💬"},
        {"label": "Member Logs", "value": "member", "emoji": "👤"},
        {"label": "Role Logs", "value": "role", "emoji": "🎭"},
        {"label": "Channel Logs", "value": "channel", "emoji": "📁"},
        {"label": "Server Logs", "value": "server", "emoji": "🏠"},
        {"label": "Voice Logs", "value": "voice", "emoji": "🔊"},
        {"label": "Moderation Logs", "value": "moderation", "emoji": "🔨"},
    ]
    
    def __init__(self):
        options = [discord.SelectOption(label=lt["label"], value=lt["value"], emoji=lt["emoji"]) for lt in self.LOG_TYPES]
        super().__init__(placeholder="Select log type...", options=options)


class BaseLayoutView(ui.LayoutView):
    DEFAULT_COLOR = 0x7c28eb
    
    def __init__(self, timeout: int = 180, author: Optional[discord.User] = None):
        super().__init__(timeout=timeout)
        self.author = author
        self._components = []
    
    def create_text(self, content: str) -> ui.TextDisplay:
        return ui.TextDisplay(content)
    
    def create_button(self, label: Optional[str] = None, style: discord.ButtonStyle = discord.ButtonStyle.secondary,
                      emoji: Optional[str] = None, url: Optional[str] = None, disabled: bool = False) -> ui.Button:
        return ui.Button(label=label, style=style, emoji=emoji, url=url, disabled=disabled)
    
    def create_action_row(self, *items) -> ui.ActionRow:
        return ui.ActionRow(*items)
    
    def build_container(self, *components, accent_color: Optional[int] = None) -> ui.Container:
        if accent_color is None:
            accent_color = self.DEFAULT_COLOR
        return ui.Container(*components, accent_color=accent_color)


class InfoLayoutView(BaseLayoutView):
    def __init__(self, title: str, description: str, fields: Optional[List[tuple]] = None, 
                 author: Optional[discord.User] = None, timeout: int = 180, accent_color: Optional[int] = None,
                 buttons: Optional[List[dict]] = None, show_delete: bool = True):
        super().__init__(timeout=timeout, author=author)
        self.title = title
        self.description = description
        self.fields = fields or []
        self.accent_color = accent_color or self.DEFAULT_COLOR
        self.buttons = buttons or []
        self.show_delete = show_delete
        self._setup_view()
    
    def _setup_view(self):
        dot = bot_emoji.arrow
        content_parts = [f"## {self.title}"]
        
        if self.description:
            content_parts.append(self.description)
        
        if self.fields:
            content_parts.append("")
            for name, value, inline in self.fields:
                content_parts.append(f"{dot} **{name}:** {value}")
        
        content = "\n".join(content_parts)
        text_display = self.create_text(content)
        
        components = [text_display]
        
        if self.buttons or self.show_delete:
            button_items = []
            for btn_data in self.buttons:
                btn = self.create_button(
                    label=btn_data.get('label'),  # type: ignore
                    style=btn_data.get('style', discord.ButtonStyle.secondary),  # type: ignore
                    emoji=btn_data.get('emoji'),  # type: ignore
                    url=btn_data.get('url'),  # type: ignore
                    disabled=btn_data.get('disabled', False)
                )
                button_items.append(btn)
            
            if self.show_delete:
                delete_btn = self.create_button(emoji=bot_emoji.delete, style=discord.ButtonStyle.red)
                button_items.append(delete_btn)
            
            if button_items:
                button_row = self.create_action_row(*button_items)
                components.append(button_row)  # type: ignore
        
        container = self.build_container(*components, accent_color=self.accent_color)
        self.add_item(container)


class SuccessLayoutView(BaseLayoutView):
    def __init__(self, message: str, title: Optional[str] = None, author: Optional[discord.User] = None, timeout: int = 60):
        super().__init__(timeout=timeout, author=author)
        self.message = message
        self.title = title or f"{bot_emoji.tick} Success"
        self._setup_view()
    
    def _setup_view(self):
        content = f"## {self.title}\n{self.message}"
        text_display = self.create_text(content)
        container = self.build_container(text_display, accent_color=0x00ff00)
        self.add_item(container)


class ErrorLayoutView(BaseLayoutView):
    def __init__(self, message: str, title: Optional[str] = None, author: Optional[discord.User] = None, timeout: int = 60):
        super().__init__(timeout=timeout, author=author)
        self.message = message
        self.title = title or f"{bot_emoji.cross} Error"
        self._setup_view()
    
    def _setup_view(self):
        content = f"## {self.title}\n{self.message}"
        text_display = self.create_text(content)
        container = self.build_container(text_display, accent_color=0xff0000)
        self.add_item(container)


class ConfirmLayoutView(BaseLayoutView):
    def __init__(self, message: str, title: Optional[str] = None, author: Optional[discord.User] = None, 
                 timeout: int = 60, confirm_label: str = "Confirm", cancel_label: str = "Cancel"):
        super().__init__(timeout=timeout, author=author)
        self.message = message
        self.title = title or f"{bot_emoji.loading} Confirmation Required"
        self.confirm_label = confirm_label
        self.cancel_label = cancel_label
        self.value = None
        self._setup_view()
    
    def _setup_view(self):
        content = f"## {self.title}\n{self.message}"
        text_display = self.create_text(content)
        
        confirm_btn = ui.Button(label=self.confirm_label, style=discord.ButtonStyle.green, custom_id="confirm_btn")
        cancel_btn = ui.Button(label=self.cancel_label, style=discord.ButtonStyle.red, custom_id="cancel_btn")
        
        @confirm_btn.callback
        async def confirm_callback(interaction: discord.Interaction) -> None:  # type: ignore
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)  # type: ignore
            self.value = True
            confirm_btn.disabled = True
            cancel_btn.disabled = True
            self.stop()
            await interaction.response.edit_message(view=self)  # type: ignore
        
        @cancel_btn.callback
        async def cancel_callback(interaction: discord.Interaction) -> None:  # type: ignore
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)  # type: ignore
            self.value = False
            confirm_btn.disabled = True
            cancel_btn.disabled = True
            self.stop()
            await interaction.response.edit_message(view=self)  # type: ignore
        
        button_row = self.create_action_row(confirm_btn, cancel_btn)
        container = self.build_container(text_display, button_row, accent_color=0x7c28eb)
        self.add_item(container)


class PaginatedLayoutView(BaseLayoutView):
    def __init__(self, pages: List[str], title: Optional[str] = None, author: Optional[discord.User] = None, 
                 timeout: int = 300, accent_color: Optional[int] = None):
        super().__init__(timeout=timeout, author=author)
        self.pages = pages
        self.title = title
        self.current_page = 0
        self.total_pages = len(pages)
        self.accent_color = accent_color or self.DEFAULT_COLOR
        self._setup_view()
    
    def _get_content(self) -> str:
        page_content = self.pages[self.current_page]
        if self.title:
            return f"## {self.title}\n{page_content}\n\n*Page {self.current_page + 1}/{self.total_pages}*"  # type: ignore
        return f"{page_content}\n\n*Page {self.current_page + 1}/{self.total_pages}*"
    
    def _setup_view(self):
        for item in list(self.children):
            self.remove_item(item)
        
        text_display = self.create_text(self._get_content())
        
        first_btn = ui.Button(emoji=bot_emoji.double_left, style=discord.ButtonStyle.gray, 
                              disabled=self.current_page == 0, custom_id="first_page")
        prev_btn = ui.Button(emoji=bot_emoji.left, style=discord.ButtonStyle.gray,
                             disabled=self.current_page == 0, custom_id="prev_page")
        delete_btn = ui.Button(emoji=bot_emoji.delete, style=discord.ButtonStyle.red, custom_id="delete_msg")
        next_btn = ui.Button(emoji=bot_emoji.right, style=discord.ButtonStyle.gray,
                             disabled=self.current_page >= self.total_pages - 1, custom_id="next_page")
        last_btn = ui.Button(emoji=bot_emoji.double_right, style=discord.ButtonStyle.gray,
                             disabled=self.current_page >= self.total_pages - 1, custom_id="last_page")
        
        @first_btn.callback
        async def first_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            self.current_page = 0
            self._setup_view()
            await interaction.response.edit_message(view=self)
        
        @prev_btn.callback
        async def prev_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            self.current_page = max(0, self.current_page - 1)
            self._setup_view()
            await interaction.response.edit_message(view=self)
        
        @delete_btn.callback
        async def delete_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            await interaction.response.edit_message(content="Message deleted.", view=None)
        
        @next_btn.callback
        async def next_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            self.current_page = min(self.total_pages - 1, self.current_page + 1)
            self._setup_view()
            await interaction.response.edit_message(view=self)
        
        @last_btn.callback
        async def last_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            self.current_page = self.total_pages - 1
            self._setup_view()
            await interaction.response.edit_message(view=self)
        
        button_row = self.create_action_row(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = self.build_container(text_display, button_row, accent_color=self.accent_color)
        self.add_item(container)


class MenuLayoutView(BaseLayoutView):
    def __init__(self, title: str, description: str, options: List[discord.SelectOption],
                 author: discord.User = None, timeout: int = 180, accent_color: int = None,
                 placeholder: str = "Select an option..."):
        super().__init__(timeout=timeout, author=author)
        self.title = title
        self.description = description
        self.options = options
        self.accent_color = accent_color or self.DEFAULT_COLOR
        self.placeholder = placeholder
        self.selected_value = None
        self._setup_view()
    
    def _setup_view(self):
        content = f"## {self.title}\n{self.description}"
        text_display = self.create_text(content)
        
        select = ui.Select(placeholder=self.placeholder, options=self.options, custom_id="menu_select")
        
        @select.callback
        async def select_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            self.selected_value = select.values[0]
            if hasattr(self, 'on_select'):
                await self.on_select(interaction, self.selected_value)
            else:
                await interaction.response.defer()
        
        select_row = self.create_action_row(select)
        
        delete_btn = ui.Button(emoji=bot_emoji.delete, style=discord.ButtonStyle.red, custom_id="delete_menu")
        
        @delete_btn.callback
        async def delete_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            await interaction.response.edit_message(content="Message deleted.", view=None)
        
        button_row = self.create_action_row(delete_btn)
        container = self.build_container(text_display, select_row, button_row, accent_color=self.accent_color)
        self.add_item(container)
