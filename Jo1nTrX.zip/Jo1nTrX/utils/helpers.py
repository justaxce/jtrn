from datetime import datetime, timezone, timedelta
import discord

def format_time_since(dt):
    """Format time since a datetime as year:month:day:hour:second"""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    
    now = datetime.now(timezone.utc)
    diff = now - dt
    
    # Calculate components
    years = diff.days // 365
    remaining_days = diff.days % 365
    months = remaining_days // 30
    days = remaining_days % 30
    hours = diff.seconds // 3600
    minutes = (diff.seconds % 3600) // 60
    seconds = diff.seconds % 60
    
    return f"{years}:{months}:{days}:{hours}:{seconds}"

def format_account_age(created_at):
    """Format account age in <year> y : <month> m : <days> d : <hour> h : <second> s format"""
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=timezone.utc)
    
    # Use IST timezone for current time
    ist_timezone = timezone(timedelta(hours=5, minutes=30))
    now = datetime.now(ist_timezone)
    diff = now - created_at
    
    # Calculate components
    years = diff.days // 365
    remaining_days = diff.days % 365
    months = remaining_days // 30
    days = remaining_days % 30
    hours = diff.seconds // 3600
    seconds = diff.seconds % 60
    
    return f"{years} y : {months} m : {days} d : {hours} h : {seconds} s"

def format_account_age_short(created_at):
    """Format account age in shorter format: <year> y : <month> m : <days> d"""
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=timezone.utc)
    
    # Use IST timezone for current time
    ist_timezone = timezone(timedelta(hours=5, minutes=30))
    now = datetime.now(ist_timezone)
    diff = now - created_at
    
    # Calculate components
    years = diff.days // 365
    remaining_days = diff.days % 365
    months = remaining_days // 30
    days = remaining_days % 30
    
    return f"{years} y : {months} m : {days} d"

def format_custom_datetime(dt):
    """Format datetime in custom format: <day>, <month> <date> <year> | <time in 12-hour format>
    Example: Mon, Jan 15 2024 | 1:16 pm"""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    
    # Convert to IST timezone
    ist_timezone = timezone(timedelta(hours=5, minutes=30))
    dt = dt.astimezone(ist_timezone)
    
    # Format the day abbreviation
    day_abbr = dt.strftime("%a")  # Mon, Tue, Wed, Thu, Fri, Sat, Sun
    
    # Format month abbreviation and date/year
    month_abbr = dt.strftime("%b")  # Jan, Feb, Mar, etc.
    date = dt.strftime("%d").lstrip('0')  # Remove leading zero from date
    year = dt.strftime("%Y")
    
    # Format time in 12-hour format
    time_12hr = dt.strftime("%I:%M %p").lower()  # 1:16 pm, 12:01 am
    # Remove leading zero from hour if present
    if time_12hr.startswith('0'):
        time_12hr = time_12hr[1:]
    
    return f"{day_abbr}, {month_abbr} {date} {year} | {time_12hr}"

def format_duration(seconds):
    """Format seconds into a human-readable duration"""
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        minutes = seconds // 60
        remaining_seconds = seconds % 60
        return f"{minutes}m {remaining_seconds}s"
    elif seconds < 86400:
        hours = seconds // 3600
        remaining_minutes = (seconds % 3600) // 60
        return f"{hours}h {remaining_minutes}m"
    else:
        days = seconds // 86400
        remaining_hours = (seconds % 86400) // 3600
        return f"{days}d {remaining_hours}h"

def is_fake_invite(member):
    """Check if a member's invite should be considered fake (account age < 7 days)"""
    if not member or not hasattr(member, 'created_at'):
        return False
    
    # Use IST timezone for current time
    ist_timezone = timezone(timedelta(hours=5, minutes=30))
    now = datetime.now(ist_timezone)
    created_at = member.created_at.replace(tzinfo=timezone.utc)
    account_age = now - created_at
    return account_age < timedelta(days=7)

def get_member_status_emoji(member):
    """Get emoji representing a member's status"""
    if isinstance(member, discord.Member):
        status_emojis = {
            discord.Status.online: "<:Jo1nTrX_On01:1415540440014520330>",
            discord.Status.idle: "<:Jo1nTrX_idle:1415540481953370236>",
            discord.Status.dnd: "<:Jo1nTrX_dnd01:1415540445856927876>",
            discord.Status.offline: "<:Jo1nTrX_off01:1415540488307605604>"
        }
        return status_emojis.get(member.status, "<:Jo1nTrX_off01:1415540488307605604>")
    return "<:Jo1nTrX_off01:1415540488307605604>"

def truncate_text(text, max_length=2000):
    """Truncate text to fit Discord's character limits"""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."

def format_number(number):
    """Format large numbers with appropriate suffixes"""
    if number >= 1000000:
        return f"{number/1000000:.1f}M"
    elif number >= 1000:
        return f"{number/1000:.1f}K"
    else:
        return str(number)

def is_valid_invite_code(code):
    """Check if a string looks like a valid Discord invite code"""
    if not code:
        return False
    
    # Remove common prefixes
    code = code.replace("discord.gg/", "").replace("discord.com/invite/", "")
    
    # Check if it's alphanumeric and reasonable length
    return code.isalnum() and 2 <= len(code) <= 32

def get_permissions_list(permissions):
    """Convert Discord permissions to a readable list"""
    if permissions.administrator:
        return ["Administrator (All Permissions)"]
    
    perm_names = []
    for perm, value in permissions:
        if value:
            # Convert permission name to title case
            readable_name = perm.replace('_', ' ').title()
            perm_names.append(readable_name)
    
    return perm_names if perm_names else ["No Permissions"]

import asyncio
import re

def parse_time(time_str):
    """Parse time string into seconds (e.g., '1h30m', '2d', '45m')"""
    if not time_str:
        return None
    
    # Remove spaces and convert to lowercase
    time_str = time_str.replace(' ', '').lower()
    
    # Pattern to match time units
    pattern = r'(\d+)([smhd])'
    matches = re.findall(pattern, time_str)
    
    if not matches:
        return None
    
    total_seconds = 0
    
    for amount, unit in matches:
        amount = int(amount)
        
        if unit == 's':
            total_seconds += amount
        elif unit == 'm':
            total_seconds += amount * 60
        elif unit == 'h':
            total_seconds += amount * 3600
        elif unit == 'd':
            total_seconds += amount * 86400
    
    return total_seconds if total_seconds > 0 else None

async def send_loading_message(ctx, action_text, delay=0.7):
    """Send a loading message and return it for editing after delay"""
    loading_embed = discord.Embed(
        description=f"<a:jo1ntrx_loading:1405094057499295806> {action_text}",
        color=0x3498db
    )
    message = await ctx.send(embed=loading_embed)
    
    # Add the requested delay
    await asyncio.sleep(delay)
    
    return message
