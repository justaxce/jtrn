import discord
import asyncio

async def send_loading_message(ctx, action_text: str):
    """
    Send a loading message with animated dots
    Returns the message object so it can be deleted later
    """
    # Create loading embed with animated dots
    embed = discord.Embed(
        title="⏳ Loading...",
        description=f"Please wait, {action_text}...",
        color=0x7c28eb
    )
    
    try:
        # Send the loading message
        loading_msg = await ctx.send(embed=embed)
        return loading_msg
    except Exception as e:
        print(f"Error sending loading message: {e}")
        return None