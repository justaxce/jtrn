import discord
from discord import ui
from datetime import datetime, timezone, timedelta
from Jo1nTrX.utils.emoji_manager import emoji
from Jo1nTrX.utils.helpers import format_custom_datetime, format_time_since


class BaseLayoutView(ui.LayoutView):
    def __init__(self, content: str, timeout: int = 300):
        super().__init__(timeout=timeout)
        self._setup_view(content)
    
    def _setup_view(self, content: str):
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


def get_footer_text(user=None):
    ist_timezone = timezone(timedelta(hours=5, minutes=30))
    ist_time = datetime.now(ist_timezone)
    time_12hr = ist_time.strftime("%I:%M %p").lower()
    if time_12hr.startswith('0'):
        time_12hr = time_12hr[1:]
    
    if user:
        return f"Executed by {user.name} | {time_12hr}"
    else:
        return f"Executed by Bot | {time_12hr}"


def create_layout_view(title=None, description=None, color_prefix="", timestamp=True, user=None):
    parts = []
    if title:
        parts.append(f"## {title}")
    if description:
        parts.append(description)
    if timestamp:
        footer = get_footer_text(user)
        parts.append(f"\n> {footer}")
    
    content = "\n\n".join(parts) if parts else ""
    return BaseLayoutView(content)


def create_error_layout_view(message, title=None, user=None):
    if title is None:
        title = f"{emoji.cross} Error"
    return create_layout_view(title=title, description=message, user=user)


def create_success_layout_view(message, title=None, user=None):
    if title is None:
        title = f"{emoji.tick} Success"
    return create_layout_view(title=title, description=message, user=user)


def create_warning_layout_view(message, title=None, user=None):
    if title is None:
        title = f"{emoji.cross} Warning"
    return create_layout_view(title=title, description=message, user=user)


def create_info_layout_view(message, title=None, user=None):
    if title is None:
        title = f"{emoji.loading} Information"
    return create_layout_view(title=title, description=message, user=user)


def create_format_guidance_layout_view(command_name, correct_format, description=None):
    title = f"{emoji.cross} Incorrect Command Format"
    message = f"**Command:** `{command_name}`\n**Correct Format:** `{correct_format}`"
    
    if description:
        message += f"\n**Description:** {description}"
    
    message += f"\n\n{emoji.loading} **Tip:** Use comma `, ` to separate multiple values where applicable!"
    
    return create_layout_view(title=title, description=message)


class InviteStatsLayoutView(ui.LayoutView):
    def __init__(self, member, stats, bot_config):
        super().__init__(timeout=300)
        self.member = member
        self.stats = stats
        self.bot_config = bot_config
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:purple_dot_Jo1nTrX:1435911247630700605>"
        parts = [f"## Invite Stats for {self.member.display_name}"]
        parts.append("")
        parts.append(f"{arrow} **Total Invites**: {self.stats['total']}")
        parts.append(f"{arrow} **Successful**: {self.stats['successful']}")
        parts.append(f"{arrow} **Left**: {self.stats['left']}")
        
        if self.stats['fake'] > 0:
            parts.append(f"{arrow} **Fake**: {self.stats['fake']}")
        if self.stats['added'] > 0:
            parts.append(f"{arrow} **Added**: {self.stats['added']}")
        if self.stats['removed'] > 0:
            parts.append(f"{arrow} **Removed**: {self.stats['removed']}")
        
        content = "\n".join(parts)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class LeaderboardLayoutView(ui.LayoutView):
    def __init__(self, guild, leaderboard_data, bot):
        super().__init__(timeout=300)
        self.guild = guild
        self.leaderboard_data = leaderboard_data
        self.bot = bot
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:purple_dot_Jo1nTrX:1435911247630700605>"
        parts = [f"## Top 10 Inviters"]
        parts.append("")
        
        if not self.leaderboard_data:
            parts.append(f"{arrow} No invite data found for this server.")
        else:
            for i, (user_id, stats) in enumerate(self.leaderboard_data):
                user = self.bot.get_user(user_id)
                user_name = user.display_name if user else f"Unknown User ({user_id})"
                
                if i == 0:
                    medal = "🥇"
                elif i == 1:
                    medal = "🥈"
                elif i == 2:
                    medal = "🥉"
                else:
                    medal = f"**{i+1}.**"
                
                parts.append(f"{medal} {user_name} - **{stats['total']}** invites")
        
        parts.append(f"\n> Leaderboard for {self.guild.name}")
        
        content = "\n".join(parts)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class InviteInfoLayoutView(ui.LayoutView):
    def __init__(self, member, invite_info, bot_config):
        super().__init__(timeout=300)
        self.member = member
        self.invite_info = invite_info
        self.bot_config = bot_config
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:purple_dot_Jo1nTrX:1435911247630700605>"
        parts = [f"## Active Invites for {self.member.display_name}"]
        parts.append("")
        
        if not self.invite_info:
            parts.append(f"{arrow} {self.member.mention} has no active invite codes.")
        else:
            for code, uses, inviter_id in self.invite_info:
                parts.append(f"{arrow} **Code:** `{code}` - **Uses:** {uses}")
        
        content = "\n".join(parts)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class InvitedUsersLayoutView(ui.LayoutView):
    def __init__(self, member, invited_data, bot):
        super().__init__(timeout=300)
        self.member = member
        self.invited_data = invited_data
        self.bot = bot
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:purple_dot_Jo1nTrX:1435911247630700605>"
        parts = [f"## Users Invited by {self.member.display_name}"]
        parts.append("")
        
        if not self.invited_data:
            parts.append(f"{arrow} {self.member.mention} hasn't invited anyone yet.")
        else:
            for i, (user_id, joined_at, left_at) in enumerate(self.invited_data[:10]):
                user = self.bot.get_user(user_id)
                user_name = user.display_name if user else f"Unknown User ({user_id})"
                
                if user:
                    account_age = format_time_since(user.created_at)
                else:
                    account_age = "Unknown"
                
                status = "❌ Left" if left_at else "✅ Active"
                parts.append(f"{arrow} **{i+1}.** {user_name} - Age: `{account_age}` - {status}")
            
            if len(self.invited_data) > 10:
                parts.append(f"\n> Showing 10 of {len(self.invited_data)} invited users")
        
        content = "\n".join(parts)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


def create_invite_stats_view(member, stats, bot_config):
    return InviteStatsLayoutView(member, stats, bot_config)


def create_leaderboard_view(guild, leaderboard_data, bot):
    return LeaderboardLayoutView(guild, leaderboard_data, bot)


def create_invite_info_view(member, invite_info, bot_config):
    return InviteInfoLayoutView(member, invite_info, bot_config)


def create_invited_users_view(member, invited_data, bot):
    return InvitedUsersLayoutView(member, invited_data, bot)


def create_embed(title=None, description=None, color=0x7c28eb, timestamp=True, user=None):
    embed = discord.Embed(
        title=title,
        description=description,
        color=color
    )
    
    if timestamp:
        ist_timezone = timezone(timedelta(hours=5, minutes=30))
        ist_time = datetime.now(ist_timezone)
        time_12hr = ist_time.strftime("%I:%M %p").lower()
        if time_12hr.startswith('0'):
            time_12hr = time_12hr[1:]
        
        if user:
            embed.set_footer(text=f"Executed by {user.name} | {time_12hr}")
        else:
            embed.set_footer(text=f"Executed by Bot | {time_12hr}")
    
    return embed


def create_error_embed(message, title=None, user=None):
    if title is None:
        title = f"{emoji.cross} Error"
    return create_embed(
        title=title,
        description=message,
        color=0xff0000,
        user=user
    )


def create_success_embed(message, title=None, user=None):
    if title is None:
        title = f"{emoji.tick} Success"
    return create_embed(
        title=title,
        description=message,
        color=0x00ff00,
        user=user
    )


def create_warning_embed(message, title=None, user=None):
    if title is None:
        title = f"{emoji.cross} Warning"
    return create_embed(
        title=title,
        description=message,
        color=0xffff00,
        user=user
    )


def create_info_embed(message, title=None, user=None):
    if title is None:
        title = f"{emoji.loading} Information"
    return create_embed(
        title=title,
        description=message,
        color=0x3498db,
        user=user
    )


def create_format_guidance_embed(command_name, correct_format, description=None):
    title = f"{emoji.cross} Incorrect Command Format"
    message = f"**Command:** `{command_name}`\n**Correct Format:** `{correct_format}`"
    
    if description:
        message += f"\n**Description:** {description}"
    
    message += f"\n\n{emoji.loading} **Tip:** Use comma `, ` to separate multiple values where applicable!"
    
    return create_embed(
        title=title,
        description=message,
        color=0xff6b6b
    )


def create_invite_stats_embed(member, stats, bot_config):
    embed = create_embed(
        title=f"📊 Invite Stats for {member.display_name}",
        color=bot_config.embed_color
    )
    
    embed.add_field(
        name="Total Invites",
        value=f"**{stats['total']}**",
        inline=True
    )
    embed.add_field(
        name="Successful",
        value=f"**{stats['successful']}**",
        inline=True
    )
    embed.add_field(
        name="Left",
        value=f"**{stats['left']}**",
        inline=True
    )
    
    if stats['fake'] > 0:
        embed.add_field(
            name="Fake",
            value=f"**{stats['fake']}**",
            inline=True
        )
    
    if stats['added'] > 0:
        embed.add_field(
            name="Added",
            value=f"**{stats['added']}**",
            inline=True
        )
    
    if stats['removed'] > 0:
        embed.add_field(
            name="Removed",
            value=f"**{stats['removed']}**",
            inline=True
        )
    
    embed.set_thumbnail(url=member.display_avatar.url)
    return embed


def create_leaderboard_embed(guild, leaderboard_data, bot):
    embed = create_embed(
        title="🏆 Top 10 Inviters",
        color=bot.config.embed_color
    )
    
    if not leaderboard_data:
        embed.description = "No invite data found for this server."
        embed.color = bot.config.warning_color
        return embed
    
    description_lines = []
    for i, (user_id, stats) in enumerate(leaderboard_data):
        user = bot.get_user(user_id)
        user_name = user.display_name if user else f"Unknown User ({user_id})"
        
        if i == 0:
            medal = "🥇"
        elif i == 1:
            medal = "🥈"
        elif i == 2:
            medal = "🥉"
        else:
            medal = f"**{i+1}.**"
        
        description_lines.append(
            f"{medal} {user_name} - **{stats['total']}** invites"
        )
    
    embed.description = "\n".join(description_lines)
    embed.set_footer(text=f"Leaderboard for {guild.name}")
    return embed


def create_invite_info_embed(member, invite_info, bot_config):
    embed = create_embed(
        title=f"📨 Active Invites for {member.display_name}",
        color=bot_config.embed_color
    )
    
    if not invite_info:
        embed.description = f"{member.mention} has no active invite codes."
        embed.color = bot_config.warning_color
        return embed
    
    description_lines = []
    for code, uses, inviter_id in invite_info:
        description_lines.append(f"**Code:** `{code}` - **Uses:** {uses}")
    
    embed.description = "\n".join(description_lines)
    return embed


def create_invited_users_embed(member, invited_data, bot):
    embed = create_embed(
        title=f"👥 Users Invited by {member.display_name}",
        color=bot.config.embed_color
    )
    
    if not invited_data:
        embed.description = f"{member.mention} hasn't invited anyone yet."
        embed.color = bot.config.warning_color
        return embed
    
    description_lines = []
    for i, (user_id, joined_at, left_at) in enumerate(invited_data[:10]):
        user = bot.get_user(user_id)
        user_name = user.display_name if user else f"Unknown User ({user_id})"
        
        status = "❌ Left" if left_at else "✅ Active"
        description_lines.append(f"**{i+1}.** {user_name} - {status}")
    
    if len(description_lines) > 10:
        description_lines.append(f"\n*Showing 10 of {len(invited_data)}*")
        
    embed.description = "\n".join(description_lines)
    return embed
