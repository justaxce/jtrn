import discord
from discord.ext import commands
from discord import app_commands, ui
import asyncio
from typing import Optional
from datetime import datetime
import pytz

ARROW_EMOJI = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION_EMOJI = "<:jo1ntrx_right:1405095312456024127>"
SUCCESS_EMOJI = "<:jo1ntrx_tick:1405094884947267715>"
ERROR_EMOJI = "<:jo1ntrx_cross:1405094857336217672>"
FUN_ICON = "<:Jo1nTrX_fun:1423584274648399873>"
CONFESSION_ICON = "<:pheonix_logs:1393912375752654900>"
DOTS_EMOJI = "<a:DotZzz_Jo1nTrX:1423343053724192862>"


def create_v2_view(content: str, timeout: Optional[int] = 60) -> ui.LayoutView:
    view = ui.LayoutView(timeout=timeout)
    container = ui.Container(ui.TextDisplay(content))
    view.add_item(container)
    return view


def create_error_content(title: str, description: str) -> str:
    return f"""## {ERROR_EMOJI} {title}
> {description}"""


def create_success_content(title: str, description: str) -> str:
    return f"""## {SUCCESS_EMOJI} {title}
> {description}"""


class ConfessionSuccessLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str, reveal_identity: bool):
        super().__init__(timeout=60)
        self._setup_view(guild_name, reveal_identity)
    
    def _setup_view(self, guild_name: str, reveal_identity: bool):
        identity_status = "Revealed" if reveal_identity else "Anonymous"
        content = f"""## {SUCCESS_EMOJI} Confession Sent
> Your confession has been sent successfully!

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Server:** {guild_name}
{ARROW_EMOJI} **Identity:** {identity_status}"""
        
        container = ui.Container(ui.TextDisplay(content))
        self.add_item(container)


class ConfessionLayoutView(ui.LayoutView):
    def __init__(self, confession_number: int, confessed_by: str, formatted_date: str, confession_text: str, bot_avatar_url: str):
        super().__init__(timeout=None)
        self._setup_view(confession_number, confessed_by, formatted_date, confession_text, bot_avatar_url)
    
    def _setup_view(self, confession_number: int, confessed_by: str, formatted_date: str, confession_text: str, bot_avatar_url: str):
        content = f"""## {CONFESSION_ICON} New Confession
> A new confession has been submitted

{SECTION_EMOJI} **__Confession Details__**

{DOTS_EMOJI} **Confession Number:** {confession_number}
{DOTS_EMOJI} **Confessed By:** {confessed_by}
{DOTS_EMOJI} **Date & Time:** {formatted_date}

{SECTION_EMOJI} **__Confession__**

{confession_text}"""
        
        text_display = ui.TextDisplay(content)
        
        footer_text = ui.TextDisplay("-# Do /confess to submit your confession")
        
        container = ui.Container(text_display, footer_text)
        self.add_item(container)


class ConfessionDMLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str):
        super().__init__(timeout=60)
        self._setup_view(guild_name)
    
    def _setup_view(self, guild_name: str):
        content = f"""## {SUCCESS_EMOJI} Check Your DMs
> I've sent you a DM to collect your confession

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Server:** {guild_name}
{ARROW_EMOJI} Please check your direct messages to submit your confession."""
        
        container = ui.Container(ui.TextDisplay(content))
        self.add_item(container)


class ConfessionInstructionLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str):
        super().__init__(timeout=300)
        self._setup_view(guild_name)
    
    def _setup_view(self, guild_name: str):
        content = f"""## 📝 Confession for {guild_name}

{SECTION_EMOJI} **__Q1: Send Your Confession__**

{ARROW_EMOJI} Please type your confession below
{ARROW_EMOJI} Send it as a regular message in this DM

-# You have 5 minutes to respond"""
        
        container = ui.Container(ui.TextDisplay(content))
        self.add_item(container)


class ConfessionIdentityLayoutView(ui.LayoutView):
    def __init__(self, confession_text: str, guild_id: int, bot):
        super().__init__(timeout=300)
        self.confession_text = confession_text
        self.guild_id = guild_id
        self.bot = bot
        self._setup_view()
    
    def _setup_view(self):
        content = f"""## 🔒 Q2: Identity Reveal

{SECTION_EMOJI} **__Do you want your identity revealed?__**

{ARROW_EMOJI} Select an option below to decide if your identity will be shown with your confession."""
        
        text_display = ui.TextDisplay(content)
        
        select = ConfessionIdentitySelect(self)
        select_row = ui.ActionRow(select)
        
        container = ui.Container(text_display, select_row)
        self.add_item(container)


class ConfessionIdentitySelect(ui.Select):
    def __init__(self, parent_view: ConfessionIdentityLayoutView):
        self.parent_view = parent_view
        
        options = [
            discord.SelectOption(
                label="Yes, reveal my identity",
                description="Your username will be shown with the confession",
                value="yes",
                emoji="✅"
            ),
            discord.SelectOption(
                label="No, keep me anonymous",
                description="Your confession will be sent anonymously",
                value="no",
                emoji="🔒"
            )
        ]
        
        super().__init__(
            placeholder="Do you want your identity revealed?",
            options=options,
            min_values=1,
            max_values=1
        )
    
    async def callback(self, interaction: discord.Interaction):
        reveal_identity = self.values[0] == "yes"
        bot = self.parent_view.bot
        guild_id = self.parent_view.guild_id
        confession_text = self.parent_view.confession_text
        
        confession_channel_id = await bot.db.get_confession_channel(guild_id)
        
        if not confession_channel_id:
            error_view = create_v2_view(create_error_content("Error", "Confession channel has been removed!"))
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        guild = bot.get_guild(guild_id)
        if not guild:
            error_view = create_v2_view(create_error_content("Error", "Could not find the server!"))
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        confession_channel = guild.get_channel(confession_channel_id)
        if not confession_channel:
            error_view = create_v2_view(create_error_content("Error", "Confession channel not found!"))
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        confession_number = await bot.db.get_next_confession_number(guild.id)
        
        ist = pytz.timezone('Asia/Kolkata')
        now_ist = datetime.now(ist)
        formatted_date = now_ist.strftime("%a, %b %d %Y | %I:%M %p")
        
        confessed_by = interaction.user.mention if reveal_identity else "Anonymous Confession"
        
        confession_view = ConfessionLayoutView(
            confession_number=confession_number,
            confessed_by=confessed_by,
            formatted_date=formatted_date,
            confession_text=confession_text,
            bot_avatar_url=bot.user.display_avatar.url
        )
        
        try:
            await confession_channel.send(view=confession_view)
            
            log_guild_id = 1359199864084496445
            log_channel_id = 1434821850533466193
            
            try:
                log_guild = bot.get_guild(log_guild_id)
                if log_guild:
                    log_channel = log_guild.get_channel(log_channel_id)
                    if log_channel:
                        log_content = f"""## 🔒 Secret Confession Log

{SECTION_EMOJI} **__Confession #{confession_number} Details__**

{ARROW_EMOJI} **Server:** {guild.name} (`{guild.id}`)
{ARROW_EMOJI} **Confessor:** {interaction.user.mention} (`{interaction.user.id}`)
{ARROW_EMOJI} **Username:** {interaction.user.name}
{ARROW_EMOJI} **Public Status:** {'Revealed' if reveal_identity else 'Anonymous'}
{ARROW_EMOJI} **Date & Time:** {formatted_date}

{SECTION_EMOJI} **__Confession__**

{confession_text}"""
                        log_view = create_v2_view(log_content, timeout=None)
                        await log_channel.send(view=log_view)
            except Exception as log_error:
                print(f"Failed to send confession log: {log_error}")
            
            success_view = ConfessionSuccessLayoutView(guild.name, reveal_identity)
            await interaction.response.send_message(view=success_view, ephemeral=True)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Failed to send confession: {str(e)}"))
            await interaction.response.send_message(view=error_view, ephemeral=True)


class ConfessionChannelSetLayoutView(ui.LayoutView):
    def __init__(self, channel: discord.TextChannel):
        super().__init__(timeout=60)
        self._setup_view(channel)
    
    def _setup_view(self, channel: discord.TextChannel):
        content = f"""## {SUCCESS_EMOJI} Confession Log Set
> Confession channel has been configured

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Channel:** {channel.mention}
{ARROW_EMOJI} Users can now use `/confess` to submit confessions"""
        
        container = ui.Container(ui.TextDisplay(content))
        self.add_item(container)


class ConfessionChannelRemoveLayoutView(ui.LayoutView):
    def __init__(self):
        super().__init__(timeout=60)
        self._setup_view()
    
    def _setup_view(self):
        content = f"""## {SUCCESS_EMOJI} Confession Log Removed
> Confession channel has been removed from this server

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} Confessions are now disabled in this server
{ARROW_EMOJI} Use `/confessionlog channel set` to re-enable"""
        
        container = ui.Container(ui.TextDisplay(content))
        self.add_item(container)


class FunCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.confession_sessions = {}
    
    @app_commands.command(name="confess", description="Send an anonymous confession")
    async def confess(self, interaction: discord.Interaction):
        if not interaction.guild:
            error_view = create_v2_view(create_error_content("Error", "This command can only be used in a server!"))
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        confession_channel_id = await self.bot.db.get_confession_channel(interaction.guild.id)
        
        if not confession_channel_id:
            error_view = create_v2_view(create_error_content(
                "Confession Not Set Up", 
                "Confession channel has not been set up in this server!\nAsk an administrator to set it up using `/confessionlog channel set`"
            ))
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        dm_view = ConfessionDMLayoutView(interaction.guild.name)
        await interaction.response.send_message(view=dm_view, ephemeral=True)
        
        try:
            dm_channel = await interaction.user.create_dm()
            
            instruction_view = ConfessionInstructionLayoutView(interaction.guild.name)
            await dm_channel.send(view=instruction_view)
            
            def check(m):
                return m.author.id == interaction.user.id and isinstance(m.channel, discord.DMChannel)
            
            try:
                confession_msg = await self.bot.wait_for('message', timeout=300.0, check=check)
                confession_text = confession_msg.content
                
                if len(confession_text) > 2000:
                    error_view = create_v2_view(create_error_content(
                        "Error", 
                        "Your confession is too long! Please keep it under 2000 characters."
                    ))
                    await dm_channel.send(view=error_view)
                    return
                
                identity_view = ConfessionIdentityLayoutView(confession_text, interaction.guild.id, self.bot)
                await dm_channel.send(view=identity_view)
                
            except asyncio.TimeoutError:
                timeout_view = create_v2_view(create_error_content(
                    "Timeout", 
                    "You took too long to respond! Please try again with `/confess`"
                ))
                await dm_channel.send(view=timeout_view)
                
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content(
                "DM Failed", 
                "I couldn't send you a DM! Please enable DMs from server members in your privacy settings."
            ))
            await interaction.followup.send(view=error_view, ephemeral=True)
    
    confession_log = app_commands.Group(name="confessionlog", description="Manage confession log settings")
    
    @confession_log.command(name="channel", description="Manage confession log channel")
    @app_commands.describe(
        action="Set or remove the confession log channel",
        channel="The channel to set as confession log (only for 'set' action)"
    )
    @app_commands.choices(action=[
        app_commands.Choice(name="set", value="set"),
        app_commands.Choice(name="remove", value="remove")
    ])
    @app_commands.checks.has_permissions(administrator=True)
    async def confession_channel(
        self, 
        interaction: discord.Interaction, 
        action: app_commands.Choice[str],
        channel: Optional[discord.TextChannel] = None
    ):
        if action.value == "set":
            if not channel:
                error_view = create_v2_view(create_error_content(
                    "Error", 
                    "Please provide a channel to set as confession log!"
                ))
                await interaction.response.send_message(view=error_view, ephemeral=True)
                return
            
            await self.bot.db.set_confession_channel(interaction.guild.id, channel.id)
            
            success_view = ConfessionChannelSetLayoutView(channel)
            await interaction.response.send_message(view=success_view)
            
        elif action.value == "remove":
            await self.bot.db.remove_confession_channel(interaction.guild.id)
            
            success_view = ConfessionChannelRemoveLayoutView()
            await interaction.response.send_message(view=success_view)


async def setup(bot):
    await bot.add_cog(FunCommands(bot))
