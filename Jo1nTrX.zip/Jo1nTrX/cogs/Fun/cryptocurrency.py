import discord
from discord.ext import commands
from discord import app_commands, ui
from typing import Optional
import aiohttp
import asyncio
import math
import re
from Jo1nTrX.utils.component import bot_emoji

ARROW_EMOJI = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION_EMOJI = "<:jo1ntrx_right:1405095312456024127>"
CURRENCY_ICON = "<:Jo1nTrX_Currency:1416791338879553690>"
SUCCESS_EMOJI = "<:Jo1nTrX_Yes:1408288995477159987>"
ERROR_EMOJI = "<:Jo1nTrX_No:1408289044470960129>"


def create_v2_view(content: str, timeout: int = 300) -> ui.LayoutView:
    view = ui.LayoutView(timeout=timeout)
    container = ui.Container(ui.TextDisplay(content))
    view.add_item(container)
    return view


def create_error_content(title: str, description: str) -> str:
    return f"""## {ERROR_EMOJI} {title}
> {description}"""


def create_success_content(title: str, description: str) -> str:
    return f"""## {SUCCESS_EMOJI} {title}
> {description}"""


class CryptoCurrencyCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.session = None
        
        self.currencies = {
            'INR': {'name': 'Indian Rupee', 'emoji': '<:Jo1nTrX_inr:1416791769294704681>', 'symbol': '₹'},
            'USD': {'name': 'US Dollar', 'emoji': '<:Jo1nTrX_dollars:1416791727678685195>', 'symbol': '$'},
            'NPR': {'name': 'Nepalese Rupee', 'emoji': '<:Jo1nTrX_npr:1416792196492824741>', 'symbol': 'रू'},
            'BDT': {'name': 'Bangladeshi Taka', 'emoji': '<:Jo1nTrX_bdt:1416792201903476869>', 'symbol': '৳'}
        }
        
        self.cryptocurrencies = {
            'LTC': {'name': 'Litecoin', 'emoji': '<:Jo1nTrX_ltc:1416792714036514866>', 'id': 'litecoin'},
            'BTC': {'name': 'Bitcoin', 'emoji': '<:Jo1nTrX_btc:1416792640665682152>', 'id': 'bitcoin'},
            'ETH': {'name': 'Ethereum', 'emoji': '<:Jo1nTrX_eth:1416792598923972608>', 'id': 'ethereum'},
            'SOL': {'name': 'Solana', 'emoji': '<:Jo1nTrX_sol:1416792605517283450>', 'id': 'solana'}
        }
        
        self.all_currencies = {**self.currencies, **self.cryptocurrencies}
    
    async def cog_load(self):
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10))
    
    async def cog_unload(self):
        if self.session:
            await self.session.close()
    
    def safe_eval(self, expression):
        try:
            expression = expression.replace(' ', '')
            expression = expression.replace('×', '*').replace('÷', '/')
            
            percentage_match = re.match(r'(\d+(?:\.\d+)?)%\s*of\s*(\d+(?:\.\d+)?)', expression)
            if percentage_match:
                percent = float(percentage_match.group(1))
                number = float(percentage_match.group(2))
                return (percent / 100) * number
            
            expression = expression.replace('√', 'sqrt')
            
            allowed_names = {
                'sqrt': math.sqrt, 'pow': pow, 'abs': abs, 'round': round,
                'min': min, 'max': max, 'pi': math.pi, 'e': math.e,
                'sin': math.sin, 'cos': math.cos, 'tan': math.tan,
                'log': math.log, 'log10': math.log10
            }
            
            dangerous = ['__', 'import', 'exec', 'eval', 'open', 'file', 'input', 'raw_input']
            if any(danger in expression.lower() for danger in dangerous):
                raise ValueError("Dangerous operation detected")
            
            if not re.match(r'^[0-9+\-*/().%a-zA-Z_]*$', expression):
                raise ValueError("Invalid characters in expression")
            
            result = eval(expression, {"__builtins__": {}}, allowed_names)
            return result
            
        except Exception as e:
            raise ValueError(f"Invalid expression: {str(e)}")
    
    async def get_crypto_price(self, crypto_id, vs_currency='usd', retry_count=0, max_retries=3):
        try:
            url = f"https://api.coingecko.com/api/v3/simple/price?ids={crypto_id}&vs_currencies={vs_currency}"
            if not self.session:
                self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10))
            
            await asyncio.sleep(0.2)
            
            async with self.session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    return data[crypto_id][vs_currency.lower()]
                elif response.status == 429 and retry_count < max_retries:
                    delay = 2 ** (retry_count + 1)
                    await asyncio.sleep(delay)
                    return await self.get_crypto_price(crypto_id, vs_currency, retry_count + 1, max_retries)
                return None
        except Exception as e:
            print(f"Error fetching crypto price: {e}")
            return None
    
    async def get_multiple_crypto_prices(self, crypto_ids, vs_currency='usd', retry_count=0, max_retries=3):
        try:
            if not crypto_ids:
                return {}
                
            ids_str = ','.join(crypto_ids)
            url = f"https://api.coingecko.com/api/v3/simple/price?ids={ids_str}&vs_currencies={vs_currency}"
            
            if not self.session:
                self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10))
            
            await asyncio.sleep(0.2)
            
            async with self.session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    result = {}
                    for crypto_id in crypto_ids:
                        if crypto_id in data and vs_currency.lower() in data[crypto_id]:
                            result[crypto_id] = data[crypto_id][vs_currency.lower()]
                    return result
                elif response.status == 429 and retry_count < max_retries:
                    delay = 2 ** (retry_count + 1)
                    await asyncio.sleep(delay)
                    return await self.get_multiple_crypto_prices(crypto_ids, vs_currency, retry_count + 1, max_retries)
                return {}
        except Exception as e:
            print(f"Error fetching multiple crypto prices: {e}")
            return {}
    
    async def get_fiat_exchange_rate(self, from_currency, to_currency):
        try:
            if not self.session:
                self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10))
            
            try:
                url = f"https://api.frankfurter.app/latest?base={from_currency}&symbols={to_currency}"
                async with self.session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        if 'rates' in data and to_currency in data['rates']:
                            return data['rates'][to_currency]
            except:
                pass
            
            try:
                base_lower = from_currency.lower()
                to_lower = to_currency.lower()
                url = f"https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/{base_lower}.json"
                async with self.session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        if base_lower in data and to_lower in data[base_lower]:
                            return data[base_lower][to_lower]
            except:
                pass
                
            return None
        except Exception as e:
            print(f"Error fetching exchange rate: {e}")
            return None
    
    async def convert_currency(self, amount, from_code, to_code):
        from_crypto = from_code in self.cryptocurrencies
        to_crypto = to_code in self.cryptocurrencies
        
        try:
            if from_crypto and to_crypto:
                from_id = self.cryptocurrencies[from_code]['id']
                to_id = self.cryptocurrencies[to_code]['id']
                prices = await self.get_multiple_crypto_prices([from_id, to_id])
                from_price = prices.get(from_id)
                to_price = prices.get(to_id)
                if from_price and to_price:
                    usd_value = amount * from_price
                    return usd_value / to_price
                    
            elif from_crypto and not to_crypto:
                crypto_price_usd = await self.get_crypto_price(self.cryptocurrencies[from_code]['id'])
                if crypto_price_usd:
                    usd_value = amount * crypto_price_usd
                    if to_code == 'USD':
                        return usd_value
                    else:
                        rate = await self.get_fiat_exchange_rate('USD', to_code)
                        if rate:
                            return usd_value * rate
                            
            elif not from_crypto and to_crypto:
                if from_code != 'USD':
                    rate_to_usd = await self.get_fiat_exchange_rate(from_code, 'USD')
                    if rate_to_usd:
                        usd_value = amount * rate_to_usd
                    else:
                        return None
                else:
                    usd_value = amount
                
                crypto_price_usd = await self.get_crypto_price(self.cryptocurrencies[to_code]['id'])
                if crypto_price_usd:
                    return usd_value / crypto_price_usd
                    
            else:
                if from_code == to_code:
                    return amount
                rate = await self.get_fiat_exchange_rate(from_code, to_code)
                if rate:
                    return amount * rate
            
            return None
            
        except Exception as e:
            print(f"Error converting currency: {e}")
            return None
    
    @commands.hybrid_command(name='calculate', aliases=['calc', 'math'])
    @app_commands.describe(expression='Mathematical expression to calculate (supports +, -, *, /, %, √, and more)')
    async def calculate(self, ctx, *, expression: Optional[str] = None):
        """Calculate mathematical expressions with support for various operations"""
        if expression is None:
            content = f"""## {CURRENCY_ICON} Calculator
> Please provide a mathematical expression to calculate.

{SECTION_EMOJI} **__Usage__**
{ARROW_EMOJI} `+calculate 2 + 2` or `+calc 5 * 3`

{SECTION_EMOJI} **__Supported__**
{ARROW_EMOJI} `+`, `-`, `*`, `/`, `%`, `√`, `pow()`, `abs()`, `round()`"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        loading_content = f"""## {CURRENCY_ICON} Calculating...
> Calculating expression: `{expression}`"""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            result = self.safe_eval(expression)
            
            if isinstance(result, float):
                if result.is_integer():
                    result = int(result)
                else:
                    result = round(result, 10)
            
            content = f"""## {CURRENCY_ICON} Calculator Result
> Mathematical Calculator

{SECTION_EMOJI} **__Result__**
{ARROW_EMOJI} **Expression:** `{expression}`
{ARROW_EMOJI} **Result:** `{result}`"""
            
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except ValueError as e:
            content = f"""## {ERROR_EMOJI} Calculation Error
> {str(e)}

{SECTION_EMOJI} **__Supported Operations__**
{ARROW_EMOJI} Basic: `+`, `-`, `*`, `/`, `%`
{ARROW_EMOJI} Functions: `√`, `pow()`, `abs()`, `round()`
{ARROW_EMOJI} Constants: `pi`, `e`
{ARROW_EMOJI} Percentage: `3% of 100`"""
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except Exception as e:
            content = create_error_content("Calculation Error", f"An unexpected error occurred: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
    
    @commands.hybrid_command(name='exchange', aliases=['currency', 'exch'])
    @commands.cooldown(1, 5, commands.BucketType.user)
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @app_commands.describe(
        amount='Amount to convert',
        from_currency='Currency to convert from',
        to_currency='Currency to convert to'
    )
    async def exchange(self, ctx, amount: Optional[float] = None, from_currency: Optional[str] = None, to_currency: Optional[str] = None):
        """Exchange between currencies and cryptocurrencies with real-time rates"""
        if amount is None or from_currency is None or to_currency is None:
            available = ', '.join([f"{code} {data['emoji']}" for code, data in self.all_currencies.items()])
            content = f"""## {CURRENCY_ICON} Currency Exchange
> Please provide all required arguments.

{SECTION_EMOJI} **__Usage__**
{ARROW_EMOJI} `+exchange 100 USD INR`

{SECTION_EMOJI} **__Available Currencies__**
{ARROW_EMOJI} {available}"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        if amount <= 0:
            content = create_error_content("Invalid Amount", "Amount must be a positive number greater than 0.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        from_code = from_currency.upper()
        to_code = to_currency.upper()
        
        if from_code not in self.all_currencies:
            available = ', '.join([f"{code} {data['emoji']}" for code, data in self.all_currencies.items()])
            content = f"""## {ERROR_EMOJI} Unsupported Currency
> **{from_code}** is not supported.

{SECTION_EMOJI} **__Available Currencies__**
{ARROW_EMOJI} {available}"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
            
        if to_code not in self.all_currencies:
            available = ', '.join([f"{code} {data['emoji']}" for code, data in self.all_currencies.items()])
            content = f"""## {ERROR_EMOJI} Unsupported Currency
> **{to_code}** is not supported.

{SECTION_EMOJI} **__Available Currencies__**
{ARROW_EMOJI} {available}"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        from_emoji = self.all_currencies[from_code]['emoji']
        to_emoji = self.all_currencies[to_code]['emoji']
        loading_content = f"""## {CURRENCY_ICON} Fetching Rates...
> Fetching rate for **{amount:,} {from_code}** {from_emoji} to **{to_code}** {to_emoji}"""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            result = await self.convert_currency(amount, from_code, to_code)
            
            if result is None:
                content = create_error_content("Exchange Rate Unavailable", f"Unable to fetch exchange rate for **{from_code}** to **{to_code}**. Please try again later.")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            if to_code in self.cryptocurrencies:
                if result >= 1:
                    result_str = f"{result:,.6f}".rstrip('0').rstrip('.')
                else:
                    result_str = f"{result:.8f}".rstrip('0').rstrip('.')
            else:
                result_str = f"{result:,.2f}"
            
            from_name = self.all_currencies[from_code]['name']
            to_name = self.all_currencies[to_code]['name']
            to_symbol = self.all_currencies[to_code].get('symbol', '')
            
            if to_symbol:
                result_display = f"{to_symbol}{result_str}"
            else:
                result_display = f"{result_str} {to_code}"
            
            rate = result / amount if amount != 0 else 0
            rate_str = f"{rate:.6f}".rstrip('0').rstrip('.')
            
            content = f"""## {CURRENCY_ICON} Currency Exchange
> Real-time Exchange Rates

{SECTION_EMOJI} **__Conversion__**
{ARROW_EMOJI} **{amount:,} {from_code}** {from_emoji} *({from_name})*
{ARROW_EMOJI} **=**
{ARROW_EMOJI} **{result_display}** {to_emoji} *({to_name})*

{SECTION_EMOJI} **__Exchange Rate__**
{ARROW_EMOJI} 1 {from_code} = {rate_str} {to_code}"""
            
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except Exception as e:
            content = create_error_content("Exchange Error", f"An error occurred while fetching exchange rates: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
    
    @exchange.autocomplete('from_currency')
    async def exchange_from_autocomplete(self, interaction: discord.Interaction, current: str):
        choices = []
        for code, data in self.all_currencies.items():
            if current.lower() in code.lower() or current.lower() in data['name'].lower():
                choices.append(app_commands.Choice(name=f"{code} - {data['name']}", value=code))
        return choices[:25]
    
    @exchange.autocomplete('to_currency')
    async def exchange_to_autocomplete(self, interaction: discord.Interaction, current: str):
        choices = []
        for code, data in self.all_currencies.items():
            if current.lower() in code.lower() or current.lower() in data['name'].lower():
                choices.append(app_commands.Choice(name=f"{code} - {data['name']}", value=code))
        return choices[:25]
    
    async def get_all_rates(self, amount, from_code):
        rates = {}
        
        async def get_single_rate(to_code):
            try:
                result = await self.convert_currency(amount, from_code, to_code)
                return (to_code, result)
            except:
                return (to_code, None)
        
        tasks = []
        for code in self.all_currencies.keys():
            if code != from_code:
                tasks.append(get_single_rate(code))
        
        batch_size = 5
        all_results = []
        
        for i in range(0, len(tasks), batch_size):
            batch = tasks[i:i + batch_size]
            batch_results = await asyncio.gather(*batch, return_exceptions=True)
            all_results.extend(batch_results)
            if i + batch_size < len(tasks):
                await asyncio.sleep(0.5)
        
        for result in all_results:
            if isinstance(result, tuple) and result[1] is not None:
                rates[result[0]] = result[1]
        
        return rates
    
    @commands.hybrid_command(name='allrates', aliases=['rates', 'ar'])
    @commands.cooldown(1, 10, commands.BucketType.user)
    @app_commands.checks.cooldown(1, 10.0, key=lambda i: i.user.id)
    @app_commands.describe(
        amount='Amount to convert',
        from_currency='Currency to convert from'
    )
    async def allrates(self, ctx, amount: Optional[float] = None, from_currency: Optional[str] = None):
        """Show exchange rates to all supported currencies"""
        if amount is None or from_currency is None:
            available = ', '.join([f"{code} {data['emoji']}" for code, data in self.all_currencies.items()])
            content = f"""## {CURRENCY_ICON} All Rates
> Please provide amount and currency.

{SECTION_EMOJI} **__Usage__**
{ARROW_EMOJI} `+allrates 100 USD`

{SECTION_EMOJI} **__Available Currencies__**
{ARROW_EMOJI} {available}"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        from_code = from_currency.upper()
        
        if from_code not in self.all_currencies:
            content = create_error_content("Unsupported Currency", f"**{from_code}** is not supported.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        from_emoji = self.all_currencies[from_code]['emoji']
        loading_content = f"""## {CURRENCY_ICON} Fetching All Rates...
> Getting rates for **{amount:,} {from_code}** {from_emoji}"""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            rates = await self.get_all_rates(amount, from_code)
            
            if not rates:
                content = create_error_content("Rates Unavailable", "Unable to fetch exchange rates. Please try again later.")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            fiat_rates = []
            crypto_rates = []
            
            for code, rate in rates.items():
                emoji = self.all_currencies[code]['emoji']
                symbol = self.all_currencies[code].get('symbol', '')
                
                if code in self.cryptocurrencies:
                    if rate >= 1:
                        rate_str = f"{rate:,.6f}".rstrip('0').rstrip('.')
                    else:
                        rate_str = f"{rate:.8f}".rstrip('0').rstrip('.')
                    crypto_rates.append(f"{ARROW_EMOJI} {emoji} **{code}:** {rate_str}")
                else:
                    rate_str = f"{rate:,.2f}"
                    display = f"{symbol}{rate_str}" if symbol else rate_str
                    fiat_rates.append(f"{ARROW_EMOJI} {emoji} **{code}:** {display}")
            
            content = f"""## {CURRENCY_ICON} Exchange Rates
> Rates for **{amount:,} {from_code}** {from_emoji}

{SECTION_EMOJI} **__Fiat Currencies__**
{chr(10).join(fiat_rates)}

{SECTION_EMOJI} **__Cryptocurrencies__**
{chr(10).join(crypto_rates)}"""
            
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except Exception as e:
            content = create_error_content("Error", f"An error occurred: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)


    async def _show_currency_rates(self, ctx, amount: float, from_code: str):
        """Helper method to show rates for a currency in all other currencies"""
        if amount <= 0:
            content = create_error_content("Invalid Amount", "Amount must be a positive number greater than 0.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        from_emoji = self.all_currencies[from_code]['emoji']
        from_symbol = self.currencies[from_code].get('symbol', '')
        loading_content = f"""## {CURRENCY_ICON} Fetching Rates...
> Getting rates for **{from_symbol}{amount:,.2f} {from_code}** {from_emoji}"""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            rates = await self.get_all_rates(amount, from_code)
            
            if not rates:
                content = create_error_content("Rates Unavailable", "Unable to fetch exchange rates. Please try again later.")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            fiat_lines = []
            crypto_lines = []
            
            for code, rate in rates.items():
                emoji = self.all_currencies[code]['emoji']
                symbol = self.all_currencies[code].get('symbol', '')
                
                if code in self.cryptocurrencies:
                    if rate >= 1:
                        rate_str = f"{rate:,.6f}".rstrip('0').rstrip('.')
                    else:
                        rate_str = f"{rate:.8f}".rstrip('0').rstrip('.')
                    crypto_lines.append(f"{ARROW_EMOJI} {emoji} **{code}:** {rate_str}")
                else:
                    rate_str = f"{rate:,.2f}"
                    display = f"{symbol}{rate_str}" if symbol else rate_str
                    fiat_lines.append(f"{ARROW_EMOJI} {emoji} **{code}:** {display}")
            
            content = f"""## {CURRENCY_ICON} {from_code} Exchange Rates
> Real-time rates for **{from_symbol}{amount:,.2f} {from_code}** {from_emoji}

{SECTION_EMOJI} **__Fiat Currencies__**
{chr(10).join(fiat_lines) if fiat_lines else f"{ARROW_EMOJI} No fiat rates available"}

{SECTION_EMOJI} **__Cryptocurrencies__**
{chr(10).join(crypto_lines) if crypto_lines else f"{ARROW_EMOJI} No crypto rates available"}"""
            
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except Exception as e:
            content = create_error_content("Error", f"An error occurred: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @commands.hybrid_command(name='inr')
    @commands.cooldown(1, 5, commands.BucketType.user)
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @app_commands.describe(amount='Amount in INR to convert')
    async def inr(self, ctx, amount: Optional[float] = None):
        """Convert INR to all other currencies with real-time rates"""
        if amount is None:
            content = f"""## {CURRENCY_ICON} INR Converter
> Convert Indian Rupees to other currencies

{SECTION_EMOJI} **__Usage__**
{ARROW_EMOJI} `+inr 100` - Convert ₹100 to all currencies"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        await self._show_currency_rates(ctx, amount, 'INR')

    @commands.hybrid_command(name='usd')
    @commands.cooldown(1, 5, commands.BucketType.user)
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @app_commands.describe(amount='Amount in USD to convert')
    async def usd(self, ctx, amount: Optional[float] = None):
        """Convert USD to all other currencies with real-time rates"""
        if amount is None:
            content = f"""## {CURRENCY_ICON} USD Converter
> Convert US Dollars to other currencies

{SECTION_EMOJI} **__Usage__**
{ARROW_EMOJI} `+usd 100` - Convert $100 to all currencies"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        await self._show_currency_rates(ctx, amount, 'USD')

    @commands.hybrid_command(name='npr')
    @commands.cooldown(1, 5, commands.BucketType.user)
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @app_commands.describe(amount='Amount in NPR to convert')
    async def npr(self, ctx, amount: Optional[float] = None):
        """Convert NPR to all other currencies with real-time rates"""
        if amount is None:
            content = f"""## {CURRENCY_ICON} NPR Converter
> Convert Nepalese Rupees to other currencies

{SECTION_EMOJI} **__Usage__**
{ARROW_EMOJI} `+npr 100` - Convert रू100 to all currencies"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        await self._show_currency_rates(ctx, amount, 'NPR')

    @commands.hybrid_command(name='bdt')
    @commands.cooldown(1, 5, commands.BucketType.user)
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @app_commands.describe(amount='Amount in BDT to convert')
    async def bdt(self, ctx, amount: Optional[float] = None):
        """Convert BDT to all other currencies with real-time rates"""
        if amount is None:
            content = f"""## {CURRENCY_ICON} BDT Converter
> Convert Bangladeshi Taka to other currencies

{SECTION_EMOJI} **__Usage__**
{ARROW_EMOJI} `+bdt 100` - Convert ৳100 to all currencies"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        await self._show_currency_rates(ctx, amount, 'BDT')


async def setup(bot):
    await bot.add_cog(CryptoCurrencyCommands(bot))
