import discord
from discord.ext import commands, tasks
from discord import app_commands, ui
import re
from datetime import datetime, timezone, timedelta
from Jo1nTrX.utils.component import bot_emoji

ARROW_EMOJI = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION_EMOJI = "<:jo1ntrx_right:1405095312456024127>"
SUCCESS_EMOJI = "<:jo1ntrx_tick:1405094884947267715>"
ERROR_EMOJI = "<a:Jo1nTrX_cross:1405094904568483880>"
AUTOACTION_ICON = "<:Jo1nTrX_autoaction:1410988700799598602>"


def create_v2_view(content: str, timeout: int = 300) -> ui.LayoutView:
    view = ui.LayoutView(timeout=timeout)
    container = ui.Container(ui.TextDisplay(content))
    view.add_item(container)
    return view


def create_error_content(title: str, description: str) -> str:
    return f"""## {ERROR_EMOJI} {title}
> {description}"""


def create_success_content(title: str, description: str) -> str:
    return f"""## {SUCCESS_EMOJI} {title}
> {description}"""


class AutoreactPaginationLayoutView(ui.LayoutView):
    def __init__(self, data, current_page, total_pages, create_content_func, author, cog):
        super().__init__(timeout=300)
        self.data = data
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_content = create_content_func
        self.author = author
        self.cog = cog
        self._setup_view()
    
    def _setup_view(self):
        content = self.create_content(self.current_page)
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutoreactPaginationLayoutView(self.data, 0, self.total_pages, self.create_content, self.author, self.cog)
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutoreactPaginationLayoutView(self.data, max(0, self.current_page - 1), self.total_pages, self.create_content, self.author, self.cog)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutoreactPaginationLayoutView(self.data, min(self.total_pages - 1, self.current_page + 1), self.total_pages, self.create_content, self.author, self.cog)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutoreactPaginationLayoutView(self.data, self.total_pages - 1, self.total_pages, self.create_content, self.author, self.cog)
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class AutoReaction(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.autoreacts = {}
    
    async def cog_load(self):
        await self.refresh_cache()
        self.auto_refresh_cache.start()
    
    async def cog_unload(self):
        self.auto_refresh_cache.cancel()
    
    @tasks.loop(seconds=10)
    async def auto_refresh_cache(self):
        await self.refresh_cache()
    
    @auto_refresh_cache.before_loop
    async def before_auto_refresh(self):
        await self.bot.wait_until_ready()
    
    async def refresh_cache(self):
        try:
            autoreacts = await self.bot.db.get_all_autoreacts()
            self.autoreacts = {}
            for guild_id, trigger_text, emojis, match_type in autoreacts:
                if guild_id not in self.autoreacts:
                    self.autoreacts[guild_id] = []
                self.autoreacts[guild_id].append({
                    'trigger': trigger_text,
                    'emojis': emojis,
                    'match_type': match_type
                })
        except Exception as e:
            print(f"[AutoReaction] Error refreshing cache: {e}")
    
    async def is_premium_user(self, user_id: int) -> bool:
        try:
            premium_users = await self.bot.db.list_premium_users()
            return user_id in [user[0] for user in premium_users] if premium_users else False
        except Exception:
            return False
    
    async def get_auto_action_limits(self, user_id: int) -> float:
        if user_id in self.bot.config.BOT_OWNER_IDS:
            return float('inf')
        elif await self.is_premium_user(user_id):
            return 15
        else:
            return 5
    
    async def get_user_autoreact_count(self, user_id: int, guild_id: int) -> int:
        try:
            count = await self.bot.db.get_user_autoreact_count(user_id, guild_id)
            return count if count is not None else 0
        except Exception as e:
            print(f"Error getting user autoreact count for user {user_id} in guild {guild_id}: {e}")
            return 0
    
    def parse_emojis(self, emoji_str):
        emoji_parts = [emoji.strip() for emoji in emoji_str.split(',')]
        if len(emoji_parts) > 5:
            emoji_parts = emoji_parts[:5]
        
        formatted_emojis = []
        for emoji in emoji_parts:
            if emoji:
                custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', emoji)
                if custom_emoji_match:
                    formatted_emojis.append(emoji)
                else:
                    formatted_emojis.append(emoji)
        
        return ','.join(formatted_emojis)
    
    def parse_emojis_for_reaction(self, emoji_str):
        if not emoji_str:
            return []
        
        emojis = []
        emoji_parts = [emoji.strip() for emoji in emoji_str.split(',')]
        
        for emoji in emoji_parts:
            if emoji:
                custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', emoji)
                if custom_emoji_match:
                    emojis.append(emoji)
                else:
                    emojis.append(emoji)
        
        return emojis
    
    def format_emojis_display(self, emojis_str):
        if not emojis_str:
            return "None"
        
        emoji_parts = [emoji.strip() for emoji in emojis_str.split(',')]
        validated_emojis = []
        invalid_emojis = []
        
        for emoji in emoji_parts:
            if emoji:
                custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', emoji)
                if custom_emoji_match:
                    emoji_id = int(custom_emoji_match.group(2))
                    emoji_obj = self.bot.get_emoji(emoji_id)
                    if emoji_obj:
                        validated_emojis.append(emoji)
                    else:
                        invalid_emojis.append(f"`{emoji}` ❌")
                else:
                    validated_emojis.append(emoji)
        
        result = " ".join(validated_emojis)
        if invalid_emojis:
            result += " " + " ".join(invalid_emojis)
        
        return result if result else "None"
    
    @commands.hybrid_group(name='autoreact', fallback='help')
    async def autoreact(self, ctx):
        """Auto reaction management commands"""
        content = f"""## {AUTOACTION_ICON} Auto React Commands
> Available auto reaction commands

{SECTION_EMOJI} **__Commands__**

{ARROW_EMOJI} `autoreact add <trigger> <emojis> <type>` - Add auto reaction
{ARROW_EMOJI} `autoreact delete <trigger>` - Remove auto reaction
{ARROW_EMOJI} `autoreact list` - List all auto reactions

{SECTION_EMOJI} **__Match Types__**

{ARROW_EMOJI} `exact` - Trigger must match exactly
{ARROW_EMOJI} `contains` - Message must contain trigger

{SECTION_EMOJI} **__Note__**

{ARROW_EMOJI} You can use up to 5 emojis separated by commas"""
        
        view = create_v2_view(content)
        await ctx.send(view=view)
    
    @autoreact.command(name='add')
    @app_commands.describe(
        trigger="The text that will trigger the reaction",
        emojis="The emojis to react with (up to 5, separated by commas)",
        match_type="Whether to match exactly or if message contains trigger"
    )
    @app_commands.choices(match_type=[
        app_commands.Choice(name="Exact", value="exact"),
        app_commands.Choice(name="Contains", value="contains")
    ])
    async def autoreact_add(self, ctx, trigger: str, emojis: str, match_type: str = "contains"):
        """Add a new auto reaction"""
        if not ctx.author.guild_permissions.manage_guild:
            content = create_error_content("Missing Permissions", "You need 'Manage Server' permission to use this command.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        user_limit = await self.get_auto_action_limits(ctx.author.id)
        if user_limit != float('inf'):
            current_count = await self.get_user_autoreact_count(ctx.author.id, ctx.guild.id)
            if current_count >= user_limit:
                is_premium = await self.is_premium_user(ctx.author.id)
                if not is_premium:
                    content = f"""## {ERROR_EMOJI} Premium Required
> You don't have premium access to use this command!

{SECTION_EMOJI} **__Get Premium__**

{ARROW_EMOJI} To get premium access, join support server.
{ARROW_EMOJI} [Join our support server](https://discord.gg/PA6UhChxZY)"""
                else:
                    content = create_error_content("Limit Reached", f"You have reached your limit of {int(user_limit)} auto reactions.\nPremium users can create up to 15 auto reactions.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
        
        formatted_emojis = self.parse_emojis(emojis)
        
        if not formatted_emojis:
            content = create_error_content("Invalid Emojis", "Please provide at least one valid emoji!")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        emoji_parts = [emoji.strip() for emoji in formatted_emojis.split(',')]
        invalid_emojis = []
        
        for emoji in emoji_parts:
            if emoji:
                custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', emoji)
                if custom_emoji_match:
                    emoji_id = int(custom_emoji_match.group(2))
                    emoji_obj = self.bot.get_emoji(emoji_id)
                    if not emoji_obj:
                        invalid_emojis.append(emoji)
        
        if invalid_emojis:
            content = create_error_content("Invalid Emojis", f"The following emojis are invalid or inaccessible: {', '.join(invalid_emojis)}\nPlease make sure the bot has access to these emojis or use different ones.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        existing = await self.bot.db.get_guild_autoreacts(ctx.guild.id)
        for existing_trigger, _, _, _ in existing:
            if existing_trigger.lower() == trigger.lower():
                content = create_error_content("Trigger Already Exists", f"Auto reaction with trigger `{trigger}` already exists!")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
        
        try:
            await self.bot.db.add_autoreact(
                ctx.guild.id, 
                trigger, 
                formatted_emojis, 
                match_type,
                ctx.author.id
            )
            
            await self.refresh_cache()
            
            content = f"""## {AUTOACTION_ICON} Auto Reaction Added
> Successfully added auto reaction!

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Trigger:** `{trigger}`
{ARROW_EMOJI} **Emojis:** {self.format_emojis_display(formatted_emojis)}
{ARROW_EMOJI} **Type:** {match_type.title()}"""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except Exception as e:
            content = create_error_content("Database Error", f"Failed to add auto reaction: {str(e)}")
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @autoreact.command(name='delete')
    @app_commands.describe(trigger="The trigger text to remove")
    async def autoreact_delete(self, ctx, *, trigger: str):
        """Delete an auto reaction"""
        if not ctx.author.guild_permissions.manage_guild:
            content = create_error_content("Missing Permissions", "You need 'Manage Server' permission to use this command.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        try:
            deleted = await self.bot.db.delete_autoreact(ctx.guild.id, trigger)
            
            if deleted:
                await self.refresh_cache()
                
                content = f"""## {AUTOACTION_ICON} Auto Reaction Deleted
> Successfully deleted auto reaction with trigger: `{trigger}`"""
                
                view = create_v2_view(content)
                await ctx.send(view=view)
            else:
                content = create_error_content("Not Found", f"No auto reaction found with trigger: `{trigger}`")
                view = create_v2_view(content)
                await ctx.send(view=view)
                
        except Exception as e:
            content = create_error_content("Database Error", f"Failed to delete auto reaction: {str(e)}")
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @autoreact.command(name='list')
    async def autoreact_list(self, ctx):
        """List all auto reactions for the guild with pagination"""
        try:
            autoreacts = await self.bot.db.get_guild_autoreacts(ctx.guild.id)
            
            if not autoreacts:
                content = f"""## {AUTOACTION_ICON} No Auto Reactions
> This server has no auto reactions set up yet.

{ARROW_EMOJI} Use `autoreact add <trigger> <emoji> <type>` to create your first auto reaction!"""
                
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            items_per_page = 5
            total_pages = (len(autoreacts) + items_per_page - 1) // items_per_page
            current_page = 0
            
            def create_autoreact_list_content(page):
                start_idx = page * items_per_page
                end_idx = start_idx + items_per_page
                page_autoreacts = autoreacts[start_idx:end_idx]
                
                content = f"""## {AUTOACTION_ICON} Auto Reactions List
> Page {page + 1} of {total_pages} | Total: {len(autoreacts)} auto reactions

{SECTION_EMOJI} **__Configured Reactions__**
"""
                
                for trigger, emojis, match_type, created_at in page_autoreacts:
                    try:
                        if isinstance(created_at, str):
                            created_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                        else:
                            created_date = created_at
                        
                        ist_timezone = timezone(timedelta(hours=5, minutes=30))
                        if created_date.tzinfo is None:
                            created_date = created_date.replace(tzinfo=timezone.utc)
                        
                        ist_time = created_date.astimezone(ist_timezone)
                        formatted_date = ist_time.strftime("%B %d, %Y at %I:%M %p IST")
                    except:
                        formatted_date = str(created_at)
                    
                    emoji_display = self.format_emojis_display(emojis)
                    
                    content += f"""
{ARROW_EMOJI} **Trigger:** {trigger}
└ **Reactions:** {emoji_display}
└ **Match Type:** {match_type.title()}
└ **Created:** {formatted_date}
"""
                
                return content
            
            if total_pages == 1:
                content = create_autoreact_list_content(0)
                view = create_v2_view(content)
                await ctx.send(view=view)
            else:
                view = AutoreactPaginationLayoutView(autoreacts, current_page, total_pages, create_autoreact_list_content, ctx.author, self)
                await ctx.send(view=view)
                
        except Exception as e:
            content = create_error_content("Database Error", f"Failed to list auto reactions: {str(e)}")
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
        
        guild_id = message.guild.id
        
        if guild_id in self.autoreacts:
            for autoreact in self.autoreacts[guild_id]:
                trigger = autoreact['trigger']
                emojis = autoreact['emojis']
                match_type = autoreact['match_type']
                
                matched = False
                if match_type == 'exact':
                    matched = message.content.lower() == trigger.lower()
                else:
                    matched = trigger.lower() in message.content.lower()
                
                if matched:
                    for emoji in self.parse_emojis_for_reaction(emojis):
                        try:
                            await message.add_reaction(emoji)
                        except Exception:
                            pass


async def setup(bot):
    await bot.add_cog(AutoReaction(bot))
