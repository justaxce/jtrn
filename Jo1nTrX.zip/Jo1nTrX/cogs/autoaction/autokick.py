import discord
import asyncio
import math
from datetime import datetime, timezone, timedelta
from discord.ext import commands
from discord import app_commands, ui
from Jo1nTrX.utils.component import bot_emoji

ARROW_EMOJI = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION_EMOJI = "<:jo1ntrx_right:1405095312456024127>"
SUCCESS_EMOJI = "<:jo1ntrx_tick:1405094884947267715>"
ERROR_EMOJI = "<a:Jo1nTrX_cross:1405094904568483880>"
MODERATION_ICON = "<:jo1ntrx_moderation:1405093582863339591>"


def create_v2_view(content: str, timeout: int = 300) -> ui.LayoutView:
    view = ui.LayoutView(timeout=timeout)
    container = ui.Container(ui.TextDisplay(content))
    view.add_item(container)
    return view


def create_error_content(title: str, description: str) -> str:
    return f"""## {ERROR_EMOJI} {title}
> {description}"""


def create_success_content(title: str, description: str) -> str:
    return f"""## {SUCCESS_EMOJI} {title}
> {description}"""


class AutokickPaginationLayoutView(ui.LayoutView):
    def __init__(self, rules, guild, author, bot, items_per_page=5):
        super().__init__(timeout=300)
        self.rules = rules
        self.guild = guild
        self.author = author
        self.bot = bot
        self.items_per_page = items_per_page
        self.current_page = 0
        self.total_pages = max(1, math.ceil(len(rules) / items_per_page))
        self._setup_view()
    
    def get_condition_display(self, condition_type):
        condition_map = {
            'username': 'Specific Username',
            'display_name': 'Specific Display Name',
            'underage': 'Specific Underage',
            'default_pfp': 'Default PFP'
        }
        return condition_map.get(condition_type, condition_type)
    
    def _get_page_content(self, page):
        if not self.rules:
            return f"""## {MODERATION_ICON} Autokick Rules
> No autokick rules configured for this server.

{SECTION_EMOJI} **__Quick Start__**

{ARROW_EMOJI} Use `/autokick set` to create a new rule."""
        
        start_idx = page * self.items_per_page
        end_idx = start_idx + self.items_per_page
        page_rules = self.rules[start_idx:end_idx]
        
        content = f"""## {MODERATION_ICON} Autokick Rules
> Page {page + 1} of {self.total_pages}

{SECTION_EMOJI} **__Active Rules__**
"""
        
        for i, rule in enumerate(page_rules, start=start_idx + 1):
            condition_display = self.get_condition_display(rule['condition_type'])
            value_display = rule['condition_value'] if rule['condition_value'] else "No value"
            
            content += f"""
{ARROW_EMOJI} **Rule #{i}**
└ **Id:** `{rule['id']}`
└ **Added By:** <@{rule['added_by']}>
└ **Condition:** {condition_display}
└ **Value:** {value_display}
"""
        
        return content
    
    def _setup_view(self):
        content = self._get_page_content(self.current_page)
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutokickPaginationLayoutView(self.rules, self.guild, self.author, self.bot, self.items_per_page)
            new_view.current_page = 0
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutokickPaginationLayoutView(self.rules, self.guild, self.author, self.bot, self.items_per_page)
            new_view.current_page = max(0, self.current_page - 1)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutokickPaginationLayoutView(self.rules, self.guild, self.author, self.bot, self.items_per_page)
            new_view.current_page = min(self.total_pages - 1, self.current_page + 1)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutokickPaginationLayoutView(self.rules, self.guild, self.author, self.bot, self.items_per_page)
            new_view.current_page = self.total_pages - 1
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class Autokick(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    async def check_owner_or_extraowner(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == interaction.guild.owner_id:
            return True
        is_extra = await self.bot.db.is_extra_owner(interaction.guild.id, interaction.user.id)
        return is_extra
    
    autokick_group = app_commands.Group(name='autokick', description='Autokick management commands')
    
    @autokick_group.command(name='set', description='Set an autokick rule')
    @app_commands.describe(
        condition='The condition type for autokick',
        value='Value for the condition (required for Username, Display Name, Underage)'
    )
    @app_commands.choices(condition=[
        app_commands.Choice(name='Specific Username', value='username'),
        app_commands.Choice(name='Specific Display Name', value='display_name'),
        app_commands.Choice(name='Specific Underage', value='underage'),
        app_commands.Choice(name='Default PFP', value='default_pfp')
    ])
    async def autokick_set(
        self, 
        interaction: discord.Interaction, 
        condition: app_commands.Choice[str],
        value: str = None
    ):
        if not await self.check_owner_or_extraowner(interaction):
            content = create_error_content("Permission Denied", "Only the server owner or extra owners can use this command.")
            view = create_v2_view(content)
            return await interaction.response.send_message(view=view, ephemeral=True)
        
        condition_type = condition.value
        
        if condition_type in ['username', 'display_name', 'underage'] and not value:
            content = f"""## {ERROR_EMOJI} Missing Value
> Value is required for **{condition.name}** condition.

{SECTION_EMOJI} **__Usage__**

{ARROW_EMOJI} **Username/Display Name:** Enter the text to match
{ARROW_EMOJI} **Underage:** Enter days (e.g., `7` for 7 days)"""
            
            view = create_v2_view(content)
            return await interaction.response.send_message(view=view, ephemeral=True)
        
        if condition_type == 'underage':
            try:
                days = int(value.replace('d', '').replace('D', '').strip())
                if days <= 0:
                    raise ValueError("Days must be positive")
                value = str(days)
            except (ValueError, AttributeError):
                content = f"""## {ERROR_EMOJI} Invalid Value
> Invalid underage value. Please enter a number of days.

{ARROW_EMOJI} **Example:** `7` for 7 days"""
                
                view = create_v2_view(content)
                return await interaction.response.send_message(view=view, ephemeral=True)
        
        if condition_type == 'default_pfp':
            value = None
        
        await interaction.response.defer()
        
        try:
            rule_id = await self.bot.db.add_autokick_rule(
                interaction.guild.id,
                condition_type,
                value,
                interaction.user.id
            )
            
            condition_display = {
                'username': 'Specific Username',
                'display_name': 'Specific Display Name',
                'underage': 'Specific Underage',
                'default_pfp': 'Default PFP'
            }.get(condition_type, condition_type)
            
            value_display = value if value else "No value"
            if condition_type == 'underage' and value:
                value_display = f"{value} days"
            
            content = f"""## {MODERATION_ICON} Autokick Rule Added
> Successfully added new autokick rule.

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Rule ID:** `{rule_id}`
{ARROW_EMOJI} **Condition:** {condition_display}
{ARROW_EMOJI} **Value:** {value_display}
{ARROW_EMOJI} **Added By:** {interaction.user.mention}"""
            
            view = create_v2_view(content)
            await interaction.followup.send(view=view)
            
        except Exception as e:
            content = create_error_content("Error", f"Failed to add autokick rule: {str(e)}")
            view = create_v2_view(content)
            await interaction.followup.send(view=view)
    
    @autokick_group.command(name='remove', description='Remove an autokick rule by ID')
    @app_commands.describe(id='The ID of the autokick rule to remove')
    async def autokick_remove(self, interaction: discord.Interaction, id: int):
        if not await self.check_owner_or_extraowner(interaction):
            content = create_error_content("Permission Denied", "Only the server owner or extra owners can use this command.")
            view = create_v2_view(content)
            return await interaction.response.send_message(view=view, ephemeral=True)
        
        await interaction.response.defer()
        
        try:
            rule = await self.bot.db.get_autokick_rule_by_id(interaction.guild.id, id)
            
            if not rule:
                content = create_error_content("Rule Not Found", f"No autokick rule found with ID `{id}` in this server.")
                view = create_v2_view(content)
                return await interaction.followup.send(view=view)
            
            removed = await self.bot.db.remove_autokick_rule(interaction.guild.id, id)
            
            if removed:
                condition_display = {
                    'username': 'Specific Username',
                    'display_name': 'Specific Display Name',
                    'underage': 'Specific Underage',
                    'default_pfp': 'Default PFP'
                }.get(rule['condition_type'], rule['condition_type'])
                
                value_display = rule['condition_value'] if rule['condition_value'] else "No value"
                
                content = f"""## {MODERATION_ICON} Autokick Rule Removed
> Successfully removed autokick rule.

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Rule ID:** `{id}`
{ARROW_EMOJI} **Condition:** {condition_display}
{ARROW_EMOJI} **Value:** {value_display}"""
                
                view = create_v2_view(content)
                await interaction.followup.send(view=view)
            else:
                content = create_error_content("Error", f"Failed to remove autokick rule with ID `{id}`.")
                view = create_v2_view(content)
                await interaction.followup.send(view=view)
                
        except Exception as e:
            content = create_error_content("Error", f"Failed to remove autokick rule: {str(e)}")
            view = create_v2_view(content)
            await interaction.followup.send(view=view)
    
    @autokick_group.command(name='show', description='Show all autokick rules')
    async def autokick_show(self, interaction: discord.Interaction):
        if not await self.check_owner_or_extraowner(interaction):
            content = create_error_content("Permission Denied", "Only the server owner or extra owners can use this command.")
            view = create_v2_view(content)
            return await interaction.response.send_message(view=view, ephemeral=True)
        
        await interaction.response.defer()
        
        try:
            rules = await self.bot.db.get_autokick_rules(interaction.guild.id)
            
            view = AutokickPaginationLayoutView(rules, interaction.guild, interaction.user, self.bot)
            
            await interaction.followup.send(view=view)
            
        except Exception as e:
            content = create_error_content("Error", f"Failed to fetch autokick rules: {str(e)}")
            view = create_v2_view(content)
            await interaction.followup.send(view=view)
    
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.bot:
            return
        
        try:
            rules = await self.bot.db.get_autokick_rules(member.guild.id)
            
            if not rules:
                return
            
            for rule in rules:
                condition_type = rule['condition_type']
                condition_value = rule['condition_value']
                should_kick = False
                kick_reason_detail = ""
                
                if condition_type == 'username':
                    if condition_value and condition_value.lower() in member.name.lower():
                        should_kick = True
                        kick_reason_detail = f"Specific Username ({condition_value})"
                
                elif condition_type == 'display_name':
                    display_name = member.display_name or member.name
                    if condition_value and condition_value.lower() in display_name.lower():
                        should_kick = True
                        kick_reason_detail = f"Specific Display Name ({condition_value})"
                
                elif condition_type == 'underage':
                    if condition_value:
                        try:
                            days = int(condition_value)
                            account_age = (datetime.now(timezone.utc) - member.created_at).days
                            if account_age < days:
                                should_kick = True
                                kick_reason_detail = f"Specific Underage ({days} days)"
                        except (ValueError, TypeError):
                            pass
                
                elif condition_type == 'default_pfp':
                    if member.avatar is None:
                        should_kick = True
                        kick_reason_detail = "Default PFP"
                
                if should_kick:
                    try:
                        kick_reason = f"kicked | Auto kick - {kick_reason_detail}"
                        await member.kick(reason=kick_reason)
                        print(f"[Autokick] Kicked {member} from {member.guild.name}: {kick_reason}")
                    except discord.Forbidden:
                        print(f"[Autokick] Failed to kick {member} from {member.guild.name}: Missing permissions")
                    except Exception as e:
                        print(f"[Autokick] Error kicking {member}: {e}")
                    return
                    
        except Exception as e:
            print(f"[Autokick] Error processing member join: {e}")


async def setup(bot):
    await bot.add_cog(Autokick(bot))
