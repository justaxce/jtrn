import discord
from discord.ext import commands
from discord import app_commands, ui
from datetime import datetime, timezone, timedelta
from Jo1nTrX.utils.component import bot_emoji

ARROW_EMOJI = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION_EMOJI = "<:jo1ntrx_right:1405095312456024127>"
SUCCESS_EMOJI = "<:jo1ntrx_tick:1405094884947267715>"
ERROR_EMOJI = "<a:Jo1nTrX_cross:1405094904568483880>"
AUTOACTION_ICON = "<:Jo1nTrX_autoaction:1410988700799598602>"


def create_v2_view(content: str, timeout: int = 300) -> ui.LayoutView:
    view = ui.LayoutView(timeout=timeout)
    container = ui.Container(ui.TextDisplay(content))
    view.add_item(container)
    return view


def create_error_content(title: str, description: str) -> str:
    return f"""## {ERROR_EMOJI} {title}
> {description}"""


def create_success_content(title: str, description: str) -> str:
    return f"""## {SUCCESS_EMOJI} {title}
> {description}"""


class AutorolePaginationLayoutView(ui.LayoutView):
    def __init__(self, data, current_page, total_pages, create_content_func, author, cog, guild):
        super().__init__(timeout=300)
        self.data = data
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_content = create_content_func
        self.author = author
        self.cog = cog
        self.guild = guild
        self._setup_view()
    
    def _setup_view(self):
        content = self.create_content(self.current_page)
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutorolePaginationLayoutView(self.data, 0, self.total_pages, self.create_content, self.author, self.cog, self.guild)
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutorolePaginationLayoutView(self.data, max(0, self.current_page - 1), self.total_pages, self.create_content, self.author, self.cog, self.guild)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutorolePaginationLayoutView(self.data, min(self.total_pages - 1, self.current_page + 1), self.total_pages, self.create_content, self.author, self.cog, self.guild)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutorolePaginationLayoutView(self.data, self.total_pages - 1, self.total_pages, self.create_content, self.author, self.cog, self.guild)
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class AutoRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    async def is_premium_user(self, user_id: int) -> bool:
        try:
            premium_users = await self.bot.db.list_premium_users()
            return user_id in [user[0] for user in premium_users] if premium_users else False
        except Exception:
            return False
    
    @commands.hybrid_group(name='autorole', fallback='help')
    async def autorole(self, ctx):
        """Auto role management commands"""
        content = f"""## {AUTOACTION_ICON} Auto Role Commands
> Available auto role commands

{SECTION_EMOJI} **__Human Autoroles__**

{ARROW_EMOJI} `autorole humans add <role1> [role2] [role3]...` - Add human autoroles
{ARROW_EMOJI} `autorole humans list` - List all human autoroles

{SECTION_EMOJI} **__Bot Autoroles__**

{ARROW_EMOJI} `autorole bots <role>` - Set bot autorole

{SECTION_EMOJI} **__Limits__**

{ARROW_EMOJI} Normal users: 5 roles
{ARROW_EMOJI} Premium users: 10 roles"""
        
        view = create_v2_view(content)
        await ctx.send(view=view)
    
    @autorole.group(name='humans', fallback='help')
    async def humans(self, ctx):
        """Human autorole management commands"""
        content = f"""## {AUTOACTION_ICON} Human Autorole Commands
> Available human autorole commands

{SECTION_EMOJI} **__Commands__**

{ARROW_EMOJI} `autorole humans add <role1> [role2] [role3]...` - Add human autoroles
{ARROW_EMOJI} `autorole humans list` - List all human autoroles

{SECTION_EMOJI} **__Limits__**

{ARROW_EMOJI} Normal users: 5 autoroles
{ARROW_EMOJI} Premium users: 10 autoroles"""
        
        view = create_v2_view(content)
        await ctx.send(view=view)
    
    @humans.command(name='add')
    @app_commands.describe(roles="The roles to add as autoroles (separate with spaces)")
    async def humans_add(self, ctx, *, roles: str):
        """Add human autoroles"""
        if not ctx.author.guild_permissions.manage_guild:
            content = create_error_content("Missing Permissions", "You need 'Manage Server' permission to use this command.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        role_list = []
        for role_str in roles.split():
            role = None
            if role_str.startswith('<@&') and role_str.endswith('>'):
                try:
                    role_id = int(role_str[3:-1])
                    role = ctx.guild.get_role(role_id)
                except ValueError:
                    pass
            else:
                try:
                    role_id = int(role_str)
                    role = ctx.guild.get_role(role_id)
                except ValueError:
                    pass
            
            if role:
                role_list.append(role)
            else:
                content = create_error_content("Invalid Role", f"Role not found: `{role_str}`")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
        
        if not role_list:
            content = create_error_content("No Valid Roles", "Please provide at least one valid role!")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        current_autoroles = await self.bot.db.get_human_autoroles(ctx.guild.id)
        current_count = len(current_autoroles)
        
        premium_info = await self.bot.db.check_premium_user(ctx.author.id, ctx.guild.id)
        is_premium = premium_info.get('has_premium', False)
        max_roles = 10 if is_premium else 5
        
        new_total = current_count + len(role_list)
        if new_total > max_roles:
            content = create_error_content("Role Limit Exceeded", f"Cannot add {len(role_list)} roles. Current: {current_count}, Limit: {max_roles} ({'Premium' if is_premium else 'Normal'} user)\nYou can add {max_roles - current_count} more roles.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        added_roles = []
        failed_roles = []
        
        for role in role_list:
            if any(existing_role_id == role.id for existing_role_id, _ in current_autoroles):
                failed_roles.append(f"{role.mention} (already exists)")
                continue
            
            success = await self.bot.db.add_human_autorole(ctx.guild.id, role.id)
            if success:
                added_roles.append(role)
            else:
                failed_roles.append(f"{role.mention} (database error)")
        
        if added_roles:
            role_mentions = [role.mention for role in added_roles]
            
            content = f"""## {SUCCESS_EMOJI} Human Autoroles Added
> Successfully added {len(added_roles)} autorole(s)

{SECTION_EMOJI} **__Added Roles__**

{ARROW_EMOJI} {', '.join(role_mentions)}"""
            
            if failed_roles:
                content += f"\n\n{SECTION_EMOJI} **__Failed__**\n"
                for failed in failed_roles:
                    content += f"\n{ARROW_EMOJI} {failed}"
            
            content += f"\n\n{SECTION_EMOJI} **__Info__**\n\n{ARROW_EMOJI} These roles will be automatically assigned to humans when they join.\n{ARROW_EMOJI} Total autoroles: {current_count + len(added_roles)}/{max_roles}"
            
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            content = create_error_content("Addition Failed", "No roles were added successfully.")
            if failed_roles:
                content += f"\n\n{SECTION_EMOJI} **__Reasons__**\n"
                for failed in failed_roles:
                    content += f"\n{ARROW_EMOJI} {failed}"
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @humans.command(name='list')
    async def humans_list(self, ctx):
        """List all human autoroles with pagination"""
        try:
            autoroles = await self.bot.db.get_human_autoroles(ctx.guild.id)
            
            if not autoroles:
                content = f"""## {AUTOACTION_ICON} No Human Autoroles
> This server has no human autoroles set up yet.

{ARROW_EMOJI} Use `autorole humans add <role>` to create your first human autorole!"""
                
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            items_per_page = 10
            total_pages = (len(autoroles) + items_per_page - 1) // items_per_page
            current_page = 0
            
            def create_autorole_list_content(page):
                start_idx = page * items_per_page
                end_idx = start_idx + items_per_page
                page_autoroles = autoroles[start_idx:end_idx]
                
                content = f"""## {AUTOACTION_ICON} Human Autoroles List
> Page {page + 1} of {total_pages} | Total: {len(autoroles)} autoroles

{SECTION_EMOJI} **__Configured Autoroles__**
"""
                
                for i, (role_id, created_at) in enumerate(page_autoroles, start=start_idx + 1):
                    role = ctx.guild.get_role(role_id)
                    role_display = role.mention if role else f"Unknown Role ({role_id})"
                    
                    try:
                        if isinstance(created_at, str):
                            created_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                        else:
                            created_date = created_at
                        
                        ist_timezone = timezone(timedelta(hours=5, minutes=30))
                        if created_date.tzinfo is None:
                            created_date = created_date.replace(tzinfo=timezone.utc)
                        
                        ist_time = created_date.astimezone(ist_timezone)
                        formatted_date = ist_time.strftime("%B %d, %Y at %I:%M %p IST")
                    except:
                        formatted_date = str(created_at)
                    
                    content += f"\n{ARROW_EMOJI} **{i}.** {role_display}\n└ Added: {formatted_date}\n"
                
                return content
            
            if total_pages == 1:
                content = create_autorole_list_content(0)
                view = create_v2_view(content)
                await ctx.send(view=view)
            else:
                view = AutorolePaginationLayoutView(autoroles, current_page, total_pages, create_autorole_list_content, ctx.author, self, ctx.guild)
                await ctx.send(view=view)
                
        except Exception as e:
            content = create_error_content("Database Error", f"Failed to list human autoroles: {str(e)}")
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @humans.command(name='remove')
    @app_commands.describe(role="The role to remove from autoroles")
    async def humans_remove(self, ctx, role: discord.Role):
        """Remove a human autorole"""
        if not ctx.author.guild_permissions.manage_guild:
            content = create_error_content("Missing Permissions", "You need 'Manage Server' permission to use this command.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        try:
            removed = await self.bot.db.remove_human_autorole(ctx.guild.id, role.id)
            
            if removed:
                content = f"""## {AUTOACTION_ICON} Human Autorole Removed
> Successfully removed {role.mention} from human autoroles."""
                
                view = create_v2_view(content)
                await ctx.send(view=view)
            else:
                content = create_error_content("Not Found", f"{role.mention} is not in the human autoroles list.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                
        except Exception as e:
            content = create_error_content("Database Error", f"Failed to remove human autorole: {str(e)}")
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @autorole.command(name='bots')
    @app_commands.describe(role="The role to assign to bots when they join")
    async def bots_set(self, ctx, role: discord.Role):
        """Set bot autorole"""
        if not ctx.author.guild_permissions.manage_guild:
            content = create_error_content("Missing Permissions", "You need 'Manage Server' permission to use this command.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        try:
            await self.bot.db.set_bot_autorole(ctx.guild.id, role.id)
            
            content = f"""## {AUTOACTION_ICON} Bot Autorole Set
> Successfully set bot autorole!

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Role:** {role.mention}
{ARROW_EMOJI} This role will be automatically assigned to bots when they join."""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except Exception as e:
            content = create_error_content("Database Error", f"Failed to set bot autorole: {str(e)}")
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        try:
            if member.bot:
                bot_autorole_id = await self.bot.db.get_bot_autorole(member.guild.id)
                if bot_autorole_id:
                    role = member.guild.get_role(bot_autorole_id)
                    if role:
                        try:
                            await member.add_roles(role, reason="Bot autorole")
                        except Exception:
                            pass
            else:
                human_autoroles = await self.bot.db.get_human_autoroles(member.guild.id)
                for role_id, _ in human_autoroles:
                    role = member.guild.get_role(role_id)
                    if role:
                        try:
                            await member.add_roles(role, reason="Human autorole")
                        except Exception:
                            pass
        except Exception as e:
            print(f"Error processing autorole for member {member}: {e}")


async def setup(bot):
    await bot.add_cog(AutoRole(bot))
