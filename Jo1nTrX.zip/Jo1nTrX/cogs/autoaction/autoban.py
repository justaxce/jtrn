import discord
import math
from datetime import datetime, timezone, timedelta
from discord.ext import commands
from discord import app_commands, ui
from Jo1nTrX.utils.component import bot_emoji

ARROW_EMOJI = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION_EMOJI = "<:jo1ntrx_right:1405095312456024127>"
SUCCESS_EMOJI = "<:jo1ntrx_tick:1405094884947267715>"
ERROR_EMOJI = "<a:Jo1nTrX_cross:1405094904568483880>"
MODERATION_ICON = "<:jo1ntrx_moderation:1405093582863339591>"


def create_v2_view(content: str, timeout: int = 300) -> ui.LayoutView:
    view = ui.LayoutView(timeout=timeout)
    container = ui.Container(ui.TextDisplay(content))
    view.add_item(container)
    return view


def create_error_content(title: str, description: str) -> str:
    return f"""## {ERROR_EMOJI} {title}
> {description}"""


def create_success_content(title: str, description: str) -> str:
    return f"""## {SUCCESS_EMOJI} {title}
> {description}"""


class AutobanPaginationLayoutView(ui.LayoutView):
    def __init__(self, rules, guild, author, bot, items_per_page=5):
        super().__init__(timeout=300)
        self.rules = rules
        self.guild = guild
        self.author = author
        self.bot = bot
        self.items_per_page = items_per_page
        self.current_page = 0
        self.total_pages = max(1, math.ceil(len(rules) / items_per_page))
        self._setup_view()
    
    def format_remaining_time(self, expires_at):
        if not expires_at:
            return "Unknown"
        
        now = datetime.now(timezone.utc)
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        
        remaining = expires_at - now
        if remaining.total_seconds() <= 0:
            return "Expired"
        
        total_seconds = int(remaining.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        
        if hours > 0:
            return f"{hours}h {minutes}m remaining"
        else:
            return f"{minutes}m remaining"
    
    def _get_page_content(self, page):
        if not self.rules:
            return f"""## {MODERATION_ICON} Autoban Rules (Active Lockdowns)
> No active autoban rules configured for this server.

{SECTION_EMOJI} **__Quick Start__**

{ARROW_EMOJI} Use `/autoban set <hours>` to start a lockdown."""
        
        start_idx = page * self.items_per_page
        end_idx = start_idx + self.items_per_page
        page_rules = self.rules[start_idx:end_idx]
        
        content = f"""## {MODERATION_ICON} Autoban Rules (Active Lockdowns)
> Page {page + 1} of {self.total_pages} | All new joiners will be banned while active

{SECTION_EMOJI} **__Active Rules__**
"""
        
        for i, rule in enumerate(page_rules, start=start_idx + 1):
            remaining = self.format_remaining_time(rule['expires_at'])
            expires_timestamp = int(rule['expires_at'].timestamp()) if rule['expires_at'] else 0
            
            content += f"""
{ARROW_EMOJI} **Rule #{i}**
└ **Id:** `{rule['id']}`
└ **Added By:** <@{rule['added_by']}>
└ **Duration:** {rule['duration_hours']} hour(s)
└ **Expires:** <t:{expires_timestamp}:R>
└ **Status:** {remaining}
"""
        
        return content
    
    def _setup_view(self):
        content = self._get_page_content(self.current_page)
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.current_page = 0
            new_view = AutobanPaginationLayoutView(self.rules, self.guild, self.author, self.bot, self.items_per_page)
            new_view.current_page = 0
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutobanPaginationLayoutView(self.rules, self.guild, self.author, self.bot, self.items_per_page)
            new_view.current_page = max(0, self.current_page - 1)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutobanPaginationLayoutView(self.rules, self.guild, self.author, self.bot, self.items_per_page)
            new_view.current_page = min(self.total_pages - 1, self.current_page + 1)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutobanPaginationLayoutView(self.rules, self.guild, self.author, self.bot, self.items_per_page)
            new_view.current_page = self.total_pages - 1
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class Autoban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    async def check_owner_or_extraowner(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == interaction.guild.owner_id:
            return True
        is_extra = await self.bot.db.is_extra_owner(interaction.guild.id, interaction.user.id)
        return is_extra
    
    autoban_group = app_commands.Group(name='autoban', description='Autoban management - temporary lockdown to ban all new joiners')
    
    @autoban_group.command(name='set', description='Start autoban lockdown - ban ALL new joiners for specified hours')
    @app_commands.describe(
        hours='Duration in hours - all new joiners will be banned during this time'
    )
    async def autoban_set(
        self, 
        interaction: discord.Interaction, 
        hours: int
    ):
        if not await self.check_owner_or_extraowner(interaction):
            content = create_error_content("Permission Denied", "Only the server owner or extra owners can use this command.")
            view = create_v2_view(content)
            return await interaction.response.send_message(view=view, ephemeral=True)
        
        if hours <= 0:
            content = create_error_content("Invalid Value", f"Hours must be a positive number.\n\n{ARROW_EMOJI} **Example:** `2` for 2 hours lockdown")
            view = create_v2_view(content)
            return await interaction.response.send_message(view=view, ephemeral=True)
        
        if hours > 168:
            content = create_error_content("Invalid Value", "Maximum lockdown duration is 168 hours (1 week).")
            view = create_v2_view(content)
            return await interaction.response.send_message(view=view, ephemeral=True)
        
        await interaction.response.defer()
        
        try:
            result = await self.bot.db.add_autoban_rule(
                interaction.guild.id,
                hours,
                interaction.user.id
            )
            
            rule_id = result['id']
            expires_at = result['expires_at']
            expires_timestamp = int(expires_at.timestamp()) if expires_at else 0
            
            content = f"""## {MODERATION_ICON} Autoban Lockdown Started
> Server lockdown is now active!

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Rule ID:** `{rule_id}`
{ARROW_EMOJI} **Duration:** {hours} hour(s)
{ARROW_EMOJI} **Expires:** <t:{expires_timestamp}:F> (<t:{expires_timestamp}:R>)
{ARROW_EMOJI} **Added By:** {interaction.user.mention}

{SECTION_EMOJI} **__Warning__**

{ARROW_EMOJI} **ALL** new members joining this server will be automatically banned until the lockdown expires."""
            
            view = create_v2_view(content)
            await interaction.followup.send(view=view)
            
        except Exception as e:
            content = create_error_content("Error", f"Failed to start autoban lockdown: {str(e)}")
            view = create_v2_view(content)
            await interaction.followup.send(view=view)
    
    @autoban_group.command(name='remove', description='Remove an autoban rule by ID (end lockdown early)')
    @app_commands.describe(id='The ID of the autoban rule to remove')
    async def autoban_remove(self, interaction: discord.Interaction, id: int):
        if not await self.check_owner_or_extraowner(interaction):
            content = create_error_content("Permission Denied", "Only the server owner or extra owners can use this command.")
            view = create_v2_view(content)
            return await interaction.response.send_message(view=view, ephemeral=True)
        
        await interaction.response.defer()
        
        try:
            rule = await self.bot.db.get_autoban_rule_by_id(interaction.guild.id, id)
            
            if not rule:
                content = create_error_content("Rule Not Found", f"No autoban rule found with ID `{id}` in this server.")
                view = create_v2_view(content)
                return await interaction.followup.send(view=view)
            
            removed = await self.bot.db.remove_autoban_rule(interaction.guild.id, id)
            
            if removed:
                content = f"""## {MODERATION_ICON} Autoban Lockdown Ended
> Successfully removed autoban rule.

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Rule ID:** `{id}`
{ARROW_EMOJI} **Duration was:** {rule['duration_hours']} hour(s)

{SECTION_EMOJI} **__Status__**

{ARROW_EMOJI} New members can now join without being auto-banned."""
                
                view = create_v2_view(content)
                await interaction.followup.send(view=view)
            else:
                content = create_error_content("Error", f"Failed to remove autoban rule with ID `{id}`.")
                view = create_v2_view(content)
                await interaction.followup.send(view=view)
                
        except Exception as e:
            content = create_error_content("Error", f"Failed to remove autoban rule: {str(e)}")
            view = create_v2_view(content)
            await interaction.followup.send(view=view)
    
    @autoban_group.command(name='show', description='Show all active autoban rules (lockdowns)')
    async def autoban_show(self, interaction: discord.Interaction):
        if not await self.check_owner_or_extraowner(interaction):
            content = create_error_content("Permission Denied", "Only the server owner or extra owners can use this command.")
            view = create_v2_view(content)
            return await interaction.response.send_message(view=view, ephemeral=True)
        
        await interaction.response.defer()
        
        try:
            rules = await self.bot.db.get_active_autoban_rules(interaction.guild.id)
            
            view = AutobanPaginationLayoutView(rules, interaction.guild, interaction.user, self.bot)
            
            await interaction.followup.send(view=view)
            
        except Exception as e:
            content = create_error_content("Error", f"Failed to fetch autoban rules: {str(e)}")
            view = create_v2_view(content)
            await interaction.followup.send(view=view)
    
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.bot:
            return
        
        try:
            rules = await self.bot.db.get_active_autoban_rules(member.guild.id)
            
            if not rules:
                return
            
            rule = rules[0]
            try:
                ban_reason = f"banned | Auto ban lockdown - Server is in lockdown mode (Rule #{rule['id']})"
                await member.ban(reason=ban_reason)
                print(f"[Autoban] Banned {member} from {member.guild.name}: {ban_reason}")
            except discord.Forbidden:
                print(f"[Autoban] Failed to ban {member} from {member.guild.name}: Missing permissions")
            except Exception as e:
                print(f"[Autoban] Error banning {member}: {e}")
                    
        except Exception as e:
            print(f"[Autoban] Error processing member join: {e}")


async def setup(bot):
    await bot.add_cog(Autoban(bot))
