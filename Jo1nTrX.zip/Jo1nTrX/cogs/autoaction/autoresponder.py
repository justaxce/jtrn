import discord
from discord.ext import commands, tasks
from discord import app_commands, ui
import re
from datetime import datetime, timezone, timedelta
from Jo1nTrX.utils.component import bot_emoji

ARROW_EMOJI = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION_EMOJI = "<:jo1ntrx_right:1405095312456024127>"
SUCCESS_EMOJI = "<:jo1ntrx_tick:1405094884947267715>"
ERROR_EMOJI = "<a:Jo1nTrX_cross:1405094904568483880>"
AUTOACTION_ICON = "<:Jo1nTrX_autoaction:1410988700799598602>"


def create_v2_view(content: str, timeout: int = 300) -> ui.LayoutView:
    view = ui.LayoutView(timeout=timeout)
    container = ui.Container(ui.TextDisplay(content))
    view.add_item(container)
    return view


def create_error_content(title: str, description: str) -> str:
    return f"""## {ERROR_EMOJI} {title}
> {description}"""


def create_success_content(title: str, description: str) -> str:
    return f"""## {SUCCESS_EMOJI} {title}
> {description}"""


class AutoresponderPaginationLayoutView(ui.LayoutView):
    def __init__(self, data, current_page, total_pages, create_content_func, author, cog):
        super().__init__(timeout=300)
        self.data = data
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_content = create_content_func
        self.author = author
        self.cog = cog
        self._setup_view()
    
    def _setup_view(self):
        content = self.create_content(self.current_page)
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutoresponderPaginationLayoutView(self.data, 0, self.total_pages, self.create_content, self.author, self.cog)
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutoresponderPaginationLayoutView(self.data, max(0, self.current_page - 1), self.total_pages, self.create_content, self.author, self.cog)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutoresponderPaginationLayoutView(self.data, min(self.total_pages - 1, self.current_page + 1), self.total_pages, self.create_content, self.author, self.cog)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutoresponderPaginationLayoutView(self.data, self.total_pages - 1, self.total_pages, self.create_content, self.author, self.cog)
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class AutoResponder(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.autoresponders = {}
    
    async def cog_load(self):
        await self.refresh_cache()
        self.auto_refresh_cache.start()
    
    async def cog_unload(self):
        self.auto_refresh_cache.cancel()
    
    @tasks.loop(seconds=10)
    async def auto_refresh_cache(self):
        await self.refresh_cache()
    
    @auto_refresh_cache.before_loop
    async def before_auto_refresh(self):
        await self.bot.wait_until_ready()
    
    async def refresh_cache(self):
        try:
            autoresponders = await self.bot.db.get_all_autoresponders()
            self.autoresponders = {}
            for guild_id, trigger, reply, match_type, req_role, reaction_emojis, mode in autoresponders:
                if guild_id not in self.autoresponders:
                    self.autoresponders[guild_id] = []
                self.autoresponders[guild_id].append({
                    'trigger': trigger,
                    'reply': reply,
                    'match_type': match_type,
                    'required_role_id': req_role,
                    'reaction_emojis': reaction_emojis,
                    'mode': mode or 'normal'
                })
        except Exception as e:
            print(f"[AutoResponder] Error refreshing cache: {e}")
    
    async def is_premium_user(self, user_id: int) -> bool:
        try:
            premium_users = await self.bot.db.list_premium_users()
            return user_id in [user[0] for user in premium_users] if premium_users else False
        except Exception:
            return False
    
    async def get_auto_action_limits(self, user_id: int) -> float:
        if user_id in self.bot.config.BOT_OWNER_IDS:
            return float('inf')
        elif await self.is_premium_user(user_id):
            return 15
        else:
            return 5
    
    async def get_user_autoresponder_count(self, user_id: int, guild_id: int) -> int:
        try:
            count = await self.bot.db.get_user_autoresponder_count(user_id, guild_id)
            return count if count is not None else 0
        except Exception as e:
            print(f"Error getting user autoresponder count for user {user_id} in guild {guild_id}: {e}")
            return 0
    
    def parse_emojis(self, emoji_str):
        emoji_parts = [emoji.strip() for emoji in emoji_str.split(',')]
        if len(emoji_parts) > 5:
            emoji_parts = emoji_parts[:5]
        
        formatted_emojis = []
        for emoji in emoji_parts:
            if emoji:
                custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', emoji)
                if custom_emoji_match:
                    formatted_emojis.append(emoji)
                else:
                    formatted_emojis.append(emoji)
        
        return ','.join(formatted_emojis)
    
    def parse_emojis_for_reaction(self, emoji_str):
        if not emoji_str:
            return []
        
        emojis = []
        emoji_parts = [emoji.strip() for emoji in emoji_str.split(',')]
        
        for emoji in emoji_parts:
            if emoji:
                custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', emoji)
                if custom_emoji_match:
                    emojis.append(emoji)
                else:
                    emojis.append(emoji)
        
        return emojis
    
    def format_emojis_display(self, emojis_str):
        if not emojis_str:
            return "None"
        
        emoji_parts = [emoji.strip() for emoji in emojis_str.split(',')]
        validated_emojis = []
        invalid_emojis = []
        
        for emoji in emoji_parts:
            if emoji:
                custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', emoji)
                if custom_emoji_match:
                    emoji_id = int(custom_emoji_match.group(2))
                    emoji_obj = self.bot.get_emoji(emoji_id)
                    if emoji_obj:
                        validated_emojis.append(emoji)
                    else:
                        invalid_emojis.append(f"`{emoji}` ❌")
                else:
                    validated_emojis.append(emoji)
        
        result = " ".join(validated_emojis)
        if invalid_emojis:
            result += " " + " ".join(invalid_emojis)
        
        return result if result else "None"
    
    @commands.hybrid_group(name='autoresponder', fallback='help')
    async def autoresponder(self, ctx):
        """Auto responder management commands"""
        content = f"""## {AUTOACTION_ICON} Auto Responder Commands
> Available auto responder commands

{SECTION_EMOJI} **__Commands__**

{ARROW_EMOJI} `autoresponder add <trigger> <reply> <type> [mode] [role] [emojis]` - Add auto responder
{ARROW_EMOJI} `autoresponder delete <trigger>` - Remove auto responder
{ARROW_EMOJI} `autoresponder list` - List all auto responders

{SECTION_EMOJI} **__Match Types__**

{ARROW_EMOJI} `exact` - Trigger must match exactly
{ARROW_EMOJI} `contains` - Message must contain trigger

{SECTION_EMOJI} **__Response Modes__**

{ARROW_EMOJI} `reply` - Send response as a reply to the trigger message
{ARROW_EMOJI} `normal` - Send response normally (default)

{SECTION_EMOJI} **__Optional Parameters__**

{ARROW_EMOJI} `required_role` - Role user must have to trigger response
{ARROW_EMOJI} `reaction_emojis` - Emojis to react with (up to 5, separated by commas)"""
        
        view = create_v2_view(content)
        await ctx.send(view=view)
    
    @autoresponder.command(name='add')
    @app_commands.describe(
        trigger="The text that will trigger the response",
        reply="The message to reply with",
        match_type="Whether to match exactly or if message contains trigger",
        mode="How to send the response (reply to message or normal)",
        required_role="Role required to trigger the response (optional)",
        reaction_emojis="Emojis to react with (up to 5, separated by commas, optional)"
    )
    @app_commands.choices(
        match_type=[
            app_commands.Choice(name="Exact", value="exact"),
            app_commands.Choice(name="Contains", value="contains")
        ],
        mode=[
            app_commands.Choice(name="Reply", value="reply"),
            app_commands.Choice(name="Normal", value="normal")
        ]
    )
    async def autoresponder_add(self, ctx, trigger: str, reply: str, match_type: str = "contains", mode: str = "normal", required_role: discord.Role = None, reaction_emojis: str = None):
        """Add a new auto responder"""
        if not ctx.author.guild_permissions.manage_guild:
            content = create_error_content("Missing Permissions", "You need 'Manage Server' permission to use this command.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        user_limit = await self.get_auto_action_limits(ctx.author.id)
        if user_limit != float('inf'):
            current_count = await self.get_user_autoresponder_count(ctx.author.id, ctx.guild.id)
            if current_count >= user_limit:
                is_premium = await self.is_premium_user(ctx.author.id)
                if not is_premium:
                    content = f"""## {ERROR_EMOJI} Premium Required
> You don't have premium access to use this command!

{SECTION_EMOJI} **__Get Premium__**

{ARROW_EMOJI} To get premium access, join support server.
{ARROW_EMOJI} [Join our support server](https://discord.gg/PA6UhChxZY)"""
                else:
                    content = create_error_content("Limit Reached", f"You have reached your limit of {int(user_limit)} auto responders.\nPremium users can create up to 15 auto responders.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
        
        formatted_reaction_emojis = None
        if reaction_emojis:
            formatted_reaction_emojis = self.parse_emojis(reaction_emojis)
            
            if formatted_reaction_emojis:
                emoji_parts = [emoji.strip() for emoji in formatted_reaction_emojis.split(',')]
                invalid_emojis = []
                
                for emoji in emoji_parts:
                    if emoji:
                        custom_emoji_match = re.match(r'<a?:(\w+):(\d+)>', emoji)
                        if custom_emoji_match:
                            emoji_id = int(custom_emoji_match.group(2))
                            emoji_obj = self.bot.get_emoji(emoji_id)
                            if not emoji_obj:
                                invalid_emojis.append(emoji)
                
                if invalid_emojis:
                    content = create_error_content("Invalid Emojis", f"The following emojis are invalid or inaccessible: {', '.join(invalid_emojis)}\nPlease make sure the bot has access to these emojis or use different ones.")
                    view = create_v2_view(content)
                    await ctx.send(view=view)
                    return
        
        existing = await self.bot.db.get_guild_autoresponders(ctx.guild.id)
        for existing_trigger, _, _, _, _, _, _ in existing:
            if existing_trigger.lower() == trigger.lower():
                content = create_error_content("Trigger Already Exists", f"Auto responder with trigger `{trigger}` already exists!")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
        
        try:
            await self.bot.db.add_autoresponder(
                ctx.guild.id, 
                trigger, 
                reply, 
                match_type,
                required_role.id if required_role else None,
                formatted_reaction_emojis,
                mode,
                ctx.author.id
            )
            
            await self.refresh_cache()
            
            content = f"""## {AUTOACTION_ICON} Auto Responder Added
> Successfully added auto responder!

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Trigger:** `{trigger}`
{ARROW_EMOJI} **Reply:** {reply[:100]}{"..." if len(reply) > 100 else ""}
{ARROW_EMOJI} **Type:** {match_type.title()}
{ARROW_EMOJI} **Mode:** {mode.title()}"""
            
            if required_role:
                content += f"\n{ARROW_EMOJI} **Required Role:** {required_role.mention}"
            
            if formatted_reaction_emojis:
                content += f"\n{ARROW_EMOJI} **Reactions:** {self.format_emojis_display(formatted_reaction_emojis)}"
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except Exception as e:
            content = create_error_content("Database Error", f"Failed to add auto responder: {str(e)}")
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @autoresponder.command(name='delete')
    @app_commands.describe(trigger="The trigger text to remove")
    async def autoresponder_delete(self, ctx, *, trigger: str):
        """Delete an auto responder"""
        if not ctx.author.guild_permissions.manage_guild:
            content = create_error_content("Missing Permissions", "You need 'Manage Server' permission to use this command.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        try:
            deleted = await self.bot.db.delete_autoresponder(ctx.guild.id, trigger)
            
            if deleted:
                await self.refresh_cache()
                
                content = f"""## {AUTOACTION_ICON} Auto Responder Deleted
> Successfully deleted auto responder with trigger: `{trigger}`"""
                
                view = create_v2_view(content)
                await ctx.send(view=view)
            else:
                content = create_error_content("Not Found", f"No auto responder found with trigger: `{trigger}`")
                view = create_v2_view(content)
                await ctx.send(view=view)
                
        except Exception as e:
            content = create_error_content("Database Error", f"Failed to delete auto responder: {str(e)}")
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @autoresponder.command(name='list')
    async def autoresponder_list(self, ctx):
        """List all auto responders for the guild with pagination"""
        try:
            autoresponders = await self.bot.db.get_guild_autoresponders(ctx.guild.id)
            
            if not autoresponders:
                content = f"""## {AUTOACTION_ICON} No Auto Responders
> This server has no auto responders set up yet.

{ARROW_EMOJI} Use `autoresponder add <trigger> <reply> <type>` to create your first auto responder!"""
                
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            items_per_page = 5
            total_pages = (len(autoresponders) + items_per_page - 1) // items_per_page
            current_page = 0
            
            def create_autoresponder_list_content(page):
                start_idx = page * items_per_page
                end_idx = start_idx + items_per_page
                page_autoresponders = autoresponders[start_idx:end_idx]
                
                content = f"""## {AUTOACTION_ICON} Auto Responders List
> Page {page + 1} of {total_pages} | Total: {len(autoresponders)} auto responders

{SECTION_EMOJI} **__Configured Responders__**
"""
                
                for trigger, reply, match_type, req_role_id, reaction_emojis, mode, created_at in page_autoresponders:
                    try:
                        if isinstance(created_at, str):
                            created_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                        else:
                            created_date = created_at
                        
                        ist_timezone = timezone(timedelta(hours=5, minutes=30))
                        if created_date.tzinfo is None:
                            created_date = created_date.replace(tzinfo=timezone.utc)
                        
                        ist_time = created_date.astimezone(ist_timezone)
                        formatted_date = ist_time.strftime("%B %d, %Y at %I:%M %p IST")
                    except:
                        formatted_date = str(created_at)
                    
                    display_reply = reply[:100] + "..." if len(reply) > 100 else reply
                    
                    content += f"""
{ARROW_EMOJI} **Trigger:** {trigger}
└ **Reply:** {display_reply}
└ **Match Type:** {match_type.title()}
└ **Mode:** {(mode or 'normal').title()}"""
                    
                    if req_role_id:
                        role = ctx.guild.get_role(req_role_id)
                        role_name = role.name if role else f"Role ID: {req_role_id}"
                        content += f"\n└ **Required Role:** {role_name}"
                    
                    if reaction_emojis:
                        emoji_display = self.format_emojis_display(reaction_emojis)
                        content += f"\n└ **Reactions:** {emoji_display}"
                    
                    content += f"\n└ **Created:** {formatted_date}\n"
                
                return content
            
            if total_pages == 1:
                content = create_autoresponder_list_content(0)
                view = create_v2_view(content)
                await ctx.send(view=view)
            else:
                view = AutoresponderPaginationLayoutView(autoresponders, current_page, total_pages, create_autoresponder_list_content, ctx.author, self)
                await ctx.send(view=view)
                
        except Exception as e:
            content = create_error_content("Database Error", f"Failed to list auto responders: {str(e)}")
            view = create_v2_view(content)
            await ctx.send(view=view)
    
    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
        
        guild_id = message.guild.id
        
        if guild_id in self.autoresponders:
            for autoresponder in self.autoresponders[guild_id]:
                trigger = autoresponder['trigger']
                reply = autoresponder['reply']
                match_type = autoresponder['match_type']
                required_role_id = autoresponder['required_role_id']
                reaction_emojis = autoresponder['reaction_emojis']
                mode = autoresponder['mode']
                
                if required_role_id:
                    member = message.author
                    role = message.guild.get_role(required_role_id)
                    if not role or role not in member.roles:
                        continue
                
                matched = False
                if match_type == 'exact':
                    matched = message.content.lower() == trigger.lower()
                else:
                    matched = trigger.lower() in message.content.lower()
                
                if matched:
                    try:
                        if mode == 'reply':
                            await message.reply(reply)
                        else:
                            await message.channel.send(reply)
                        
                        if reaction_emojis:
                            for emoji in self.parse_emojis_for_reaction(reaction_emojis):
                                try:
                                    await message.add_reaction(emoji)
                                except Exception:
                                    pass
                    except Exception:
                        pass


async def setup(bot):
    await bot.add_cog(AutoResponder(bot))
