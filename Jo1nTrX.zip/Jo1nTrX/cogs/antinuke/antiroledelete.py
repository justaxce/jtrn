import discord
from discord.ext import commands
import asyncio
import time

class AntiRoleDelete(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.engine = None
    
    async def cog_load(self):
        """Initialize engine"""
        from .antinuke_helper import AntiNukeEngine
        if not hasattr(self.bot, 'antinuke_engine'):
            self.bot.antinuke_engine = AntiNukeEngine(self.bot)
        self.engine = self.bot.antinuke_engine

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        """Signal emitter"""
        if self.engine:
            # Pass full role data for recovery
            self.engine.signal(role.guild.id, 'rldl', {
                'role_id': role.id,
                'role_name': role.name,
                'permissions': role.permissions,
                'color': role.color,
                'hoist': role.hoist,
                'mentionable': role.mentionable
            })

async def setup(bot):
    await bot.add_cog(AntiRoleDelete(bot))
