import discord
from discord.ext import commands
import asyncio
import time

class AntiEveryone(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.helper = None
    
    async def cog_load(self):
        """Initialize helper after cog is loaded"""
        from .antinuke_helper import AntiNukeHelper
        self.helper = AntiNukeHelper(self.bot)

    @commands.Cog.listener()
    async def on_message(self, message):
        if not message.guild or message.author.bot: return
        if not hasattr(self.bot, 'antinuke_engine'): return
        
        if message.mention_everyone:
            self.bot.antinuke_engine.signal(message.guild.id, 'meneve', {'message': message})

async def setup(bot):
    await bot.add_cog(AntiEveryone(bot))
