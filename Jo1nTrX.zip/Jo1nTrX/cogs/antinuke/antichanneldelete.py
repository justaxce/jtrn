import discord
from discord.ext import commands
import asyncio
import time

class AntiChannelDelete(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.engine = None
    
    async def cog_load(self):
        """Initialize engine after cog is loaded"""
        from .antinuke_helper import AntiNukeEngine
        if not hasattr(self.bot, 'antinuke_engine'):
            self.bot.antinuke_engine = AntiNukeEngine(self.bot)
        self.engine = self.bot.antinuke_engine

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        """O(1) Signal Emitter"""
        if self.engine:
            # Pass full channel data for recovery
            self.engine.signal(channel.guild.id, 'chdl', {
                'channel_id': channel.id,
                'channel_name': channel.name,
                'channel_type': channel.type,
                'category_id': channel.category_id,
                'overwrites': channel.overwrites
            })

async def setup(bot):
    await bot.add_cog(AntiChannelDelete(bot))
