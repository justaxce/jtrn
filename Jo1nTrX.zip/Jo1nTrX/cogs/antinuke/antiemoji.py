import discord
from discord.ext import commands
import asyncio
import time

class AntiEmoji(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.engine = None
    
    async def cog_load(self):
        """Initialize engine"""
        from .antinuke_helper import AntiNukeEngine
        if not hasattr(self.bot, 'antinuke_engine'):
            self.bot.antinuke_engine = AntiNukeEngine(self.bot)
        self.engine = self.bot.antinuke_engine

    @commands.Cog.listener()
    async def on_guild_emojis_update(self, guild, before, after):
        """Signal emitter"""
        if not self.engine:
            return

        created = len(after) > len(before)
        deleted = len(before) > len(after)

        if created:
            self.engine.signal(guild.id, 'emcr', {'guild': guild})
                    
        if deleted:
            self.engine.signal(guild.id, 'emdl', {'guild': guild})

async def setup(bot):
    await bot.add_cog(AntiEmoji(bot))
