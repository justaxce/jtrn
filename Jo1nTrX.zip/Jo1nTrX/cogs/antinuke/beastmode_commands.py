import discord
from discord.ext import commands
from discord import ui
import asyncio
import json
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)


def get_beastmode_help_content() -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    return f"""## <:Jo1nTrX_antinuke:1438450620402237542> Beastmode Protection
> Enhanced protection that monitors even whitelisted users for excessive actions.

{section} **__How It Works__**
Beastmode tracks actions per minute. If a whitelisted user exceeds the configured threshold, they will be kicked automatically!

{section} **__Available Commands__**

{arrow} `beastmode enable` - Enable beastmode protection
{arrow} `beastmode disable` - Disable beastmode protection
{arrow} `beastmode config` - Configure threshold limits
{arrow} `beastmode status` - View beastmode status"""


def get_beastmode_status_content(guild_name: str, config: dict, enabled_emoji: str, disabled_emoji: str) -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    status_text = f"{enabled_emoji} **Enabled**" if config['enabled'] else f"{disabled_emoji} **Disabled**"
    
    content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> Beastmode Status
> Protection status for **{guild_name}**

{section} **__Status__**
{status_text}"""
    
    if config['enabled']:
        content += f"""

{section} **__Current Thresholds__**

{arrow} Max Ban per min: `{config['max_ban_per_min']}`
{arrow} Max Kick per min: `{config['max_kick_per_min']}`
{arrow} Max Channel Create per min: `{config['max_channel_create_per_min']}`
{arrow} Max Channel Delete per min: `{config['max_channel_delete_per_min']}`
{arrow} Max Role Create per min: `{config['max_role_create_per_min']}`
{arrow} Max Role Delete per min: `{config['max_role_delete_per_min']}`
{arrow} Max Webhook Create per min: `{config['max_webhook_create_per_min']}`
{arrow} Max Mention per min: `{config['max_mention_per_min']}`
{arrow} Max Emoji Create per min: `{config['max_emoji_create_per_min']}`
{arrow} Max Emoji Delete per min: `{config['max_emoji_delete_per_min']}`"""
    
    return content


def get_beastmode_enabled_content(guild_name: str, config: dict, tick_emoji: str) -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    return f"""## {tick_emoji} Beastmode Enabled
> **{guild_name}** is now protected with beastmode!

Whitelisted users will be monitored for excessive actions and kicked if they exceed configured limits.

{section} **__Current Thresholds__**

{arrow} Max Ban per min: `{config['max_ban_per_min']}`
{arrow} Max Kick per min: `{config['max_kick_per_min']}`
{arrow} Max Channel Create per min: `{config['max_channel_create_per_min']}`
{arrow} Max Channel Delete per min: `{config['max_channel_delete_per_min']}`
{arrow} Max Role Create per min: `{config['max_role_create_per_min']}`
{arrow} Max Role Delete per min: `{config['max_role_delete_per_min']}`
{arrow} Max Webhook Create per min: `{config['max_webhook_create_per_min']}`
{arrow} Max Mention per min: `{config['max_mention_per_min']}`
{arrow} Max Emoji Create per min: `{config['max_emoji_create_per_min']}`
{arrow} Max Emoji Delete per min: `{config['max_emoji_delete_per_min']}`
{arrow} Max Unverified Bot per week: `{config['max_unverified_bot_per_week']}`

*Use `beastmode config` to customize these thresholds*"""


def get_beastmode_disabled_content(guild_name: str, cross_emoji: str) -> str:
    return f"""## {cross_emoji} Beastmode Disabled
> Beastmode protection has been disabled for **{guild_name}**.

Use `beastmode enable` to re-enable protection."""


class BeastmodeHelpLayoutView(ui.LayoutView):
    def __init__(self, requester: discord.Member = None):
        super().__init__(timeout=300)
        self.requester = requester
        self._setup_view()
    
    def _setup_view(self):
        content = get_beastmode_help_content()
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class BeastmodeStatusLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str, config: dict, enabled_emoji: str, disabled_emoji: str, requester: discord.Member = None):
        super().__init__(timeout=300)
        self.requester = requester
        self.guild_name = guild_name
        self.config = config
        self.enabled_emoji = enabled_emoji
        self.disabled_emoji = disabled_emoji
        self._setup_view()
    
    def _setup_view(self):
        content = get_beastmode_status_content(self.guild_name, self.config, self.enabled_emoji, self.disabled_emoji)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class BeastmodeEnabledLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str, config: dict, tick_emoji: str, requester: discord.Member = None):
        super().__init__(timeout=300)
        self.requester = requester
        self.guild_name = guild_name
        self.config = config
        self.tick_emoji = tick_emoji
        self._setup_view()
    
    def _setup_view(self):
        content = get_beastmode_enabled_content(self.guild_name, self.config, self.tick_emoji)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class BeastmodeDisabledLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str, cross_emoji: str, requester: discord.Member = None):
        super().__init__(timeout=300)
        self.requester = requester
        self.guild_name = guild_name
        self.cross_emoji = cross_emoji
        self._setup_view()
    
    def _setup_view(self):
        content = get_beastmode_disabled_content(self.guild_name, self.cross_emoji)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class BeastmodeConfigSelect(BaseSelect):
    def __init__(self, bot):
        options = [
            discord.SelectOption(label="Max Ban per min", value="max_ban_per_min", description="Threshold for ban actions"),
            discord.SelectOption(label="Max Kick per min", value="max_kick_per_min", description="Threshold for kick actions"),
            discord.SelectOption(label="Max Channel Create per min", value="max_channel_create_per_min", description="Threshold for channel creation"),
            discord.SelectOption(label="Max Channel Delete per min", value="max_channel_delete_per_min", description="Threshold for channel deletion"),
            discord.SelectOption(label="Max Role Create per min", value="max_role_create_per_min", description="Threshold for role creation"),
            discord.SelectOption(label="Max Role Delete per min", value="max_role_delete_per_min", description="Threshold for role deletion"),
            discord.SelectOption(label="Max Webhook Create per min", value="max_webhook_create_per_min", description="Threshold for webhook creation"),
            discord.SelectOption(label="Max Everyone/here/mainrole Mention per min", value="max_mention_per_min", description="Threshold for mentions"),
            discord.SelectOption(label="Max Emoji Create per min", value="max_emoji_create_per_min", description="Threshold for emoji creation"),
            discord.SelectOption(label="Max Emoji Delete per min", value="max_emoji_delete_per_min", description="Threshold for emoji deletion"),
            discord.SelectOption(label="Max Unverified Bot per week", value="max_unverified_bot_per_week", description="Threshold for unverified bot additions"),
        ]
        super().__init__(
            placeholder="Select a setting to configure...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        await self.view.show_value_modal(interaction, self.values[0])

class BeastmodeValueModal(ui.Modal):
    def __init__(self, setting_name, setting_display, current_value, view):
        super().__init__(title=f"Configure {setting_display}")
        self.setting_name = setting_name
        self.view = view
        
        is_weekly = 'week' in setting_name
        
        self.value_input = ui.TextInput(
            label="New Value",
            placeholder=f"Current: {current_value}" + (" (0 = none allowed)" if is_weekly else ""),
            default=str(current_value),
            min_length=1,
            max_length=2,
            required=True
        )
        self.add_item(self.value_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            new_value = int(self.value_input.value)
            is_weekly = 'week' in self.setting_name
            min_val = 0 if is_weekly else 1
            max_val = 50
            
            if new_value < min_val or new_value > max_val:
                await interaction.response.send_message(f"<a:jo1ntrx_cross:1405094953444954123> Value must be between {min_val} and {max_val}!", ephemeral=True)
                return
            
            self.view.config_updates[self.setting_name] = new_value
            await self.view.update_display(interaction)
        except ValueError:
            await interaction.response.send_message("<a:jo1ntrx_cross:1405094953444954123> Please enter a valid number!", ephemeral=True)

class BeastmodeConfigLayoutView(ui.LayoutView):
    def __init__(self, ctx, bot, current_config, requester: discord.Member = None):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.bot = bot
        self.current_config = current_config
        self.config_updates = {}
        self.requester = requester
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        settings_text = []
        for setting, display in [
            ("max_ban_per_min", "Max Ban per min"),
            ("max_kick_per_min", "Max Kick per min"),
            ("max_channel_create_per_min", "Max Channel Create per min"),
            ("max_channel_delete_per_min", "Max Channel Delete per min"),
            ("max_role_create_per_min", "Max Role Create per min"),
            ("max_role_delete_per_min", "Max Role Delete per min"),
            ("max_webhook_create_per_min", "Max Webhook Create per min"),
            ("max_mention_per_min", "Max Everyone/here/mainrole Mention per min"),
            ("max_emoji_create_per_min", "Max Emoji Create per min"),
            ("max_emoji_delete_per_min", "Max Emoji Delete per min"),
            ("max_unverified_bot_per_week", "Max Unverified Bot per week"),
        ]:
            value = self.config_updates.get(setting, self.current_config.get(setting, 0))
            modified = " ✨" if setting in self.config_updates else ""
            settings_text.append(f"{arrow} **{display}:** `{value}`{modified}")
        
        content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> Beastmode Configuration
> Configure threshold limits for beastmode protection

{section} **__Current Settings__**

{chr(10).join(settings_text)}

{section} **__Instructions__**
{arrow} Select a setting from the dropdown below
{arrow} Enter the new value in the popup
{arrow} Click "Save Changes" to apply all modifications"""
        
        text_display = ui.TextDisplay(content)
        
        select = BeastmodeConfigSelect(self.bot)
        select.callback = self._select_callback
        select_row = ui.ActionRow(select)
        
        confirm_btn = ui.Button(label="Save Changes", style=discord.ButtonStyle.primary)
        reset_btn = ui.Button(label="Reset to Defaults", style=discord.ButtonStyle.secondary)
        cancel_btn = ui.Button(label="Cancel", style=discord.ButtonStyle.danger)
        
        async def confirm_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            if not self.config_updates:
                return await interaction.response.send_message(f"{bot_emoji.cross} No changes to save!", ephemeral=True)
            
            await self.bot.db.update_beastmode_config(self.ctx.guild.id, self.config_updates)
            
            success_content = f"""## <a:jo1ntrx_tick:1405094825754378281> Configuration Updated
> Successfully applied {len(self.config_updates)} change(s)"""
            
            success_view = ui.LayoutView(timeout=60)
            success_container = ui.Container(ui.TextDisplay(success_content))
            success_view.add_item(success_container)
            await interaction.response.edit_message(view=success_view)
        
        async def reset_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            self.config_updates = {
                "max_ban_per_min": 3,
                "max_kick_per_min": 3,
                "max_channel_create_per_min": 5,
                "max_channel_delete_per_min": 3,
                "max_role_create_per_min": 5,
                "max_role_delete_per_min": 3,
                "max_webhook_create_per_min": 5,
                "max_mention_per_min": 3,
                "max_emoji_create_per_min": 5,
                "max_emoji_delete_per_min": 5,
                "max_unverified_bot_per_week": 0
            }
            new_view = BeastmodeConfigLayoutView(self.ctx, self.bot, self.current_config, self.requester)
            await interaction.response.edit_message(view=new_view)
        
        async def cancel_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            cancel_content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> Configuration Cancelled
> No changes were made"""
            cancel_view = ui.LayoutView(timeout=60)
            cancel_container = ui.Container(ui.TextDisplay(cancel_content))
            cancel_view.add_item(cancel_container)
            await interaction.response.edit_message(view=cancel_view)
        
        confirm_btn.callback = confirm_callback
        reset_btn.callback = reset_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(confirm_btn, reset_btn, cancel_btn)
        
        container = ui.Container(text_display, select_row, button_row)
        self.add_item(container)
    
    async def _select_callback(self, interaction: discord.Interaction):
        if self.requester and interaction.user.id != self.requester.id:
            return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
        
        setting_name = interaction.data['values'][0]
        setting_display_names = {
            "max_ban_per_min": "Max Ban per min",
            "max_kick_per_min": "Max Kick per min",
            "max_channel_create_per_min": "Max Channel Create per min",
            "max_channel_delete_per_min": "Max Channel Delete per min",
            "max_role_create_per_min": "Max Role Create per min",
            "max_role_delete_per_min": "Max Role Delete per min",
            "max_webhook_create_per_min": "Max Webhook Create per min",
            "max_mention_per_min": "Max Everyone/here/mainrole Mention per min",
            "max_emoji_create_per_min": "Max Emoji Create per min",
            "max_emoji_delete_per_min": "Max Emoji Delete per min",
            "max_unverified_bot_per_week": "Max Unverified Bot per week"
        }
        
        current_value = self.config_updates.get(setting_name, self.current_config.get(setting_name, 3))
        modal = BeastmodeValueModal(setting_name, setting_display_names[setting_name], current_value, self)
        await interaction.response.send_modal(modal)

class BeastmodeCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.load_emojis()
    
    def load_emojis(self):
        try:
            with open('Jo1nTrX/core/emojis.json', 'r') as f:
                emoji_data = json.load(f)
                self.tick_emoji = emoji_data['animated']['tick']
                self.cross_emoji = emoji_data['animated']['cross']
                self.enabled_emoji = emoji_data['static']['enabled']
                self.disabled_emoji = emoji_data['static']['disabled']
        except:
            self.tick_emoji = "✅"
            self.cross_emoji = "❌"
            self.enabled_emoji = "🟢"
            self.disabled_emoji = "🔴"

    async def is_guild_owner_or_extra_owner(self, ctx):
        if ctx.author.id == ctx.guild.owner_id:
            return True
        return await self.bot.db.is_extra_owner(ctx.guild.id, ctx.author.id)

    @commands.group(name='beastmode', invoke_without_command=True)
    async def beastmode(self, ctx):
        if ctx.invoked_subcommand is None:
            view = BeastmodeHelpLayoutView(requester=ctx.author)
            await ctx.send(view=view)

    @beastmode.command(name='enable')
    async def enable(self, ctx):
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can enable beastmode.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        antinuke_config = await self.bot.db.get_antinuke_config(ctx.guild.id)
        if not antinuke_config['status']:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Anti-nuke protection must be enabled before enabling beastmode!\n\n"
                           f"Use `antinuke enable` to enable anti-nuke protection first.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        config = await self.bot.db.get_beastmode_config(ctx.guild.id)
        if config['enabled']:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Beastmode is already enabled!",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        await self.bot.db.set_beastmode_status(ctx.guild.id, True)
        
        log_channel_id = antinuke_config.get('log_channel_id')
        if log_channel_id:
            log_channel = ctx.guild.get_channel(log_channel_id)
            if log_channel:
                log_embed = discord.Embed(
                    title="<:Jo1nTrX_antinuke:1438450620402237542> Beastmode Enabled",
                    description=f"**Beastmode protection has been enabled by {ctx.author.mention}**\n\n"
                               "Whitelisted users will now be monitored for excessive actions.",
                    color=0x00FF00,
                    timestamp=discord.utils.utcnow()
                )
                log_embed.set_footer(text=f"Enabled by {ctx.author}", icon_url=ctx.author.display_avatar.url)
                try:
                    await log_channel.send(embed=log_embed)
                except:
                    pass

        view = BeastmodeEnabledLayoutView(ctx.guild.name, config, self.tick_emoji, requester=ctx.author)
        await ctx.send(view=view)

    @beastmode.command(name='disable')
    async def disable(self, ctx):
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can disable beastmode.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        config = await self.bot.db.get_beastmode_config(ctx.guild.id)
        if not config['enabled']:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Beastmode is already disabled!",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        await self.bot.db.set_beastmode_status(ctx.guild.id, False)
        
        antinuke_config = await self.bot.db.get_antinuke_config(ctx.guild.id)
        log_channel_id = antinuke_config.get('log_channel_id')
        if log_channel_id:
            log_channel = ctx.guild.get_channel(log_channel_id)
            if log_channel:
                log_embed = discord.Embed(
                    title="<:Jo1nTrX_antinuke:1438450620402237542> Beastmode Disabled",
                    description=f"**Beastmode protection has been disabled by {ctx.author.mention}**",
                    color=0xFF0000,
                    timestamp=discord.utils.utcnow()
                )
                log_embed.set_footer(text=f"Disabled by {ctx.author}", icon_url=ctx.author.display_avatar.url)
                try:
                    await log_channel.send(embed=log_embed)
                except:
                    pass

        view = BeastmodeDisabledLayoutView(ctx.guild.name, self.cross_emoji, requester=ctx.author)
        await ctx.send(view=view)

    @beastmode.command(name='config')
    async def config(self, ctx):
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can configure beastmode.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        current_config = await self.bot.db.get_beastmode_config(ctx.guild.id)
        view = BeastmodeConfigLayoutView(ctx, self.bot, current_config, requester=ctx.author)
        await ctx.send(view=view)

    @beastmode.command(name='status')
    async def status(self, ctx):
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can view beastmode status.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)
        
        config = await self.bot.db.get_beastmode_config(ctx.guild.id)
        
        view = BeastmodeStatusLayoutView(ctx.guild.name, config, self.enabled_emoji, self.disabled_emoji, requester=ctx.author)
        await ctx.send(view=view)

async def setup(bot):
    await bot.add_cog(BeastmodeCommands(bot))
