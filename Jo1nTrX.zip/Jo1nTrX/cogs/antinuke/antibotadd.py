import discord
from discord.ext import commands
import asyncio
import datetime
import pytz
import time

class AntiBotAdd(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.engine = None
    
    async def cog_load(self):
        """Initialize engine"""
        from .antinuke_helper import AntiNukeEngine
        if not hasattr(self.bot, 'antinuke_engine'):
            self.bot.antinuke_engine = AntiNukeEngine(self.bot)
        self.engine = self.bot.antinuke_engine

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Signal emitter"""
        if member.bot and self.engine:
            self.engine.signal(member.guild.id, 'antibot', {'user_id': member.id})

async def setup(bot):
    await bot.add_cog(AntiBotAdd(bot))
