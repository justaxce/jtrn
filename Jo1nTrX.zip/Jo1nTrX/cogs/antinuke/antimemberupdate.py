import discord
from discord.ext import commands
import asyncio
import time

class AntiMemberUpdate(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.engine = None
    
    async def cog_load(self):
        """Initialize engine"""
        from .antinuke_helper import AntiNukeEngine
        if not hasattr(self.bot, 'antinuke_engine'):
            self.bot.antinuke_engine = AntiNukeEngine(self.bot)
        self.engine = self.bot.antinuke_engine

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        """Signal emitter for dangerous role updates"""
        if self.engine:
            self.engine.signal(before.guild.id, 'memup', {'user_id': after.id})

async def setup(bot):
    await bot.add_cog(AntiMemberUpdate(bot))
