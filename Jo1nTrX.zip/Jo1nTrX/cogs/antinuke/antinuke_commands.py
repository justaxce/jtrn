import discord
from discord.ext import commands
from discord import ui
import asyncio
import json
import typing
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji, BaseLayoutView
)


def get_antinuke_help_content(category: str = "main") -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    if category == "main":
        return f"""## <:Jo1nTrX_antinuke:1438450620402237542> Anti-Nuke System
> Protect your server from malicious actions with Jo1nTrX's anti-nuke system.

{section} **__Main Commands__**

{arrow} `antinuke enable` - Enable anti-nuke protection
{arrow} `antinuke disable` - Disable anti-nuke protection
{arrow} `antinuke status` - View anti-nuke status"""
    
    elif category == "whitelist":
        return f"""## <:Jo1nTrX_antinuke:1438450620402237542> Whitelist Commands
> Manage whitelisted users who can bypass anti-nuke protection.

{section} **__Available Commands__**

{arrow} `whitelist add <user>` - Add user to whitelist
{arrow} `whitelist remove <user>` - Remove user from whitelist
{arrow} `whitelist show` - Show whitelisted users
{arrow} `whitelist reset` - Reset all whitelisted users"""
    
    elif category == "extraowner":
        return f"""## <:Jo1nTrX_antinuke:1438450620402237542> Extra Owner Commands
> Manage extra owners who have full control over anti-nuke settings.

{section} **__Available Commands__**

{arrow} `extraowner add <user>` - Add extra owner
{arrow} `extraowner remove <user>` - Remove extra owner
{arrow} `extraowner show` - Show extra owners
{arrow} `extraowner reset` - Reset all extra owners"""
    
    return get_antinuke_help_content("main")


def get_antinuke_status_content(guild_name: str, is_enabled: bool, enabled_emoji: str, disabled_emoji: str, log_channel_mention: str = None) -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    status_text = f"{enabled_emoji} **Enabled**" if is_enabled else f"{disabled_emoji} **Disabled**"
    
    content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> Anti-Nuke Status
> Protection status for **{guild_name}**

{section} **__Status__**
{status_text}"""
    
    if is_enabled and log_channel_mention:
        content += f"\n\n{section} **__Log Channel__**\n{arrow} {log_channel_mention}"
    
    return content


def get_whitelist_help_content() -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    return f"""## <:Jo1nTrX_antinuke:1438450620402237542> Whitelist Commands
> Manage whitelisted users who can bypass anti-nuke protection.

{section} **__Available Commands__**

{arrow} `whitelist add <@user/@role>` - Add user/role to whitelist
{arrow} `whitelist remove <@user/@role>` - Remove user/role from whitelist
{arrow} `whitelist show` - Show whitelisted users and roles
{arrow} `whitelist reset` - Reset all whitelisted users

{section} **__Aliases__**
`wl`

{section} **__Examples__**
{arrow} `wl add @user` - Add user to whitelist
{arrow} `wl list` - Show all whitelisted users and roles
{arrow} `wl remove @role` - Remove role from whitelist"""


class AntiNukeStatusLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str, is_enabled: bool, enabled_emoji: str, disabled_emoji: str, log_channel_mention: str = None, requester: discord.Member = None):
        super().__init__(timeout=300)
        self.requester = requester
        self.guild_name = guild_name
        self.is_enabled = is_enabled
        self.enabled_emoji = enabled_emoji
        self.disabled_emoji = disabled_emoji
        self.log_channel_mention = log_channel_mention
        self._setup_view()
    
    def _setup_view(self):
        content = get_antinuke_status_content(self.guild_name, self.is_enabled, self.enabled_emoji, self.disabled_emoji, self.log_channel_mention)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class WhitelistHelpLayoutView(ui.LayoutView):
    def __init__(self, requester: discord.Member = None):
        super().__init__(timeout=300)
        self.requester = requester
        self._setup_view()
    
    def _setup_view(self):
        content = get_whitelist_help_content()
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class AntiNukeHelpLayoutView(ui.LayoutView):
    def __init__(self, requester: discord.Member = None, category: str = "main"):
        super().__init__(timeout=300)
        self.requester = requester
        self.current_category = category
        self._setup_view()
    
    def _setup_view(self):
        content = get_antinuke_help_content(self.current_category)
        text_display = ui.TextDisplay(content)
        
        main_btn = ui.Button(label="Main", style=discord.ButtonStyle.primary, custom_id="an_main")
        whitelist_btn = ui.Button(label="Whitelist", style=discord.ButtonStyle.secondary, custom_id="an_whitelist")
        extraowner_btn = ui.Button(label="Extra Owner", style=discord.ButtonStyle.success, custom_id="an_extraowner")
        
        async def main_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AntiNukeHelpLayoutView(self.requester, "main")
            await interaction.response.edit_message(view=new_view)
        
        async def whitelist_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AntiNukeHelpLayoutView(self.requester, "whitelist")
            await interaction.response.edit_message(view=new_view)
        
        async def extraowner_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AntiNukeHelpLayoutView(self.requester, "extraowner")
            await interaction.response.edit_message(view=new_view)
        
        main_btn.callback = main_callback
        whitelist_btn.callback = whitelist_callback
        extraowner_btn.callback = extraowner_callback
        
        button_row = ui.ActionRow(main_btn, whitelist_btn, extraowner_btn)
        
        container = ui.Container(text_display, button_row)
        self.add_item(container)

MODULE_NAMES = {
    "ban": "Anti Ban", "kick": "Anti Kick", "chcr": "Anti Channel Create",
    "chdl": "Anti Channel Delete", "chup": "Anti Channel Update",
    "rlcr": "Anti Role Create", "rldl": "Anti Role Delete", "rlup": "Anti Role Update",
    "botadd": "Anti Bot Add", "mngweb": "Anti Webhook Create",
    "serverup": "Anti Guild Update", "meneve": "Anti Everyone Mention",
    "prune": "Anti Member Prune", "emcr": "Anti Emoji Create", "emdl": "Anti Emoji Delete"
}

ALL_PERMS = ['ban', 'kick', 'chcr', 'chdl', 'chup', 'rlcr', 'rldl', 'rlup', 
             'botadd', 'mngweb', 'meneve', 'serverup', 'prune', 'emcr', 'emdl']


class WhitelistSuccessLayoutView(ui.LayoutView):
    def __init__(self, entity_mention: str, entity_type: str, modules: list = None, all_modules: bool = False):
        super().__init__(timeout=300)
        self._setup_view(entity_mention, entity_type, modules, all_modules)
    
    def _setup_view(self, entity_mention: str, entity_type: str, modules: list, all_modules: bool):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if all_modules:
            content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> {entity_type} Whitelisted
> Successfully added to all antinuke modules

{section} **__{entity_type} Details__**
{arrow} **{entity_type}:** {entity_mention}
{arrow} **Modules:** All {len(ALL_PERMS)} modules
{arrow} **Status:** <:jo1ntrx_tick:1405094884947267715> Active"""
        else:
            module_list = "\n".join([f"{arrow} {MODULE_NAMES.get(m, m)}" for m in modules])
            content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> {entity_type} Whitelisted
> Successfully whitelisted from selected modules

{section} **__{entity_type} Details__**
{arrow} **{entity_type}:** {entity_mention}
{arrow} **Modules Count:** {len(modules)}

{section} **__Selected Modules__**
{module_list}"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class WhitelistLayoutView(ui.LayoutView):
    def __init__(self, ctx, entity, bot, requester: discord.Member = None):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.entity = entity
        self.bot = bot
        self.requester = requester
        self.selected_modules = []
        self._setup_view()
    
    def _setup_view(self):
        entity_type = "Role" if isinstance(self.entity, discord.Role) else "User"
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> Whitelist Configuration
> Configure module access for {entity_type.lower()}

{section} **__{entity_type} Details__**
{arrow} **{entity_type}:** {self.entity.mention}

{section} **__Instructions__**
{arrow} Use the dropdown to select modules
{arrow} Or click "Whitelist All" for all modules
{arrow} Click "Confirm" to save selection"""
        
        text_display = ui.TextDisplay(content)
        
        module_select = ui.Select(
            placeholder="Select modules to whitelist...",
            min_values=1,
            max_values=len(ALL_PERMS),
            options=[
                discord.SelectOption(label="Anti Ban", value="ban", description="Whitelist from ban module"),
                discord.SelectOption(label="Anti Kick", value="kick", description="Whitelist from kick module"),
                discord.SelectOption(label="Anti Channel Create", value="chcr", description="Whitelist from channel create"),
                discord.SelectOption(label="Anti Channel Delete", value="chdl", description="Whitelist from channel delete"),
                discord.SelectOption(label="Anti Channel Update", value="chup", description="Whitelist from channel update"),
                discord.SelectOption(label="Anti Role Create", value="rlcr", description="Whitelist from role create"),
                discord.SelectOption(label="Anti Role Delete", value="rldl", description="Whitelist from role delete"),
                discord.SelectOption(label="Anti Role Update", value="rlup", description="Whitelist from role update"),
                discord.SelectOption(label="Anti Bot Add", value="botadd", description="Whitelist from bot add"),
                discord.SelectOption(label="Anti Webhook Create", value="mngweb", description="Whitelist from webhook"),
                discord.SelectOption(label="Anti Guild Update", value="serverup", description="Whitelist from server update"),
                discord.SelectOption(label="Anti Everyone Mention", value="meneve", description="Whitelist from everyone mention"),
                discord.SelectOption(label="Anti Member Prune", value="prune", description="Whitelist from member prune"),
                discord.SelectOption(label="Anti Emoji Create", value="emcr", description="Whitelist from emoji create"),
                discord.SelectOption(label="Anti Emoji Delete", value="emdl", description="Whitelist from emoji delete"),
            ]
        )
        
        async def module_select_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.selected_modules = module_select.values
            await interaction.response.defer()
        
        module_select.callback = module_select_callback
        select_row = ui.ActionRow(module_select)
        
        whitelist_all_btn = ui.Button(label="Whitelist All", style=discord.ButtonStyle.success)
        confirm_btn = ui.Button(label="Confirm Selection", style=discord.ButtonStyle.primary)
        cancel_btn = ui.Button(label="Cancel", style=discord.ButtonStyle.danger)
        
        async def whitelist_all_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            perm_dict = {perm: 1 for perm in ALL_PERMS}
            entity_type = "Role" if isinstance(self.entity, discord.Role) else "User"
            
            if isinstance(self.entity, discord.Role):
                await self.bot.db.add_whitelist_role(self.ctx.guild.id, self.entity.id, perm_dict)
            else:
                await self.bot.db.add_whitelist_user(self.ctx.guild.id, self.entity.id, perm_dict)
            
            success_view = WhitelistSuccessLayoutView(self.entity.mention, entity_type, all_modules=True)
            await interaction.response.edit_message(view=success_view)
        
        async def confirm_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            if not self.selected_modules:
                return await interaction.response.send_message(f"{bot_emoji.cross} Please select at least one module!", ephemeral=True)
            
            perm_dict = {perm: 0 for perm in ALL_PERMS}
            for perm in self.selected_modules:
                if perm in ALL_PERMS:
                    perm_dict[perm] = 1
            
            entity_type = "Role" if isinstance(self.entity, discord.Role) else "User"
            
            if isinstance(self.entity, discord.Role):
                await self.bot.db.add_whitelist_role(self.ctx.guild.id, self.entity.id, perm_dict)
            else:
                await self.bot.db.add_whitelist_user(self.ctx.guild.id, self.entity.id, perm_dict)
            
            success_view = WhitelistSuccessLayoutView(self.entity.mention, entity_type, modules=self.selected_modules)
            await interaction.response.edit_message(view=success_view)
        
        async def cancel_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            cancel_content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> Whitelist Cancelled
> Operation cancelled by user"""
            cancel_view = ui.LayoutView(timeout=60)
            cancel_container = ui.Container(ui.TextDisplay(cancel_content))
            cancel_view.add_item(cancel_container)
            await interaction.response.edit_message(view=cancel_view)
        
        whitelist_all_btn.callback = whitelist_all_callback
        confirm_btn.callback = confirm_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(whitelist_all_btn, confirm_btn, cancel_btn)
        
        container = ui.Container(text_display, select_row, button_row)
        self.add_item(container)

class WhitelistRemoveSuccessLayoutView(ui.LayoutView):
    def __init__(self, entity_mention: str, entity_type: str, removed_modules: list = None, all_removed: bool = False):
        super().__init__(timeout=300)
        self._setup_view(entity_mention, entity_type, removed_modules, all_removed)
    
    def _setup_view(self, entity_mention: str, entity_type: str, removed_modules: list, all_removed: bool):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if all_removed:
            content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> {entity_type} Removed
> Successfully removed from all antinuke modules

{section} **__{entity_type} Details__**
{arrow} **{entity_type}:** {entity_mention}
{arrow} **Status:** <a:Jo1nTrX_cross:1405094904568483880> Removed from all modules"""
        elif removed_modules:
            module_list = "\n".join([f"{arrow} {MODULE_NAMES.get(m, m)}" for m in removed_modules])
            content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> Whitelist Updated
> Successfully updated whitelist configuration

{section} **__{entity_type} Details__**
{arrow} **{entity_type}:** {entity_mention}

{section} **__Removed From Modules__**
{module_list}"""
        else:
            content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> No Changes Made
> Whitelist configuration unchanged

{section} **__{entity_type} Details__**
{arrow} **{entity_type}:** {entity_mention}
{arrow} **Status:** No changes were made"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class WhitelistRemoveLayoutView(ui.LayoutView):
    def __init__(self, ctx, entity, bot, current_permissions, requester: discord.Member = None):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.entity = entity
        self.bot = bot
        self.current_permissions = current_permissions
        self.requester = requester
        self.selected_modules = [perm for perm, is_whitelisted in current_permissions.items() if is_whitelisted]
        self._setup_view()
    
    def _setup_view(self):
        entity_type = "Role" if isinstance(self.entity, discord.Role) else "User"
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        whitelisted_modules = [MODULE_NAMES.get(perm, perm) for perm, is_wl in self.current_permissions.items() if is_wl]
        module_list = "\n".join([f"{arrow} {name}" for name in whitelisted_modules[:10]])
        if len(whitelisted_modules) > 10:
            module_list += f"\n{arrow} ...and {len(whitelisted_modules) - 10} more"
        
        content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> Whitelist Removal
> Configure which modules to keep or remove

{section} **__{entity_type} Details__**
{arrow} **{entity_type}:** {self.entity.mention}
{arrow} **Currently Whitelisted:** {len(whitelisted_modules)} modules

{section} **__Instructions__**
{arrow} Select modules to **keep** in the dropdown
{arrow} Unselected modules will be removed
{arrow} Click "Remove All" to remove from everything"""
        
        text_display = ui.TextDisplay(content)
        
        options = []
        for perm in ALL_PERMS:
            is_default = self.current_permissions.get(perm, False)
            options.append(discord.SelectOption(
                label=MODULE_NAMES.get(perm, perm),
                value=perm,
                description=f"Keep whitelisted from {MODULE_NAMES.get(perm, perm).lower()}",
                default=is_default
            ))
        
        module_select = ui.Select(
            placeholder="Select modules to keep whitelisted...",
            min_values=0,
            max_values=len(ALL_PERMS),
            options=options
        )
        
        async def module_select_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.selected_modules = module_select.values
            await interaction.response.defer()
        
        module_select.callback = module_select_callback
        select_row = ui.ActionRow(module_select)
        
        remove_all_btn = ui.Button(label="Remove All", style=discord.ButtonStyle.danger)
        confirm_btn = ui.Button(label="Confirm Changes", style=discord.ButtonStyle.primary)
        cancel_btn = ui.Button(label="Cancel", style=discord.ButtonStyle.secondary)
        
        async def remove_all_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            entity_type = "Role" if isinstance(self.entity, discord.Role) else "User"
            
            if isinstance(self.entity, discord.Role):
                await self.bot.db.remove_whitelist_role(self.ctx.guild.id, self.entity.id)
            else:
                await self.bot.db.remove_whitelist_user(self.ctx.guild.id, self.entity.id)
            
            success_view = WhitelistRemoveSuccessLayoutView(self.entity.mention, entity_type, all_removed=True)
            await interaction.response.edit_message(view=success_view)
        
        async def confirm_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            entity_type = "Role" if isinstance(self.entity, discord.Role) else "User"
            
            if not self.selected_modules:
                if isinstance(self.entity, discord.Role):
                    await self.bot.db.remove_whitelist_role(self.ctx.guild.id, self.entity.id)
                else:
                    await self.bot.db.remove_whitelist_user(self.ctx.guild.id, self.entity.id)
                
                success_view = WhitelistRemoveSuccessLayoutView(self.entity.mention, entity_type, all_removed=True)
                await interaction.response.edit_message(view=success_view)
                return
            
            perm_dict = {perm: 0 for perm in ALL_PERMS}
            for perm in self.selected_modules:
                if perm in ALL_PERMS:
                    perm_dict[perm] = 1
            
            if isinstance(self.entity, discord.Role):
                await self.bot.db.add_whitelist_role(self.ctx.guild.id, self.entity.id, perm_dict)
            else:
                await self.bot.db.add_whitelist_user(self.ctx.guild.id, self.entity.id, perm_dict)
            
            removed_modules = [perm for perm in ALL_PERMS if self.current_permissions.get(perm) and perm not in self.selected_modules]
            
            success_view = WhitelistRemoveSuccessLayoutView(self.entity.mention, entity_type, removed_modules=removed_modules)
            await interaction.response.edit_message(view=success_view)
        
        async def cancel_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            cancel_content = f"""## <:Jo1nTrX_antinuke:1438450620402237542> Operation Cancelled
> Whitelist configuration unchanged"""
            cancel_view = ui.LayoutView(timeout=60)
            cancel_container = ui.Container(ui.TextDisplay(cancel_content))
            cancel_view.add_item(cancel_container)
            await interaction.response.edit_message(view=cancel_view)
        
        remove_all_btn.callback = remove_all_callback
        confirm_btn.callback = confirm_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(remove_all_btn, confirm_btn, cancel_btn)
        
        container = ui.Container(text_display, select_row, button_row)
        self.add_item(container)

class AntiNukeCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.load_emojis()
    
    def load_emojis(self):
        """Load emojis from emojis.json"""
        try:
            with open('Jo1nTrX/core/emojis.json', 'r') as f:
                emoji_data = json.load(f)
                self.loading_emoji = emoji_data['animated']['loading']
                self.tick_emoji = emoji_data['animated']['tick']
                self.cross_emoji = emoji_data['animated']['cross']
                self.enabled_emoji = emoji_data['static']['enabled']
                self.disabled_emoji = emoji_data['static']['disabled']
        except:
            self.loading_emoji = "⏳"
            self.tick_emoji = "✅"
            self.cross_emoji = "❌"
            self.enabled_emoji = "🟢"
            self.disabled_emoji = "🔴"

    async def is_guild_owner_or_extra_owner(self, ctx):
        """Check if user is guild owner or extra owner"""
        if ctx.author.id == ctx.guild.owner_id:
            return True
        
        return await self.bot.db.is_extra_owner(ctx.guild.id, ctx.author.id)

    @commands.group(name='antinuke', invoke_without_command=True)
    async def antinuke(self, ctx):
        """Anti-nuke protection system commands"""
        if ctx.invoked_subcommand is None:
            view = AntiNukeHelpLayoutView(ctx.author, "main")
            await ctx.send(view=view)

    @antinuke.command(name='enable')
    async def enable(self, ctx):
        """Enable anti-nuke protection"""
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can enable anti-nuke protection.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        config = await self.bot.db.get_antinuke_config(ctx.guild.id)
        if config['status']:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Anti-nuke is already enabled!\nKindly disable it to enable again.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        modules = [
            ("Anti Ban", "ban"),
            ("Anti Kick", "kick"),
            ("Anti Channel Create", "chcr"),
            ("Anti Channel Delete", "chdl"),
            ("Anti Channel Update", "chup"),
            ("Anti Role Create", "rlcr"),
            ("Anti Role Delete", "rldl"),
            ("Anti Role Update", "rlup"),
            ("Anti Bot Add", "botadd"),
            ("Anti Webhook Create", "mngweb"),
            ("Anti Webhook Delete", "mngweb"),
            ("Anti Guild Update", "serverup"),
            ("Anti Everyone Mention", "meneve"),
            ("Anti Member Prune", "prune")
        ]

        embed = discord.Embed(
            title=f"{self.loading_emoji} Enabling Anti-Nuke Protection",
            description="Please wait while I set up the protection system...",
            color=0x7c28eb
        )
        loading_msg = await ctx.send(embed=embed)

        try:
            bot_member = ctx.guild.me
            bot_top_role = bot_member.top_role
            
            embed.description = f"{self.loading_emoji} **Step 1:** Creating Protection Role"
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(0.5)
            
            secured_role = discord.utils.get(ctx.guild.roles, name="Secured By Jo1nTrX™")
            if not secured_role:
                secured_role = await ctx.guild.create_role(
                    name="Secured By Jo1nTrX™",
                    color=discord.Color(0x7c28eb),
                    reason="Anti-Nuke Protection Role"
                )
            
            await secured_role.edit(position=bot_top_role.position - 1)
            
            embed.description = f"{self.tick_emoji} **Step 1:** Protection Role Created - {secured_role.mention}"
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(0.5)
            
            embed.description = f"{self.tick_emoji} **Step 1:** Protection Role Created - {secured_role.mention}\n{self.loading_emoji} **Step 2:** Creating Log Channel"
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(0.5)
            
            overwrites = {
                ctx.guild.default_role: discord.PermissionOverwrite(view_channel=False),
                ctx.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_messages=True)
            }
            
            log_channel = await ctx.guild.create_text_channel(
                name="antinuke-logs",
                topic="Anti-Nuke Protection Logs - All antinuke events are logged here",
                overwrites=overwrites,
                reason="Anti-Nuke Protection Enabled"
            )
            
            embed.description = f"{self.tick_emoji} **Step 1:** Protection Role Created - {secured_role.mention}\n{self.tick_emoji} **Step 2:** Log Channel Created - {log_channel.mention}"
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(0.5)
            
            embed.description = f"{self.tick_emoji} **Step 1:** Protection Role Created - {secured_role.mention}\n{self.tick_emoji} **Step 2:** Log Channel Created - {log_channel.mention}\n{self.loading_emoji} **Step 3:** Enabling Modules"
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(0.5)
            
            module_status = []
            for i, (module_name, _) in enumerate(modules):
                module_status.append(f"{self.loading_emoji} {module_name}")
            
            step_desc = f"{self.tick_emoji} **Step 1:** Protection Role Created - {secured_role.mention}\n{self.tick_emoji} **Step 2:** Log Channel Created - {log_channel.mention}\n{self.loading_emoji} **Step 3:** Enabling Modules\n\n"
            embed.description = step_desc + "\n".join(module_status)
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(1)
            
            for i, (module_name, _) in enumerate(modules):
                module_status[i] = f"{self.tick_emoji} {module_name}"
                embed.description = step_desc + "\n".join(module_status)
                await loading_msg.edit(embed=embed)
                await asyncio.sleep(0.3)
            
            await self.bot.db.set_antinuke_status(ctx.guild.id, True, log_channel.id)
            
            final_embed = discord.Embed(
                title=f"{self.tick_emoji} Anti-Nuke Protection Enabled",
                description=f"**{ctx.guild.name}** is now secured!\n\n"
                           f"**Protection Role:** {secured_role.mention}\n"
                           f"**Log Channel:** {log_channel.mention}\n"
                           f"**Total Modules Enabled:** `{len(modules)}`",
                color=0x00FF00
            )
            final_embed.add_field(
                name="Protected Role",
                value=f"Users with {secured_role.mention} role are protected from anti-nuke actions.",
                inline=False
            )
            final_embed.add_field(
                name="💡 Tip: Enable Beastmode",
                value="Use `beastmode enable` for enhanced protection even from whitelisted users!\n"
                     "Beastmode monitors actions per minute and kicks users who exceed configured thresholds.",
                inline=False
            )
            await loading_msg.edit(embed=final_embed)
            
            welcome_embed = discord.Embed(
                title="<:Jo1nTrX_antinuke:1438450620402237542> Anti-Nuke Protection Active",
                description=f"This channel logs all anti-nuke events for **{ctx.guild.name}**.\n\n"
                           "All unauthorized actions will be logged here.",
                color=0x7c28eb
            )
            await log_channel.send(embed=welcome_embed)
            
        except discord.Forbidden:
            embed = discord.Embed(
                description=f"{self.cross_emoji} I don't have permission to create channels or roles. Please grant me the necessary permissions.",
                color=0xFF0000
            )
            await loading_msg.edit(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Failed to enable anti-nuke protection: {str(e)}",
                color=0xFF0000
            )
            await loading_msg.edit(embed=embed)

    @antinuke.command(name='disable')
    async def disable(self, ctx):
        """Disable anti-nuke protection"""
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can disable anti-nuke protection.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        config = await self.bot.db.get_antinuke_config(ctx.guild.id)
        if not config['status']:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Anti-nuke is already disabled!",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        modules = [
            "Anti Ban", "Anti Kick", "Anti Channel Create", "Anti Channel Delete",
            "Anti Channel Update", "Anti Role Create", "Anti Role Delete", "Anti Role Update",
            "Anti Bot Add", "Anti Webhook Create", "Anti Webhook Delete",
            "Anti Guild Update", "Anti Everyone Mention", "Anti Member Prune"
        ]

        embed = discord.Embed(
            title=f"{self.loading_emoji} Disabling Anti-Nuke Protection",
            description="Please wait while I disable the protection system...",
            color=0x7c28eb
        )
        loading_msg = await ctx.send(embed=embed)

        try:
            embed.description = f"{self.loading_emoji} **Step 1:** Disabling Modules"
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(0.5)
            
            module_status = []
            for module in modules:
                module_status.append(f"{self.loading_emoji} {module}")
            
            step_desc = f"{self.loading_emoji} **Step 1:** Disabling Modules\n\n"
            embed.description = step_desc + "\n".join(module_status)
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(1)
            
            for i, module in enumerate(modules):
                module_status[i] = f"{self.cross_emoji} {module}"
                embed.description = step_desc + "\n".join(module_status)
                await loading_msg.edit(embed=embed)
                await asyncio.sleep(0.3)
            
            embed.description = f"{self.tick_emoji} **Step 1:** Modules Disabled\n{self.loading_emoji} **Step 2:** Deleting Log Channel"
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(0.5)
            
            log_channel_id = config.get('log_channel_id')
            if log_channel_id:
                log_channel = ctx.guild.get_channel(log_channel_id)
                if log_channel:
                    try:
                        await log_channel.delete(reason="Anti-Nuke Protection Disabled")
                    except:
                        pass
            
            embed.description = f"{self.tick_emoji} **Step 1:** Modules Disabled\n{self.tick_emoji} **Step 2:** Log Channel Deleted\n{self.loading_emoji} **Step 3:** Removing Protection Role"
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(0.5)
            
            secured_role = discord.utils.get(ctx.guild.roles, name="Secured By Jo1nTrX™")
            if secured_role:
                try:
                    await secured_role.delete(reason="Anti-Nuke Protection Disabled")
                except:
                    pass
            
            embed.description = f"{self.tick_emoji} **Step 1:** Modules Disabled\n{self.tick_emoji} **Step 2:** Log Channel Deleted\n{self.tick_emoji} **Step 3:** Protection Role Removed"
            await loading_msg.edit(embed=embed)
            await asyncio.sleep(0.5)
            
            await self.bot.db.set_antinuke_status(ctx.guild.id, False, None)
            
            final_embed = discord.Embed(
                title=f"{self.cross_emoji} Anti-Nuke Protection Disabled",
                description=f"**{ctx.guild.name}** protection has been disabled.\n\n"
                           f"**Total Modules Disabled:** `{len(modules)}`",
                color=0xFF0000
            )
            await loading_msg.edit(embed=final_embed)
            
        except Exception as e:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Failed to disable anti-nuke protection: {str(e)}",
                color=0xFF0000
            )
            await loading_msg.edit(embed=embed)

    @antinuke.command(name='status')
    async def status(self, ctx):
        """Check anti-nuke status"""
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can view anti-nuke status.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)
        
        config = await self.bot.db.get_antinuke_config(ctx.guild.id)
        is_enabled = config['status']
        log_channel_id = config.get('log_channel_id')
        
        log_channel_mention = None
        if is_enabled and log_channel_id:
            log_channel = ctx.guild.get_channel(log_channel_id)
            if log_channel:
                log_channel_mention = log_channel.mention
        
        view = AntiNukeStatusLayoutView(ctx.guild.name, is_enabled, self.enabled_emoji, self.disabled_emoji, log_channel_mention, requester=ctx.author)
        await ctx.send(view=view)

    @commands.group(name='whitelist', aliases=['wl'], invoke_without_command=True)
    async def whitelist(self, ctx):
        """Whitelist management commands"""
        if ctx.invoked_subcommand is None:
            view = WhitelistHelpLayoutView(requester=ctx.author)
            await ctx.send(view=view)

    @whitelist.command(name='add')
    async def whitelist_add(self, ctx, entity: typing.Union[discord.Member, discord.Role], *permissions):
        """Add a user or role to the whitelist with specific permissions"""
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="Only the server owner or extra owners can manage the whitelist.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        config = await self.bot.db.get_antinuke_config(ctx.guild.id)
        if not config['status']:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Anti-nuke protection must be enabled before whitelisting!\n\n"
                           f"Use `antinuke enable` to enable anti-nuke protection first.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        entity_type = "Role" if isinstance(entity, discord.Role) else "User"

        # If permissions are provided via CLI, use old method
        if permissions:
            valid_perms = ['ban', 'kick', 'chcr', 'chdl', 'chup', 'rlcr', 'rldl', 'rlup', 
                           'botadd', 'mngweb', 'meneve', 'serverup', 'prune', 'emcr', 'emdl']
            
            perm_dict = {perm: 0 for perm in valid_perms}
            
            if 'all' in permissions:
                perm_dict = {perm: 1 for perm in valid_perms}
            else:
                for perm in permissions:
                    if perm in valid_perms:
                        perm_dict[perm] = 1

            if isinstance(entity, discord.Role):
                await self.bot.db.add_whitelist_role(ctx.guild.id, entity.id, perm_dict)
            else:
                await self.bot.db.add_whitelist_user(ctx.guild.id, entity.id, perm_dict)

            active_perms = [perm for perm, value in perm_dict.items() if value == 1]
            perms_text = ', '.join(active_perms) if active_perms else 'None'

            embed = discord.Embed(
                title=f"✅ {entity_type} Whitelisted",
                description=f"**{entity.mention}** has been added to the whitelist.\n\n"
                           f"**Permissions:** {perms_text}",
                color=0x00FF00
            )
            return await ctx.send(embed=embed)

        # Otherwise, show interactive menu with component v2
        view = WhitelistLayoutView(ctx, entity, self.bot, requester=ctx.author)
        await ctx.send(view=view)

    @whitelist.command(name='remove')
    async def whitelist_remove(self, ctx, entity: typing.Union[discord.Member, discord.Role]):
        """Remove a user or role from the whitelist"""
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="Only the server owner or extra owners can manage the whitelist.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        config = await self.bot.db.get_antinuke_config(ctx.guild.id)
        if not config['status']:
            embed = discord.Embed(
                title="❌ Anti-Nuke Not Enabled",
                description="Anti-nuke protection must be enabled before managing the whitelist.\nUse `antinuke enable` to enable it.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        entity_type = "Role" if isinstance(entity, discord.Role) else "User"
        
        if isinstance(entity, discord.Role):
            current_permissions = await self.bot.db.get_role_whitelist_permissions(ctx.guild.id, entity.id)
        else:
            current_permissions = await self.bot.db.get_user_whitelist_permissions(ctx.guild.id, entity.id)
        
        if not current_permissions or not any(current_permissions.values()):
            embed = discord.Embed(
                title="❌ Not Whitelisted",
                description=f"**{entity.mention}** is not currently whitelisted from any modules.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)
        
        # Use component v2 view for whitelist removal
        view = WhitelistRemoveLayoutView(ctx, entity, self.bot, current_permissions, requester=ctx.author)
        await ctx.send(view=view)

    @whitelist.command(name='show', aliases=['list'])
    async def whitelist_show(self, ctx):
        """Show all whitelisted users and roles with their modules"""
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can view the whitelist.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)
        
        from Jo1nTrX.utils.pagination import PaginationView
        import math
        
        user_ids = await self.bot.db.get_whitelisted_users(ctx.guild.id)
        role_ids = await self.bot.db.get_whitelisted_roles(ctx.guild.id)

        if not user_ids and not role_ids:
            embed = discord.Embed(
                title="<:Jo1nTrX_antinuke:1438450620402237542> Whitelist",
                description="No users or roles are currently whitelisted.",
                color=0xFF0000
            )
            await ctx.send(embed=embed)
            return

        module_names = {
            "ban": "Anti Ban", "kick": "Anti Kick", "chcr": "Anti Channel Create",
            "chdl": "Anti Channel Delete", "chup": "Anti Channel Update",
            "rlcr": "Anti Role Create", "rldl": "Anti Role Delete", "rlup": "Anti Role Update",
            "botadd": "Anti Bot Add", "mngweb": "Anti Webhook Create",
            "serverup": "Anti Guild Update", "meneve": "Anti Everyone Mention",
            "prune": "Anti Member Prune", "emcr": "Anti Emoji Create", "emdl": "Anti Emoji Delete"
        }
        
        whitelist_data = []
        
        for user_id in user_ids:
            display_name = f"<@{user_id}>"
            
            permissions = await self.bot.db.get_user_whitelist_permissions(ctx.guild.id, user_id)
            
            whitelisted_modules = [module_names.get(perm, perm) for perm, is_whitelisted in permissions.items() if is_whitelisted]
            
            if len(whitelisted_modules) == len(module_names):
                modules_text = "All Modules"
            elif whitelisted_modules:
                modules_text = ", ".join(whitelisted_modules)
            else:
                continue
            
            whitelist_data.append({
                'type': 'User',
                'display': display_name,
                'modules': modules_text
            })
        
        for role_id in role_ids:
            role = ctx.guild.get_role(role_id)
            if role:
                display_name = f"{role.mention}"
            else:
                display_name = f"Deleted Role (ID: {role_id})"
            
            permissions = await self.bot.db.get_role_whitelist_permissions(ctx.guild.id, role_id)
            
            whitelisted_modules = [module_names.get(perm, perm) for perm, is_whitelisted in permissions.items() if is_whitelisted]
            
            if len(whitelisted_modules) == len(module_names):
                modules_text = "All Modules"
            elif whitelisted_modules:
                modules_text = ", ".join(whitelisted_modules)
            else:
                continue
            
            whitelist_data.append({
                'type': 'Role',
                'display': display_name,
                'modules': modules_text
            })
        
        items_per_page = 5
        total_items = len(whitelist_data)
        
        if total_items == 0:
            embed = discord.Embed(
                title="<:Jo1nTrX_antinuke:1438450620402237542> Whitelist",
                description="No users or roles are currently whitelisted.",
                color=0xFF0000
            )
            await ctx.send(embed=embed)
            return
        
        total_pages = math.ceil(total_items / items_per_page)
        current_page = 0
        
        def create_embed(page):
            start = page * items_per_page
            end = start + items_per_page
            page_data = whitelist_data[start:end]
            
            description = ""
            for idx, entry in enumerate(page_data, start=start + 1):
                description += f"**{idx}.** {entry['display']}\n"
                description += f"└ **Type:** {entry['type']}\n"
                description += f"└ **Modules:** {entry['modules']}\n\n"
            
            embed = discord.Embed(
                title="<:Jo1nTrX_antinuke:1438450620402237542> Whitelist",
                description=description,
                color=0x00FF00
            )
            if total_pages > 1:
                embed.set_footer(text=f"Page {page + 1}/{total_pages} • Total: {len(user_ids)} users, {len(role_ids)} roles")
            else:
                embed.set_footer(text=f"Total: {len(user_ids)} users, {len(role_ids)} roles")
            return embed
        
        embed = EmbedFactory.create(current_page)
        
        if total_pages > 1:
            view = PaginationView(current_page, total_pages, create_embed, ctx.author)
            await ctx.send(embed=embed, view=view)
        else:
            await ctx.send(embed=embed)

    @whitelist.command(name='reset')
    async def whitelist_reset(self, ctx):
        """Reset all whitelisted users"""
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can reset the whitelist.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        await self.bot.db.reset_whitelist(ctx.guild.id)

        embed = discord.Embed(
            title="✅ Whitelist Reset",
            description="All whitelisted users have been removed.",
            color=0x00FF00
        )
        await ctx.send(embed=embed)

    @commands.group(name='extraowner', invoke_without_command=True)
    async def extraowner(self, ctx):
        """Extra owner management commands"""
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="<:Jo1nTrX_antinuke:1438450620402237542> Extra Owner Commands",
                description="**Available Commands:**\n"
                           "`extraowner add <user>` - Add extra owner\n"
                           "`extraowner remove <user>` - Remove extra owner\n"
                           "`extraowner show` - Show extra owners\n"
                           "`extraowner reset` - Reset all extra owners\n\n"
                           "**Note:** Extra owners have full anti-nuke bypass and can manage all anti-nuke settings.",
                color=0x00FF00
            )
            await ctx.send(embed=embed)

    @extraowner.command(name='add')
    async def extraowner_add(self, ctx, user: discord.Member):
        """Add an extra owner"""
        if ctx.author.id != ctx.guild.owner_id:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner can add extra owners.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)
        
        current_owners = await self.bot.db.get_extra_owners(ctx.guild.id)
        current_count = len(current_owners)
        
        premium_data = await self.bot.db.check_premium_user(ctx.author.id, ctx.guild.id)
        max_owners = 5 if premium_data['has_premium'] else 2
        
        if current_count >= max_owners:
            premium_status = "Premium" if premium_data['has_premium'] else "Normal"
            embed = discord.Embed(
                description=f"{self.cross_emoji} You've reached your extra owner limit!\n\n"
                           f"**User Type:** {premium_status}\n"
                           f"**Current Extra Owners:** {current_count}/{max_owners}\n\n"
                           f"{'Upgrade to premium to add up to 5 extra owners!' if not premium_data['has_premium'] else 'Remove some extra owners before adding new ones.'}",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)
        
        is_already_owner = await self.bot.db.is_extra_owner(ctx.guild.id, user.id)
        if is_already_owner:
            embed = discord.Embed(
                description=f"{self.cross_emoji} **{user.mention}** is already an extra owner!",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        await self.bot.db.add_extra_owner(ctx.guild.id, user.id)
        
        premium_status = "Premium" if premium_data['has_premium'] else "Normal"
        new_count = current_count + 1

        embed = discord.Embed(
            description=f"{self.tick_emoji} **{user.mention}** has been added as an extra owner.\n\n"
                       f"**User Type:** {premium_status} ({new_count}/{max_owners} extra owners)",
            color=0x00FF00
        )
        await ctx.send(embed=embed)

    @extraowner.command(name='remove')
    async def extraowner_remove(self, ctx, user: discord.Member):
        """Remove an extra owner"""
        if ctx.author.id != ctx.guild.owner_id:
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner can remove extra owners.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        await self.bot.db.remove_extra_owner(ctx.guild.id, user.id)

        embed = discord.Embed(
            title="✅ Extra Owner Removed",
            description=f"**{user.mention}** has been removed from extra owners.",
            color=0x00FF00
        )
        await ctx.send(embed=embed)

    @extraowner.command(name='show')
    async def extraowner_show(self, ctx):
        """Show all extra owners"""
        if not await self.is_guild_owner_or_extra_owner(ctx):
            embed = discord.Embed(
                description=f"{self.cross_emoji} Only the server owner or extra owners can view extra owners.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)
        
        owner_ids = await self.bot.db.get_extra_owners(ctx.guild.id)

        if not owner_ids:
            embed = discord.Embed(
                title="<:Jo1nTrX_antinuke:1438450620402237542> Extra Owners",
                description="No extra owners have been added.",
                color=0xFF0000
            )
        else:
            users_list = []
            for owner_id in owner_ids:
                try:
                    user = await self.bot.fetch_user(owner_id)
                    users_list.append(f"• {user.mention} ({user.name})")
                except:
                    users_list.append(f"• <@{owner_id}> (ID: {owner_id})")

            embed = discord.Embed(
                title="<:Jo1nTrX_antinuke:1438450620402237542> Extra Owners",
                description="\n".join(users_list),
                color=0x00FF00
            )

        await ctx.send(embed=embed)

    @extraowner.command(name='reset')
    async def extraowner_reset(self, ctx):
        """Reset all extra owners"""
        if ctx.author.id != ctx.guild.owner_id:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="Only the server owner can reset extra owners.",
                color=0xFF0000
            )
            return await ctx.send(embed=embed)

        await self.bot.db.reset_extra_owners(ctx.guild.id)

        embed = discord.Embed(
            title="✅ Extra Owners Reset",
            description="All extra owners have been removed.",
            color=0x00FF00
        )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AntiNukeCommands(bot))
