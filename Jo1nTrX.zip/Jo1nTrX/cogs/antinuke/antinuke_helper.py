import discord
import asyncio
import time
from collections import deque
from datetime import datetime, timezone
from Jo1nTrX.utils.embeds import create_layout_view
from Jo1nTrX.utils.emoji_manager import emoji

class AntiNukeCache:
    """High-performance in-memory cache for antinuke data"""
    
    def __init__(self, ttl=60):
        self.ttl = ttl
        self.cache = {}
        self.timestamps = {}
    
    def get(self, key):
        """Get value from cache if not expired"""
        if key in self.cache:
            if time.time() - self.timestamps[key] < self.ttl:
                return self.cache[key]
            else:
                del self.cache[key]
                del self.timestamps[key]
        return None
    
    def set(self, key, value):
        """Set value in cache"""
        self.cache[key] = value
        self.timestamps[key] = time.time()
    
    def invalidate(self, guild_id):
        """Invalidate all cache entries for a guild"""
        keys_to_delete = [k for k in self.cache.keys() if k.startswith(f"{guild_id}_")]
        for key in keys_to_delete:
            del self.cache[key]
            del self.timestamps[key]

class AntiNukeEngine:
    """Rexz/Wick-style central AntinukeEngine for signal-based detection"""
    
    def __init__(self, bot):
        self.bot = bot
        from .engine import AntinukeEngine as InternalEngine
        self.engine = InternalEngine(bot)
    
    def signal(self, guild_id, event_type, metadata=None):
        """O(1) signal emission from event listeners"""
        if self.engine.signal(guild_id, event_type):
            asyncio.create_task(self.handle_lockdown(guild_id, event_type, metadata))

    async def handle_lockdown(self, guild_id, event_type, metadata):
        """Centralized detection, punishment, and recovery"""
        try:
            guild = self.bot.get_guild(guild_id)
            if not guild: return

            # 1. IDENTIFY EXECUTOR (Audit Log check AFTER lockdown)
            helper = AntiNukeHelper(self.bot)
            # Fetch config directly to ensure we have latest status
            config = await self.bot.db.get_antinuke_config(guild_id)
            if not config or not config.get('status'):
                self.engine.release_lockdown(guild_id)
                return

            action_map = {
                'chdl': discord.AuditLogAction.channel_delete,
                'chcr': discord.AuditLogAction.channel_create,
                'rldl': discord.AuditLogAction.role_delete,
                'rlcr': discord.AuditLogAction.role_create,
                'ban': discord.AuditLogAction.ban,
                'kick': discord.AuditLogAction.kick,
                'mngweb': discord.AuditLogAction.webhook_create,
                'meneve': None, # No audit log for message mentions
                'emcr': discord.AuditLogAction.emoji_create,
                'emdl': discord.AuditLogAction.emoji_delete,
                'antiunban': discord.AuditLogAction.unban,
                'antibot': discord.AuditLogAction.bot_add,
                'prune': discord.AuditLogAction.member_prune,
                'gup': discord.AuditLogAction.guild_update,
                'chup': discord.AuditLogAction.channel_update,
                'rlup': discord.AuditLogAction.role_update
            }
            
            full_event_names = {
                'chdl': 'Channel Delete',
                'chcr': 'Channel Create',
                'rldl': 'Role Delete',
                'rlcr': 'Role Create',
                'ban': 'Member Ban',
                'kick': 'Member Kick',
                'mngweb': 'Manage Webhooks',
                'meneve': 'Mention Everyone/Here',
                'emcr': 'Emoji Create',
                'emdl': 'Emoji Delete',
                'antiunban': 'Member Unban',
                'antibot': 'Bot Add',
                'prune': 'Member Prune',
                'gup': 'Guild Update',
                'chup': 'Channel Update',
                'rlup': 'Role Update'
            }
            long_event_type = full_event_names.get(event_type, event_type)

            executor = None
            target_id = None
            if event_type == 'meneve' and metadata and 'message' in metadata:
                executor = metadata['message'].author
            elif event_type in action_map and action_map[event_type]:
                # Optimized for instant punishment:
                # 1) Start with NO delay for the first check
                # 2) Match by BOTH: action type and target.id
                if metadata:
                    if 'channel_id' in metadata: target_id = metadata['channel_id']
                    elif 'role_id' in metadata: target_id = metadata['role_id']
                    elif 'user_id' in metadata: target_id = metadata['user_id']
                
                # Check audit logs up to 10 times with tiny intervals for near-instant detection
                for i in range(10):
                    logs = await helper.fetch_audit_logs_fast(guild, action_map[event_type], target_id)
                    if logs:
                        executor = logs.user
                        break
                    # Wait only 0.1s for the next check if not found
                    await asyncio.sleep(0.1)

            if not executor or executor.id == guild.owner_id or executor.id == self.bot.user.id:
                self.engine.release_lockdown(guild_id)
                return

            # Check Whitelist
            perm_check = await helper.check_all_permissions_parallel(guild, executor.id, event_type)
            if perm_check['bypass']:
                self.engine.release_lockdown(guild_id)
                return

            # 2. PUNISHMENT
            punishment_taken = False
            punish_start_time = time.monotonic()
            try:
                # CRITICAL: Punishment must be immediate and bold
                await guild.ban(executor, reason=f"Jo1nTrX Anti-Nuke | {long_event_type} Detected")
                punishment_taken = True
                print(f"✅ PUNISHED: {executor} (ID: {executor.id}) banned in guild {guild.id} for {long_event_type}")
            except Exception as e:
                print(f"❌ PUNISHMENT FAILED: {e}")
                # Fallback to kick if ban fails
                try:
                    await guild.kick(executor, reason=f"Jo1nTrX Anti-Nuke | {long_event_type} Detected (Ban Failed)")
                    punishment_taken = True
                    print(f"✅ PUNISHED (KICK): {executor} (ID: {executor.id}) kicked in guild {guild.id} for {long_event_type}")
                except Exception as ke:
                    print(f"❌ KICK FAILED: {ke}")
            
            punish_end_time = time.monotonic()
            response_time_val = punish_end_time - punish_start_time
            response_time_str = f"{response_time_val:.2f}s"

            # 3. LOGGING
            await helper.log_event(
                guild_id=guild_id,
                event_type=f"VELOCITY_DETECT: {long_event_type}",
                executor=executor,
                target=metadata.get('target') or metadata.get('channel_id') or metadata.get('role_id') or metadata.get('user_id'),
                action_taken="Banned" if punishment_taken else "Lockdown Triggered",
                reason=f"Exceeded burst threshold for {long_event_type}",
                time_taken=response_time_str
            )

            # 4. RECOVERY (Deferred to background)
            asyncio.create_task(self.perform_recovery(guild, event_type, metadata))
            
            # Keep lockdown active briefly to prevent immediate re-trigger during cleanup
            await asyncio.sleep(5)
            
            # CRITICAL: Reset engine state for this event type to allow future detection
            if hasattr(self.engine, 'reset_signals'):
                self.engine.reset_signals(guild_id, event_type)
            
        finally:
            self.engine.release_lockdown(guild_id)

    async def perform_recovery(self, guild, event_type, metadata):
        """Standardized recovery logic based on event type with 2s cooldown and retries"""
        await asyncio.sleep(1) # Start recovery quickly
        
        async def safe_recover(action_coro, action_name):
            for attempt in range(3):
                try:
                    await action_coro
                    print(f"✅ Recovery Successful: {action_name} in {guild.name}")
                    return True
                except Exception as e:
                    print(f"⚠️ Recovery Attempt {attempt+1} Failed: {action_name} - {e}")
                    await asyncio.sleep(2) # 2s Cooldown between retries
            return False

        try:
            # 1. Channels Recovery
            if event_type == 'chdl' and metadata and 'channel_id' in metadata:
                # RECREATE DELETED CHANNEL
                channel_name = metadata.get('channel_name', 'recovered-channel')
                channel_type = metadata.get('channel_type', discord.ChannelType.text)
                overwrites = metadata.get('overwrites', {})
                category_id = metadata.get('category_id')
                category = guild.get_channel(category_id) if category_id else None
                
                await safe_recover(
                    guild.create_text_channel(name=channel_name, category=category, overwrites=overwrites, reason="Jo1nTrX Anti-Nuke Recovery | Unauthorized Channel Delete"),
                    f"Recreate Channel: {channel_name}"
                )

            elif event_type == 'chcr' and metadata and 'channel_id' in metadata:
                channel = guild.get_channel(metadata['channel_id'])
                if channel: 
                    await safe_recover(
                        channel.delete(reason="Jo1nTrX Anti-Nuke Recovery | Unauthorized Channel Create"),
                        "Channel Delete"
                    )
            
            # 2. Roles Recovery
            elif event_type == 'rldl' and metadata and 'role_id' in metadata:
                # RECREATE DELETED ROLE
                role_name = metadata.get('role_name', 'recovered-role')
                permissions = metadata.get('permissions', discord.Permissions.none())
                color = metadata.get('color', discord.Color.default())
                hoist = metadata.get('hoist', False)
                mentionable = metadata.get('mentionable', False)
                
                await safe_recover(
                    guild.create_role(name=role_name, permissions=permissions, color=color, hoist=hoist, mentionable=mentionable, reason="Jo1nTrX Anti-Nuke Recovery | Unauthorized Role Delete"),
                    f"Recreate Role: {role_name}"
                )

            elif event_type == 'rlcr' and metadata and 'role_id' in metadata:
                role = guild.get_role(metadata['role_id'])
                if role: 
                    await asyncio.sleep(1) # Shorter cooldown
                    await safe_recover(
                        role.delete(reason="Jo1nTrX Anti-Nuke Recovery | Unauthorized Role Create"),
                        "Role Delete"
                    )
            
            # 3. Security Recovery
            elif event_type == 'antiunban' and metadata and 'user_id' in metadata:
                user = await self.bot.fetch_user(metadata['user_id'])
                if user: 
                    await asyncio.sleep(1) # Shorter cooldown
                    await safe_recover(
                        guild.ban(user, reason="Jo1nTrX Anti-Nuke Recovery | Unauthorized Unban"),
                        "Re-Ban User"
                    )
            elif event_type == 'antibot' and metadata and 'user_id' in metadata:
                bot_member = guild.get_member(metadata['user_id'])
                if bot_member: 
                    await asyncio.sleep(1) # Shorter cooldown
                    await safe_recover(
                        bot_member.kick(reason="Jo1nTrX Anti-Nuke Recovery | Unauthorized Bot"),
                        "Kick Unauthorized Bot"
                    )
            
            # 4. Webhook Recovery
            elif event_type == 'mngweb' and metadata and 'channel_id' in metadata:
                pass

            # 5. Message Recovery
            elif event_type == 'meneve' and metadata and 'message' in metadata:
                try: 
                    await asyncio.sleep(1) # Shorter cooldown
                    await safe_recover(
                        metadata['message'].delete(),
                        "Delete Mention Message"
                    )
                except: pass
        except Exception as e:
            print(f"Recovery Error: {e}")

class AntiNukeHelper:
    """Helper class for common antinuke functionality with aggressive caching"""
    
    def __init__(self, bot):
        self.bot = bot
        self.cache = AntiNukeCache(ttl=120)
        self.perf_stats = {}
    
    async def is_antinuke_enabled(self, guild_id):
        """Check if antinuke is enabled for a guild (cached)"""
        cache_key = f"{guild_id}_enabled"
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        try:
            config = await self.bot.db.get_antinuke_config(guild_id)
            if not config:
                self.cache.set(cache_key, False)
                return False
                
            is_enabled = bool(config.get('status'))
            self.cache.set(cache_key, is_enabled)
            return is_enabled
        except Exception:
            return False
    
    async def is_whitelisted(self, guild_id, user_id, permission):
        """Check if a user is whitelisted for a permission (cached)"""
        cache_key = f"{guild_id}_wl_{user_id}_{permission}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        guild = self.bot.get_guild(guild_id)
        user_roles = None
        if guild:
            member = guild.get_member(user_id)
            if member:
                user_roles = member.roles
        
        result = await self.bot.db.is_whitelisted(guild_id, user_id, permission, user_roles)
        self.cache.set(cache_key, result)
        return result
    
    async def is_extra_owner(self, guild_id, user_id):
        """Check if a user is an extra owner (cached)"""
        cache_key = f"{guild_id}_owner_{user_id}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        result = await self.bot.db.is_extra_owner(guild_id, user_id)
        self.cache.set(cache_key, result)
        return result
    
    async def check_all_permissions_parallel(self, guild, executor_id, permission):
        """Ultra-fast parallel permission check - combines all checks in one call"""
        if executor_id in {guild.owner_id, self.bot.user.id}:
            return {'bypass': True, 'reason': 'owner_or_bot'}
        
        has_secured, is_owner, is_whitelisted = await asyncio.gather(
            self.has_secured_role(guild, executor_id),
            self.is_extra_owner(guild.id, executor_id),
            self.is_whitelisted(guild.id, executor_id, permission),
            return_exceptions=True
        )
        
        if isinstance(has_secured, Exception): has_secured = False
        if isinstance(is_owner, Exception): is_owner = False
        if isinstance(is_whitelisted, Exception): is_whitelisted = False
        
        if has_secured or is_owner:
            return {'bypass': True, 'reason': 'secured_or_extra_owner'}
        
        return {
            'bypass': False,
            'whitelisted': is_whitelisted
        }
    
    async def check_beastmode(self, guild_id, user_id, action_type):
        """Check if beastmode is enabled and if user has exceeded threshold
        
        Returns:
            True if action is allowed
            False if user has exceeded threshold and should be kicked
        """
        config = await self.bot.db.get_beastmode_config(guild_id)
        
        if not config['enabled']:
            return True
        
        action_type_mapping = {
            'ban': 'max_ban_per_min',
            'kick': 'max_kick_per_min',
            'chcr': 'max_channel_create_per_min',
            'chdl': 'max_channel_delete_per_min',
            'rlcr': 'max_role_create_per_min',
            'rldl': 'max_role_delete_per_min',
            'mngweb': 'max_webhook_create_per_min',
            'meneve': 'max_mention_per_min',
            'emcr': 'max_emoji_create_per_min',
            'emdl': 'max_emoji_delete_per_min'
        }
        
        if action_type not in action_type_mapping:
            return True
        
        recent_actions = await self.bot.db.get_recent_beastmode_actions(guild_id, user_id, action_type, minutes=1)
        
        threshold = config[action_type_mapping[action_type]]
        
        if recent_actions >= threshold:
            return False
        
        await self.bot.db.track_beastmode_action(guild_id, user_id, action_type)
        
        return True
    
    async def is_protected_user(self, guild, user_id):
        """Check if a user is protected (owner, bot itself, or has secured role)"""
        if user_id in {guild.owner_id, self.bot.user.id}:
            return True
        
        member = guild.get_member(user_id)
        if member:
            secured_role = discord.utils.get(guild.roles, name="Secured By Jo1nTrX™")
            if secured_role and secured_role in member.roles:
                return True
        
        return False
    
    async def has_secured_role(self, guild, user_id):
        """Check if a user has the Secured By Jo1nTrX™ role"""
        member = guild.get_member(user_id)
        if member:
            secured_role = discord.utils.get(guild.roles, name="Secured By Jo1nTrX™")
            if secured_role and secured_role in member.roles:
                return True
        return False
    
    async def log_event(self, guild_id, event_type, executor, target=None, action_taken=None, reason=None, time_taken=None):
        """Log an antinuke event to both database and log channel (deferred to background)"""
        # Ensure we don't block the critical path
        asyncio.create_task(self._log_event_background(guild_id, event_type, executor, target, action_taken, reason, time_taken))

    async def fetch_audit_logs_fast(self, guild, action, target_id):
        """Ultra-fast audit log fetch with moderate limit to catch rapid actions"""
        if not guild.me.guild_permissions.view_audit_log:
            return None
        try:
            # 2) Increase limit to at least 10 (using 50 to be safe for rapid events)
            async for entry in guild.audit_logs(action=action, limit=50):
                # 2) Match by BOTH action type (implicit in 'action' param) and target.id
                # 3) Do NOT assume the first audit-log entry is the correct one (searching through 50)
                if target_id is None or (entry.target and entry.target.id == target_id):
                    # Check if the entry is recent (within 20 seconds to account for delay and retry loop)
                    if (discord.utils.utcnow() - entry.created_at).total_seconds() < 20:
                        return entry
        except Exception:
            pass
        return None
    
    async def _log_event_background(self, guild_id, event_type, executor, target, action_taken, reason, time_taken):
        """Background task for logging - handles rapid events without blocking"""
        try:
            # We use a semaphore or lock if needed, but for now just fire and forget
            await self.bot.db.log_antinuke_event(
                guild_id=guild_id,
                event_type=event_type,
                executor_id=executor.id,
                target_id=target.id if target and hasattr(target, 'id') else None,
                action_taken=action_taken,
                reason=reason
            )
            
            await self.send_to_log_channel(guild_id, event_type, executor, target, action_taken, reason, time_taken)
        except Exception as e:
            # Silence background logging errors to avoid cluttering logs
            pass
    
    def track_performance(self, guild_id, module_name, time_taken):
        """Track performance metrics for a specific module"""
        key = f"{guild_id}_{module_name}"
        if key not in self.perf_stats:
            self.perf_stats[key] = []
        
        # Ensure time_taken is a float for statistics
        try:
            val = float(time_taken.replace('s', '')) if isinstance(time_taken, str) else float(time_taken)
            self.perf_stats[key].append(val)
        except:
            pass
        
        if len(self.perf_stats[key]) > 100:
            self.perf_stats[key].pop(0)
        
        if self.perf_stats[key]:
            avg_time = sum(self.perf_stats[key]) / len(self.perf_stats[key])
            val = self.perf_stats[key][-1]
            if val > 1.0:
                print(f"⚠️ {module_name}: Slow response {val:.3f}s (avg: {avg_time:.3f}s)")
            elif val < 0.1:
                print(f"⚡ {module_name}: Fast response {val*1000:.1f}ms (avg: {avg_time*1000:.1f}ms)")
    
    async def send_to_log_channel(self, guild_id, event_type, executor, target=None, action_taken=None, reason=None, time_taken=None):
        """Send event log to the designated log channel using Component V2 design"""
        try:
            # We must ensure we're getting the log_channel_id correctly
            config = await self.bot.db.get_antinuke_config(guild_id)
            if not config:
                print(f"DEBUG: No antinuke config found for guild {guild_id}")
                return

            log_channel_id = config.get('log_channel_id')
            print(f"DEBUG: Log channel ID for guild {guild_id}: {log_channel_id}")
            
            if not log_channel_id:
                return
            
            guild = self.bot.get_guild(guild_id)
            if not guild:
                print(f"DEBUG: Guild {guild_id} not found in cache")
                return
            
            log_channel = guild.get_channel(int(log_channel_id))
            if not log_channel:
                try:
                    log_channel = await guild.fetch_channel(int(log_channel_id))
                    print(f"DEBUG: Fetched log channel {log_channel_id} for {guild.name}")
                except Exception as e:
                    print(f"DEBUG: Failed to fetch log channel {log_channel_id}: {e}")
                    # Attempt to find by name as fallback
                    log_channel = discord.utils.get(guild.text_channels, name="antinuke-logs")
                    if not log_channel:
                        return
            
            if not log_channel.permissions_for(guild.me).send_messages:
                print(f"DEBUG: No send permissions in log channel {log_channel.name}")
                return
            
            time_str = str(time_taken) if time_taken else "N/A"
            # Performance tracking already handled in handle_lockdown if needed
            
            from Jo1nTrX.utils.component import create_antinuke_log_view
            view, embed = create_antinuke_log_view(guild, event_type, executor, target, action_taken, time_str)
            
            msg = await log_channel.send(embed=embed, view=view)
            print(f"✅ AntiNuke Log sent successfully: {msg.id} in {log_channel.name}")
        except Exception as e:
            print(f"Error sending to log channel: {e}")
