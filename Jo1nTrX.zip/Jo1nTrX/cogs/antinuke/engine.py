import discord
import asyncio
import time
from collections import deque
from datetime import datetime, timezone

class AntinukeEngine:
    """Central engine for high-velocity antinuke detection"""
    
    def __init__(self, bot):
        self.bot = bot
        self.signals = {} # {guild_id: {event_type: deque([timestamps])}}
        self.lockdowns = {} # {guild_id: bool}
        self.thresholds = {
            'ban': 1, 'kick': 1, 'chcr': 1, 'chdl': 1, 
            'rlcr': 1, 'rldl': 1, 'mngweb': 1, 'meneve': 5,
            'emcr': 3, 'emdl': 3, 'antiunban': 1, 'antibot': 1,
            'gup': 1, 'chup': 1, 'rlup': 1, 'prune': 1
        }
        self.window = 10 # 10 second window for burst detection

    def signal(self, guild_id, event_type, metadata=None) -> bool:
        """O(1) signal emission. Returns True if threshold is crossed."""
        if guild_id not in self.signals:
            self.signals[guild_id] = {}
        
        if event_type not in self.signals[guild_id]:
            self.signals[guild_id][event_type] = deque()
        
        now = time.monotonic()
        self.signals[guild_id][event_type].append(now)
        
        # Cleanup old signals outside the window
        while self.signals[guild_id][event_type] and now - self.signals[guild_id][event_type][0] > self.window:
            self.signals[guild_id][event_type].popleft()
        
        # Check threshold
        # ALWAYS trigger if threshold is 1, regardless of lockdown status to ensure punishment
        is_threshold_hit = len(self.signals[guild_id][event_type]) >= self.thresholds.get(event_type, 3)
        
        if is_threshold_hit:
            # If already in lockdown, we still return True if it's a critical single-event threshold
            # but we update the lockdown status.
            if self.lockdowns.get(guild_id) and self.thresholds.get(event_type, 3) > 1:
                return False
                
            self.lockdowns[guild_id] = True
            return True
            
        return False

    def release_lockdown(self, guild_id):
        """Reset lockdown flag for a guild"""
        self.lockdowns[guild_id] = False

    def reset_signals(self, guild_id, event_type=None):
        """Reset signal history for a guild/event"""
        if guild_id in self.signals:
            if event_type:
                if event_type in self.signals[guild_id]:
                    self.signals[guild_id][event_type] = deque()
            else:
                self.signals[guild_id] = {}
