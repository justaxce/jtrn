import discord
from discord.ext import commands
from discord import app_commands, ui
from typing import Optional
import asyncio
from Jo1nTrX.utils.component import bot_emoji
from .admin_helper import ARROW_EMOJI, SECTION_EMOJI, create_v2_view

CHANNELS_ICON = "<:Jo1nTrX_channels:1420433174949003294>"
LOCK_ICON = "<:Jo1nTrX_lock_1:1412701461749563463>"
UNLOCK_ICON = "<:Jo1nTrX_unlock_1:1412701488328998972>"
DELETE_ICON = "<:jo1ntrx_delete:1405095625795702895>"
SUCCESS_EMOJI = "<:Jo1nTrX_Yes:1408288995477159987>"
ERROR_EMOJI = "<:Jo1nTrX_No:1408289044470960129>"


def create_error_content(title: str, description: str) -> str:
    return f"""## {ERROR_EMOJI} {title}
> {description}"""


def create_success_content(title: str, description: str) -> str:
    return f"""## {SUCCESS_EMOJI} {title}
> {description}"""


class ChannelConfirmationLayoutView(ui.LayoutView):
    def __init__(self, ctx, action_type, target: Optional[discord.TextChannel] = None, targets: Optional[list] = None):
        super().__init__(timeout=30)
        self.ctx = ctx
        self.action_type = action_type
        self.target = target
        self.targets = targets or []
        self._setup_view()

    def _setup_view(self):
        action_descriptions = {
            "nuke": f"Nuke channel **{self.target.mention if self.target else 'Unknown'}**",
            "lockall": f"Lock **{len(self.targets)}** channels",
            "unlockall": f"Unlock **{len(self.targets)}** channels",
            "hideall": f"Hide **{len(self.targets)}** channels",
            "unhideall": f"Unhide **{len(self.targets)}** channels"
        }
        
        content = f"""## {DELETE_ICON if self.action_type == 'nuke' else CHANNELS_ICON} Confirm {self.action_type.title()}
> Are you sure you want to {action_descriptions.get(self.action_type, self.action_type)}?

{SECTION_EMOJI} **__Warning__**
{ARROW_EMOJI} This action may take some time for bulk operations
{ARROW_EMOJI} Click Yes to confirm or No to cancel"""

        text_display = ui.TextDisplay(content)
        
        yes_btn = ui.Button(label="Yes", style=discord.ButtonStyle.success, emoji="✅")
        no_btn = ui.Button(label="No", style=discord.ButtonStyle.danger, emoji="❌")
        
        async def yes_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            await interaction.response.defer()
            await self._execute_action(interaction)
        
        async def no_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            content = create_error_content("Cancelled", f"{self.action_type.title()} operation has been cancelled.")
            view = create_v2_view(content)
            await interaction.response.edit_message(view=view)
        
        yes_btn.callback = yes_callback
        no_btn.callback = no_callback
        
        button_row = ui.ActionRow(yes_btn, no_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)
    
    async def _execute_action(self, interaction: discord.Interaction):
        try:
            if self.action_type == "nuke" and self.target:
                channel = self.target
                position = channel.position
                everyone_overwrite = channel.overwrites_for(channel.guild.default_role)
                is_locked = everyone_overwrite.send_messages is False
                
                new_channel = await channel.clone(reason=f"Channel nuked by {self.ctx.author}")
                await new_channel.edit(position=position)
                
                if is_locked:
                    overwrite = new_channel.overwrites_for(new_channel.guild.default_role)
                    overwrite.send_messages = False
                    await new_channel.set_permissions(new_channel.guild.default_role, overwrite=overwrite)
                
                await channel.delete(reason=f"Channel nuked by {self.ctx.author}")
                
                content = create_success_content("Channel Nuked", f"Successfully nuked channel **{channel.name}**!")
                view = create_v2_view(content)
                await new_channel.send(view=view)
                
            elif self.action_type in ["lockall", "unlockall", "hideall", "unhideall"] and self.targets:
                loading_content = f"""## {CHANNELS_ICON} Processing...
> Processing {len(self.targets)} channels..."""
                loading_view = create_v2_view(loading_content)
                await interaction.edit_original_response(view=loading_view)
                
                for i, channel in enumerate(self.targets):
                    try:
                        overwrite = channel.overwrites_for(channel.guild.default_role)
                        if self.action_type == "lockall":
                            overwrite.send_messages = False
                        elif self.action_type == "unlockall":
                            overwrite.send_messages = None
                        elif self.action_type == "hideall":
                            overwrite.view_channel = False
                        elif self.action_type == "unhideall":
                            overwrite.view_channel = None
                        await channel.set_permissions(channel.guild.default_role, overwrite=overwrite)
                    except:
                        pass
                    if i > 0 and i % 5 == 0:
                        await asyncio.sleep(0.5)
                
                action_messages = {
                    "lockall": "Locked all channels",
                    "unlockall": "Unlocked all channels",
                    "hideall": "Hidden all channels",
                    "unhideall": "Unhidden all channels"
                }
                content = create_success_content("Success", f"{action_messages[self.action_type]} of this server!")
                view = create_v2_view(content)
                await interaction.edit_original_response(view=view)
                
        except Exception as e:
            content = create_error_content("Error", f"Failed to perform {self.action_type}: {str(e)}")
            view = create_v2_view(content)
            await interaction.edit_original_response(view=view)


class CategoryConfirmationLayoutView(ui.LayoutView):
    def __init__(self, ctx, action_type, category, category_id: str):
        super().__init__(timeout=30)
        self.ctx = ctx
        self.action_type = action_type
        self.category = category
        self.category_id = category_id
        self._setup_view()

    def _setup_view(self):
        channel_count = len(self.category.text_channels) + len(self.category.voice_channels) if self.action_type in ["hidecat", "unhidecat", "clearcat"] else len(self.category.text_channels)
        
        content = f"""## {DELETE_ICON if self.action_type == 'clearcat' else CHANNELS_ICON} Confirm {self.action_type.title()}
> Are you sure you want to {self.action_type} category **{self.category.name}**?

{SECTION_EMOJI} **__Affected__**
{ARROW_EMOJI} This will affect **{channel_count}** channels
{ARROW_EMOJI} Click Yes to confirm or No to cancel"""

        text_display = ui.TextDisplay(content)
        
        yes_btn = ui.Button(label="Yes", style=discord.ButtonStyle.success, emoji="✅")
        no_btn = ui.Button(label="No", style=discord.ButtonStyle.danger, emoji="❌")
        
        async def yes_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            await interaction.response.defer()
            await self._execute_action(interaction)
        
        async def no_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            content = create_error_content("Cancelled", f"{self.action_type.title()} operation has been cancelled.")
            view = create_v2_view(content)
            await interaction.response.edit_message(view=view)
        
        yes_btn.callback = yes_callback
        no_btn.callback = no_callback
        
        button_row = ui.ActionRow(yes_btn, no_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)
    
    async def _execute_action(self, interaction: discord.Interaction):
        try:
            loading_content = f"""## {CHANNELS_ICON} Processing...
> Processing category {self.category.name}..."""
            loading_view = create_v2_view(loading_content)
            await interaction.edit_original_response(view=loading_view)
            
            if self.action_type == "lockcat":
                for i, channel in enumerate(self.category.text_channels):
                    try:
                        overwrite = channel.overwrites_for(self.ctx.guild.default_role)
                        overwrite.send_messages = False
                        await channel.set_permissions(self.ctx.guild.default_role, overwrite=overwrite)
                    except:
                        pass
                    if i > 0 and i % 5 == 0:
                        await asyncio.sleep(0.5)
                        
            elif self.action_type == "unlockcat":
                for i, channel in enumerate(self.category.text_channels):
                    try:
                        overwrite = channel.overwrites_for(self.ctx.guild.default_role)
                        overwrite.send_messages = None
                        await channel.set_permissions(self.ctx.guild.default_role, overwrite=overwrite)
                    except:
                        pass
                    if i > 0 and i % 5 == 0:
                        await asyncio.sleep(0.5)
                        
            elif self.action_type == "hidecat":
                try:
                    overwrite = self.category.overwrites_for(self.ctx.guild.default_role)
                    overwrite.view_channel = False
                    await self.category.set_permissions(self.ctx.guild.default_role, overwrite=overwrite)
                except:
                    pass
                    
                for i, channel in enumerate(self.category.text_channels + self.category.voice_channels):
                    try:
                        overwrite = channel.overwrites_for(self.ctx.guild.default_role)
                        overwrite.view_channel = False
                        await channel.set_permissions(self.ctx.guild.default_role, overwrite=overwrite)
                    except:
                        pass
                    if i > 0 and i % 5 == 0:
                        await asyncio.sleep(0.5)
                        
            elif self.action_type == "unhidecat":
                try:
                    overwrite = self.category.overwrites_for(self.ctx.guild.default_role)
                    overwrite.view_channel = None
                    await self.category.set_permissions(self.ctx.guild.default_role, overwrite=overwrite)
                except:
                    pass
                    
                for i, channel in enumerate(self.category.text_channels + self.category.voice_channels):
                    try:
                        overwrite = channel.overwrites_for(self.ctx.guild.default_role)
                        overwrite.view_channel = None
                        await channel.set_permissions(self.ctx.guild.default_role, overwrite=overwrite)
                    except:
                        pass
                    if i > 0 and i % 5 == 0:
                        await asyncio.sleep(0.5)
                        
            elif self.action_type == "clearcat":
                all_channels = self.category.text_channels + self.category.voice_channels
                for i, channel in enumerate(all_channels):
                    try:
                        await channel.delete(reason=f"Category cleared by {self.ctx.author}")
                    except:
                        pass
                    if i > 0 and i % 3 == 0:
                        await asyncio.sleep(0.7)
            
            action_messages = {
                "lockcat": f"Locked all channels in category {self.category.name}",
                "unlockcat": f"Unlocked all channels in category {self.category.name}",
                "hidecat": f"Hidden all channels in category {self.category.name}",
                "unhidecat": f"Unhidden all channels in category {self.category.name}",
                "clearcat": f"Cleared all channels in category {self.category.name}"
            }
            content = create_success_content("Success", action_messages.get(self.action_type, "Operation completed"))
            view = create_v2_view(content)
            await interaction.edit_original_response(view=view)
            
        except Exception as e:
            content = create_error_content("Error", f"Failed to perform {self.action_type}: {str(e)}")
            view = create_v2_view(content)
            await interaction.edit_original_response(view=view)


class CreateChannelLayoutView(ui.LayoutView):
    def __init__(self, ctx):
        super().__init__(timeout=300)
        self.ctx = ctx
        self._setup_view()

    def _setup_view(self):
        content = f"""## {CHANNELS_ICON} Channel Creation Setup
> Choose an option below to proceed with channel creation.

{SECTION_EMOJI} **__Instructions__**
{ARROW_EMOJI} Click 'Create Channel' to start the setup
{ARROW_EMOJI} You'll be asked for channel name and category"""

        text_display = ui.TextDisplay(content)
        
        create_btn = ui.Button(label="Create Channel", style=discord.ButtonStyle.primary)
        cancel_btn = ui.Button(label="Cancel", style=discord.ButtonStyle.danger)
        
        async def create_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            
            await interaction.response.send_message("Enter the channel name you want to create. Type `cancel` to cancel!", ephemeral=True)
            
            def check(message):
                return message.author.id == self.ctx.author.id and message.channel == self.ctx.channel
            
            try:
                message = await self.ctx.bot.wait_for('message', timeout=300.0, check=check)
                
                if message.content.lower() == 'cancel':
                    content = create_error_content("Cancelled", "Channel creation cancelled.")
                    view = create_v2_view(content)
                    await message.reply(view=view)
                    return
                
                channel_name = message.content.strip()
                
                await message.reply("Enter category ID if you want this channel in a specific category. Type `skip` for uncategorized or `cancel` to cancel!", delete_after=300)
                
                category_message = await self.ctx.bot.wait_for('message', timeout=300.0, check=check)
                
                if category_message.content.lower() == 'cancel':
                    content = create_error_content("Cancelled", "Channel creation cancelled.")
                    view = create_v2_view(content)
                    await category_message.reply(view=view)
                    return
                
                category = None
                if category_message.content.lower() != 'skip':
                    try:
                        category_id = int(category_message.content.strip())
                        category = discord.utils.get(interaction.guild.categories, id=category_id) if interaction.guild else None
                    except:
                        pass
                
                new_channel = await interaction.guild.create_text_channel(
                    name=channel_name,
                    category=category,
                    reason=f"Channel created by {self.ctx.author}"
                )
                
                content = create_success_content("Channel Created", f"Successfully created channel {new_channel.mention}!")
                view = create_v2_view(content)
                await category_message.reply(view=view)
                
            except asyncio.TimeoutError:
                content = create_error_content("Timeout", "Channel creation timed out.")
                view = create_v2_view(content)
                await interaction.followup.send(view=view, ephemeral=True)
        
        async def cancel_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this!", ephemeral=True)
            content = create_error_content("Cancelled", "Channel creation cancelled.")
            view = create_v2_view(content)
            await interaction.response.edit_message(view=view)
        
        create_btn.callback = create_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(create_btn, cancel_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class ChannelsMgmt(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_premium(self, ctx):
        premium_status = await self.bot.db.check_premium_user(ctx.author.id, ctx.guild.id)
        if not (premium_status and premium_status.get('has_premium')):
            content = f"""## {ERROR_EMOJI} Premium Required
> You don't have premium access to use this command!

{SECTION_EMOJI} **__Get Premium__**
{ARROW_EMOJI} To get premium access, join support server.
{ARROW_EMOJI} [Join our support server](https://discord.gg/PA6UhChxZY)"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return False
        return True

    @commands.command(name='lock')
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def lock(self, ctx, channel: discord.TextChannel = None):
        """Lock a channel (prevents @everyone from sending messages)"""
        if channel is None:
            channel = ctx.channel
        if not isinstance(channel, discord.TextChannel):
            content = create_error_content("Invalid Channel", "This command only works in text channels.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        loading_content = f"""## {LOCK_ICON} Locking Channel
> Locking {channel.mention}..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            overwrite = channel.overwrites_for(ctx.guild.default_role)
            overwrite.send_messages = False
            await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            
            content = create_success_content("Channel Locked", f"Successfully locked channel {channel.mention} | {ctx.author.mention}!")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except discord.Forbidden:
            content = create_error_content("Permission Error", "I don't have permission to manage this channel.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except Exception as e:
            content = create_error_content("Error", f"Error locking channel: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @commands.command(name='unlock')
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def unlock(self, ctx, channel: discord.TextChannel = None):
        """Unlock a channel (allows @everyone to send messages)"""
        if channel is None:
            channel = ctx.channel
        if not isinstance(channel, discord.TextChannel):
            content = create_error_content("Invalid Channel", "This command only works in text channels.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        loading_content = f"""## {UNLOCK_ICON} Unlocking Channel
> Unlocking {channel.mention}..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            overwrite = channel.overwrites_for(ctx.guild.default_role)
            overwrite.send_messages = None
            await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            
            content = create_success_content("Channel Unlocked", f"Successfully unlocked channel {channel.mention} | {ctx.author.mention}!")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except discord.Forbidden:
            content = create_error_content("Permission Error", "I don't have permission to manage this channel.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except Exception as e:
            content = create_error_content("Error", f"Error unlocking channel: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @commands.command(name='hide')
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def hide(self, ctx, channel: discord.TextChannel = None):
        """Hide a channel from @everyone"""
        if channel is None:
            channel = ctx.channel
        if not isinstance(channel, discord.TextChannel):
            content = create_error_content("Invalid Channel", "This command only works in text channels.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        loading_content = f"""## {CHANNELS_ICON} Hiding Channel
> Hiding {channel.mention}..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            overwrite = channel.overwrites_for(ctx.guild.default_role)
            overwrite.view_channel = False
            await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            
            content = create_success_content("Channel Hidden", f"Successfully hidden channel {channel.mention} | {ctx.author.mention}!")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except discord.Forbidden:
            content = create_error_content("Permission Error", "I don't have permission to manage this channel.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except Exception as e:
            content = create_error_content("Error", f"Error hiding channel: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @commands.command(name='unhide')
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def unhide(self, ctx, channel: discord.TextChannel = None):
        """Unhide a channel for @everyone"""
        if channel is None:
            channel = ctx.channel
        if not isinstance(channel, discord.TextChannel):
            content = create_error_content("Invalid Channel", "This command only works in text channels.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        loading_content = f"""## {CHANNELS_ICON} Unhiding Channel
> Unhiding {channel.mention}..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            overwrite = channel.overwrites_for(ctx.guild.default_role)
            overwrite.view_channel = None
            await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            
            content = create_success_content("Channel Unhidden", f"Successfully unhidden channel {channel.mention} | {ctx.author.mention}!")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except discord.Forbidden:
            content = create_error_content("Permission Error", "I don't have permission to manage this channel.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except Exception as e:
            content = create_error_content("Error", f"Error unhiding channel: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @commands.command(name='nuke')
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def nuke(self, ctx, channel: Optional[discord.TextChannel] = None):
        """Nuke a text channel (delete and recreate)"""
        if channel is None:
            channel = ctx.channel
        if not isinstance(channel, discord.TextChannel):
            content = create_error_content("Invalid Channel", "This command only works in text channels.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        view = ChannelConfirmationLayoutView(ctx, "nuke", channel)
        await ctx.send(view=view)

    @commands.command(name='slowmode')
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def slowmode(self, ctx, seconds: int, channel: discord.TextChannel = None):
        """Set slowmode for a channel"""
        if channel is None:
            channel = ctx.channel
        if not isinstance(channel, discord.TextChannel):
            content = create_error_content("Invalid Channel", "This command only works in text channels.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        if seconds < 0 or seconds > 21600:
            content = create_error_content("Invalid Value", "Slowmode must be between 0 and 21600 seconds (6 hours).")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        loading_content = f"""## {CHANNELS_ICON} Setting Slowmode
> Setting slowmode for {channel.mention}..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            await channel.edit(slowmode_delay=seconds)
            
            if seconds == 0:
                content = f"""## {CHANNELS_ICON} Slowmode Disabled
> {CHANNELS_ICON} Disabled slowmode in {channel.mention}
> **Moderator:** {ctx.author.mention}"""
            else:
                content = f"""## {CHANNELS_ICON} Slowmode Set
> {CHANNELS_ICON} Set slowmode to **{seconds}** seconds in {channel.mention}
> **Moderator:** {ctx.author.mention}"""
            
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except discord.Forbidden:
            content = create_error_content("Permission Error", "I don't have permission to manage this channel.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except Exception as e:
            content = create_error_content("Error", f"Error setting slowmode: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @commands.command(name='lockall')
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def lockall(self, ctx):
        """Lock all channels in the server (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        text_channels = [channel for channel in ctx.guild.text_channels]
        if not text_channels:
            content = create_error_content("No Channels", "No text channels found in this server.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        view = ChannelConfirmationLayoutView(ctx, "lockall", targets=text_channels)
        await ctx.send(view=view)

    @lockall.error
    async def lockall_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='unlockall')
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def unlockall(self, ctx):
        """Unlock all channels in the server (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        text_channels = [channel for channel in ctx.guild.text_channels]
        if not text_channels:
            content = create_error_content("No Channels", "No text channels found in this server.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        view = ChannelConfirmationLayoutView(ctx, "unlockall", targets=text_channels)
        await ctx.send(view=view)

    @unlockall.error
    async def unlockall_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='hideall')
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def hideall(self, ctx):
        """Hide all channels from @everyone (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        text_channels = [channel for channel in ctx.guild.text_channels]
        if not text_channels:
            content = create_error_content("No Channels", "No text channels found in this server.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        view = ChannelConfirmationLayoutView(ctx, "hideall", targets=text_channels)
        await ctx.send(view=view)

    @hideall.error
    async def hideall_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='unhideall')
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def unhideall(self, ctx):
        """Unhide all channels for @everyone (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        text_channels = [channel for channel in ctx.guild.text_channels]
        if not text_channels:
            content = create_error_content("No Channels", "No text channels found in this server.")
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        view = ChannelConfirmationLayoutView(ctx, "unhideall", targets=text_channels)
        await ctx.send(view=view)

    @unhideall.error
    async def unhideall_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='createchannel', aliases=['channelcreate'])
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def create_channel(self, ctx):
        """Create a new channel with interactive setup"""
        view = CreateChannelLayoutView(ctx)
        await ctx.send(view=view)

    @commands.command(name='deletechannel', aliases=['channeldelete'])
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def delete_channel(self, ctx, channel_id: str):
        """Delete a channel by its ID"""
        loading_content = f"""## {DELETE_ICON} Deleting Channel
> Locating channel..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            channel_id_int = int(channel_id.strip('<>#'))
            channel = self.bot.get_channel(channel_id_int)
            
            if not channel:
                content = create_error_content("Not Found", "Channel not found or I don't have access to it.")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            if not isinstance(channel, discord.TextChannel):
                content = create_error_content("Invalid Channel", "This command only works with text channels.")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            if channel.guild != ctx.guild:
                content = create_error_content("Invalid Channel", "Cannot delete channels from other servers.")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            channel_name = channel.name
            await channel.delete(reason=f"Channel deleted by {ctx.author}")
            
            content = create_success_content("Channel Deleted", f"Successfully deleted channel **{channel_name}**!")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except ValueError:
            content = create_error_content("Invalid ID", "Invalid channel ID format. Please provide a valid channel ID.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except discord.Forbidden:
            content = create_error_content("Permission Error", "I don't have permission to delete this channel.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except Exception as e:
            content = create_error_content("Error", f"Error deleting channel: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @commands.command(name='lockcat')
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def lock_category(self, ctx, category_id: str):
        """Lock all channels in a category (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        try:
            category_id_int = int(category_id.strip())
            category = discord.utils.get(ctx.guild.categories, id=category_id_int)
            
            if not category:
                content = create_error_content("Not Found", "Category not found.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            if not category.text_channels:
                content = create_error_content("Empty Category", "No text channels found in this category.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            view = CategoryConfirmationLayoutView(ctx, "lockcat", category, category_id)
            await ctx.send(view=view)
            
        except ValueError:
            content = create_error_content("Invalid ID", "Invalid category ID format.")
            view = create_v2_view(content)
            await ctx.send(view=view)

    @lock_category.error
    async def lock_category_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='unlockcat')
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def unlock_category(self, ctx, category_id: str):
        """Unlock all channels in a category (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        try:
            category_id_int = int(category_id.strip())
            category = discord.utils.get(ctx.guild.categories, id=category_id_int)
            
            if not category:
                content = create_error_content("Not Found", "Category not found.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            if not category.text_channels:
                content = create_error_content("Empty Category", "No text channels found in this category.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            view = CategoryConfirmationLayoutView(ctx, "unlockcat", category, category_id)
            await ctx.send(view=view)
            
        except ValueError:
            content = create_error_content("Invalid ID", "Invalid category ID format.")
            view = create_v2_view(content)
            await ctx.send(view=view)

    @unlock_category.error
    async def unlock_category_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='hidecat')
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def hide_category(self, ctx, category_id: str):
        """Hide all channels in a category from @everyone (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        try:
            category_id_int = int(category_id.strip())
            category = discord.utils.get(ctx.guild.categories, id=category_id_int)
            
            if not category:
                content = create_error_content("Not Found", "Category not found.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            all_channels = category.text_channels + category.voice_channels
            if not all_channels:
                content = create_error_content("Empty Category", "No channels found in this category.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            view = CategoryConfirmationLayoutView(ctx, "hidecat", category, category_id)
            await ctx.send(view=view)
            
        except ValueError:
            content = create_error_content("Invalid ID", "Invalid category ID format.")
            view = create_v2_view(content)
            await ctx.send(view=view)

    @hide_category.error
    async def hide_category_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='unhidecat')
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def unhide_category(self, ctx, category_id: str):
        """Unhide all channels in a category for @everyone (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        try:
            category_id_int = int(category_id.strip())
            category = discord.utils.get(ctx.guild.categories, id=category_id_int)
            
            if not category:
                content = create_error_content("Not Found", "Category not found.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            all_channels = category.text_channels + category.voice_channels
            if not all_channels:
                content = create_error_content("Empty Category", "No channels found in this category.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            view = CategoryConfirmationLayoutView(ctx, "unhidecat", category, category_id)
            await ctx.send(view=view)
            
        except ValueError:
            content = create_error_content("Invalid ID", "Invalid category ID format.")
            view = create_v2_view(content)
            await ctx.send(view=view)

    @unhide_category.error
    async def unhide_category_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='clearcat')
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def clear_category(self, ctx, category_id: str):
        """Delete all channels in a category (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        try:
            category_id_int = int(category_id.strip())
            category = discord.utils.get(ctx.guild.categories, id=category_id_int)
            
            if not category:
                content = create_error_content("Not Found", "Category not found.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            all_channels = category.text_channels + category.voice_channels
            if not all_channels:
                content = create_error_content("Empty Category", "No channels found in this category.")
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            view = CategoryConfirmationLayoutView(ctx, "clearcat", category, category_id)
            await ctx.send(view=view)
            
        except ValueError:
            content = create_error_content("Invalid ID", "Invalid category ID format.")
            view = create_v2_view(content)
            await ctx.send(view=view)

    @clear_category.error
    async def clear_category_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='catcreate', aliases=['createcat'])
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def create_category(self, ctx, *, name: str):
        """Create a new category (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        loading_content = f"""## {CHANNELS_ICON} Creating Category
> Creating category '{name}'..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            category = await ctx.guild.create_category(
                name=name,
                reason=f"Category created by {ctx.author}"
            )
            
            content = create_success_content("Category Created", f"Successfully created category **{category.name}**!")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except discord.Forbidden:
            content = create_error_content("Permission Error", "I don't have permission to create categories.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except Exception as e:
            content = create_error_content("Error", f"Error creating category: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @create_category.error
    async def create_category_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error

    @commands.command(name='catdelete', aliases=['deletecat'])
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def delete_category(self, ctx, category_id: str):
        """Delete a category (Premium Only)"""
        if not await self.check_premium(ctx):
            return
        
        loading_content = f"""## {DELETE_ICON} Deleting Category
> Locating category..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            category_id_int = int(category_id.strip())
            category = discord.utils.get(ctx.guild.categories, id=category_id_int)
            
            if not category:
                content = create_error_content("Not Found", "Category not found.")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            category_name = category.name
            await category.delete(reason=f"Category deleted by {ctx.author}")
            
            content = create_success_content("Category Deleted", f"Successfully deleted category **{category_name}**!")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except ValueError:
            content = create_error_content("Invalid ID", "Invalid category ID format.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except discord.Forbidden:
            content = create_error_content("Permission Error", "I don't have permission to delete this category.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
        except Exception as e:
            content = create_error_content("Error", f"Error deleting category: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @delete_category.error
    async def delete_category_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            content = create_error_content("Cooldown", f"You are on cooldown. Try again in {error.retry_after:.0f}s")
            view = create_v2_view(content)
            await ctx.send(view=view)
        else:
            raise error


async def setup(bot):
    await bot.add_cog(ChannelsMgmt(bot))
