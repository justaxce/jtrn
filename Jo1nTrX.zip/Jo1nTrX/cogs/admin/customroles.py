import discord
from discord.ext import commands
from discord import app_commands, ui
from typing import Optional
import math
from Jo1nTrX.utils.component import bot_emoji
from .admin_helper import ARROW_EMOJI, SECTION_EMOJI, create_v2_view

CUSTOM_ROLE_ICON = "<:Jo1nTrX_custom_role:1414269165241372712>"
SUCCESS_EMOJI = "<:jo1ntrx_tick:1405094884947267715>"
ERROR_EMOJI = "<a:Jo1nTrX_cross:1405094904568483880>"


def create_error_content(title: str, description: str) -> str:
    return f"""## {ERROR_EMOJI} {title}
> {description}"""


def create_success_content(title: str, description: str) -> str:
    return f"""## {SUCCESS_EMOJI} {title}
> {description}"""


class CustomRolesPaginationLayoutView(ui.LayoutView):
    def __init__(self, premade_roles, custom_roles, reqrole_mention, current_page, total_pages, create_content_func, author):
        super().__init__(timeout=300)
        self.premade_roles = premade_roles
        self.custom_roles = custom_roles
        self.reqrole_mention = reqrole_mention
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_content = create_content_func
        self.author = author
        self._setup_view()
    
    def _setup_view(self):
        content = self.create_content(self.current_page)
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = CustomRolesPaginationLayoutView(self.premade_roles, self.custom_roles, self.reqrole_mention, 0, self.total_pages, self.create_content, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = CustomRolesPaginationLayoutView(self.premade_roles, self.custom_roles, self.reqrole_mention, max(0, self.current_page - 1), self.total_pages, self.create_content, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = CustomRolesPaginationLayoutView(self.premade_roles, self.custom_roles, self.reqrole_mention, min(self.total_pages - 1, self.current_page + 1), self.total_pages, self.create_content, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = CustomRolesPaginationLayoutView(self.premade_roles, self.custom_roles, self.reqrole_mention, self.total_pages - 1, self.total_pages, self.create_content, self.author)
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class CustomRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_role_hierarchy(self, user: discord.Member, target_role: discord.Role):
        if user.top_role.position <= target_role.position:
            return False
        return True

    async def is_premium_user(self, user_id: int) -> bool:
        premium_users = await self.bot.db.list_premium_users()
        return user_id in [user[0] for user in premium_users] if premium_users else False

    async def get_role_limits(self, user_id: int) -> int:
        if user_id in self.bot.config.BOT_OWNER_IDS:
            return float('inf')
        elif await self.is_premium_user(user_id):
            return 15
        else:
            return 5

    @commands.group(name='setup', invoke_without_command=True)
    async def setup(self, ctx):
        """Custom role setup commands"""
        if ctx.invoked_subcommand is None:
            await self.setup_help(ctx)

    @setup.command(name='help')
    async def setup_help(self, ctx):
        """Show help menu for setup commands"""
        content = f"""## {CUSTOM_ROLE_ICON} Custom Roles Setup Help
> Here's how to use the custom roles system:

{SECTION_EMOJI} **__Setup Commands__**
{ARROW_EMOJI} `+setup staff <role>` - Setup staff role
{ARROW_EMOJI} `+setup girl <role>` - Setup girl role
{ARROW_EMOJI} `+setup vip <role>` - Setup VIP role
{ARROW_EMOJI} `+setup friend <role>` - Setup friend role
{ARROW_EMOJI} `+setup guest <role>` - Setup guest role
{ARROW_EMOJI} `+setup create <alias> <role>` - Create custom role with alias

{SECTION_EMOJI} **__Management Commands__**
{ARROW_EMOJI} `+setup list` - List all setup roles
{ARROW_EMOJI} `+setup delete <alias>` - Delete a custom role
{ARROW_EMOJI} `+reqrole add <role>` - Set the request role for assignments

{SECTION_EMOJI} **__How it Works__**
{ARROW_EMOJI} **Setup roles** first using the setup commands
{ARROW_EMOJI} **Set a reqrole** - Only users with this role can assign custom roles
{ARROW_EMOJI} **Users with reqrole** can use aliases directly (no prefix needed)
{ARROW_EMOJI} **Hierarchy matters** - Can only assign roles below your highest role
{ARROW_EMOJI} **Limits**: Normal users (5 custom), Premium (15), Owner (unlimited)

{SECTION_EMOJI} **__Examples__**
{ARROW_EMOJI} `+setup staff @Staff` - Setup staff role
{ARROW_EMOJI} `+setup create admin @Admin` - Create custom 'admin' alias
{ARROW_EMOJI} `+reqrole add @Moderator` - Set moderator as reqrole"""
        
        view = create_v2_view(content)
        await ctx.send(view=view)

    @setup.command(name='staff')
    @commands.has_permissions(administrator=True)
    async def setup_staff(self, ctx, role: discord.Role):
        """Setup staff role"""
        await self._setup_premade_role(ctx, role, 'staff', 'Staff')

    @setup.command(name='girl')
    @commands.has_permissions(administrator=True)
    async def setup_girl(self, ctx, role: discord.Role):
        """Setup girl role"""
        await self._setup_premade_role(ctx, role, 'girl', 'Girl')

    @setup.command(name='vip')
    @commands.has_permissions(administrator=True)
    async def setup_vip(self, ctx, role: discord.Role):
        """Setup VIP role"""
        await self._setup_premade_role(ctx, role, 'vip', 'VIP')

    @setup.command(name='friend')
    @commands.has_permissions(administrator=True)
    async def setup_friend(self, ctx, role: discord.Role):
        """Setup friend role"""
        await self._setup_premade_role(ctx, role, 'friend', 'Friend')

    @setup.command(name='guest')
    @commands.has_permissions(administrator=True)
    async def setup_guest(self, ctx, role: discord.Role):
        """Setup guest role"""
        await self._setup_premade_role(ctx, role, 'guest', 'Guest')

    async def _setup_premade_role(self, ctx, role: discord.Role, role_type: str, display_name: str):
        loading_content = f"""## {CUSTOM_ROLE_ICON} Setting Up Role
> Setting up {display_name.lower()} role..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            existing = await self.bot.db.get_custom_role(ctx.guild.id, role_type)
            if existing:
                await self.bot.db.update_custom_role(ctx.guild.id, role_type, new_role_id=role.id)
                action = "updated"
            else:
                await self.bot.db.add_custom_role(ctx.guild.id, role.id, role_type, role_type, ctx.author.id)
                action = "setup"
            
            content = f"""## {SUCCESS_EMOJI} Role Setup Successful
> Successfully {action} **{display_name}** role!

{SECTION_EMOJI} **__Configuration__**
{ARROW_EMOJI} **Role:** {role.name}
{ARROW_EMOJI} **Alias:** `{role_type}`

{SECTION_EMOJI} **__Usage__**
{ARROW_EMOJI} Users with reqrole can now use: `{role_type} @user`"""
            
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except Exception as e:
            content = create_error_content("Setup Failed", f"Failed to setup {display_name.lower()} role: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @setup.command(name='create')
    @commands.has_permissions(administrator=True)
    async def setup_create(self, ctx, alias: str, role: discord.Role):
        """Create a custom role with alias"""
        loading_content = f"""## {CUSTOM_ROLE_ICON} Creating Custom Role
> Creating custom role with alias '{alias}'..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            user_limit = await self.get_role_limits(ctx.author.id)
            current_count = await self.bot.db.get_custom_role_count(ctx.guild.id, ctx.author.id)
            
            if current_count >= user_limit:
                is_premium = await self.is_premium_user(ctx.author.id)
                if not is_premium:
                    content = f"""## {ERROR_EMOJI} Premium Required
> You've reached your limit of {int(user_limit)} custom roles!

{SECTION_EMOJI} **__Get Premium__**
{ARROW_EMOJI} To get premium access, join support server.
{ARROW_EMOJI} [Join our support server](https://discord.gg/PA6UhChxZY)"""
                else:
                    content = create_error_content("Role Limit Reached", f"You can only create {int(user_limit)} custom roles (plus 5 premade roles).")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            existing = await self.bot.db.get_custom_role(ctx.guild.id, alias.lower())
            if existing:
                content = create_error_content("Alias Already Exists", f"Alias `{alias}` is already in use!")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            await self.bot.db.add_custom_role(ctx.guild.id, role.id, alias.lower(), 'custom', ctx.author.id)
            
            remaining = user_limit - current_count - 1 if user_limit != float('inf') else '∞'
            
            content = f"""## {SUCCESS_EMOJI} Custom Role Created
> Successfully created custom role!

{SECTION_EMOJI} **__Configuration__**
{ARROW_EMOJI} **Role:** {role.name}
{ARROW_EMOJI} **Alias:** `{alias.lower()}`
{ARROW_EMOJI} **Remaining:** {remaining} more custom roles

{SECTION_EMOJI} **__Usage__**
{ARROW_EMOJI} Users with reqrole can now use: `{alias.lower()} @user`"""
            
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except Exception as e:
            content = create_error_content("Creation Failed", f"Failed to create custom role: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @setup.command(name='list')
    async def setup_list(self, ctx):
        """List all custom setup roles with pagination"""
        loading_content = f"""## {CUSTOM_ROLE_ICON} Loading Roles
> Loading custom roles list..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            reqrole_id = await self.bot.db.get_reqrole(ctx.guild.id)
            if reqrole_id:
                reqrole = ctx.guild.get_role(reqrole_id)
                reqrole_display = f"**{reqrole.name}**" if reqrole else f"Unknown Role ({reqrole_id})"
            else:
                reqrole_display = "**No reqrole setup**"
            
            all_roles = await self.bot.db.get_all_custom_roles(ctx.guild.id)
            
            if not all_roles:
                content = f"""## {CUSTOM_ROLE_ICON} Jo1nTrX Custom Roles List
> No custom roles have been setup yet!

{SECTION_EMOJI} **__Reqrole__**
{ARROW_EMOJI} {reqrole_display}

{SECTION_EMOJI} **__Get Started__**
{ARROW_EMOJI} Use `+setup staff <role>` to setup a premade role
{ARROW_EMOJI} Use `+setup create <alias> <role>` to create custom roles"""
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            premade_roles = []
            custom_roles = []
            
            for alias, role_id, role_type in all_roles:
                role = ctx.guild.get_role(role_id)
                role_display = role.name if role else f"Unknown Role ({role_id})"
                
                if role_type in ['staff', 'girl', 'vip', 'friend', 'guest']:
                    premade_roles.append(f"{ARROW_EMOJI} {role_type.title()} : {role_display}")
                else:
                    custom_roles.append(f"{ARROW_EMOJI} {alias} : {role_display}")
            
            def create_roles_content(page):
                content = f"""## {CUSTOM_ROLE_ICON} Jo1nTrX Custom Roles List
> Custom roles configuration

{SECTION_EMOJI} **__Reqrole__**
{ARROW_EMOJI} {reqrole_display}
"""
                
                if page == 0:
                    if premade_roles:
                        content += f"""
{SECTION_EMOJI} **__Premade Setup Roles__**
{chr(10).join(premade_roles[:5])}
"""
                    
                    if custom_roles:
                        content += f"""
{SECTION_EMOJI} **__Custom Setup Roles__**
{chr(10).join(custom_roles[:5])}
"""
                else:
                    start_idx = 5 + (page - 1) * 5
                    end_idx = start_idx + 5
                    display_custom = custom_roles[start_idx:end_idx]
                    
                    if display_custom:
                        content += f"""
{SECTION_EMOJI} **__Custom Setup Roles__**
{chr(10).join(display_custom)}
"""
                
                total_pages = math.ceil(max(0, len(custom_roles) - 5) / 5) + 1 if len(custom_roles) > 5 else 1
                content += f"""
{SECTION_EMOJI} **__Stats__**
{ARROW_EMOJI} Premade: {len(premade_roles)} | Custom: {len(custom_roles)} | Total: {len(all_roles)}
{ARROW_EMOJI} Page {page + 1}/{total_pages}"""
                
                return content
            
            total_pages = math.ceil(max(0, len(custom_roles) - 5) / 5) + 1 if len(custom_roles) > 5 else 1
            
            if total_pages == 1:
                content = create_roles_content(0)
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
            else:
                view = CustomRolesPaginationLayoutView(premade_roles, custom_roles, reqrole_display, 0, total_pages, create_roles_content, ctx.author)
                await loading_msg.edit(view=view)
            
        except Exception as e:
            content = create_error_content("Failed to Load Roles", f"Error: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @setup.command(name='delete')
    @commands.has_permissions(administrator=True)
    async def setup_delete(self, ctx, alias: str):
        """Delete a custom role setup"""
        loading_content = f"""## {CUSTOM_ROLE_ICON} Deleting Role
> Deleting custom role '{alias}'..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            existing = await self.bot.db.get_custom_role(ctx.guild.id, alias.lower())
            if not existing:
                content = create_error_content("Role Not Found", f"No custom role found with alias `{alias}`")
                view = create_v2_view(content)
                await loading_msg.edit(view=view)
                return
            
            success = await self.bot.db.delete_custom_role(ctx.guild.id, alias.lower())
            
            if success:
                content = create_success_content("Role Deleted", f"Successfully deleted custom role `{alias}`")
            else:
                content = create_error_content("Deletion Failed", f"Failed to delete custom role `{alias}`")
            
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except Exception as e:
            content = create_error_content("Deletion Failed", f"Error: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @commands.group(name='reqrole', invoke_without_command=True)
    async def reqrole(self, ctx):
        """Request role commands"""
        if ctx.invoked_subcommand is None:
            reqrole_id = await self.bot.db.get_reqrole(ctx.guild.id)
            if reqrole_id:
                role = ctx.guild.get_role(reqrole_id)
                role_display = role.name if role else f"Unknown Role ({reqrole_id})"
                content = f"""## {CUSTOM_ROLE_ICON} Current Reqrole
> Current reqrole: **{role_display}**

{SECTION_EMOJI} **__Info__**
{ARROW_EMOJI} Users with this role can assign custom roles
{ARROW_EMOJI} Use `+reqrole add <role>` to change it"""
            else:
                content = f"""## {CUSTOM_ROLE_ICON} No Reqrole Set
> No reqrole has been setup.

{SECTION_EMOJI} **__Setup__**
{ARROW_EMOJI} Use `+reqrole add <role>` to set one."""
            
            view = create_v2_view(content)
            await ctx.send(view=view)

    @reqrole.command(name='add')
    @commands.has_permissions(administrator=True)
    async def reqrole_add(self, ctx, role: discord.Role):
        """Set the request role for custom role assignments"""
        loading_content = f"""## {CUSTOM_ROLE_ICON} Setting Reqrole
> Setting request role..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            await self.bot.db.set_reqrole(ctx.guild.id, role.id)
            
            content = f"""## {SUCCESS_EMOJI} Reqrole Set
> Successfully set the request role!

{SECTION_EMOJI} **__Configuration__**
{ARROW_EMOJI} **Role:** {role.name}

{SECTION_EMOJI} **__Info__**
{ARROW_EMOJI} Users with this role can now assign custom roles
{ARROW_EMOJI} They can use role aliases like `staff @user`"""
            
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except Exception as e:
            content = create_error_content("Failed to Set Reqrole", f"Error: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @reqrole.command(name='remove')
    @commands.has_permissions(administrator=True)
    async def reqrole_remove(self, ctx):
        """Remove the current request role"""
        loading_content = f"""## {CUSTOM_ROLE_ICON} Removing Reqrole
> Removing request role..."""
        loading_view = create_v2_view(loading_content)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            await self.bot.db.remove_reqrole(ctx.guild.id)
            
            content = create_success_content("Reqrole Removed", "Successfully removed the request role.")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)
            
        except Exception as e:
            content = create_error_content("Failed to Remove Reqrole", f"Error: {str(e)}")
            view = create_v2_view(content)
            await loading_msg.edit(view=view)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
        
        content = message.content.strip()
        if not content:
            return
        
        parts = content.split(maxsplit=1)
        if len(parts) < 2:
            return
        
        alias = parts[0].lower()
        
        reqrole_id = await self.bot.db.get_reqrole(message.guild.id)
        if not reqrole_id:
            return
        
        member = message.author
        if not any(role.id == reqrole_id for role in member.roles):
            return
        
        custom_role = await self.bot.db.get_custom_role(message.guild.id, alias)
        if not custom_role:
            return
        
        role_id = custom_role[0]
        role = message.guild.get_role(role_id)
        if not role:
            content = create_error_content("Role Not Found", "The configured role no longer exists.")
            view = create_v2_view(content)
            await message.channel.send(view=view)
            return
        
        if not await self.check_role_hierarchy(member, role):
            content = create_error_content("Hierarchy Error", "You cannot assign this role due to role hierarchy.")
            view = create_v2_view(content)
            await message.channel.send(view=view)
            return
        
        mentioned_members = message.mentions
        if not mentioned_members:
            return
        
        for target in mentioned_members:
            try:
                if role in target.roles:
                    await target.remove_roles(role, reason=f"Custom role removed by {member}")
                    result_content = f"""## {SUCCESS_EMOJI} Role Removed
> Successfully removed **{role.name}** from {target.display_name}

{SECTION_EMOJI} **__Details__**
{ARROW_EMOJI} **Moderator:** {member.display_name}
{ARROW_EMOJI} **Alias:** `{alias}`"""
                else:
                    await target.add_roles(role, reason=f"Custom role assigned by {member}")
                    result_content = f"""## {SUCCESS_EMOJI} Role Assigned
> Successfully assigned **{role.name}** to {target.display_name}

{SECTION_EMOJI} **__Details__**
{ARROW_EMOJI} **Moderator:** {member.display_name}
{ARROW_EMOJI} **Alias:** `{alias}`"""
                
                view = create_v2_view(result_content)
                await message.channel.send(view=view)
                
            except discord.Forbidden:
                result_content = create_error_content("Permission Error", f"I don't have permission to manage {target.mention}'s roles.")
                view = create_v2_view(result_content)
                await message.channel.send(view=view)
            except Exception as e:
                result_content = create_error_content("Error", f"Failed to manage role for {target.mention}: {str(e)}")
                view = create_v2_view(result_content)
                await message.channel.send(view=view)


async def setup(bot):
    await bot.add_cog(CustomRoles(bot))
