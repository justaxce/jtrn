from .welcome import WelcomeCommands
from .boost import BoostCommands
from .moderation import ModerationCommands
from .rolemgmt import RoleManagementCommands
from .utility import UtilityCommands

async def setup(bot):
    await bot.add_cog(WelcomeCommands(bot))
    await bot.add_cog(BoostCommands(bot))
    await bot.add_cog(ModerationCommands(bot))
    await bot.add_cog(RoleManagementCommands(bot))
    await bot.add_cog(UtilityCommands(bot))
