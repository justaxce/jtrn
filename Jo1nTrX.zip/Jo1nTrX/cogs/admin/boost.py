import discord
import asyncio
from discord.ext import commands
from discord import app_commands, ui
from Jo1nTrX.utils.component import BaseView, bot_emoji
from .admin_helper import (
    ARROW_EMOJI, SECTION_EMOJI, SUCCESS_EMOJI, ERROR_EMOJI, ADMIN_ICON,
    create_v2_view, create_success_content, create_error_content
)


class BoostSetupViewV2(ui.LayoutView):
    def __init__(self, bot, author_id, prefix, requester=None):
        super().__init__(timeout=300)
        self.bot = bot
        self.author_id = author_id
        self.prefix = prefix
        self.requester = requester
        self._setup_buttons()
    
    def _setup_buttons(self):
        text_btn = ui.Button(label='Text Message', style=discord.ButtonStyle.primary)
        embed_btn = ui.Button(label='Embed Message', style=discord.ButtonStyle.secondary)
        cancel_btn = ui.Button(label='Cancel', style=discord.ButtonStyle.danger)
        
        async def text_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await self._handle_text_setup(interaction)
        
        async def embed_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await self._handle_embed_setup(interaction)
        
        async def cancel_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            cancel_content = f"""## {ERROR_EMOJI} Boost Setup Cancelled
> Boost message setup has been cancelled."""
            cancel_view = create_v2_view(cancel_content)
            await interaction.response.edit_message(view=cancel_view)
        
        text_btn.callback = text_callback
        embed_btn.callback = embed_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(text_btn, embed_btn, cancel_btn)
        self.add_item(button_row)
    
    async def _handle_text_setup(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            "Enter the channel ID or <#channel> you want your boost message to be sent in.\n"
            "Send `cancel` to cancel boost setup.",
            ephemeral=True
        )
        
        def check(message):
            return message.author.id == self.author_id and message.channel == interaction.channel
        
        try:
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply("❌ Boost setup cancelled.")
                return
            
            channel = None
            if message.channel_mentions:
                channel = message.channel_mentions[0]
            else:
                try:
                    channel_id = int(message.content.strip('<>#'))
                    channel = self.bot.get_channel(channel_id)
                except ValueError:
                    await message.reply("❌ Invalid channel format. Please use a channel mention or valid channel ID.")
                    return
            
            if not channel:
                await message.reply("❌ Channel not found or I don't have access to it.")
                return
            
            await message.reply(
                "Send your boost message (with variables), you want to setup.\n"
                "Send `cancel` to cancel boost setup."
            )
            
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply("❌ Boost setup cancelled.")
                return
            
            boost_message = message.content
            
            await message.reply(
                "Enter the emoji ID or emoji you want as reaction on boost message.\n"
                "Type `skip` to skip or `cancel` to cancel."
            )
            
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply("❌ Boost setup cancelled.")
                return
            
            boost_emoji = None if message.content.lower() == 'skip' else message.content
            
            await self.bot.db.set_boost_channel(interaction.guild.id, channel.id)
            await self.bot.db.set_boost_message(interaction.guild.id, boost_message)
            if boost_emoji:
                await self.bot.db.set_boost_emoji(interaction.guild.id, boost_emoji)
            
            success_content = f"""## {SUCCESS_EMOJI} Boost Message Setup Complete
> Text boost message has been configured!

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Channel:** {channel.mention}
{ARROW_EMOJI} **Message:** {boost_message[:100]}{'...' if len(boost_message) > 100 else ''}
{ARROW_EMOJI} **Emoji:** {boost_emoji if boost_emoji else 'None'}"""
            
            success_view = create_v2_view(success_content)
            await message.reply(view=success_view)
            
        except asyncio.TimeoutError:
            await interaction.followup.send("⏰ Timeout! Boost setup was not completed within 5 minutes.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Error setting up boost message: {str(e)}", ephemeral=True)
    
    async def _handle_embed_setup(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            "Enter the channel ID or <#channel> you want your boost message to be sent in.\n"
            "Send `cancel` to cancel boost setup.",
            ephemeral=True
        )
        
        def check(message):
            return message.author.id == self.author_id and message.channel == interaction.channel
        
        try:
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply("❌ Boost setup cancelled.")
                return
            
            channel = None
            if message.channel_mentions:
                channel = message.channel_mentions[0]
            else:
                try:
                    channel_id = int(message.content.strip('<>#'))
                    channel = self.bot.get_channel(channel_id)
                except ValueError:
                    await message.reply("❌ Invalid channel format. Please use a channel mention or valid channel ID.")
                    return
            
            if not channel:
                await message.reply("❌ Channel not found or I don't have access to it.")
                return
            
            embeds = await self.bot.db.get_all_custom_embeds(interaction.guild.id)
            
            if not embeds:
                await message.reply(f"❌ No custom embeds found. Create one first using `{self.prefix}embed create <name>`.")
                return
            
            embed_select_view = BoostEmbedSelectionViewV2(self.bot, self.author_id, channel, embeds, self.requester)
            
            select_content = f"""## {ADMIN_ICON} Choose your boost embed!
> Select an embed from the dropdown below.

{ARROW_EMOJI} Send `cancel` to cancel boost setup."""
            
            embed_select_view.add_item(ui.Container(ui.TextDisplay(select_content)))
            await message.reply(view=embed_select_view)
            
        except asyncio.TimeoutError:
            await interaction.followup.send("⏰ Timeout! Boost setup was not completed within 5 minutes.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Error setting up boost embed: {str(e)}", ephemeral=True)


class BoostEmbedSelectionViewV2(ui.LayoutView):
    def __init__(self, bot, author_id, channel, embeds, requester=None):
        super().__init__(timeout=300)
        self.bot = bot
        self.author_id = author_id
        self.channel = channel
        self.embeds = embeds
        self.requester = requester
        self._setup_view()
    
    def _setup_view(self):
        options = []
        for embed_data in self.embeds[:25]:
            options.append(discord.SelectOption(
                label=embed_data['name'],
                description=f"Created by {embed_data['creator_name']}",
                value=embed_data['name']
            ))
        
        if options:
            embed_select = ui.Select(
                placeholder="Select an embed...",
                min_values=1,
                max_values=1,
                options=options
            )
            
            async def select_callback(interaction: discord.Interaction):
                if self.requester and interaction.user.id != self.requester.id:
                    return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
                
                selected_embed = embed_select.values[0]
                
                await interaction.response.send_message(
                    "Enter the emoji ID or emoji you want as reaction on boost message.\n"
                    "Type `skip` to skip or `cancel` to cancel.",
                    ephemeral=True
                )
                
                def check(message):
                    return message.author.id == self.author_id and message.channel == interaction.channel
                
                try:
                    message = await self.bot.wait_for('message', timeout=300.0, check=check)
                    
                    if message.content.lower() == 'cancel':
                        await message.reply("❌ Boost setup cancelled.")
                        return
                    
                    boost_emoji = None if message.content.lower() == 'skip' else message.content
                    
                    await self.bot.db.set_boost_channel(interaction.guild.id, self.channel.id)
                    await self.bot.db.set_boost_embed(interaction.guild.id, selected_embed)
                    if boost_emoji:
                        await self.bot.db.set_boost_emoji(interaction.guild.id, boost_emoji)
                    
                    success_content = f"""## {SUCCESS_EMOJI} Boost Embed Setup Complete
> Embed has been configured successfully!

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Channel:** {self.channel.mention}
{ARROW_EMOJI} **Embed:** {selected_embed}
{ARROW_EMOJI} **Emoji:** {boost_emoji if boost_emoji else 'None'}"""
                    
                    success_view = create_v2_view(success_content)
                    await message.reply(view=success_view)
                    
                except asyncio.TimeoutError:
                    await interaction.followup.send("⏰ Timeout! Boost setup was not completed within 5 minutes.", ephemeral=True)
                except Exception as e:
                    await interaction.followup.send(f"❌ Error setting up boost embed: {str(e)}", ephemeral=True)
            
            embed_select.callback = select_callback
            select_row = ui.ActionRow(embed_select)
            self.add_item(select_row)


class BoostCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name='setboostmessage')
    @commands.has_permissions(administrator=True)
    async def setboostmessage(self, ctx):
        """Setup boost message configuration with interactive menu"""
        try:
            prefix = await self.bot.db.get_guild_prefix(ctx.guild.id)
            if not prefix:
                prefix = "+"
            
            content = f"""## <:Jo1nTrX_boost:1408686831415066715> {ctx.guild.name}
> Choose the button below for which type of boost message you want to setup

{SECTION_EMOJI} **__Message Types__**

{ARROW_EMOJI} **Text Message** - Setup normal text boost message!
{ARROW_EMOJI} **Embed Message** - Setup embed boost message!

{SECTION_EMOJI} **__Note__** <:Jo1nTrX_Note:1411930562288943104>

{ARROW_EMOJI} If you're setting **Embed boost message**, create **Boost Embed** first from `{prefix}embed create <name>`.
{ARROW_EMOJI} For Variables list do `{prefix}variables`.
{ARROW_EMOJI} Setting up boost message will remove the regular boost message from that channel.
{ARROW_EMOJI} If someone boosts 2 times, bot will send this boost message both times!"""
            
            view = BoostSetupViewV2(self.bot, ctx.author.id, prefix, ctx.author)
            view.add_item(ui.Container(ui.TextDisplay(content)))
            await ctx.send(view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error starting boost setup: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='clearboost-config')
    @commands.has_permissions(administrator=True)
    async def clearboost_config(self, ctx):
        """Clear all boost message configuration for this server"""
        try:
            await self.bot.db.unset_boost_config(ctx.guild.id)
            
            content = f"""## {SUCCESS_EMOJI} Boost Configuration Cleared
> All boost message configuration has been successfully cleared!

{SECTION_EMOJI} **__Removed Configuration__**

{ARROW_EMOJI} Boost channel removed
{ARROW_EMOJI} Custom boost message cleared
{ARROW_EMOJI} Custom boost embed cleared
{ARROW_EMOJI} Boost emoji removed

> Boost messages will now use the default system."""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error clearing boost configuration: {str(e)}"))
            await ctx.send(view=error_view)


async def setup(bot):
    await bot.add_cog(BoostCommands(bot))
