import discord
from discord import ui

ARROW_EMOJI = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION_EMOJI = "<:jo1ntrx_right:1405095312456024127>"
SUCCESS_EMOJI = "<:jo1ntrx_tick:1405094884947267715>"
ERROR_EMOJI = "<a:Jo1nTrX_error:1437649234957434993>"
ADMIN_ICON = "<a:pheonix_mod:1395067883465474172>"

def create_v2_view(content: str, timeout: int = 60) -> ui.LayoutView:
    view = ui.LayoutView(timeout=timeout)
    container = ui.Container(ui.TextDisplay(content))
    view.add_item(container)
    return view

def create_success_content(title: str, description: str) -> str:
    return f"""## ✅ {title}
> {description}"""

def create_error_content(title: str, description: str) -> str:
    return f"""## ❌ {title}
> {description}"""
