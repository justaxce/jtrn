import discord
from datetime import datetime, timezone, timedelta
from discord.ext import commands
from discord import app_commands
from Jo1nTrX.utils.helpers import send_loading_message
from .admin_helper import (
    ARROW_EMOJI, SECTION_EMOJI, SUCCESS_EMOJI, ERROR_EMOJI, ADMIN_ICON,
    create_v2_view, create_success_content, create_error_content
)


class ModerationCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    def parse_duration(self, duration_str):
        if not duration_str:
            return None
        
        duration_str = duration_str.lower().strip()
        
        if duration_str.isdigit():
            return int(duration_str)
        
        import re
        match = re.match(r'^(\d+)([mhd])$', duration_str)
        if not match:
            return None
        
        amount = int(match.group(1))
        unit = match.group(2)
        
        if unit == 'm':
            return amount
        elif unit == 'h':
            return amount * 60
        elif unit == 'd':
            return amount * 1440
        
        return None
    
    def _check_hierarchy(self, ctx, member):
        if member == ctx.author:
            return False, "You cannot moderate yourself."
        
        if member == ctx.guild.owner:
            return False, "Cannot moderate the server owner."
        
        if ctx.author != ctx.guild.owner and member.top_role >= ctx.author.top_role:
            return False, "You cannot moderate someone with a higher or equal role."
        
        if member.top_role >= ctx.guild.me.top_role:
            return False, "I cannot moderate someone with a higher or equal role than me."
        
        return True, None
    
    def _check_warn_hierarchy(self, ctx, member):
        if member == ctx.author:
            return False, "You cannot warn yourself."
        
        if member == ctx.guild.owner:
            return False, "Cannot warn the server owner."
        
        if ctx.author != ctx.guild.owner and member.top_role > ctx.author.top_role:
            return False, "You cannot warn someone with a higher role."
        
        if member.top_role >= ctx.guild.me.top_role:
            return False, "I cannot warn someone with a higher or equal role than me."
        
        return True, None
    
    async def _check_moderation_permissions(self, ctx):
        if ctx.author.guild_permissions.administrator:
            return True
        
        if ctx.author.guild_permissions.moderate_members:
            return True
        
        modrole_id = await self.bot.db.get_modrole(ctx.guild.id)
        if modrole_id:
            modrole = ctx.guild.get_role(modrole_id)
            if modrole and modrole in ctx.author.roles:
                return True
        
        return False
    
    @commands.hybrid_command(name='ban')
    @app_commands.describe(member='The member to ban', reason='Reason for the ban (optionally start with a number 0-7 to delete messages)')
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason: str = None):
        """Ban a member from the server"""
        delete_messages = 0
        
        if reason:
            parts = reason.split(maxsplit=1)
            if parts and parts[0].isdigit():
                num = int(parts[0])
                if 0 <= num <= 7:
                    delete_messages = num
                    reason = parts[1] if len(parts) > 1 else "No reason provided"
                else:
                    pass
        
        if not reason:
            reason = "No reason provided"
        
        if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
            error_view = create_v2_view(create_error_content("Error", "You cannot ban someone with a higher or equal role."))
            await ctx.send(view=error_view)
            return
        
        if member.top_role >= ctx.guild.me.top_role:
            error_view = create_v2_view(create_error_content("Error", "I cannot ban someone with a higher or equal role than me."))
            await ctx.send(view=error_view)
            return
        
        try:
            try:
                dm_content = f"""## {ERROR_EMOJI} You Have Been Banned
> You have been banned from **{ctx.guild.name}**

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Reason:** {reason}
{ARROW_EMOJI} **Done by:** {ctx.author.mention}"""
                dm_view = create_v2_view(dm_content)
                await member.send(view=dm_view)
            except:
                pass
            
            await member.ban(reason=f"Banned by {ctx.author} | {reason}", delete_message_days=delete_messages)
            
            content = f"""## {SUCCESS_EMOJI} Member Banned
> {member.mention} has been banned from the server.

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Reason:** {reason}
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("Permission Error", "I don't have permission to ban this member."))
            await ctx.send(view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error banning member: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='unban')
    @app_commands.describe(user='The user to unban (username, user ID, or username#discriminator)', reason='Reason for the unban')
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def unban(self, ctx, user: str, *, reason: str = "No reason provided"):
        """Unban a user from the server"""
        try:
            banned_users = [entry async for entry in ctx.guild.bans(limit=None)]
            
            member_name, member_discriminator = None, None
            user_id = None
            
            try:
                user_id = int(user)
            except ValueError:
                pass
            
            if '#' in user:
                member_name, member_discriminator = user.split('#')
            else:
                member_name = user
            
            ban_entry = None
            
            for ban_entry_item in banned_users:
                ban_user = ban_entry_item.user
                
                if user_id and ban_user.id == user_id:
                    ban_entry = ban_entry_item
                    break
                elif member_discriminator:
                    if (ban_user.name.lower() == member_name.lower() and ban_user.discriminator == member_discriminator):
                        ban_entry = ban_entry_item
                        break
                else:
                    if ban_user.name.lower() == member_name.lower() or ban_user.mention == user:
                        ban_entry = ban_entry_item
                        break
            
            if ban_entry is None:
                error_view = create_v2_view(create_error_content("Error", f"Could not find a banned user matching '{user}'. Make sure the user is actually banned."))
                await ctx.send(view=error_view)
                return
            
            await ctx.guild.unban(ban_entry.user, reason=f"Unbanned by {ctx.author} | {reason}")
            
            content = f"""## {SUCCESS_EMOJI} User Unbanned
> {ban_entry.user.mention} has been unbanned from the server.

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **User:** {ban_entry.user.mention}
{ARROW_EMOJI} **Reason:** {reason}
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("Permission Error", "I don't have permission to unban members."))
            await ctx.send(view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error unbanning user: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='kick', aliases=['Nikallwde'])
    @app_commands.describe(member='The member to kick', reason='Reason for the kick')
    @commands.has_permissions(kick_members=True)
    @commands.bot_has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Kick a member from the server"""
        if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
            error_view = create_v2_view(create_error_content("Error", "You cannot kick someone with a higher or equal role."))
            await ctx.send(view=error_view)
            return
        
        if member.top_role >= ctx.guild.me.top_role:
            error_view = create_v2_view(create_error_content("Error", "I cannot kick someone with a higher or equal role than me."))
            await ctx.send(view=error_view)
            return
        
        try:
            try:
                dm_content = f"""## {ERROR_EMOJI} You Have Been Kicked
> You have been kicked from **{ctx.guild.name}**

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Reason:** {reason}
{ARROW_EMOJI} **Done by:** {ctx.author.mention}"""
                dm_view = create_v2_view(dm_content)
                await member.send(view=dm_view)
            except:
                pass
            
            await member.kick(reason=f"Kicked by {ctx.author} | {reason}")
            
            content = f"""## {SUCCESS_EMOJI} Member Kicked
> {member.mention} has been kicked from the server.

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Reason:** {reason}
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("Permission Error", "I don't have permission to kick this member."))
            await ctx.send(view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error kicking member: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='mute', aliases=['stfu', 'to', 'timeout'])
    @app_commands.describe(member='The member to mute', duration='Duration (e.g., 10m, 1h, 2d or just 60 for minutes)', reason='Reason for the mute')
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    async def mute(self, ctx, member: discord.Member, duration: str = None, *, reason: str = "No reason provided"):
        """Mute (timeout) a member for a specified duration"""
        if duration is None:
            error_view = create_v2_view(create_error_content("Error", "Please provide a duration in minutes. Example: `+mute @user 60 reason`"))
            await ctx.send(view=error_view)
            return
        
        duration_int = self.parse_duration(duration)
        if duration_int is None:
            error_view = create_v2_view(create_error_content("Error", "Invalid duration format. Use: 10m (minutes), 1h (hours), 1d (days), or just 60 (minutes). Example: `+mute @user 10m reason`"))
            await ctx.send(view=error_view)
            return
        
        if duration_int <= 0 or duration_int > 40320:
            error_view = create_v2_view(create_error_content("Error", "Duration must be between 1 minute and 28 days (40320 minutes)."))
            await ctx.send(view=error_view)
            return
        
        if member.top_role > ctx.author.top_role and ctx.author != ctx.guild.owner:
            error_view = create_v2_view(create_error_content("Error", "You cannot mute someone with a higher role."))
            await ctx.send(view=error_view)
            return
        
        if member.top_role >= ctx.guild.me.top_role:
            error_view = create_v2_view(create_error_content("Error", "I cannot mute someone with a higher or equal role than me."))
            await ctx.send(view=error_view)
            return
        
        try:
            timeout_until = datetime.now(timezone.utc) + timedelta(minutes=duration_int)
            
            if duration_int < 60:
                duration_str = f"{duration_int} minutes"
            elif duration_int < 1440:
                hours = duration_int // 60
                minutes = duration_int % 60
                duration_str = f"{hours}h {minutes}m" if minutes > 0 else f"{hours} hours"
            else:
                days = duration_int // 1440
                remaining_minutes = duration_int % 1440
                hours = remaining_minutes // 60
                minutes = remaining_minutes % 60
                duration_str = f"{days}d"
                if hours > 0:
                    duration_str += f" {hours}h"
                if minutes > 0:
                    duration_str += f" {minutes}m"
            
            try:
                dm_content = f"""## {ERROR_EMOJI} You Have Been Muted
> You have been muted in **{ctx.guild.name}**

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Duration:** {duration_str}
{ARROW_EMOJI} **Reason:** {reason}
{ARROW_EMOJI} **Done by:** {ctx.author.mention}"""
                dm_view = create_v2_view(dm_content)
                await member.send(view=dm_view)
            except:
                pass
            
            await member.timeout(timeout_until, reason=f"Muted by {ctx.author} | {reason}")
            
            content = f"""## {SUCCESS_EMOJI} Member Muted
> {member.mention} has been muted for {duration_str}.

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Duration:** {duration_str}
{ARROW_EMOJI} **Reason:** {reason}
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("Permission Error", "I don't have permission to timeout this member."))
            await ctx.send(view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error muting member: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='unmute', aliases=['rto', 'removetimeout'])
    @app_commands.describe(member='The member to unmute')
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    async def unmute(self, ctx, member: discord.Member):
        """Remove timeout from a member"""
        if not member.is_timed_out():
            error_view = create_v2_view(create_error_content("Error", "This member is not currently muted."))
            await ctx.send(view=error_view)
            return
        
        try:
            await member.timeout(None, reason=f"Unmuted by {ctx.author}")
            
            content = f"""## {SUCCESS_EMOJI} Member Unmuted
> {member.mention} has been unmuted.

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("Permission Error", "I don't have permission to remove timeout from this member."))
            await ctx.send(view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error unmuting member: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='warn')
    @app_commands.describe(
        member='The member to warn',
        reason='Reason for the warning'
    )
    async def warn(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Issue a warning to a member"""
        if not await self._check_moderation_permissions(ctx):
            error_view = create_v2_view(create_error_content("Permission Error", "You need moderation permissions or the mod role to use this command."))
            await ctx.send(view=error_view)
            return
        
        can_moderate, error_msg = self._check_warn_hierarchy(ctx, member)
        if not can_moderate:
            error_view = create_v2_view(create_error_content("Error", error_msg or "Cannot warn this member."))
            await ctx.send(view=error_view)
            return
        
        loading_msg = await send_loading_message(ctx, f"warning {member.mention}")
        
        try:
            await self.bot.db.add_warning(ctx.guild.id, member.id, ctx.author.id, reason)
            
            warning_count = await self.bot.db.get_warning_count(ctx.guild.id, member.id)
            
            content = f"""## {SUCCESS_EMOJI} Member Warned
> {member.mention} has been warned.

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Reason:** {reason}
{ARROW_EMOJI} **Warning Count:** {warning_count}
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            
            view = create_v2_view(content)
            await loading_msg.edit(content=None, embed=None, view=view)
            
            try:
                dm_content = f"""## {ERROR_EMOJI} Warning Received
> You have been warned in **{ctx.guild.name}**

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Reason:** {reason}
{ARROW_EMOJI} **Warning Count:** {warning_count}"""
                dm_view = create_v2_view(dm_content)
                await member.send(view=dm_view)
            except:
                pass
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error issuing warning: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)
    
    @commands.hybrid_command(name='unwarn')
    @app_commands.describe(
        member='The member to remove warning from',
        warning_id='ID of the warning to remove (optional, removes latest if not provided)'
    )
    async def unwarn(self, ctx, member: discord.Member, warning_id: int = None):
        """Remove a warning from a member"""
        if not await self._check_moderation_permissions(ctx):
            error_view = create_v2_view(create_error_content("Permission Error", "You need moderation permissions or the mod role to use this command."))
            await ctx.send(view=error_view)
            return
        
        loading_msg = await send_loading_message(ctx, f"removing warning from {member.mention}")
        
        try:
            success = await self.bot.db.remove_warning(ctx.guild.id, member.id, warning_id)
            
            if success:
                warning_count = await self.bot.db.get_warning_count(ctx.guild.id, member.id)
                content = f"""## {SUCCESS_EMOJI} Warning Removed
> Warning removed from {member.mention}

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **New Warning Count:** {warning_count}
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
                view = create_v2_view(content)
                await loading_msg.edit(content=None, embed=None, view=view)
            else:
                error_view = create_v2_view(create_error_content("Error", "No active warnings found for this user."))
                await loading_msg.edit(content=None, embed=None, view=error_view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error removing warning: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)
    
    @commands.hybrid_command(name='warnings')
    @app_commands.describe(member='The member to check warnings for')
    async def warnings(self, ctx, member: discord.Member = None):
        """View warnings for a member"""
        if member is None:
            member = ctx.author
        
        loading_msg = await send_loading_message(ctx, f"fetching warnings for {member.mention}")
        
        try:
            warnings_data = await self.bot.db.get_warnings(ctx.guild.id, member.id)
            
            if not warnings_data:
                content = f"""## {SUCCESS_EMOJI} No Warnings
> {member.mention} has no warnings."""
                view = create_v2_view(content)
                await loading_msg.edit(content=None, embed=None, view=view)
                return
            
            warning_lines = []
            for i, warning in enumerate(warnings_data[:10], 1):
                if not warning or warning.get('id') is None:
                    continue
                    
                moderator = ctx.guild.get_member(warning['moderator_id'])
                mod_name = moderator.mention if moderator else f"Unknown (ID: {warning['moderator_id']})"
                
                try:
                    timestamp = int(warning['created_at'].timestamp())
                except (AttributeError, ValueError):
                    timestamp = int(datetime.now().timestamp())
                
                warning_lines.append(f"""
{SECTION_EMOJI} **__Warning #{warning['id']}__**

{ARROW_EMOJI} **Reason:** {warning.get('reason', 'No reason provided')}
{ARROW_EMOJI} **Moderator:** {mod_name}
{ARROW_EMOJI} **Date:** <t:{timestamp}:R>""")
            
            footer = f"\n\n> Showing first 10 of {len(warnings_data)} warnings" if len(warnings_data) > 10 else ""
            
            content = f"""## {ERROR_EMOJI} Warnings for {member.display_name}
> Total Active Warnings: **{len(warnings_data)}**{''.join(warning_lines)}{footer}"""
            
            view = create_v2_view(content)
            await loading_msg.edit(content=None, embed=None, view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error fetching warnings: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)


async def setup(bot):
    await bot.add_cog(ModerationCommands(bot))
