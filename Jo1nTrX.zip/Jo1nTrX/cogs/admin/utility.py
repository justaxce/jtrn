import discord
from discord.ext import commands
from discord import app_commands, ui

from Jo1nTrX.utils.helpers import send_loading_message, format_custom_datetime
from Jo1nTrX.utils.embeds import create_embed, create_error_embed, create_success_embed
from Jo1nTrX.utils.emoji_manager import emoji
from .admin_helper import (
    ARROW_EMOJI, SECTION_EMOJI, SUCCESS_EMOJI, ERROR_EMOJI,
    create_v2_view, create_error_content
)
import time
import psutil
import platform
import asyncio
import aiohttp
import io
import re
from datetime import datetime, timezone, timedelta
from typing import Optional, List
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji,
    BaseLayoutView
)

def get_serverinfo_content(guild: discord.Guild, category: str = "general") -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    if category == "general":
        owner_text = guild.owner.mention if guild.owner else 'Unknown'
        return f"""## <:Jo1nTrX_server:1411471136746897549> {guild.name}
{section} **__General Information__**

{arrow} **Name:** {guild.name}
{arrow} **ID:** `{guild.id}`
{arrow} **Owner:** <:Jo1nTrX_owner:1411471179771940904> {owner_text}
{arrow} **Created:** <t:{int(guild.created_at.timestamp())}:F>
{arrow} **Members:** {guild.member_count}"""
    
    elif category == "members":
        humans = len([m for m in guild.members if not m.bot])
        bots = len([m for m in guild.members if m.bot])
        online = len([m for m in guild.members if m.status == discord.Status.online])
        idle = len([m for m in guild.members if m.status == discord.Status.idle])
        dnd = len([m for m in guild.members if m.status == discord.Status.dnd])
        offline = len([m for m in guild.members if m.status == discord.Status.offline])
        
        return f"""## <:Jo1nTrX_server:1411471136746897549> {guild.name}
{section} **__Member Count Stats__**

{arrow} **Total Humans Count:** {humans}
{arrow} **Total Bot's Count:** {bots}
{arrow} **Overall Member Count:** {guild.member_count}

{section} **__Members Presence Stats__**

<:Jo1nTrX_On01:1415540440014520330> : {online} online
<:Jo1nTrX_idle:1415540481953370236> : {idle} idle
<:Jo1nTrX_dnd01:1415540445856927876> : {dnd} dnd
<:Jo1nTrX_off01:1415540488307605604> : {offline} offline"""
    
    elif category == "roles":
        import random
        roles = guild.roles[1:]
        roles.reverse()
        random.shuffle(roles)
        role_count = len(roles)
        
        if role_count == 0:
            role_text = "No roles found"
        elif role_count > 70:
            role_list = [f"`{role.name}`" for role in roles[:70]]
            role_text = ", ".join(role_list) + f"\n....{role_count - 70} more!"
        else:
            role_list = [f"`{role.name}`" for role in roles]
            role_text = ", ".join(role_list)
        
        return f"""## <:Jo1nTrX_server:1411471136746897549> {guild.name}
{section} **__Roles Information ({role_count})__**

{role_text}"""
    
    elif category == "emoji":
        static_emojis = len([e for e in guild.emojis if not e.animated])
        animated_emojis = len([e for e in guild.emojis if e.animated])
        total_emojis = len(guild.emojis)
        
        return f"""## <:Jo1nTrX_server:1411471136746897549> {guild.name}
{section} **__Emoji Information__**

{arrow} **Static:** {static_emojis}
{arrow} **Animated:** {animated_emojis}
{arrow} **Total:** {total_emojis}"""
    
    elif category == "features":
        verification_levels = {
            discord.VerificationLevel.none: "None",
            discord.VerificationLevel.low: "Low",
            discord.VerificationLevel.medium: "Medium",
            discord.VerificationLevel.high: "High",
            discord.VerificationLevel.highest: "Highest"
        }
        upload_limit = guild.filesize_limit // (1024 * 1024)
        afk_timeout = guild.afk_timeout // 60 if guild.afk_timeout else 0
        system_channel = guild.system_channel.mention if guild.system_channel else "None"
        system_welcome = "<:Jo1nTrX_Yes:1408288995477159987>" if guild.system_channel_flags.join_notifications else "<:Jo1nTrX_No:1408289044470960129>"
        system_boost = "<:Jo1nTrX_Yes:1408288995477159987>" if guild.system_channel_flags.premium_subscriptions else "<:Jo1nTrX_No:1408289044470960129>"
        default_notifications = "All Messages" if guild.default_notifications == discord.NotificationLevel.all_messages else "Only @mentions"
        explicit_filter_emoji = "<:Jo1nTrX_Yes:1408288995477159987>" if guild.explicit_content_filter != discord.ContentFilter.disabled else "<:Jo1nTrX_No:1408289044470960129>"
        mfa_emoji = "<:Jo1nTrX_Yes:1408288995477159987>" if guild.mfa_level == discord.MFALevel.require_2fa else "<:Jo1nTrX_No:1408289044470960129>"
        boost_count = guild.premium_subscription_count or 0
        boost_tier = f"Tier {guild.premium_tier}"
        
        return f"""## <:Jo1nTrX_server:1411471136746897549> {guild.name}
{section} **__Server Features__**

{arrow} **Verification Level:** {verification_levels.get(guild.verification_level, 'Unknown')}
{arrow} **Upload Limit:** {upload_limit} MB
{arrow} **Inactive Timeout:** {afk_timeout} minutes
{arrow} **System Message Channel:** {system_channel}
{arrow} **System Welcome Messages:** {system_welcome}
{arrow} **System Boost Messages:** {system_boost}
{arrow} **Default Notifications:** {default_notifications}
{arrow} **Explicit Media Content Filter:** {explicit_filter_emoji}
{arrow} **2FA Requirements:** {mfa_emoji}

{section} **__Boost Stats__** <:Jo1nTrX_boostnitrobadge:1408288175272493096>

{arrow} **Boost Count:** {boost_count}
{arrow} **Boost Tier:** {boost_tier}"""
    
    return get_serverinfo_content(guild, "general")


class ServerInfoSelect(ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="General", value="general", description="Server overview"),
            discord.SelectOption(label="Members", value="members", description="Member statistics"),
            discord.SelectOption(label="Roles", value="roles", description="Role information"),
            discord.SelectOption(label="Emoji", value="emoji", description="Emoji statistics"),
            discord.SelectOption(label="Features", value="features", description="Server features & boost")
        ]
        super().__init__(placeholder="Select a category...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        current_view: ServerInfoLayoutView = self.view  # type: ignore
        if not current_view:
            return await interaction.response.defer()
        if current_view.requester and interaction.user.id != current_view.requester.id:
            return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
        category = self.values[0]
        new_view = ServerInfoLayoutView(current_view.guild, current_view.requester, category)
        await interaction.response.edit_message(view=new_view)


class ServerInfoLayoutView(ui.LayoutView):
    def __init__(self, guild: discord.Guild, requester: discord.Member = None, category: str = "general"):
        super().__init__(timeout=300)
        self.guild = guild
        self.requester = requester
        self.current_category = category
        self._setup_view()
    
    def _setup_view(self):
        content = get_serverinfo_content(self.guild, self.current_category)
        text_display = ui.TextDisplay(content)
        
        select = ServerInfoSelect()
        select_row = ui.ActionRow(select)
        
        container = ui.Container(text_display, select_row)
        self.add_item(container)

def get_botinfo_content(bot, category: str = "info", uptime_str: str = "", total_users: int = 0, 
                        total_commands: int = 0, slash_commands: int = 0) -> str:
    arrow = "<:jo1ntrx_right:1405095312456024127>"
    
    if category == "info":
        return f"""## <:pheonix_bots:1395063570743431371> Jo1nTrX
> Your multifeatured advanced Discord bot for invite tracking, utilities, message count, and more!
> Use prefix: `+` | Type `+help` to explore all commands!

<:pheonix_supportsrv:1395063576980619275> **__Bot Identity__**
{arrow} **Name:** `Jo1nTrX`
{arrow} **Tag:** `Jo1nTrX#0241`
{arrow} **ID:** `1404011822700564520`

<:pheonix_ping:1393906893843464262> **__Live Stats__**
{arrow} **Uptime:** `{uptime_str}`
{arrow} **Users:** `{total_users:,}`

<:pheonix_emoji_1:1393906887887425597> **__System Information__**
{arrow} **Python:** {platform.python_version()}
{arrow} **discord.py:** {discord.__version__}
{arrow} **Platform:** Linux

<:Jo1nTrX_server:1411471136746897549> **__Commands Information__**
{arrow} **Total Commands:** {total_commands}
{arrow} **Slash Commands:** {slash_commands}

<:Jo1nTrX_link:1415182665912418409> **__Links__**
{arrow} **[Invite Bot](https://discord.com/oauth2/authorize?client_id=1404011822700564520&permissions=8&integration_type=0&scope=bot+applications.commands)**
{arrow} **[Support Server]({bot.config.SUPPORT_SERVER_URL})**
{arrow} **[Dashboard]({bot.config.DASHBOARD_URL})**"""
    
    elif category == "owners":
        owner_names = ["Δ  C  Σ", "S A Y A N"]
        owner_links = []
        for i, owner_id in enumerate(bot.config.BOT_OWNER_IDS[:2]):
            name = owner_names[i] if i < len(owner_names) else f"Owner {i+1}"
            owner_links.append(f"➛ **[{name}](https://discord.com/users/{owner_id})**")
        
        return f"""## <:Jo1nTrX_owner:1411471179771940904> Jo1nTrX Owners

{chr(10).join(owner_links)}"""
    
    elif category == "hosting":
        return f"""## 🖥️ Our Host

> Sriyan Nodes delivers reliable, high-performance hosting for Discord bots, game servers, and databases — all at unbeatable prices with 99% uptime.

<:Jo1nTrX_link:1415182665912418409> **[Sriyan Nodes](https://discord.gg/PA6UhChxZY)**"""
    
    return get_botinfo_content(bot, "info", uptime_str, total_users, total_commands, slash_commands)


class BotInfoSelect(ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Bot Info", value="info", description="Bot statistics"),
            discord.SelectOption(label="Owners", value="owners", description="Bot owners"),
            discord.SelectOption(label="Hosting", value="hosting", description="Hosting information")
        ]
        super().__init__(placeholder="Select a category...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        current_view: BotInfoLayoutView = self.view  # type: ignore
        if not current_view:
            return await interaction.response.defer()
        if current_view.requester and interaction.user.id != current_view.requester.id:
            return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
        category = self.values[0]
        new_view = BotInfoLayoutView(current_view.bot, current_view.requester, category,
                                     current_view.uptime_str, current_view.total_users,
                                     current_view.total_commands, current_view.slash_commands)
        await interaction.response.edit_message(view=new_view)


class BotInfoLayoutView(ui.LayoutView):
    def __init__(self, bot, requester: discord.Member = None, category: str = "info",
                 uptime_str: str = "", total_users: int = 0, total_commands: int = 0, slash_commands: int = 0):
        super().__init__(timeout=300)
        self.bot = bot
        self.requester = requester
        self.current_category = category
        self.uptime_str = uptime_str
        self.total_users = total_users
        self.total_commands = total_commands
        self.slash_commands = slash_commands
        self._setup_view()
    
    def _setup_view(self):
        content = get_botinfo_content(self.bot, self.current_category, self.uptime_str, 
                                      self.total_users, self.total_commands, self.slash_commands)
        text_display = ui.TextDisplay(content)
        
        select = BotInfoSelect()
        select_row = ui.ActionRow(select)
        
        container = ui.Container(text_display, select_row)
        self.add_item(container)


def get_userinfo_content(member: discord.Member, category: str = "info") -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    if category == "info":
        status_emoji_map = {
            discord.Status.online: "<:Jo1nTrX_On01:1415540440014520330>",
            discord.Status.idle: "<:Jo1nTrX_idle:1415540481953370236>",
            discord.Status.dnd: "<:Jo1nTrX_dnd01:1415540445856927876>",
            discord.Status.offline: "<:Jo1nTrX_off01:1415540488307605604>"
        }
        status_emoji = status_emoji_map.get(member.status, "<:Jo1nTrX_off01:1415540488307605604>")
        bot_badge = "<:Jo1nTrX_bot:1408288863389954138>" if member.bot else ""
        
        return f"""## <:Jo1nTrX_pin:1411471142828380240> {member.display_name} {bot_badge}
{section} **__User Details__**

{arrow} **Username:** {member.name}
{arrow} **Display Name:** {member.display_name}
{arrow} **ID:** `{member.id}`
{arrow} **Bot:** {'<:Jo1nTrX_Yes:1408288995477159987> Yes' if member.bot else '<:Jo1nTrX_No:1408289044470960129> No'}
{arrow} **Status:** {status_emoji} {str(member.status).title()}

{section} **__Timestamps__**

{arrow} **Account Created:** <t:{int(member.created_at.timestamp())}:F>
{arrow} **Joined Server:** <t:{int(member.joined_at.timestamp())}:F>""" if member.joined_at else f"""## <:Jo1nTrX_pin:1411471142828380240> {member.display_name} {bot_badge}
{section} **__User Details__**

{arrow} **Username:** {member.name}
{arrow} **Display Name:** {member.display_name}
{arrow} **ID:** `{member.id}`
{arrow} **Bot:** {'<:Jo1nTrX_Yes:1408288995477159987> Yes' if member.bot else '<:Jo1nTrX_No:1408289044470960129> No'}
{arrow} **Status:** {status_emoji} {str(member.status).title()}

{section} **__Timestamps__**

{arrow} **Account Created:** <t:{int(member.created_at.timestamp())}:F>
{arrow} **Joined Server:** Unknown"""
    
    elif category == "roles":
        import random
        roles = member.roles[1:]
        roles.reverse()
        random.shuffle(roles)
        role_count = len(roles)
        
        if role_count == 0:
            roles_text = "No roles"
        elif role_count > 70:
            role_list = [f"`{role.name}`" for role in roles[:70]]
            roles_text = ", ".join(role_list) + f"\n....{role_count - 70} more!"
        else:
            roles_text = ", ".join([f"`{role.name}`" for role in roles])
        
        top_role = member.top_role if member.top_role.name != "@everyone" else None
        top_role_text = f"`{top_role.name}`" if top_role else "None"
        
        return f"""## <:roles_Jo1nTrX:1448526797041045567> {member.display_name}'s Roles
{section} **__Role Information ({role_count} roles)__**

{arrow} **Top Role:** {top_role_text}

{section} **__All Roles__**

{roles_text}"""
    
    elif category == "permissions":
        key_perms = []
        if member.guild_permissions.administrator:
            key_perms.append("<:Jo1nTrX_Yes:1408288995477159987> Administrator")
        else:
            key_perms.append("<:Jo1nTrX_No:1408289044470960129> Administrator")
        if member.guild_permissions.manage_guild:
            key_perms.append("<:Jo1nTrX_Yes:1408288995477159987> Manage Server")
        if member.guild_permissions.manage_channels:
            key_perms.append("<:Jo1nTrX_Yes:1408288995477159987> Manage Channels")
        if member.guild_permissions.manage_roles:
            key_perms.append("<:Jo1nTrX_Yes:1408288995477159987> Manage Roles")
        if member.guild_permissions.manage_messages:
            key_perms.append("<:Jo1nTrX_Yes:1408288995477159987> Manage Messages")
        if member.guild_permissions.kick_members:
            key_perms.append("<:Jo1nTrX_Yes:1408288995477159987> Kick Members")
        if member.guild_permissions.ban_members:
            key_perms.append("<:Jo1nTrX_Yes:1408288995477159987> Ban Members")
        if member.guild_permissions.mention_everyone:
            key_perms.append("<:Jo1nTrX_Yes:1408288995477159987> Mention Everyone")
        
        perms_text = "\n".join(key_perms) if key_perms else "No special permissions"
        
        return f"""## <:jo1ntrx_moderation:1405093582863339591> {member.display_name}'s Permissions
{section} **__Key Permissions__**

{perms_text}"""
    
    return get_userinfo_content(member, "info")


class UserInfoSelect(ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Info", value="info", description="User details"),
            discord.SelectOption(label="Roles", value="roles", description="User roles"),
            discord.SelectOption(label="Permissions", value="permissions", description="User permissions")
        ]
        super().__init__(placeholder="Select a category...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        current_view: UserInfoLayoutView = self.view  # type: ignore
        if not current_view:
            return await interaction.response.defer()
        if current_view.requester and interaction.user.id != current_view.requester.id:
            return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
        category = self.values[0]
        new_view = UserInfoLayoutView(current_view.member, current_view.requester, category)
        await interaction.response.edit_message(view=new_view)


class UserInfoLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member, requester: discord.Member = None, category: str = "info"):
        super().__init__(timeout=300)
        self.member = member
        self.requester = requester
        self.current_category = category
        self._setup_view()
    
    def _setup_view(self):
        content = get_userinfo_content(self.member, self.current_category)
        text_display = ui.TextDisplay(content)
        
        select = UserInfoSelect()
        select_row = ui.ActionRow(select)
        
        container = ui.Container(text_display, select_row)
        self.add_item(container)


class RoleInfoLayoutView(ui.LayoutView):
    def __init__(self, role: discord.Role):
        super().__init__(timeout=300)
        self.role = role
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        key_perms = []
        if self.role.permissions.administrator:
            key_perms.append("Administrator")
        if self.role.permissions.manage_guild:
            key_perms.append("Manage Server")
        if self.role.permissions.manage_channels:
            key_perms.append("Manage Channels")
        if self.role.permissions.manage_roles:
            key_perms.append("Manage Roles")
        if self.role.permissions.manage_messages:
            key_perms.append("Manage Messages")
        if self.role.permissions.kick_members:
            key_perms.append("Kick Members")
        if self.role.permissions.ban_members:
            key_perms.append("Ban Members")
        
        perms_text = ", ".join(key_perms) if key_perms else "No key permissions"
        
        content = f"""## <:roles_Jo1nTrX:1448526797041045567> {self.role.name}
{section} **__Role Details__**

{arrow} **Name:** {self.role.name}
{arrow} **ID:** `{self.role.id}`
{arrow} **Mention:** {self.role.mention}
{arrow} **Color:** {str(self.role.color)}
{arrow} **Position:** {self.role.position}

{section} **__Settings__**

{arrow} **Hoisted:** {'<:Jo1nTrX_Yes:1408288995477159987>' if self.role.hoist else '<:Jo1nTrX_No:1408289044470960129>'}
{arrow} **Mentionable:** {'<:Jo1nTrX_Yes:1408288995477159987>' if self.role.mentionable else '<:Jo1nTrX_No:1408289044470960129>'}
{arrow} **Managed:** {'<:Jo1nTrX_Yes:1408288995477159987>' if self.role.managed else '<:Jo1nTrX_No:1408289044470960129>'}
{arrow} **Members:** {len(self.role.members)}
{arrow} **Created:** <t:{int(self.role.created_at.timestamp())}:F>

{section} **__Key Permissions__**

{arrow} {perms_text}"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class AvatarLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member):
        super().__init__(timeout=300)
        self.member = member
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        avatar_url = self.member.avatar.url if self.member.avatar else self.member.default_avatar.url
        
        content = f"""## <:Jo1nTrX_avatR:1411471185543168117> {self.member.display_name}'s Avatar
{section} **__Avatar Information__**

{arrow} **User:** {self.member.mention}
{arrow} **Format:** {'Animated GIF' if self.member.avatar and self.member.avatar.is_animated() else 'Static PNG'}"""
        
        text_display = ui.TextDisplay(content)
        
        media_item = discord.MediaGalleryItem(media=avatar_url)
        media_gallery = ui.MediaGallery(media_item)
        
        view_btn = ui.Button(label="View Full Size", url=avatar_url, style=discord.ButtonStyle.link)
        button_row = ui.ActionRow(view_btn)
        
        container = ui.Container(text_display, media_gallery, button_row)
        self.add_item(container)


class BannerLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member, user: discord.User):
        super().__init__(timeout=300)
        self.member = member
        self.user = user
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if self.user.banner:
            banner_url = self.user.banner.url
            content = f"""## <:Jo1nTrX_avatR:1411471185543168117> {self.member.display_name}'s Banner
{section} **__Banner Information__**

{arrow} **User:** {self.member.mention}
{arrow} **Format:** {'Animated GIF' if self.user.banner.is_animated() else 'Static PNG'}"""
            
            text_display = ui.TextDisplay(content)
            
            media_item = discord.MediaGalleryItem(media=banner_url)
            media_gallery = ui.MediaGallery(media_item)
            
            view_btn = ui.Button(label="View Full Size", url=banner_url, style=discord.ButtonStyle.link)
            button_row = ui.ActionRow(view_btn)
            container = ui.Container(text_display, media_gallery, button_row)
        else:
            content = f"""## <:Jo1nTrX_avatR:1411471185543168117> {self.member.display_name}'s Banner
{section} **__No Banner__**

{arrow} This user has no banner set."""
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
        
        self.add_item(container)


class PingLayoutView(ui.LayoutView):
    def __init__(self, bot_latency: int, db_latency):
        super().__init__(timeout=300)
        self.bot_latency = bot_latency
        self.db_latency = db_latency
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:Jo1nTrX_ping:1411471241067630694> Pong!
{section} **__Latency Information__**

{arrow} **API Latency:** `{self.bot_latency}ms`
{arrow} **Database Latency:** `{self.db_latency}ms`"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class UptimeLayoutView(ui.LayoutView):
    def __init__(self, uptime_str: str, start_time: float):
        super().__init__(timeout=300)
        self.uptime_str = uptime_str
        self.start_time = start_time
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:jo1ntrX_bot:1405305955742257314> Bot Uptime
{section} **__Uptime Information__**

{arrow} **Current Uptime:** `{self.uptime_str}`
{arrow} **Started:** <t:{int(self.start_time)}:F>"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class MemberCountLayoutView(ui.LayoutView):
    def __init__(self, guild: discord.Guild):
        super().__init__(timeout=300)
        self.guild = guild
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        total_members = self.guild.member_count
        humans = len([m for m in self.guild.members if not m.bot])
        bots = len([m for m in self.guild.members if m.bot])
        
        content = f"""## <:Jo1nTrX_server:1411471136746897549> {self.guild.name}
{section} **__Member Count__**

{arrow} **Total Members:** `{total_members}`
{arrow} **Humans:** `{humans}`
{arrow} **Bots:** `{bots}`"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class SupportLayoutView(ui.LayoutView):
    def __init__(self, support_url: str, dashboard_url: str):
        super().__init__(timeout=300)
        self.support_url = support_url
        self.dashboard_url = dashboard_url
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:pheonix_supportsrv:1395063576980619275> Jo1nTrX Support
{section} **__Need Help?__**

{arrow} Join our support server for assistance
{arrow} Visit the dashboard for easy bot management

**What you'll find:**
{arrow} 24/7 Support team
{arrow} Bot updates & announcements
{arrow} Feature requests & suggestions
{arrow} Community discussions"""
        
        text_display = ui.TextDisplay(content)
        
        support_btn = ui.Button(label="Support Server", url=self.support_url, style=discord.ButtonStyle.link)
        dashboard_btn = ui.Button(label="Dashboard", url=self.dashboard_url, style=discord.ButtonStyle.link)
        button_row = ui.ActionRow(support_btn, dashboard_btn)
        
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class ServerIconLayoutView(ui.LayoutView):
    def __init__(self, guild: discord.Guild):
        super().__init__(timeout=300)
        self.guild = guild
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if self.guild.icon:
            icon_url = self.guild.icon.url
            format_type = 'Animated GIF' if self.guild.icon.is_animated() else 'Static PNG'
            content = f"""## <:Jo1nTrX_server:1411471136746897549> {self.guild.name}'s Icon
{section} **__Icon Information__**

{arrow} **Server:** {self.guild.name}
{arrow} **Format:** {format_type}"""
            
            text_display = ui.TextDisplay(content)
            
            media_item = discord.MediaGalleryItem(media=icon_url)
            media_gallery = ui.MediaGallery(media_item)
            
            view_btn = ui.Button(label="View Full Size", url=icon_url, style=discord.ButtonStyle.link)
            button_row = ui.ActionRow(view_btn)
            container = ui.Container(text_display, media_gallery, button_row)
        else:
            content = f"""## <:Jo1nTrX_server:1411471136746897549> {self.guild.name}'s Icon
{section} **__No Icon__**

{arrow} This server has no icon set."""
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
        
        self.add_item(container)


class GuildBannerLayoutView(ui.LayoutView):
    def __init__(self, guild: discord.Guild):
        super().__init__(timeout=300)
        self.guild = guild
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if self.guild.banner:
            banner_url = self.guild.banner.url
            format_type = 'Animated GIF' if self.guild.banner.is_animated() else 'Static PNG'
            content = f"""## <:Jo1nTrX_avatR:1411471185543168117> {self.guild.name}'s Banner
{section} **__Banner Information__**

{arrow} **Server:** {self.guild.name}
{arrow} **Format:** {format_type}"""
            
            text_display = ui.TextDisplay(content)
            
            media_item = discord.MediaGalleryItem(media=banner_url)
            media_gallery = ui.MediaGallery(media_item)
            
            view_btn = ui.Button(label="View Full Size", url=banner_url, style=discord.ButtonStyle.link)
            button_row = ui.ActionRow(view_btn)
            container = ui.Container(text_display, media_gallery, button_row)
        else:
            content = f"""## <:Jo1nTrX_avatR:1411471185543168117> {self.guild.name}'s Banner
{section} **__No Banner__**

{arrow} This server has no banner set."""
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
        
        self.add_item(container)


class SnipeLayoutView(ui.LayoutView):
    def __init__(self, deleted_msgs: list, requester: discord.Member):
        super().__init__(timeout=300)
        self.deleted_msgs = deleted_msgs
        self.requester = requester
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:Jo1nTrX_message:1411471191834890354> Recently Deleted Messages
> Showing last **{len(self.deleted_msgs)}** deleted message(s)

"""
        for i, deleted_msg in enumerate(self.deleted_msgs, 1):
            time_diff = datetime.now(timezone.utc) - deleted_msg['deleted_at']
            
            if time_diff.total_seconds() < 60:
                time_ago = f"{int(time_diff.total_seconds())} seconds ago"
            elif time_diff.total_seconds() < 3600:
                time_ago = f"{int(time_diff.total_seconds() // 60)} minutes ago"
            else:
                time_ago = f"{int(time_diff.total_seconds() // 3600)} hours ago"
            
            msg_content = deleted_msg['content'][:150] + "..." if len(deleted_msg['content']) > 150 else deleted_msg['content']
            
            content += f"""{section} **__Message #{i}__**
{arrow} **Author:** {deleted_msg['author'].mention}
{arrow} **Channel:** {deleted_msg['channel'].mention}
{arrow} **Deleted:** {time_ago}
"""
            if msg_content:
                content += f"{arrow} **Content:** {msg_content}\n"
            if deleted_msg['stickers']:
                content += f"{arrow} **Stickers:** {', '.join(deleted_msg['stickers'])}\n"
            content += "\n"
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class ConfirmationView(BaseView):
    def __init__(self, ctx, action_type: str, target: Optional[discord.TextChannel] = None):
        super().__init__(timeout=30.0)
        self.ctx = ctx
        self.action_type = action_type
        self.target = target
        self.value = None

    @discord.ui.button(label='Yes', style=discord.ButtonStyle.success, emoji='✅')
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("Only the command author can use these buttons.", ephemeral=True)
            return
        
        await interaction.response.defer()
        
        try:
            if self.action_type == "nuke" and self.target:
                # Clone the channel and delete the original
                channel = self.target
                position = channel.position
                new_channel = await channel.clone(reason=f"Channel nuked by {self.ctx.author}")
                await new_channel.edit(position=position)
                await channel.delete(reason=f"Channel nuked by {self.ctx.author}")
                
                embed = create_success_embed(
                    f"Channel **{channel.name}** has been successfully nuked!\n\n"
                    f"**Actions performed:**\n"
                    f"<:Jo1nTrX_arrow2:1415026780783247420> Created new channel with same settings\n"
                    f"<:Jo1nTrX_arrow2:1415026780783247420> Deleted original channel\n"
                    f"<:Jo1nTrX_arrow2:1415026780783247420> Maintained channel position",
                    title="Channel Nuked Successfully"
                )
                await new_channel.send(embed=embed)
            
            # Disable all buttons
            for item in self.children:
                if hasattr(item, 'disabled'):
                    item.disabled = True
            
        except Exception as e:
            error_embed = create_error_embed(
                f"Error performing {self.action_type}: {str(e)}",
                title="Operation Failed"
            )
            await interaction.edit_original_response(embed=error_embed, view=None)

    @discord.ui.button(label='No', style=discord.ButtonStyle.danger, emoji='❌')
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("Only the command author can use these buttons.", ephemeral=True)
            return
        
        embed = EmbedFactory.create(
            title="Operation Cancelled",
            description=f"{self.action_type.title()} operation has been cancelled.\n\nNo changes were made.",
            color=self.ctx.bot.config.error_color
        )
        
        # Disable all buttons
        for item in self.children:
            if hasattr(item, 'disabled'):
                item.disabled = True
        
        await interaction.response.edit_message(embed=embed, view=self)

    async def on_timeout(self):
        embed = EmbedFactory.create(
            title="Operation Timed Out",
            description="The confirmation request timed out. No changes were made.",
            color=0xffff00
        )
        
        # Disable all buttons
        for item in self.children:
            if hasattr(item, 'disabled'):
                item.disabled = True

class UtilityCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cog_start_time = time.time()  # Float unix timestamp for this cog's uptime calculation
        self.deleted_messages = {}  # Store last 3 deleted messages per server (guild_id -> list of messages)
    
    async def delete_command_message(self, ctx, delay: int = 3):
        """Delete the command message after a delay"""
        await asyncio.sleep(delay)
        try:
            await ctx.message.delete()
        except:
            pass  # Ignore if message is already deleted or no permission
    
    def _check_nickname_hierarchy(self, ctx, member):
        if member == ctx.author:
            return False, "You cannot change your own nickname with this command."
        
        if member == ctx.guild.owner:
            return False, "Cannot change the server owner's nickname."
        
        if ctx.author != ctx.guild.owner and member.top_role > ctx.author.top_role:
            return False, "You cannot change the nickname of someone with a higher role."
        
        if member.top_role >= ctx.guild.me.top_role:
            return False, "I cannot change the nickname of someone with a higher or equal role than me."
        
        return True, None
    
    @commands.hybrid_command(name='nick')
    @app_commands.describe(
        member='The member to change nickname for',
        nickname='The new nickname (leave empty to remove nickname)'
    )
    @commands.has_permissions(manage_nicknames=True)
    @commands.bot_has_permissions(manage_nicknames=True)
    async def nick(self, ctx, member: discord.Member, *, nickname: str = None):
        """Change a member's nickname"""
        can_moderate, error_msg = self._check_nickname_hierarchy(ctx, member)
        if not can_moderate and member != ctx.author:
            error_view = create_v2_view(create_error_content("Error", error_msg or "Cannot change this member's nickname."))
            await ctx.send(view=error_view)
            return
        
        action = "removing nickname" if nickname is None else f"changing nickname to {nickname}"
        loading_msg = await send_loading_message(ctx, f"{action} for {member.mention}")
        
        try:
            old_nick = member.display_name
            await member.edit(nick=nickname)
            
            if nickname:
                content = f"""## {SUCCESS_EMOJI} Nickname Changed
> Changed {member.mention}'s nickname

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **From:** {old_nick}
{ARROW_EMOJI} **To:** {nickname}
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            else:
                content = f"""## {SUCCESS_EMOJI} Nickname Removed
> Removed {member.mention}'s nickname

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Previous:** {old_nick}
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            
            view = create_v2_view(content)
            await loading_msg.edit(content=None, embed=None, view=view)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("Permission Error", "I don't have permission to change this member's nickname."))
            await loading_msg.edit(content=None, embed=None, view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error changing nickname: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)
    
    @commands.hybrid_command(name='clearnick')
    @app_commands.describe(member='The member to clear nickname for')
    @commands.has_permissions(manage_nicknames=True)
    @commands.bot_has_permissions(manage_nicknames=True)
    async def clearnick(self, ctx, member: discord.Member):
        """Clear a member's nickname"""
        await ctx.invoke(self.nick, member=member, nickname=None)
    
    async def _has_purge_permission(self, ctx):
        """Check if user has permission to purge messages (admin, manage_messages, or modrole)"""
        if ctx.author.guild_permissions.administrator:
            return True
        if ctx.author.guild_permissions.manage_messages:
            return True
        
        modrole_id = await self.bot.db.get_modrole(ctx.guild.id)
        if modrole_id:
            modrole = ctx.guild.get_role(modrole_id)
            if modrole and modrole in ctx.author.roles:
                return True
        
        return False
    
    def _check_purge_hierarchy(self, ctx, member):
        """Check role hierarchy for purging member's messages"""
        if member == ctx.guild.owner:
            return False, "Cannot purge messages from the server owner."
        
        if ctx.author != ctx.guild.owner and member.top_role >= ctx.author.top_role:
            return False, "You cannot purge messages from someone with a higher or equal role."
        
        return True, None
    
    @commands.hybrid_command(name='purge', aliases=['prge'])
    @app_commands.describe(
        amount='Number of messages to delete (1-1000)',
        member='Only delete messages from this member (optional)'
    )
    @commands.bot_has_permissions(manage_messages=True)
    async def purge(self, ctx, amount: int, member: discord.Member = None):
        """Bulk delete messages"""
        has_permission = await self._has_purge_permission(ctx)
        if not has_permission:
            error_view = create_v2_view(create_error_content("Permission Denied", "You need `Manage Messages` permission or Mod Role to use this command."))
            await ctx.send(view=error_view)
            return
        
        if member:
            can_purge, error_msg = self._check_purge_hierarchy(ctx, member)
            if not can_purge:
                error_view = create_v2_view(create_error_content("Hierarchy Error", error_msg))
                await ctx.send(view=error_view)
                return
        
        if amount < 1 or amount > 1000:
            error_view = create_v2_view(create_error_content("Error", "Amount must be between 1 and 1000."))
            await ctx.send(view=error_view)
            return
        
        loading_msg = await send_loading_message(ctx, f"deleting {amount} messages")
        
        try:
            def check(message):
                return member is None or message.author == member
            
            deleted = await ctx.channel.purge(limit=amount + 1, check=check)
            actual_deleted = len(deleted) - 1
            
            if member:
                content = f"""## {SUCCESS_EMOJI} Messages Purged
> Deleted **{actual_deleted}** messages from {member.mention}

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Channel:** {ctx.channel.mention}
{ARROW_EMOJI} **Target:** {member.mention}
{ARROW_EMOJI} **Deleted:** {actual_deleted} messages
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            else:
                content = f"""## {SUCCESS_EMOJI} Messages Purged
> Deleted **{actual_deleted}** messages

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Channel:** {ctx.channel.mention}
{ARROW_EMOJI} **Deleted:** {actual_deleted} messages
{ARROW_EMOJI} **Moderator:** {ctx.author.mention}"""
            
            view = create_v2_view(content)
            confirm_msg = await ctx.send(view=view)
            await confirm_msg.delete(delay=5)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("Permission Error", "I don't have permission to delete messages in this channel."))
            await loading_msg.edit(content=None, embed=None, view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error purging messages: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)
    
    @commands.hybrid_command(name='dmuser')
    @app_commands.describe(
        user='The user to send a direct message to',
        message='The message to send to the user'
    )
    @commands.has_permissions(administrator=True)
    async def dmuser(self, ctx, user: discord.Member, *, message: str):
        """Send a direct message to a user (Admin only)"""
        loading_msg = await send_loading_message(ctx, f"sending DM to {user.mention}")
        
        try:
            full_message = f"{message}\n\n{ARROW_EMOJI} **Sent By `{ctx.guild.name}`**"
            
            await user.send(full_message)
            
            content = f"""## {SUCCESS_EMOJI} DM Sent Successfully
> Direct message sent to {user.mention}

{SECTION_EMOJI} **__Message Content__**

{ARROW_EMOJI} {message}

{ARROW_EMOJI} **Sent By `{ctx.guild.name}`**"""
            
            view = create_v2_view(content)
            await loading_msg.edit(content=None, embed=None, view=view)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("DM Failed", f"Could not send DM to {user.mention}. They may have DMs disabled or have blocked the bot."))
            await loading_msg.edit(content=None, embed=None, view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error sending DM: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)

    @commands.command(name='serverinfo', aliases=['si'])
    async def server_info(self, ctx):
        """Display server information with interactive buttons"""
        loading_msg = await send_loading_message(ctx, "Gathering server information...")
        
        view = ServerInfoLayoutView(ctx.guild, ctx.author, "general")
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='userinfo', aliases=['ui'])
    async def user_info(self, ctx, member: Optional[discord.Member] = None):
        """Display user information with interactive buttons"""
        loading_msg = await send_loading_message(ctx, "Gathering user information...")
        
        if member is None:
            member = ctx.author
        
        view = UserInfoLayoutView(member, ctx.author, "info")
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='roleinfo', aliases=['ri'])
    async def role_info(self, ctx, *, role: discord.Role):
        """Display role information"""
        loading_msg = await send_loading_message(ctx, "Gathering role information...")
        view = RoleInfoLayoutView(role)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='avatar', aliases=['av'])
    async def avatar(self, ctx, member: Optional[discord.Member] = None):
        """Display user's avatar"""
        loading_msg = await send_loading_message(ctx, "Fetching avatar...")
        if member is None:
            member = ctx.author
        view = AvatarLayoutView(member)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='banner')
    async def banner(self, ctx, member: Optional[discord.Member] = None):
        """Display user's banner"""
        loading_msg = await send_loading_message(ctx, "Fetching banner...")
        if member is None:
            member = ctx.author
        user = await self.bot.fetch_user(member.id)
        view = BannerLayoutView(member, user)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='guildbanner')
    async def guild_banner(self, ctx):
        """Display server's banner"""
        loading_msg = await send_loading_message(ctx, "Fetching server banner...")
        view = GuildBannerLayoutView(ctx.guild)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='servericon', aliases=['sicon'])
    async def server_icon(self, ctx):
        """Display server's icon"""
        loading_msg = await send_loading_message(ctx, "Fetching server icon...")
        view = ServerIconLayoutView(ctx.guild)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='support')
    async def support(self, ctx):
        """Display support server invite"""
        loading_msg = await send_loading_message(ctx, "Loading support information...")
        view = SupportLayoutView(self.bot.config.SUPPORT_SERVER_URL, self.bot.config.DASHBOARD_URL)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='membercount', aliases=['mc'])
    async def member_count(self, ctx):
        """Display server member count"""
        loading_msg = await send_loading_message(ctx, "Counting members...")
        view = MemberCountLayoutView(ctx.guild)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='uptime')
    async def uptime(self, ctx):
        """Display bot uptime"""
        loading_msg = await send_loading_message(ctx, "Calculating uptime...")
        current_time = time.time()
        uptime_seconds = int(current_time - self.cog_start_time)
        days = uptime_seconds // 86400
        hours = (uptime_seconds % 86400) // 3600
        minutes = (uptime_seconds % 3600) // 60
        seconds = uptime_seconds % 60
        uptime_str = f"{days}d {hours}h {minutes}m {seconds}s"
        view = UptimeLayoutView(uptime_str, self.cog_start_time)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='botinfo', aliases=['bi'])
    async def botinfo(self, ctx):
        """Display bot information with interactive buttons"""
        loading_msg = await send_loading_message(ctx, "Loading bot information...")
        
        current_time = time.time()
        uptime_seconds = int(current_time - self.cog_start_time)
        
        days = uptime_seconds // 86400
        hours = (uptime_seconds % 86400) // 3600
        minutes = (uptime_seconds % 3600) // 60
        
        if days > 0:
            uptime_str = f"{days}d {hours}h {minutes}m"
        elif hours > 0:
            uptime_str = f"{hours}h {minutes}m"
        else:
            uptime_str = f"{minutes}m"
        
        total_users = sum(guild.member_count for guild in self.bot.guilds)
        total_commands = len([cmd for cmd in self.bot.commands])
        slash_commands = len([cmd for cmd in self.bot.tree.get_commands()])
        
        view = BotInfoLayoutView(self.bot, ctx.author, "info", uptime_str, total_users, total_commands, slash_commands)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='ping')
    async def ping(self, ctx):
        """Display bot latency"""
        loading_msg = await send_loading_message(ctx, "Testing connection...")
        bot_latency = round(self.bot.latency * 1000)
        start_time = time.time()
        try:
            await self.bot.db.get_guild_prefix(ctx.guild.id if ctx.guild else 0)
            db_latency = round((time.time() - start_time) * 1000)
        except Exception:
            db_latency = "Error"
        view = PingLayoutView(bot_latency, db_latency)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='setprefix', aliases=['prefix'])
    @commands.has_permissions(manage_guild=True)
    async def set_prefix(self, ctx, *, new_prefix: str):
        """Set a custom prefix for this server"""
        loading_msg = await send_loading_message(ctx, "Setting custom prefix...")
        
        if len(new_prefix) > 5:
            embed = create_error_embed(
                "Prefix cannot be longer than 5 characters!",
                title="Invalid Prefix"
            )
            await loading_msg.edit(embed=embed)
            return
        
        try:
            await self.bot.db.set_guild_prefix(ctx.guild.id, new_prefix)
            
            embed = create_success_embed(
                f"<:Jo1nTrX_arrow2:1415026780783247420> Server prefix has been changed to: `{new_prefix}`\n\n"
                f"<:Jo1nTrX_arrow2:1415026780783247420> You can now use commands with `{new_prefix}` instead of `+`",
                title="Prefix Updated"
            )
            await loading_msg.edit(embed=embed)
            
        except Exception as e:
            embed = create_error_embed(
                f"Error setting prefix: {str(e)}",
                title="Database Error"
            )
            await loading_msg.edit(embed=embed)

    @commands.command(name='deleteprefix')
    @commands.has_permissions(manage_guild=True)
    async def delete_prefix(self, ctx):
        """Reset server prefix to default"""
        loading_msg = await send_loading_message(ctx, "Resetting prefix...")
        
        try:
            await self.bot.db.delete_guild_prefix(ctx.guild.id)
            
            embed = create_success_embed(
                f"<:Jo1nTrX_arrow2:1415026780783247420> Server prefix has been reset to default: `+`\n\n"
                f"<:Jo1nTrX_arrow2:1415026780783247420> You can now use commands with `+` prefix again.",
                title="Prefix Reset"
            )
            await loading_msg.edit(embed=embed)
            
        except Exception as e:
            embed = create_error_embed(
                f"Error resetting prefix: {str(e)}",
                title="Database Error"
            )
            await loading_msg.edit(embed=embed)


    @commands.Cog.listener()
    async def on_message_delete(self, message):
        """Track deleted messages for snipe command"""
        # Only track messages from guilds
        if not message.guild:
            return
        
        # Don't track bot messages
        if message.author.bot:
            return
        
        # Skip if message has no content, stickers, or attachments
        if not message.content and not message.stickers and not message.attachments:
            return
        
        # Collect sticker names if any
        sticker_names = [sticker.name for sticker in message.stickers] if message.stickers else []
        
        # Collect attachment URLs if any
        attachment_urls = [attachment.url for attachment in message.attachments] if message.attachments else []
        
        # Store the deleted message data
        deleted_data = {
            'content': message.content or '',
            'author': message.author,
            'channel': message.channel,
            'created_at': message.created_at,
            'deleted_at': datetime.now(timezone.utc),
            'stickers': sticker_names,
            'attachments': attachment_urls
        }
        
        # Initialize server's deleted messages list if not exists
        if message.guild.id not in self.deleted_messages:
            self.deleted_messages[message.guild.id] = []
        
        # Add to the beginning of the list (most recent first)
        self.deleted_messages[message.guild.id].insert(0, deleted_data)
        
        # Keep only last 3 messages
        if len(self.deleted_messages[message.guild.id]) > 3:
            self.deleted_messages[message.guild.id] = self.deleted_messages[message.guild.id][:3]

    @commands.command(name='snipe')
    async def snipe(self, ctx):
        """Show the last 3 deleted messages in this server"""
        loading_msg = await send_loading_message(ctx, "Searching for deleted messages...")
        
        # Check if there are any deleted messages in this server
        if ctx.guild.id not in self.deleted_messages or not self.deleted_messages[ctx.guild.id]:
            embed = create_error_embed(
                "No recently deleted messages found in this server.",
                title="No Deleted Messages"
            )
            await loading_msg.edit(embed=embed)
            return
        
        deleted_msgs = self.deleted_messages[ctx.guild.id]
        view = SnipeLayoutView(deleted_msgs, ctx.author)
        await loading_msg.edit(content=None, embed=None, view=view)

    @commands.command(name='clearuser', aliases=['cu', 'pu'])
    @commands.has_permissions(manage_messages=True)
    async def clear_user(self, ctx, member: discord.Member, amount: int = 100):
        """Clear messages from a specific user in the current channel"""
        try:
            # Limit amount to prevent abuse
            if amount > 500:
                amount = 500
            elif amount < 1:
                amount = 1
            
            # Collect user messages
            user_messages = []
            async for message in ctx.channel.history(limit=amount * 3):
                if message.author == member and len(user_messages) < amount:
                    user_messages.append(message)
                if len(user_messages) >= amount:
                    break
            
            actual_deleted = len(user_messages)
            
            # Bulk delete if possible
            if user_messages:
                try:
                    await ctx.channel.delete_messages(user_messages)
                except discord.HTTPException:
                    # If bulk delete fails, delete one by one
                    for message in user_messages:
                        try:
                            await message.delete()
                        except (discord.errors.NotFound, discord.errors.Forbidden):
                            pass
            
            # Delete the command message
            try:
                await ctx.message.delete()
            except:
                pass
            
            # Send success message using component v2
            arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
            section = "<:jo1ntrx_right:1405095312456024127>"
            tick = "<:Jo1nTrX_Yes:1408288995477159987>"
            
            content = f"""## {tick} User Messages Cleared

{section} **__Details__**
{arrow} **Cleared:** {actual_deleted} messages from {member.mention}
{arrow} **Channel:** {ctx.channel.mention}
{arrow} **Cleared By:** {ctx.author.mention}"""
            
            success_view = ui.LayoutView(timeout=None)
            success_view.add_item(ui.Container(ui.TextDisplay(content)))
            success_msg = await ctx.send(view=success_view)
            await asyncio.sleep(3)
            try:
                await success_msg.delete()
            except:
                pass
            
        except discord.errors.Forbidden:
            await ctx.send("I don't have permission to delete messages in this channel.", delete_after=5)
        except Exception as e:
            await ctx.send(f"Error clearing user messages: {str(e)}", delete_after=5)

    @commands.command(name='clearbots', aliases=['cb', 'pb'])
    @commands.has_permissions(manage_messages=True)
    async def clear_bots(self, ctx, amount: int = 100):
        """Clear messages from all bots in the current channel"""
        try:
            # Limit amount to prevent abuse
            if amount > 500:
                amount = 500
            elif amount < 1:
                amount = 1
            
            # Collect bot messages
            bot_messages = []
            async for message in ctx.channel.history(limit=amount * 3):
                if message.author.bot and len(bot_messages) < amount:
                    bot_messages.append(message)
                if len(bot_messages) >= amount:
                    break
            
            actual_deleted = len(bot_messages)
            
            # Bulk delete if possible
            if bot_messages:
                try:
                    await ctx.channel.delete_messages(bot_messages)
                except discord.HTTPException:
                    # If bulk delete fails, delete one by one
                    for message in bot_messages:
                        try:
                            await message.delete()
                        except (discord.errors.NotFound, discord.errors.Forbidden):
                            pass
            
            # Delete the command message
            try:
                await ctx.message.delete()
            except:
                pass
            
            # Send success message using component v2
            arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
            section = "<:jo1ntrx_right:1405095312456024127>"
            tick = "<:Jo1nTrX_Yes:1408288995477159987>"
            
            content = f"""## {tick} Bot Messages Cleared

{section} **__Details__**
{arrow} **Cleared:** {actual_deleted} bot messages
{arrow} **Channel:** {ctx.channel.mention}
{arrow} **Cleared By:** {ctx.author.mention}"""
            
            success_view = ui.LayoutView(timeout=None)
            success_view.add_item(ui.Container(ui.TextDisplay(content)))
            success_msg = await ctx.send(view=success_view)
            await asyncio.sleep(3)
            try:
                await success_msg.delete()
            except:
                pass
            
        except discord.errors.Forbidden:
            await ctx.send("I don't have permission to delete messages in this channel.", delete_after=5)
        except Exception as e:
            await ctx.send(f"Error clearing bot messages: {str(e)}", delete_after=5)

    @commands.command(name='clear', aliases=['c'])
    @commands.has_permissions(manage_messages=True)
    async def clear_messages(self, ctx, amount: int = 10):
        """Clear specified number of messages from the current channel (excluding command message)"""
        try:
            # Limit amount to prevent abuse
            if amount > 500:
                amount = 500
            elif amount < 1:
                amount = 1
            
            # Delete messages excluding the command message
            deleted_messages = []
            async for message in ctx.channel.history(limit=amount, before=ctx.message):
                deleted_messages.append(message)
            
            actual_deleted = len(deleted_messages)
            
            # Bulk delete if possible (messages less than 14 days old)
            if deleted_messages:
                try:
                    await ctx.channel.delete_messages(deleted_messages)
                except discord.HTTPException:
                    # If bulk delete fails, delete one by one
                    for message in deleted_messages:
                        try:
                            await message.delete()
                        except (discord.errors.NotFound, discord.errors.Forbidden):
                            pass
            
            # Delete the command message
            try:
                await ctx.message.delete()
            except:
                pass
            
            # Send success message using component v2
            arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
            section = "<:jo1ntrx_right:1405095312456024127>"
            tick = "<:Jo1nTrX_Yes:1408288995477159987>"
            
            content = f"""## {tick} Messages Cleared

{section} **__Details__**
{arrow} **Cleared:** {actual_deleted} messages
{arrow} **Channel:** {ctx.channel.mention}
{arrow} **Cleared By:** {ctx.author.mention}"""
            
            success_view = ui.LayoutView(timeout=None)
            success_view.add_item(ui.Container(ui.TextDisplay(content)))
            success_msg = await ctx.send(view=success_view)
            await asyncio.sleep(3)
            try:
                await success_msg.delete()
            except:
                pass
            
        except discord.errors.Forbidden:
            await ctx.send("I don't have permission to delete messages in this channel.", delete_after=5)
        except Exception as e:
            await ctx.send(f"Error clearing messages: {str(e)}", delete_after=5)

    @commands.command(name='afk')
    async def afk(self, ctx, *, reason: str = "No reason provided"):
        """Set your AFK status with interactive options"""
        print(f"🔍 AFK command called by {ctx.author.id} in guild {ctx.guild.id}")
        try:
            arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
            section = "<:jo1ntrx_right:1405095312456024127>"
            
            content = f"""## <a:jo1ntrx_loading:1405094057499295806> AFK Setup

{section} **__Reason:__** {reason}

{section} **__Configure your AFK settings:__**

{arrow} **DM Mentions:** Toggle whether to receive DMs when mentioned
{arrow} **Scope:** Choose server-wide or global AFK status

> Select your preferences below to confirm your AFK status."""
            
            view = AFKLayoutView(ctx, reason)
            view.add_item(ui.Container(ui.TextDisplay(content), view.dm_select_row, view.scope_select_row))
            
            loading_msg = await ctx.send(view=view)
            print(f"✅ AFK command completed successfully")
        except Exception as e:
            print(f"❌ Error in AFK command: {e}")
            import traceback
            traceback.print_exc()
            try:
                await ctx.send(f"❌ Error setting up AFK: {str(e)}", delete_after=10)
            except:
                pass

    @commands.hybrid_command(name='timediff')
    @app_commands.describe(
        message_id_1='First message ID',
        message_id_2='Second message ID'
    )
    async def time_diff(self, ctx, message_id_1: str, message_id_2: str):
        """Calculate time difference between two Discord messages"""
        loading_msg = await send_loading_message(ctx, "calculating time difference between messages")
        
        try:
            # Convert string IDs to integers
            try:
                id1 = int(message_id_1)
                id2 = int(message_id_2)
            except ValueError:
                await loading_msg.edit(embed=create_error_embed("Invalid message IDs provided. Please provide valid Discord message IDs."))
                return
            
            # Extract timestamps from Discord snowflake IDs
            # Discord epoch is January 1, 2015
            discord_epoch = 1420070400000  # Discord epoch in milliseconds
            
            def snowflake_to_timestamp(snowflake_id):
                """Convert Discord snowflake ID to timestamp"""
                timestamp_ms = ((snowflake_id >> 22) + discord_epoch)
                return datetime.fromtimestamp(timestamp_ms / 1000, tz=timezone.utc)
            
            # Get timestamps from message IDs
            timestamp1 = snowflake_to_timestamp(id1)
            timestamp2 = snowflake_to_timestamp(id2)
            
            # Calculate the difference
            time_diff = abs((timestamp2 - timestamp1).total_seconds())
            
            # Format the time difference
            def format_time_diff(seconds):
                if seconds < 1:
                    return "Less than 1 second"
                
                days = int(seconds // 86400)
                hours = int((seconds % 86400) // 3600)
                minutes = int((seconds % 3600) // 60)
                secs = int(seconds % 60)
                
                parts = []
                if days > 0:
                    parts.append(f"{days} day{'s' if days != 1 else ''}")
                if hours > 0:
                    parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
                if minutes > 0:
                    parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
                if secs > 0:
                    parts.append(f"{secs} second{'s' if secs != 1 else ''}")
                
                return ", ".join(parts)
            
            # Determine which message is older
            if timestamp1 < timestamp2:
                older_id, newer_id = id1, id2
                older_time, newer_time = timestamp1, timestamp2
            else:
                older_id, newer_id = id2, id1
                older_time, newer_time = timestamp2, timestamp1
            
            embed = EmbedFactory.create(
                title="⏱️ Message Time Difference",
                color=self.bot.config.embed_color
            )
            
            embed.add_field(
                name="Message Details",
                value=f"**Older Message:** `{older_id}`\n"
                      f"**Sent:** {format_custom_datetime(older_time)}\n\n"
                      f"**Newer Message:** `{newer_id}`\n"
                      f"**Sent:** {format_custom_datetime(newer_time)}",
                inline=False
            )
            
            embed.add_field(
                name="Time Difference",
                value=f"**{format_time_diff(time_diff)}**",
                inline=False
            )
            
            # Add note about message location
            embed.set_footer(text="Note: This calculates difference using Discord message IDs, regardless of server or DM location.")
            
            await loading_msg.edit(embed=embed)
            
        except Exception as e:
            await loading_msg.edit(embed=create_error_embed(f"Error calculating time difference: {str(e)}"))

    @commands.hybrid_command(name='boostcount', aliases=['bc'])
    async def boost_count(self, ctx):
        """Display server boost count and tier"""
        loading_msg = await send_loading_message(ctx, "Fetching boost information...")
        
        guild = ctx.guild
        boost_count = guild.premium_subscription_count or 0
        boost_tier = guild.premium_tier
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        ist_timezone = timezone(timedelta(hours=5, minutes=30))
        current_time = datetime.now(ist_timezone).strftime('%I:%M %p')
        
        content = f"""## <:Jo1nTrX_boost:1411471227973009548> {guild.name} Boost Count

{section} **__Boost Statistics__**

{arrow} **Total Boosts:** {boost_count}
{arrow} **Boost Tier:** {boost_tier}
{arrow} **Server Name:** {guild.name}

> Jo1nTrX ™ — Utility Commands | Requested by {ctx.author.name} at {current_time}"""
        
        view = ui.LayoutView(timeout=300)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='listboosters', aliases=['lb'])
    async def list_boosters(self, ctx):
        """Display detailed list of server boosters"""
        loading_msg = await send_loading_message(ctx, "Gathering booster information...")
        
        guild = ctx.guild
        boost_count = guild.premium_subscription_count or 0
        boost_tier = guild.premium_tier
        
        # Get boosters sorted by boost time (earliest first)
        boosters = []
        if hasattr(guild, 'premium_subscribers'):
            boosters = guild.premium_subscribers
        else:
            # Fallback: get boosters from member list
            boosters = [member for member in guild.members if member.premium_since is not None]
        
        # Sort by premium_since date (earliest boosters first)
        boosters.sort(key=lambda member: member.premium_since or datetime.now(timezone.utc))
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        ist_timezone = timezone(timedelta(hours=5, minutes=30))
        current_time = datetime.now(ist_timezone).strftime('%I:%M %p')
        
        # List boosters with numbering and clickable mentions
        booster_list = []
        for i, member in enumerate(boosters[:20], 1):  # Limit to 20 to avoid message limit
            if member.premium_since:
                # Calculate days since boost
                days_boosting = (datetime.now(timezone.utc) - member.premium_since).days
                # Use numbering and mention format for clickable profile
                booster_list.append(f"{i}. {member.mention} — {days_boosting} days ago")
        
        if booster_list:
            booster_text = "\n".join(booster_list)
            if len(booster_list) < len(boosters):
                booster_text += f"\n... and {len(boosters) - 20} more boosters"
        else:
            booster_text = "No boosters found"
        
        description = f"""{section} **__{guild.name}__** <:Arziyaan_pinkwings:1411709655805329592>
**__Server Boosters__** ({len(boosters)})

{booster_text}

{section} **Boost Statistics** <:Jo1nTrX_server:1411471136746897549>

{arrow} **Total Boosts:** {boost_count}
{arrow} **Boost Tier:** {boost_tier}
{arrow} **Total Boosters:** {len(boosters)}"""
        
        embed = discord.Embed(
            title="<:Jo1nTrX_boost:1411471227973009548> Server Boosters <:Jo1nTrX_boost:1411471227973009548>",
            description=description,
            color=0x7c28eb
        )
        embed.set_footer(text=f"Jo1nTrX ™ — Utility Commands | Requested by {ctx.author.name} at {current_time}")
        
        await loading_msg.edit(embed=embed)

    @commands.command(name='steal', aliases=['s'])
    async def steal(self, ctx, *args):
        """Steal emojis, stickers, or images from messages or direct input"""
        loading_msg = await send_loading_message(ctx, "Processing steal request...")
        
        # Check if premium user or bot owner
        premium_status = await self.bot.db.check_premium_user(ctx.author.id, ctx.guild.id)
        is_premium = premium_status and premium_status.get('has_premium')
        is_bot_owner = ctx.author.id in self.bot.config.BOT_OWNER_IDS
        
        if is_bot_owner:
            max_limit = float('inf')  # Unlimited for bot owner
        else:
            max_limit = 20 if is_premium else 6
        
        # Collect items to steal (emojis, stickers, images)
        steal_items = []
        
        # Check if it's a reply to a message
        if ctx.message.reference:
            # Get the replied message
            replied_msg = await ctx.channel.fetch_message(ctx.message.reference.message_id)
            
            # Extract emojis from content
            emojis = self.extract_emojis_and_images_from_message(replied_msg.content)
            steal_items.extend(emojis)
            
            # Extract images from attachments (enhanced support)
            for attachment in replied_msg.attachments:
                # Get file extension
                filename_parts = attachment.filename.split('.')
                file_ext = filename_parts[-1].lower() if len(filename_parts) > 1 else ''
                base_name = '.'.join(filename_parts[:-1]) if len(filename_parts) > 1 else attachment.filename
                
                # Supported image/sticker formats
                image_extensions = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'tiff', 'svg']
                
                # Check if it's an image by content type or file extension
                is_image = (
                    (attachment.content_type and attachment.content_type.startswith('image/')) or
                    file_ext in image_extensions
                )
                
                if is_image:
                    # Determine if animated
                    is_animated = file_ext in ['gif', 'webp']  # WebP can be animated too
                    
                    steal_items.append({
                        'type': 'image',
                        'url': attachment.url,
                        'name': base_name,
                        'display': f"🖼️ {attachment.filename}",
                        'animated': is_animated,
                        'original_filename': attachment.filename,
                        'file_size': attachment.size
                    })
                
                # Also check for any other stealable file types
                elif file_ext in ['mp4', 'mov', 'avi'] and attachment.size < 8 * 1024 * 1024:  # 8MB limit for videos as emojis
                    steal_items.append({
                        'type': 'image',  # Discord allows video emojis now
                        'url': attachment.url,
                        'name': base_name,
                        'display': f"🎥 {attachment.filename}",
                        'animated': True,
                        'original_filename': attachment.filename,
                        'file_size': attachment.size
                    })
            
            # Extract stickers
            for sticker in replied_msg.stickers:
                steal_items.append({
                    'type': 'sticker',
                    'url': sticker.url,
                    'name': sticker.name
                })
            
            if not steal_items:
                embed = create_error_embed(
                    "No emojis, stickers, or images found in the replied message!",
                    title="Nothing to Steal"
                )
                return await loading_msg.edit(embed=embed)
        
        elif args:
            # Direct input - can be emojis or Discord CDN URLs
            for arg in args:
                extracted = self.extract_emojis_and_images_from_text(arg)
                steal_items.extend(extracted)
            
            if not steal_items:
                embed = create_error_embed(
                    "No valid emojis, stickers, or images found in your input!",
                    title="Nothing to Steal"
                )
                return await loading_msg.edit(embed=embed)
        
        else:
            embed = create_error_embed(
                "Please reply to a message with emojis/images or provide them directly!\n\n"
                "**Examples:**\n"
                f"`{ctx.prefix}steal` (reply to a message)\n"
                f"`{ctx.prefix}steal 😀 😂 🎉`\n"
                f"`{ctx.prefix}steal <:custom:123456789>`\n"
                f"`{ctx.prefix}steal https://cdn.discordapp.com/attachments/...`",
                title="Invalid Usage"
            )
            return await loading_msg.edit(embed=embed)
        
        # Check limits
        if len(steal_items) > max_limit:
            if not is_premium:
                embed = create_error_embed(
                    f"You can only steal up to **{max_limit}** items at once!\n\n"
                    f"Premium users can steal up to **20** items.\n"
                    f"Get premium access by joining our support server!",
                    title="Limit Exceeded"
                )
                return await loading_msg.edit(embed=embed)
            else:
                # Truncate to premium limit
                steal_items = steal_items[:max_limit]
        
        # Show emoji/sticker choice menu
        view = StealChoiceView(ctx, steal_items, loading_msg)
        
        # Create description with item preview (enhanced)
        description_items = []
        for i, item in enumerate(steal_items[:10]):
            if item.get('type') == 'emoji':
                description_items.append(f"• {item['display']}")
            elif item.get('type') == 'image':
                # Enhanced display for images with file info
                display_name = item.get('display', f"🖼️ {item['name']}")
                file_info = ""
                if item.get('file_size'):
                    size_mb = item['file_size'] / (1024 * 1024)
                    if size_mb >= 1:
                        file_info = f" ({size_mb:.1f}MB)"
                    else:
                        size_kb = item['file_size'] / 1024
                        file_info = f" ({size_kb:.0f}KB)"
                
                animated_indicator = " [ANIMATED]" if item.get('animated') else ""
                description_items.append(f"• {display_name}{file_info}{animated_indicator}")
            elif item.get('type') == 'sticker':
                description_items.append(f"• 📋 {item['name']}")
            else:
                description_items.append(f"• {item}")
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        stolen_emoji = "<:stolen_emoji_blaze:1406641607926616076>"
        
        items_text = "\n".join([f"{arrow} {item}" for item in description_items])
        more_text = f"\n{arrow} ... and {len(steal_items) - 10} more" if len(steal_items) > 10 else ""
        
        content = f"""## {stolen_emoji} Choose Steal Type

{section} **__Found {len(steal_items)} item(s) to steal:__**

{items_text}{more_text}

> How would you like to steal them?"""
        
        steal_view = ui.LayoutView(timeout=300)
        text_display = ui.TextDisplay(content)
        
        emoji_btn = ui.Button(label="As Emoji", style=discord.ButtonStyle.primary)
        sticker_btn = ui.Button(label="As Sticker", style=discord.ButtonStyle.secondary)
        
        async def emoji_callback(interaction: discord.Interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("Only the command author can use this.", ephemeral=True)
            await interaction.response.defer()
            await view.process_steal(interaction, 'emoji')
        
        async def sticker_callback(interaction: discord.Interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("Only the command author can use this.", ephemeral=True)
            await interaction.response.defer()
            await view.process_steal(interaction, 'sticker')
        
        emoji_btn.callback = emoji_callback
        sticker_btn.callback = sticker_callback
        
        button_row = ui.ActionRow(emoji_btn, sticker_btn)
        container = ui.Container(text_display, button_row)
        steal_view.add_item(container)
        
        # Delete loading message and send new one with Components V2
        # (Can't edit embed message to use Components V2)
        await loading_msg.delete()
        await ctx.send(view=steal_view)
    
    def extract_emojis_and_images_from_message(self, content):
        """Extract emojis and Discord CDN URLs from message content"""
        import re
        
        items = []
        
        # Find custom emojis <:name:id> or <a:name:id>
        custom_pattern = r'<(a?):([a-zA-Z0-9_]+):(\d+)>'
        custom_matches = re.findall(custom_pattern, content)
        for animated, name, emoji_id in custom_matches:
            ext = 'gif' if animated else 'png'
            items.append({
                'type': 'emoji',
                'name': name,
                'url': f"https://cdn.discordapp.com/emojis/{emoji_id}.{ext}",
                'display': f"<{animated}:{name}:{emoji_id}>",
                'animated': bool(animated)
            })
        
        # Find Discord CDN URLs (improved to handle query parameters and stickers)
        discord_cdn_pattern = r'https://cdn\.discordapp\.com/(?:attachments|emojis|stickers)/[^\s]+?\.(png|jpg|jpeg|gif|webp|json)(?:\?[^\s]*)?'
        for i, match in enumerate(re.finditer(discord_cdn_pattern, content)):
            url = match.group(0)
            # Extract file extension from the URL before query parameters
            url_without_params = url.split('?')[0]
            ext = url_without_params.split('.')[-1].lower()
            # Extract name from URL or use generic name
            url_parts = url_without_params.split('/')
            filename = url_parts[-1].split('.')[0] if len(url_parts) > 0 else f"image_{i+1}"
            
            # Check if this is an emoji, sticker, or regular image URL
            if '/emojis/' in url:
                # This is an emoji URL - treat as emoji and detect if animated
                items.append({
                    'type': 'emoji',
                    'name': filename,
                    'url': url,
                    'display': f"<:emoji:{filename}>",
                    'animated': ext == 'gif'  # gif = animated, png = static
                })
            elif '/stickers/' in url:
                # This is a sticker URL - treat as sticker
                items.append({
                    'type': 'sticker',
                    'name': filename,
                    'url': url,
                    'display': f"📋 {filename}",
                    'animated': ext in ['gif', 'json']  # json = Lottie animated, gif = animated
                })
            else:
                # Regular image/attachment
                items.append({
                    'type': 'image',
                    'name': filename,
                    'url': url,
                    'display': f"🖼️ {filename}",
                    'animated': ext == 'gif'  # For consistency, mark gifs as animated
                })
        
        # Find unicode emojis
        unicode_pattern = r'[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF\U00002702-\U000027B0\U000024C2-\U0001F251]+'
        unicode_matches = re.findall(unicode_pattern, content)
        for emoji in unicode_matches:
            items.append({
                'type': 'unicode_emoji',
                'name': f"unicode_emoji",
                'display': emoji
            })
        
        return items
    
    def extract_emojis_and_images_from_text(self, text):
        """Extract emojis and Discord CDN URLs from text input"""
        import re
        
        items = []
        
        # Find ALL custom emojis in text (not just the first one)
        custom_pattern = r'<(a?):([a-zA-Z0-9_]+):(\d+)>'
        custom_matches = re.findall(custom_pattern, text)
        for animated, name, emoji_id in custom_matches:
            ext = 'gif' if animated else 'png'
            items.append({
                'type': 'emoji',
                'name': name,
                'url': f"https://cdn.discordapp.com/emojis/{emoji_id}.{ext}",
                'display': f"<{animated}:{name}:{emoji_id}>",
                'animated': bool(animated)
            })
        
        # Find Discord CDN URLs (improved to handle query parameters and stickers)
        discord_cdn_pattern = r'https://cdn\.discordapp\.com/(?:attachments|emojis|stickers)/[^\s]+?\.(png|jpg|jpeg|gif|webp|json)(?:\?[^\s]*)?'
        for i, match in enumerate(re.finditer(discord_cdn_pattern, text)):
            url = match.group(0)
            # Extract file extension from the URL before query parameters
            url_without_params = url.split('?')[0]
            ext = url_without_params.split('.')[-1].lower()
            # Extract filename from URL
            url_parts = url_without_params.split('/')
            filename = url_parts[-1] if len(url_parts) > 0 else f"item_{i+1}.{ext}"
            name = filename.split('.')[0]  # Remove extension
            
            # Check if this is an emoji, sticker, or regular image URL
            if '/emojis/' in url:
                # This is an emoji URL - treat as emoji and detect if animated
                items.append({
                    'type': 'emoji',
                    'name': name,
                    'url': url,
                    'display': f"<:emoji:{name}>",
                    'animated': ext == 'gif'  # gif = animated, png = static
                })
            elif '/stickers/' in url:
                # This is a sticker URL - treat as sticker
                items.append({
                    'type': 'sticker',
                    'name': name,
                    'url': url,
                    'display': f"📋 {name}",
                    'animated': ext in ['gif', 'json']  # json = Lottie animated, gif = animated
                })
            else:
                # Regular image/attachment
                items.append({
                    'type': 'image',
                    'name': name,
                    'url': url,
                    'display': f"🖼️ {name}",
                    'animated': ext == 'gif'  # For consistency, mark gifs as animated
                })
        
        # Find unicode emojis
        unicode_pattern = r'[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF\U00002702-\U000027B0\U000024C2-\U0001F251]+'
        unicode_matches = re.findall(unicode_pattern, text)
        for emoji in unicode_matches:
            items.append({
                'type': 'unicode_emoji',
                'name': f"unicode_emoji",
                'display': emoji
            })
        
        return items

    def parse_time(self, time_string):
        """Parse time string and return total seconds"""
        # Time units mapping
        units = {
            's': 1, 'sec': 1, 'second': 1, 'seconds': 1,
            'm': 60, 'min': 60, 'minute': 60, 'minutes': 60,
            'h': 3600, 'hr': 3600, 'hour': 3600, 'hours': 3600,
            'd': 86400, 'day': 86400, 'days': 86400,
            'w': 604800, 'week': 604800, 'weeks': 604800,
            'mo': 2629746, 'month': 2629746, 'months': 2629746,
            'y': 31556952, 'year': 31556952, 'years': 31556952
        }
        
        # Pattern to match number followed by unit
        pattern = r'(\d+(?:\.\d+)?)\s*([a-zA-Z]+)'
        matches = re.findall(pattern, time_string.lower())
        
        if not matches:
            return None
        
        total_seconds = 0
        for value, unit in matches:
            if unit in units:
                total_seconds += float(value) * units[unit]
            else:
                return None
        
        # Maximum 1 year limit
        if total_seconds > 31556952:
            return None
            
        return int(total_seconds)

    def format_time_remaining(self, seconds):
        """Format seconds into human readable time"""
        if seconds <= 0:
            return "Timer ended!"
        
        years = seconds // 31556952
        seconds %= 31556952
        months = seconds // 2629746
        seconds %= 2629746
        days = seconds // 86400
        seconds %= 86400
        hours = seconds // 3600
        seconds %= 3600
        minutes = seconds // 60
        seconds %= 60
        
        parts = []
        if years > 0:
            parts.append(f"{int(years)}y")
        if months > 0:
            parts.append(f"{int(months)}mo")
        if days > 0:
            parts.append(f"{int(days)}d")
        if hours > 0:
            parts.append(f"{int(hours)}h")
        if minutes > 0:
            parts.append(f"{int(minutes)}m")
        if seconds > 0:
            parts.append(f"{int(seconds)}s")
        
        return " ".join(parts[:3])  # Show max 3 units

    @commands.hybrid_command(name='timer')
    @app_commands.describe(
        time="Time duration (e.g., '5m', '1h 30m', '2d 5h 30m')",
        reason="Optional reason for the timer"
    )
    @commands.has_guild_permissions(manage_guild=True)
    async def timer_command(self, ctx, time: str, *, reason: Optional[str] = None):
        """Create a countdown timer with optional reason"""
        loading_msg = await send_loading_message(ctx, "Setting up your timer...")
        
        # Parse the time string
        total_seconds = self.parse_time(time)
        print(f"DEBUG TIMER: Input '{time}' parsed to {total_seconds} seconds")
        if total_seconds is None:
            embed = create_error_embed(
                "Invalid time format!\n\n"
                "**Valid formats:**\n"
                "• `5s` or `5 seconds`\n"
                "• `30m` or `30 minutes`\n"
                "• `2h` or `2 hours`\n"
                "• `1d` or `1 day`\n"
                "• `1mo` or `1 month`\n"
                "• `1y` or `1 year`\n\n"
                "**Examples:**\n"
                "• `timer 5m` - 5 minutes\n"
                "• `timer 1h 30m` - 1 hour 30 minutes\n"
                "• `timer 2d 5h 30m work break` - with reason",
                title="Invalid Time Format"
            )
            await loading_msg.edit(embed=embed)
            return
        
        if total_seconds < 1:
            embed = create_error_embed(
                "Timer duration must be at least 1 second!",
                title="Invalid Duration"
            )
            await loading_msg.edit(embed=embed)
            return
        
        # Calculate end time
        end_time = datetime.now(timezone.utc) + timedelta(seconds=total_seconds)
        
        # Create timer in database
        timer_id = await self.bot.db.create_timer(
            ctx.guild.id,
            ctx.author.id,
            ctx.channel.id,
            end_time,
            reason
        )
        
        # Create initial timer embed
        time_remaining = self.format_time_remaining(total_seconds)
        
        # Format end time in IST
        ist_timezone = timezone(timedelta(hours=5, minutes=30))
        end_time_ist = end_time.astimezone(ist_timezone)
        end_time_str = end_time_ist.strftime("%I:%M %p IST")
        
        # Create component v2 content
        TIMER = "<:Jo1nTrX_time:1419672663109927014>"
        SECTION = "<:jo1ntrx_right:1405095312456024127>"
        ARROW = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        
        content = f"""## {TIMER} Timer Active
> Time remaining: **{time_remaining}**

{SECTION} **__Timer Details__**
{ARROW} **Started by:** {ctx.author.mention}
{ARROW} **Ends at:** {end_time_str}"""
        
        # Send the timer message with component v2 layout
        timer_view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        timer_view.add_item(container)
        
        await loading_msg.edit(embed=None, view=timer_view)
        
        # Update message ID in database
        await self.bot.db.update_timer_message_id(timer_id, loading_msg.id)
        
        # Register timer with the new scheduler system
        timer_system = self.bot.get_cog('TimerSystem')
        if timer_system:
            timer_system.register_timer(
                timer_id=timer_id,
                guild_id=ctx.guild.id,
                user_id=ctx.author.id,
                channel_id=ctx.channel.id,
                message_id=loading_msg.id,
                end_time=end_time,
                reason=reason
            )
        
        # Schedule the delete after a delay (for cleanup)
        asyncio.create_task(self.delete_command_message(ctx, 3))

    @commands.hybrid_command(name='mytimers')
    @commands.has_guild_permissions(manage_guild=True)
    async def my_timers(self, ctx):
        """View your active timers"""
        loading_msg = await send_loading_message(ctx, "Fetching your timers...")
        
        timers = await self.bot.db.get_user_timers(ctx.guild.id, ctx.author.id)
        
        if not timers:
            embed = EmbedFactory.create(
                title="No Active Timers",
                description="You don't have any active timers in this server.\n\n"
                           "Use `+timer <time> [reason]` to create a new timer!",
                color=self.bot.config.embed_color
            )
            await loading_msg.edit(embed=embed)
            return
        
        embed = EmbedFactory.create(
            title=f"⏰ Your Active Timers ({len(timers)})",
            color=self.bot.config.embed_color
        )
        
        current_time = datetime.now(timezone.utc)
        for timer in timers[:10]:  # Show max 10 timers
            timer_id, channel_id, message_id, end_time, reason, created_at = timer
            
            # Calculate time remaining
            if isinstance(end_time, str):
                end_time = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
            
            time_remaining_seconds = (end_time - current_time).total_seconds()
            time_remaining = self.format_time_remaining(time_remaining_seconds)
            
            channel = self.bot.get_channel(channel_id)
            channel_mention = channel.mention if channel else f"<#{channel_id}>"
            
            reason_text = f" - {reason}" if reason else ""
            embed.add_field(
                name=f"Timer #{timer_id}",
                value=f"**Time:** {time_remaining}\n"
                      f"**Channel:** {channel_mention}\n"
                      f"**Ends:** <t:{int(end_time.timestamp())}:R>{reason_text}",
                inline=False
            )
        
        embed.set_footer(text=f"Requested by {ctx.author.display_name}", 
                        icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        await loading_msg.edit(embed=embed)
        
        # Schedule cleanup
        asyncio.create_task(self.delete_command_message(ctx, 3))

class StealChoiceView(BaseView):
    def __init__(self, ctx, steal_items, loading_msg):
        super().__init__(timeout=300.0)
        self.ctx = ctx
        self.steal_items = steal_items
        self.loading_msg = loading_msg
    
    @discord.ui.button(label='As Emoji', style=discord.ButtonStyle.primary)
    async def steal_as_emoji(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("Only the command author can use this.", ephemeral=True)
            return
        
        await interaction.response.defer()
        await self.process_steal(interaction, 'emoji')
    
    @discord.ui.button(label='As Sticker', style=discord.ButtonStyle.secondary)
    async def steal_as_sticker(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("Only the command author can use this.", ephemeral=True)
            return
        
        await interaction.response.defer()
        await self.process_steal(interaction, 'sticker')
    
    async def process_steal(self, interaction, steal_type):
        """Process the stealing operation"""
        import aiohttp
        import io
        
        guild = self.ctx.guild
        success_count = 0
        failed_count = 0
        errors = []
        
        # Check guild limits for emojis (separate animated and static)
        if steal_type == 'emoji':
            # Count current animated and static emojis
            current_animated = sum(1 for emoji in guild.emojis if emoji.animated)
            current_static = sum(1 for emoji in guild.emojis if not emoji.animated)
            max_emojis_per_type = guild.emoji_limit  # Each type (animated/static) gets the full limit
            
            # Count items to steal by type
            animated_to_steal = sum(1 for item in self.steal_items if item.get('animated', False))
            static_to_steal = sum(1 for item in self.steal_items if not item.get('animated', False))
            
            cross = "<:jo1ntrx_cross:1405094904568483880>"
            section = "<:jo1ntrx_right:1405095312456024127>"
            arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
            
            # Check animated emoji slots
            if animated_to_steal > 0:
                available_animated_slots = max_emojis_per_type - current_animated
                
                if available_animated_slots <= 0:
                    error_content = f"""## {cross} Animated Emoji Limit Reached

{section} **__Error__**
{arrow} This server has reached its animated emoji limit! ({current_animated}/{max_emojis_per_type})
{arrow} Please delete some animated emojis before stealing new ones."""
                    error_view = ui.LayoutView(timeout=None)
                    error_view.add_item(ui.Container(ui.TextDisplay(error_content)))
                    return await interaction.edit_original_response(embed=None, view=error_view)
                
                if animated_to_steal > available_animated_slots:
                    error_content = f"""## {cross} Not Enough Animated Emoji Space

{section} **__Error__**
{arrow} Can only add {available_animated_slots} more animated emoji(s)!
{arrow} Trying to steal: {animated_to_steal} animated emojis
{arrow} Current animated: {current_animated}/{max_emojis_per_type}"""
                    error_view = ui.LayoutView(timeout=None)
                    error_view.add_item(ui.Container(ui.TextDisplay(error_content)))
                    return await interaction.edit_original_response(embed=None, view=error_view)
            
            # Check static emoji slots
            if static_to_steal > 0:
                available_static_slots = max_emojis_per_type - current_static
                
                if available_static_slots <= 0:
                    error_content = f"""## {cross} Static Emoji Limit Reached

{section} **__Error__**
{arrow} This server has reached its static emoji limit! ({current_static}/{max_emojis_per_type})
{arrow} Please delete some static emojis before stealing new ones."""
                    error_view = ui.LayoutView(timeout=None)
                    error_view.add_item(ui.Container(ui.TextDisplay(error_content)))
                    return await interaction.edit_original_response(embed=None, view=error_view)
                
                if static_to_steal > available_static_slots:
                    error_content = f"""## {cross} Not Enough Static Emoji Space

{section} **__Error__**
{arrow} Can only add {available_static_slots} more static emoji(s)!
{arrow} Trying to steal: {static_to_steal} static emojis
{arrow} Current static: {current_static}/{max_emojis_per_type}"""
                    error_view = ui.LayoutView(timeout=None)
                    error_view.add_item(ui.Container(ui.TextDisplay(error_content)))
                    return await interaction.edit_original_response(embed=None, view=error_view)
        
        # Check guild limits for stickers
        elif steal_type == 'sticker':
            current_stickers = len(guild.stickers)
            max_stickers = guild.sticker_limit
            available_slots = max_stickers - current_stickers
            
            cross = "<:jo1ntrx_cross:1405094904568483880>"
            section = "<:jo1ntrx_right:1405095312456024127>"
            arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
            
            if available_slots <= 0:
                error_content = f"""## {cross} Sticker Limit Reached

{section} **__Error__**
{arrow} This server has reached its sticker limit! ({current_stickers}/{max_stickers})
{arrow} Please delete some stickers before stealing new ones."""
                error_view = ui.LayoutView(timeout=None)
                error_view.add_item(ui.Container(ui.TextDisplay(error_content)))
                return await interaction.edit_original_response(embed=None, view=error_view)
            
            if len(self.steal_items) > available_slots:
                error_content = f"""## {cross} Not Enough Space

{section} **__Error__**
{arrow} Can only add {available_slots} more sticker(s) to this server!
{arrow} Current: {current_stickers}/{max_stickers}"""
                error_view = ui.LayoutView(timeout=None)
                error_view.add_item(ui.Container(ui.TextDisplay(error_content)))
                return await interaction.edit_original_response(embed=None, view=error_view)
        
        # Process each item
        stolen_emoji = "<:stolen_emoji_blaze:1406641607926616076>"
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        tick = "<:Jo1nTrX_tick:1405094884947267715>"
        cross = "<:jo1ntrx_cross:1405094904568483880>"
        
        for i, item in enumerate(self.steal_items):
            try:
                # Update progress using Components V2
                progress_content = f"""## {stolen_emoji} Stealing {steal_type.capitalize()}s...

{section} **__Progress__**
{arrow} Processing {i+1}/{len(self.steal_items)}...
{arrow} Success: {success_count} | Failed: {failed_count}"""
                progress_view = ui.LayoutView(timeout=None)
                progress_view.add_item(ui.Container(ui.TextDisplay(progress_content)))
                await interaction.edit_original_response(embed=None, view=progress_view)
                
                # Handle different item types
                if isinstance(item, dict) and 'url' in item:
                    # Item with URL (emoji, image, sticker)
                    base_name = item['name']
                    # Use original filename for attachments if available, otherwise add suffix
                    if item.get('original_filename'):
                        name = base_name + "_Jo1nTrX"
                    else:
                        name = base_name + "_Jo1nTrX"  # Add suffix
                    url = item['url']
                    
                    async with aiohttp.ClientSession() as session:
                        # Add headers to mimic a browser request
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                        }
                        print(f"[DEBUG] Attempting to download: {url}")
                        async with session.get(url, headers=headers) as resp:
                            print(f"[DEBUG] Response status: {resp.status} for URL: {url}")
                            if resp.status == 200:
                                image_data = await resp.read()
                                
                                # Check file size limits
                                file_size = len(image_data)
                                max_emoji_size = 256 * 1024  # 256KB for emojis
                                max_sticker_size = 500 * 1024  # 500KB for stickers
                                
                                if steal_type == 'emoji':
                                    if file_size > max_emoji_size:
                                        size_mb = file_size / (1024 * 1024)
                                        errors.append(f"{item['name']}: File too large ({size_mb:.1f}MB, max 256KB for emojis)")
                                        failed_count += 1
                                        continue
                                    
                                    # Add as emoji
                                    try:
                                        # Determine file extension for proper filename
                                        original_filename = item.get('original_filename', f"{name}.png")
                                        file_ext = original_filename.split('.')[-1] if '.' in original_filename else 'png'
                                        
                                        new_emoji = await guild.create_custom_emoji(
                                            name=name[:32],  # Discord limit is 32 chars
                                            image=image_data,
                                            reason=f"Stolen by {self.ctx.author}"
                                        )
                                        success_count += 1
                                    except discord.HTTPException as e:
                                        if "Invalid image" in str(e):
                                            errors.append(f"{item['name']}: Invalid image format")
                                        elif "File cannot be larger than" in str(e):
                                            errors.append(f"{item['name']}: File too large")
                                        else:
                                            errors.append(f"{item['name']}: {str(e)}")
                                        failed_count += 1
                                else:
                                    if file_size > max_sticker_size:
                                        size_mb = file_size / (1024 * 1024)
                                        errors.append(f"{item['name']}: File too large ({size_mb:.1f}MB, max 500KB for stickers)")
                                        failed_count += 1
                                        continue
                                    
                                    # Add as sticker
                                    try:
                                        # Determine proper filename and extension
                                        original_filename = item.get('original_filename', f"{name}.png")
                                        file_ext = original_filename.split('.')[-1] if '.' in original_filename else 'png'
                                        
                                        new_sticker = await guild.create_sticker(
                                            name=name[:30],  # Discord limit is 30 chars for stickers
                                            description=f"Stolen by {self.ctx.author.display_name}",
                                            emoji="😀",  # Required field
                                            file=discord.File(io.BytesIO(image_data), filename=f"{name}.{file_ext}"),
                                            reason=f"Stolen by {self.ctx.author}"
                                        )
                                        success_count += 1
                                    except discord.HTTPException as e:
                                        if "Lottie stickers are not supported" in str(e):
                                            errors.append(f"{item['name']}: Lottie stickers not supported")
                                        elif "Invalid image" in str(e):
                                            errors.append(f"{item['name']}: Invalid image format")
                                        elif "File cannot be larger than" in str(e):
                                            errors.append(f"{item['name']}: File too large")
                                        else:
                                            errors.append(f"{item['name']}: {str(e)}")
                                        failed_count += 1
                            else:
                                # Provide more detailed error information with debug info
                                print(f"[DEBUG] Failed download - Status: {resp.status}, URL: {url}")
                                if resp.status == 404:
                                    errors.append(f"{item['name']}: URL expired or not found (HTTP 404)")
                                elif resp.status == 403:
                                    errors.append(f"{item['name']}: Access denied (HTTP 403)")
                                elif resp.status == 429:
                                    errors.append(f"{item['name']}: Rate limited (HTTP 429)")
                                else:
                                    errors.append(f"{item['name']}: Failed to download (HTTP {resp.status})")
                                failed_count += 1
                
                elif isinstance(item, dict) and item.get('type') == 'unicode_emoji':
                    # Unicode emoji - cannot be added to server
                    errors.append(f"{item['display']}: Cannot add unicode emoji to server")
                    failed_count += 1
                
                else:
                    # Legacy string format
                    errors.append(f"{item}: Unsupported format")
                    failed_count += 1
                        
            except discord.HTTPException as e:
                failed_count += 1
                if "Maximum number of emojis reached" in str(e):
                    errors.append("Server emoji limit reached")
                    break
                elif "Maximum number of stickers reached" in str(e):
                    errors.append("Server sticker limit reached")
                    break
                else:
                    errors.append(f"Discord error: {str(e)}")
            except Exception as e:
                failed_count += 1
                errors.append(f"Unexpected error: {str(e)}")
        
        # Show final results using component v2
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        tick = "<:Jo1nTrX_tick:1405094884947267715>"
        cross = "<:jo1ntrx_cross:1405094904568483880>"
        stolen_emoji = "<:stolen_emoji_blaze:1406641607926616076>"
        
        if success_count > 0:
            failed_text = f"\n{arrow} **Failed:** {failed_count}" if failed_count > 0 else ""
            content = f"""## {tick} Steal Complete

{section} **__Results__**
{arrow} {stolen_emoji} Successfully stole **{success_count}** {steal_type}(s)!{failed_text}"""
        else:
            error_list = "\n".join([f"{arrow} {err}" for err in errors[:5]])
            more_errors = f"\n{arrow} ... and {len(errors) - 5} more errors" if len(errors) > 5 else ""
            content = f"""## {cross} Steal Failed

{section} **__Errors__**
{error_list}{more_errors}"""
        
        result_view = ui.LayoutView(timeout=None)
        result_view.add_item(ui.Container(ui.TextDisplay(content)))
        await interaction.edit_original_response(embed=None, view=result_view)

class AFKLayoutView(ui.LayoutView):
    """Components v2 AFK Setup View"""
    def __init__(self, ctx, reason):
        super().__init__(timeout=300)
        self.ctx = ctx
        self.reason = reason
        self.dm_mentions = False
        self.scope = None
        self._setup_view()
    
    def _setup_view(self):
        dm_select = ui.Select(
            placeholder='Choose DM notification preference...',
            min_values=1,
            max_values=1,
            options=[
                discord.SelectOption(label='Yes', description='Receive DMs when mentioned while AFK', value='yes'),
                discord.SelectOption(label='No', description='Do not receive DMs when mentioned', value='no')
            ]
        )
        
        scope_select = ui.Select(
            placeholder='Choose AFK scope...',
            min_values=1,
            max_values=1,
            options=[
                discord.SelectOption(label='Server-wide', description='AFK status only in this server', value='server'),
                discord.SelectOption(label='Global', description='AFK status across all servers', value='global')
            ]
        )
        
        async def dm_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message("Only the command author can use this.", ephemeral=True)
            self.dm_mentions = dm_select.values[0] == 'yes'
            await self._update_view(interaction)
        
        async def scope_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message("Only the command author can use this.", ephemeral=True)
            self.scope = scope_select.values[0]
            await self._finalize_afk(interaction)
        
        dm_select.callback = dm_callback
        scope_select.callback = scope_callback
        
        self.dm_select_row = ui.ActionRow(dm_select)
        self.scope_select_row = ui.ActionRow(scope_select)
    
    async def _update_view(self, interaction: discord.Interaction):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <a:jo1ntrx_loading:1405094057499295806> AFK Setup

{section} **__Reason:__** {self.reason}

{section} **__Configure your AFK settings:__**

{arrow} **DM Mentions:** {'Yes' if self.dm_mentions else 'No'}
{arrow} **Scope:** Choose server-wide or global AFK status

> Select a scope to confirm your AFK status."""
        
        new_view = ui.LayoutView(timeout=300)
        new_view.add_item(ui.Container(ui.TextDisplay(content), self.dm_select_row, self.scope_select_row))
        await interaction.response.edit_message(view=new_view)
    
    async def _finalize_afk(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        await self.ctx.bot.db.set_afk(
            self.ctx.author.id,
            self.reason,
            self.dm_mentions,
            self.scope,
            self.ctx.guild.id if self.scope == 'server' else None
        )
        
        permission_error = False
        try:
            member = self.ctx.guild.get_member(self.ctx.author.id)
            if member:
                current_nick = member.display_name
                if not current_nick.startswith('[AFK]'):
                    new_nick = f"[AFK] {current_nick}"
                    if len(new_nick) > 32:
                        new_nick = f"[AFK] {current_nick[:26]}"
                    try:
                        await member.edit(nick=new_nick)
                        print(f"✅ Added [AFK] to {member.display_name}'s nickname")
                    except discord.Forbidden:
                        permission_error = True
                        print(f"⚠️  No permission to change nickname for {member.display_name}")
                    except Exception as e:
                        print(f"❌ Error changing nickname: {e}")
        except Exception as e:
            print(f"❌ Error in nickname change process: {e}")
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        tick = "<:Jo1nTrX_tick:1405094884947267715>"
        
        content = f"""## {tick} AFK Status Set

{section} **__You are now AFK!__**

{arrow} **Reason:** {self.reason}
{arrow} **DM Mentions:** {'Yes' if self.dm_mentions else 'No'}
{arrow} **Scope:** {self.scope.capitalize() if self.scope else 'Unknown'}

> Send any message to remove your AFK status."""
        
        if permission_error:
            content += "\n\n⚠️ *Note: I couldn't add [AFK] to your nickname due to missing permissions.*"
        
        success_view = ui.LayoutView(timeout=None)
        success_view.add_item(ui.Container(ui.TextDisplay(content)))
        await interaction.edit_original_response(view=success_view)


async def setup(bot):
    await bot.add_cog(UtilityCommands(bot))