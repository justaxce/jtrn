import discord
import asyncio
from discord.ext import commands
from discord import app_commands, ui
from Jo1nTrX.utils.helpers import send_loading_message
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    PaginationView, bot_emoji
)
from .admin_helper import (
    ARROW_EMOJI, SECTION_EMOJI, SUCCESS_EMOJI, ERROR_EMOJI, ADMIN_ICON,
    create_v2_view, create_success_content, create_error_content
)


class TestMessageView(BaseView):
    def __init__(self, bot, guild_id, author):
        super().__init__(timeout=60, author=author)
        self.bot = bot
        self.guild_id = guild_id
        self.author = author
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message(
                "You cannot interact with this menu.", 
                ephemeral=True
            )
            return False
        return True
    
    @discord.ui.select(
        placeholder="Choose message type to test...",
        options=[
            discord.SelectOption(
                label="Join Messages",
                description="Test your join messages",
                value="join"
            ),
            discord.SelectOption(
                label="Leave Messages", 
                description="Test your leave messages",
                value="leave"
            ),
            discord.SelectOption(
                label="Boost Messages",
                description="Test your boost messages",
                value="boost"
            )
        ]
    )
    async def select_message_type(self, interaction: discord.Interaction, select: discord.ui.Select):
        await interaction.response.defer()
        
        message_type = select.values[0]
        
        try:
            if message_type == "boost":
                await self.test_boost_message(interaction)
                return
            
            join_channels = await self.bot.db.get_join_channels(self.guild_id, message_type)
            
            if not join_channels:
                error_content = create_error_content("No Channels Configured", f"No {message_type} channels configured for this server.\nUse `+setjoinmessage` or `+setleavemessage` to configure channels first.")
                error_view = create_v2_view(error_content)
                await interaction.followup.send(view=error_view, ephemeral=True)
                return
            
            class FakeInvite:
                def __init__(self):
                    self.code = "testcode"
                    self.uses = 1
                    self.inviter = interaction.user
            
            fake_invite = FakeInvite()
            
            for channel_data in join_channels:
                channel_id = channel_data['channel_id']
                custom_message = channel_data.get('custom_message')
                embed_name = channel_data.get('embed_name')
                
                channel = self.bot.get_channel(channel_id)
                if not channel:
                    continue
                
                if embed_name:
                    try:
                        from Jo1nTrX.cogs.extra.embeds import create_embed_from_database_data
                        message_content, test_embed = await create_embed_from_database_data(
                            self.bot, interaction.guild.id, embed_name, interaction.user, fake_invite
                        )
                        
                        if test_embed:
                            confirm_content = create_success_content(f"Test {message_type.title()} Embed Sent", f"Test embed '{embed_name}' has been sent to {channel.mention}")
                            confirm_view = create_v2_view(confirm_content)
                            await interaction.followup.send(view=confirm_view)
                            
                            try:
                                if message_content:
                                    sent_message = await channel.send(content=f"🧪 **Test Message Preview**\n{message_content}", embed=test_embed)
                                else:
                                    sent_message = await channel.send(content="🧪 **Test Message Preview**", embed=test_embed)
                                
                                delete_time = await self.bot.db.get_join_message_delete_timer(interaction.guild.id, channel.id)
                                if delete_time:
                                    await self.bot.schedule_message_deletion(sent_message, delete_time)
                            except discord.Forbidden:
                                error_content = create_error_content("Permission Error", f"I don't have permission to send messages in {channel.mention}")
                                error_view = create_v2_view(error_content)
                                await interaction.followup.send(view=error_view)
                        else:
                            error_content = create_error_content(f"Test {message_type.title()} Message - {channel.name}", f"**Channel:** {channel.mention}\n**Error:** Could not load embed '{embed_name}'")
                            error_view = create_v2_view(error_content)
                            await interaction.followup.send(view=error_view)
                    except Exception as e:
                        error_content = create_error_content(f"Test {message_type.title()} Message - {channel.name}", f"**Channel:** {channel.mention}\n**Error:** Failed to test embed: {str(e)}")
                        error_view = create_v2_view(error_content)
                        await interaction.followup.send(view=error_view)
                        
                elif custom_message:
                    try:
                        processed_message = await self.bot.replace_variables(custom_message, interaction.user, fake_invite)
                        
                        confirm_content = create_success_content(f"Test {message_type.title()} Message Sent", f"Test message has been sent to {channel.mention}")
                        confirm_view = create_v2_view(confirm_content)
                        await interaction.followup.send(view=confirm_view)
                        
                        try:
                            sent_message = await channel.send(f"🧪 **Test Message Preview**\n{processed_message}")
                            
                            delete_time = await self.bot.db.get_join_message_delete_timer(interaction.guild.id, channel.id)
                            if delete_time:
                                await self.bot.schedule_message_deletion(sent_message, delete_time)
                        except discord.Forbidden:
                            error_content = create_error_content("Permission Error", f"I don't have permission to send messages in {channel.mention}")
                            error_view = create_v2_view(error_content)
                            await interaction.followup.send(view=error_view)
                    except Exception as e:
                        error_content = create_error_content(f"Test {message_type.title()} Message - {channel.name}", f"**Channel:** {channel.mention}\n**Error:** Failed to process variables: {str(e)}")
                        error_view = create_v2_view(error_content)
                        await interaction.followup.send(view=error_view)
                else:
                    warning_content = f"""## {ERROR_EMOJI} Test {message_type.title()} Message - {channel.name}
> **Channel:** {channel.mention}
> **Status:** No custom message or embed configured"""
                    warning_view = create_v2_view(warning_content)
                    await interaction.followup.send(view=warning_view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error testing message: {str(e)}"))
            await interaction.followup.send(view=error_view)
    
    async def test_boost_message(self, interaction):
        try:
            boost_channel_id = await self.bot.db.get_boost_channel(self.guild_id)
            boost_message = await self.bot.db.get_boost_message(self.guild_id)
            boost_embed_name = await self.bot.db.get_boost_embed(self.guild_id)
            boost_emoji = await self.bot.db.get_boost_emoji(self.guild_id)
            
            if not boost_channel_id and not boost_message and not boost_embed_name:
                error_content = create_error_content("No Boost Configuration", "No boost message configuration found for this server.\nUse `+setboostmessage` to configure boost messages first.")
                error_view = create_v2_view(error_content)
                await interaction.followup.send(view=error_view, ephemeral=True)
                return
            
            test_channel = None
            if boost_channel_id:
                test_channel = self.bot.get_channel(boost_channel_id)
            
            if not test_channel:
                test_channel = interaction.guild.system_channel
                if not test_channel:
                    test_channel = next((c for c in interaction.guild.text_channels if c.permissions_for(interaction.guild.me).send_messages), None)
            
            if not test_channel:
                error_content = create_error_content("Channel Error", "Could not find a suitable channel to send the test boost message.")
                error_view = create_v2_view(error_content)
                await interaction.followup.send(view=error_view, ephemeral=True)
                return
            
            class FakeInvite:
                def __init__(self):
                    self.code = "testcode"
                    self.uses = 1
                    self.inviter = interaction.user
            
            fake_invite = FakeInvite()
            
            if boost_embed_name:
                try:
                    from Jo1nTrX.cogs.extra.embeds import create_embed_from_database_data
                    message_content, test_embed = await create_embed_from_database_data(
                        self.bot, interaction.guild.id, boost_embed_name, interaction.user, fake_invite, interaction.user
                    )
                    
                    if test_embed:
                        confirm_content = create_success_content("Test Boost Embed Sent", f"Test boost embed '{boost_embed_name}' has been sent to {test_channel.mention}")
                        confirm_view = create_v2_view(confirm_content)
                        await interaction.followup.send(view=confirm_view)
                        
                        try:
                            if message_content:
                                sent_message = await test_channel.send(content=f"🧪 **Test Boost Message Preview**\n{message_content}", embed=test_embed)
                            else:
                                sent_message = await test_channel.send(content="🧪 **Test Boost Message Preview**", embed=test_embed)
                            
                            if boost_emoji:
                                try:
                                    await sent_message.add_reaction(boost_emoji)
                                except:
                                    pass
                                    
                        except discord.Forbidden:
                            error_content = create_error_content("Permission Error", f"I don't have permission to send messages in {test_channel.mention}")
                            error_view = create_v2_view(error_content)
                            await interaction.followup.send(view=error_view)
                    else:
                        error_content = create_error_content("Test Boost Message Error", f"**Channel:** {test_channel.mention}\n**Error:** Could not load embed '{boost_embed_name}'")
                        error_view = create_v2_view(error_content)
                        await interaction.followup.send(view=error_view)
                except Exception as e:
                    error_content = create_error_content("Test Boost Message Error", f"**Channel:** {test_channel.mention}\n**Error:** Failed to test embed: {str(e)}")
                    error_view = create_v2_view(error_content)
                    await interaction.followup.send(view=error_view)
            
            elif boost_message:
                try:
                    processed_message = await self.bot.replace_variables(boost_message, interaction.user, fake_invite, False, interaction.user)
                    
                    confirm_content = create_success_content("Test Boost Message Sent", f"Test boost message has been sent to {test_channel.mention}")
                    confirm_view = create_v2_view(confirm_content)
                    await interaction.followup.send(view=confirm_view)
                    
                    try:
                        sent_message = await test_channel.send(f"🧪 **Test Boost Message Preview**\n{processed_message}")
                        
                        if boost_emoji:
                            try:
                                await sent_message.add_reaction(boost_emoji)
                            except:
                                pass
                                
                    except discord.Forbidden:
                        error_content = create_error_content("Permission Error", f"I don't have permission to send messages in {test_channel.mention}")
                        error_view = create_v2_view(error_content)
                        await interaction.followup.send(view=error_view)
                except Exception as e:
                    error_content = create_error_content("Test Boost Message Error", f"**Channel:** {test_channel.mention}\n**Error:** Failed to process variables: {str(e)}")
                    error_view = create_v2_view(error_content)
                    await interaction.followup.send(view=error_view)
            
            else:
                try:
                    confirm_content = create_success_content("Test Boost Message Sent", f"Test default boost message has been sent to {test_channel.mention}")
                    confirm_view = create_v2_view(confirm_content)
                    await interaction.followup.send(view=confirm_view)
                    
                    try:
                        default_message = f"🎉 {interaction.user.mention} just boosted **{interaction.guild.name}**! Thank you for your support!"
                        sent_message = await test_channel.send(f"🧪 **Test Boost Message Preview**\n{default_message}")
                        
                        if boost_emoji:
                            try:
                                await sent_message.add_reaction(boost_emoji)
                            except:
                                pass
                                
                    except discord.Forbidden:
                        error_content = create_error_content("Permission Error", f"I don't have permission to send messages in {test_channel.mention}")
                        error_view = create_v2_view(error_content)
                        await interaction.followup.send(view=error_view)
                except Exception as e:
                    error_content = create_error_content("Test Boost Message Error", f"**Channel:** {test_channel.mention}\n**Error:** Failed to send default message: {str(e)}")
                    error_view = create_v2_view(error_content)
                    await interaction.followup.send(view=error_view)
                    
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error testing boost messages: {str(e)}"))
            await interaction.followup.send(view=error_view, ephemeral=True)
    
    async def on_timeout(self):
        for item in self.children:
            item.disabled = True


class WelcomeSetupViewV2(ui.LayoutView):
    def __init__(self, bot, author_id, message_type, prefix, requester=None):
        super().__init__(timeout=300)
        self.bot = bot
        self.author_id = author_id
        self.message_type = message_type
        self.prefix = prefix
        self.requester = requester
        self._setup_buttons()
    
    def _setup_buttons(self):
        text_btn = ui.Button(label='Text Message', style=discord.ButtonStyle.primary)
        embed_btn = ui.Button(label='Embed Message', style=discord.ButtonStyle.secondary)
        cancel_btn = ui.Button(label='Cancel', style=discord.ButtonStyle.danger)
        
        async def text_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await self._handle_text_setup(interaction)
        
        async def embed_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await self._handle_embed_setup(interaction)
        
        async def cancel_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            cancel_content = f"""## {ERROR_EMOJI} {self.message_type.title()} Setup Cancelled
> {self.message_type.title()} message setup has been cancelled."""
            cancel_view = create_v2_view(cancel_content)
            await interaction.response.edit_message(view=cancel_view)
        
        text_btn.callback = text_callback
        embed_btn.callback = embed_callback
        cancel_btn.callback = cancel_callback
        
        arrow = ARROW_EMOJI
        section = SECTION_EMOJI
        
        content = f"""## {ADMIN_ICON} {self.message_type.title()} Message Setup

{section} **__Choose Message Type__**

{arrow} **Text Message** - Send a plain text welcome message
{arrow} **Embed Message** - Use a custom embed for your message

> Select an option below to continue setup."""
        
        button_row = ui.ActionRow(text_btn, embed_btn, cancel_btn)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display, button_row)
        self.add_item(container)
    
    async def _handle_text_setup(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            f"Enter the channel ID or <#channel> you want your {self.message_type} message to be sent in.\n"
            f"Send `cancel` to cancel {self.message_type} setup.",
            ephemeral=True
        )
        
        def check(message):
            return message.author.id == self.author_id and message.channel == interaction.channel
        
        try:
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply(f"❌ {self.message_type.title()} setup cancelled.")
                return
            
            channel = None
            if message.channel_mentions:
                channel = message.channel_mentions[0]
            else:
                try:
                    channel_id = int(message.content.strip('<>#'))
                    channel = self.bot.get_channel(channel_id)
                except ValueError:
                    await message.reply("❌ Invalid channel format. Please use a channel mention or valid channel ID.")
                    return
            
            if not channel:
                await message.reply("❌ Channel not found or I don't have access to it.")
                return
            
            await message.reply(
                f"Send your {self.message_type} message (with variables), you want to setup.\n"
                f"Send `cancel` to cancel {self.message_type} setup."
            )
            
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply(f"❌ {self.message_type.title()} setup cancelled.")
                return
            
            welcome_message = message.content
            
            await self.bot.db.add_join_channel(interaction.guild.id, channel.id, self.message_type)
            await self.bot.db.set_join_channel_message(interaction.guild.id, channel.id, self.message_type, welcome_message)
            
            success_content = f"""## {SUCCESS_EMOJI} {self.message_type.title()} Message Setup Complete
> Text {self.message_type} message has been configured!

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Channel:** {channel.mention}
{ARROW_EMOJI} **Message:** {welcome_message[:100]}{'...' if len(welcome_message) > 100 else ''}"""
            
            success_view = create_v2_view(success_content)
            await message.reply(view=success_view)
            
        except asyncio.TimeoutError:
            await interaction.followup.send(f"⏰ Timeout! {self.message_type.title()} setup was not completed within 5 minutes.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Error setting up {self.message_type} message: {str(e)}", ephemeral=True)
    
    async def _handle_embed_setup(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            f"Enter the channel ID or <#channel> you want your {self.message_type} message to be sent in.\n"
            f"Send `cancel` to cancel {self.message_type} setup.",
            ephemeral=True
        )
        
        def check(message):
            return message.author.id == self.author_id and message.channel == interaction.channel
        
        try:
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply(f"❌ {self.message_type.title()} setup cancelled.")
                return
            
            channel = None
            if message.channel_mentions:
                channel = message.channel_mentions[0]
            else:
                try:
                    channel_id = int(message.content.strip('<>#'))
                    channel = self.bot.get_channel(channel_id)
                except ValueError:
                    await message.reply("❌ Invalid channel format. Please use a channel mention or valid channel ID.")
                    return
            
            if not channel:
                await message.reply("❌ Channel not found or I don't have access to it.")
                return
            
            embeds = await self.bot.db.get_all_custom_embeds(interaction.guild.id)
            
            if not embeds:
                await message.reply(f"❌ No custom embeds found. Create one first using `{self.prefix}embed create <name>`.")
                return
            
            embed_select_view = EmbedSelectionViewV2(self.bot, self.author_id, channel, self.message_type, embeds, self.requester)
            
            select_content = f"""## {ADMIN_ICON} Choose your {self.message_type} embed!
> Select an embed from the dropdown below.

{ARROW_EMOJI} Send `cancel` to cancel {self.message_type} setup."""
            
            embed_select_view.add_item(ui.Container(ui.TextDisplay(select_content)))
            await message.reply(view=embed_select_view)
            
        except asyncio.TimeoutError:
            await interaction.followup.send(f"⏰ Timeout! {self.message_type.title()} setup was not completed within 5 minutes.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Error setting up {self.message_type} embed: {str(e)}", ephemeral=True)


class EmbedSelectionViewV2(ui.LayoutView):
    def __init__(self, bot, author_id, channel, message_type, embeds, requester=None):
        super().__init__(timeout=300)
        self.bot = bot
        self.author_id = author_id
        self.channel = channel
        self.message_type = message_type
        self.embeds = embeds
        self.requester = requester
        self._setup_view()
    
    def _setup_view(self):
        options = []
        for embed_data in self.embeds[:25]:
            options.append(discord.SelectOption(
                label=embed_data['name'],
                description=f"Created by {embed_data['creator_name']}",
                value=embed_data['name']
            ))
        
        if options:
            embed_select = ui.Select(
                placeholder="Select an embed...",
                min_values=1,
                max_values=1,
                options=options
            )
            
            async def select_callback(interaction: discord.Interaction):
                if self.requester and interaction.user.id != self.requester.id:
                    return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
                
                selected_embed = embed_select.values[0]
                await self.bot.db.add_join_channel(interaction.guild.id, self.channel.id, self.message_type)
                await self.bot.db.set_join_channel_embed(interaction.guild.id, self.channel.id, self.message_type, selected_embed)
                
                success_content = f"""## {SUCCESS_EMOJI} {self.message_type.title()} Embed Setup Complete
> Embed has been configured successfully!

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Channel:** {self.channel.mention}
{ARROW_EMOJI} **Embed:** {selected_embed}"""
                
                success_view = create_v2_view(success_content)
                await interaction.response.edit_message(view=success_view)
            
            embed_select.callback = select_callback
            select_row = ui.ActionRow(embed_select)
            self.add_item(select_row)


class ResetConfirmationView(BaseView):
    def __init__(self, bot, author_id, guild_id):
        super().__init__(timeout=300)
        self.bot = bot
        self.author_id = author_id
        self.guild_id = guild_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("Only the user who started this reset can confirm it.", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label='Confirm Reset', style=discord.ButtonStyle.danger)
    async def confirm_reset(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            await self.bot.db.clear_all_join_channels(self.guild_id)
            
            success_content = f"""## {SUCCESS_EMOJI} Welcome Configuration Reset
> All welcome configuration has been successfully reset!

{SECTION_EMOJI} **__Actions Performed__**

{ARROW_EMOJI} All join channels removed
{ARROW_EMOJI} All leave channels removed
{ARROW_EMOJI} All custom messages cleared
{ARROW_EMOJI} All embed configurations cleared"""
            success_view = create_v2_view(success_content)
            await interaction.response.edit_message(view=success_view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Reset Error", f"Error resetting welcome configuration: {str(e)}"))
            await interaction.response.edit_message(view=error_view)
    
    @discord.ui.button(label='Cancel', style=discord.ButtonStyle.secondary)
    async def cancel_reset(self, interaction: discord.Interaction, button: discord.ui.Button):
        cancel_content = f"""## {ERROR_EMOJI} Reset Cancelled
> Welcome configuration reset has been cancelled.

{ARROW_EMOJI} No changes were made."""
        cancel_view = create_v2_view(cancel_content)
        await interaction.response.edit_message(view=cancel_view)


class WelcomeCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    def parse_time_string(self, time_str: str) -> int:
        import re
        time_str = time_str.replace(" ", "").lower()
        match = re.match(r'^(\d+)([smh])$', time_str)
        if not match:
            return None
        value, unit = match.groups()
        value = int(value)
        if unit == 's':
            return value
        elif unit == 'm':
            return value * 60
        elif unit == 'h':
            return value * 3600
        return None
    
    def format_time_display(self, seconds: int) -> str:
        if seconds < 60:
            return f"{seconds} second{'s' if seconds != 1 else ''}"
        elif seconds < 3600:
            minutes = seconds // 60
            return f"{minutes} minute{'s' if minutes != 1 else ''}"
        else:
            hours = seconds // 3600
            remaining_minutes = (seconds % 3600) // 60
            if remaining_minutes > 0:
                return f"{hours} hour{'s' if hours != 1 else ''} {remaining_minutes} minute{'s' if remaining_minutes != 1 else ''}"
            else:
                return f"{hours} hour{'s' if hours != 1 else ''}"
    
    @commands.hybrid_command(name='setjoinmessage')
    @commands.has_permissions(administrator=True)
    async def setjoinmessage(self, ctx):
        """Setup welcome message configuration with interactive menu"""
        try:
            prefix = await self.bot.db.get_guild_prefix(ctx.guild.id)
            if not prefix:
                prefix = "+"
            
            content = f"""## <:Jo1nTrX_welcome:1408686831415066715> {ctx.guild.name}
> Choose the button below for which type of welcome message you want to setup

{SECTION_EMOJI} **__Message Types__**

{ARROW_EMOJI} **Text Message** - Setup normal text welcome message!
{ARROW_EMOJI} **Embed Message** - Setup embed welcome message!

{SECTION_EMOJI} **__Note__** <:Jo1nTrX_Note:1411930562288943104>

{ARROW_EMOJI} If you're setting **Embed welcome message**, create **Welcome Embed** first from `{prefix}embed create <name>`.
{ARROW_EMOJI} For Variables list do `{prefix}variables`."""
            
            view = WelcomeSetupViewV2(self.bot, ctx.author.id, "join", prefix, ctx.author)
            view.add_item(ui.Container(ui.TextDisplay(content)))
            await ctx.send(view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error starting welcome setup: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='unsetjoinmessage')
    @app_commands.describe(channel='The channel to remove join message from')
    @commands.has_permissions(administrator=True)
    async def unsetjoinmessage(self, ctx, channel: discord.TextChannel):
        """Remove custom join message from a specific channel"""
        try:
            await self.bot.db.unset_join_channel_message(ctx.guild.id, channel.id, 'join')
            
            success_content = f"""## {SUCCESS_EMOJI} Join Message Unset
> Custom join message has been removed!

{ARROW_EMOJI} **Channel:** {channel.mention}"""
            success_view = create_v2_view(success_content)
            await ctx.send(view=success_view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error unsetting join message: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='setleavemessage')
    @commands.has_permissions(administrator=True)
    async def setleavemessage(self, ctx):
        """Setup leave message configuration with interactive menu"""
        try:
            prefix = await self.bot.db.get_guild_prefix(ctx.guild.id)
            if not prefix:
                prefix = "+"
            
            content = f"""## <:Jo1nTrX_welcome:1408686831415066715> {ctx.guild.name}
> Choose the button below for which type of leave message you want to setup

{SECTION_EMOJI} **__Message Types__**

{ARROW_EMOJI} **Text Message** - Setup normal text leave message!
{ARROW_EMOJI} **Embed Message** - Setup embed leave message!

{SECTION_EMOJI} **__Note__** <:Jo1nTrX_Note:1411930562288943104>

{ARROW_EMOJI} If you're setting **Embed leave message**, create **Leave Embed** first from `{prefix}embed create <name>`.
{ARROW_EMOJI} For Variables list do `{prefix}variables`."""
            
            view = WelcomeSetupViewV2(self.bot, ctx.author.id, "leave", prefix, ctx.author)
            view.add_item(ui.Container(ui.TextDisplay(content)))
            await ctx.send(view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error starting leave setup: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='unsetleavemessage')
    @app_commands.describe(channel='The channel to remove leave message from')
    @commands.has_permissions(administrator=True)
    async def unsetleavemessage(self, ctx, channel: discord.TextChannel):
        """Remove custom leave message from a specific channel"""
        try:
            await self.bot.db.unset_join_channel_message(ctx.guild.id, channel.id, 'leave')
            
            success_content = f"""## {SUCCESS_EMOJI} Leave Message Unset
> Custom leave message has been removed!

{ARROW_EMOJI} **Channel:** {channel.mention}"""
            success_view = create_v2_view(success_content)
            await ctx.send(view=success_view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error unsetting leave message: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='variables')
    async def variables(self, ctx):
        """Displays the variables so that you can use them in custom welcome message"""
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        arrow2 = "<:Jo1nTrX_arrow2:1415026780783247420>"
        
        separator = "-# ~~                                                                                          ** **         ~~"
        
        content = f"""## {ADMIN_ICON} Available Variables
> Use these variables in your custom welcome messages

{arrow2} **__User Variables__**
{arrow} `{{user}}` - User display name
{arrow} `{{user.mention}}` - User mention
{arrow} `{{user.tag}}` - User tag (name#discriminator)
{arrow} `{{user.id}}` - User ID
{arrow} `{{user.created}}` - Account creation date
{arrow} `{{user.joined}}` - Date user joined the server
{arrow} `{{user.nickname}}` - User nickname (or display name if no nickname)
{arrow} `{{user.avatar}}` - User avatar URL
{arrow} `{{user.status}}` - User status (online, idle, dnd, offline)

{separator}

{arrow2} **__Guild Variables__**
{arrow} `{{guild}}` - Guild name
{arrow} `{{guild.name}}` - Guild name
{arrow} `{{guild.id}}` - Guild ID
{arrow} `{{guild.owner}}` - Guild owner display name
{arrow} `{{guild.owner.mention}}` - Guild owner mention
{arrow} `{{guild.created}}` - Guild creation date
{arrow} `{{guild.icon}}` - Guild icon URL
{arrow} `{{membercount}}` - Current member count
{arrow} `{{membercount.ordinal}}` - Member count as ordinal (1st, 2nd, 10th, etc.)
{arrow} `{{guild.boosts}}` - Number of server boosts
{arrow} `{{guild.boost_level}}` - Server boost level

{separator}

{arrow2} **__Time Variables__**
{arrow} `{{time}}` - Current time (24-hour format)
{arrow} `{{time.12}}` - Current time (12-hour format)
{arrow} `{{date}}` - Current date
{arrow} `{{datetime}}` - Current date and time

{separator}

{arrow2} **__Invite Variables__ (Welcome only):**
{arrow} `{{inviter}}` - Inviter display 
{arrow} `{{inviter.mention}}` - Inviter mention
{arrow} `{{inviter.tag}}` - Inviter tag
{arrow} `{{inviter.id}}` - Inviter ID
{arrow} `{{invite.code}}` - Invite code used
{arrow} `{{invite.uses}}` - Number of times invite was used

{separator}

{arrow2} **__Special Variables__**
{arrow} `{{boost.count}}` - Total guild boost count
{arrow} `{{booster.mention}}` - Booster mention who boosted
{arrow} `{{booster.name}}` - User display name of booster

{separator} """
        
        view = create_v2_view(content)
        await ctx.send(view=view)
    
    @commands.hybrid_command(name='resetwelcomeconfig')
    @commands.has_permissions(administrator=True)
    async def resetwelcomeconfig(self, ctx):
        """Reset all welcome configuration for this server"""
        try:
            confirm_content = f"""## {ERROR_EMOJI} Reset Welcome Configuration
> This will remove ALL welcome configuration!

{SECTION_EMOJI} **__This action will:__**

{ARROW_EMOJI} Remove all join channels and messages
{ARROW_EMOJI} Remove all leave channels and messages
{ARROW_EMOJI} Remove all embed configurations

> **This action cannot be undone!**"""
            
            view = ResetConfirmationView(self.bot, ctx.author.id, ctx.guild.id)
            view.add_item(ui.Container(ui.TextDisplay(confirm_content)))
            await ctx.send(view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error starting reset: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='testmessage')
    async def testmessage(self, ctx):
        """Test your configured join/leave messages for this server"""
        try:
            all_channels = await self.bot.db.get_join_channels(ctx.guild.id)
            
            if not all_channels:
                error_content = create_error_content("No Channels Configured", "No join/leave channels configured for this server.\nUse `+setjoinmessage` or `+setleavemessage` to configure channels first.")
                error_view = create_v2_view(error_content)
                await ctx.send(view=error_view)
                return
            
            test_view = TestMessageView(self.bot, ctx.guild.id, ctx.author)
            
            content = f"""## {ADMIN_ICON} Test Message
> Select the type of message you want to test from the dropdown below."""
            
            embed = discord.Embed(description=content, color=discord.Color.blurple())
            await ctx.send(embed=embed, view=test_view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error testing message: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.group(name='joinmessage', invoke_without_command=True)
    async def joinmessage(self, ctx):
        """Join message configuration commands"""
        content = f"""## {ADMIN_ICON} Join Message Commands
> Configure join message settings

{SECTION_EMOJI} **__Available Commands__**

{ARROW_EMOJI} `+joinmessage delete <channel> <time>` - Set delete timer for join messages

{SECTION_EMOJI} **__Examples__**

{ARROW_EMOJI} `+joinmessage delete #welcome 30s` - Delete after 30 seconds
{ARROW_EMOJI} `+joinmessage delete #general 5m` - Delete after 5 minutes
{ARROW_EMOJI} `+joinmessage delete #announcements 1h` - Delete after 1 hour"""
        
        view = create_v2_view(content)
        await ctx.send(view=view)
    
    @joinmessage.command(name='delete')
    @commands.has_permissions(administrator=True)
    async def joinmessage_delete(self, ctx, channel: discord.TextChannel, time: str):
        """Set delete timer for join messages in a channel"""
        try:
            loading_msg = await ctx.send(f"<a:jo1ntrx_loading:1405094057499295806> Setting up delete timer...")
            
            time_seconds = self.parse_time_string(time)
            if time_seconds is None or time_seconds <= 0:
                await loading_msg.edit(content="❌ Invalid time format. Use formats like: `30s`, `5m`, `2h`")
                return
            
            if time_seconds > 86400:
                await loading_msg.edit(content="❌ Maximum delete time is 24 hours.")
                return
            
            join_channels = await self.bot.db.get_join_channels(ctx.guild.id)
            channel_configured = any(jc['channel_id'] == channel.id for jc in join_channels)
            
            if not channel_configured:
                await loading_msg.edit(content=f"❌ No join messages configured for {channel.mention}. Please configure join messages first using `+setjoinchannel`.")
                return
            
            await self.bot.db.set_join_message_delete_timer(ctx.guild.id, channel.id, time_seconds)
            
            time_display = self.format_time_display(time_seconds)
            
            await loading_msg.edit(content=f"✅ Join messages in {channel.mention} will now be deleted after **{time_display}**!")
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"Error in joinmessage delete: {e}")
            await ctx.send(f"❌ An error occurred: {str(e)}")
    
    @app_commands.command(name='joinmessage-delete', description='Set delete timer for join messages in a channel')
    @app_commands.describe(
        channel='Channel to set delete timer for',
        time='Delete time (e.g., 30s, 5m, 1h)'
    )
    async def slash_joinmessage_delete(self, interaction: discord.Interaction, channel: discord.TextChannel, time: str):
        """Set delete timer for join messages in a channel using slash command"""
        try:
            if not interaction.user.guild_permissions.administrator:
                await interaction.response.send_message("❌ You need Administrator permission to use this command!", ephemeral=True)
                return
            
            await interaction.response.send_message(f"<a:jo1ntrx_loading:1405094057499295806> Setting up delete timer...", ephemeral=True)
            
            time_seconds = self.parse_time_string(time)
            if time_seconds is None or time_seconds <= 0:
                await interaction.edit_original_response(content="❌ Invalid time format. Use formats like: `30s`, `5m`, `2h`")
                return
            
            if time_seconds > 86400:
                await interaction.edit_original_response(content="❌ Maximum delete time is 24 hours.")
                return
            
            join_channels = await self.bot.db.get_join_channels(interaction.guild.id)
            channel_configured = any(jc['channel_id'] == channel.id for jc in join_channels)
            
            if not channel_configured:
                await interaction.edit_original_response(content=f"❌ {channel.mention} is not configured for join messages. Please configure join messages first before adding a delete timer.")
                return
            
            await self.bot.db.set_join_message_delete_timer(interaction.guild.id, channel.id, time_seconds)
            
            time_display = self.format_time_display(time_seconds)
            
            await interaction.edit_original_response(content=f"✅ Join messages in {channel.mention} will now be deleted after **{time_display}**!")
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"Error in slash joinmessage delete: {e}")
            await interaction.edit_original_response(content=f"❌ Error setting delete timer: {str(e)}")
    
    @commands.hybrid_command(name='joinmessage-config')
    @commands.has_permissions(administrator=True)
    async def joinmessage_config(self, ctx):
        """View current join/leave message configurations for this server"""
        try:
            join_channels = await self.bot.db.get_join_channels(ctx.guild.id)
            
            if not join_channels:
                content = f"""## {ERROR_EMOJI} No Configurations Found
> No join/leave messages configured for this server.

{ARROW_EMOJI} Use `+setjoinmessage` or `+setleavemessage` to configure channels."""
                view = create_v2_view(content)
                await ctx.send(view=view)
                return
            
            items_per_page = 3
            total_pages = (len(join_channels) + items_per_page - 1) // items_per_page
            current_page = 0
            
            def create_config_list_embed(page):
                start_idx = page * items_per_page
                end_idx = start_idx + items_per_page
                page_configs = join_channels[start_idx:end_idx]
                
                config_list = []
                for config_data in page_configs:
                    channel_id = config_data['channel_id']
                    message_type = config_data['message_type']
                    custom_message = config_data.get('custom_message')
                    embed_name = config_data.get('embed_name')
                    delete_time = config_data.get('delete_time')
                    
                    channel = ctx.guild.get_channel(channel_id)
                    channel_mention = channel.mention if channel else f"<#{channel_id}> (Channel Not Found)"
                    
                    delete_display = "No auto-delete"
                    if delete_time:
                        delete_display = self.format_time_display(delete_time)
                    
                    message_content = "Default message"
                    if embed_name:
                        message_content = f"Embed: **{embed_name}**"
                    elif custom_message:
                        truncated_message = custom_message[:50] + "..." if len(custom_message) > 50 else custom_message
                        message_content = f"Custom: {truncated_message}"
                    
                    config_entry = (
                        f"--------------------------------------------\n"
                        f"➛ | Channel: {channel_mention}\n"
                        f"➛ | Type: {message_type.title()} Message\n"
                        f"➛ | Content: {message_content}\n"
                        f"➛ | Auto-delete: {delete_display}\n"
                        f"--------------------------------------------"
                    )
                    config_list.append(config_entry)
                
                description = "\n\n".join(config_list)
                
                content = f"""## <:Jo1nTrX_welcome:1408686831415066715> Join/Leave Message Configuration

{description}

> Page {page + 1} of {total_pages} • Total: {len(join_channels)} configurations"""
                
                return create_v2_view(content)
            
            view = create_config_list_embed(current_page)
            
            if total_pages == 1:
                await ctx.send(view=view)
                return
            
            from Jo1nTrX.utils.pagination import PaginationView
            pagination_view = PaginationView(current_page, total_pages, create_config_list_embed, ctx.author)
            await ctx.send(view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Configuration Error", f"Failed to list join message configurations: {str(e)}"))
            await ctx.send(view=error_view)


async def setup(bot):
    await bot.add_cog(WelcomeCommands(bot))
