import discord
from discord.ext import commands
from discord import app_commands
from Jo1nTrX.utils.helpers import send_loading_message
from .admin_helper import (
    ARROW_EMOJI, SECTION_EMOJI, SUCCESS_EMOJI, ERROR_EMOJI,
    create_v2_view, create_error_content
)


class RoleManagementCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    def _check_hierarchy(self, ctx, member):
        if member == ctx.author:
            return False, "You cannot moderate yourself."
        
        if member == ctx.guild.owner:
            return False, "Cannot moderate the server owner."
        
        if ctx.author != ctx.guild.owner and member.top_role >= ctx.author.top_role:
            return False, "You cannot moderate someone with a higher or equal role."
        
        if member.top_role >= ctx.guild.me.top_role:
            return False, "I cannot moderate someone with a higher or equal role than me."
        
        return True, None
    
    @commands.hybrid_command(name='role')
    @app_commands.describe(
        member='The member to give/remove role to/from',
        role='The role to add or remove',
        action='Whether to add or remove the role'
    )
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def role_command(self, ctx, member: discord.Member, role: discord.Role, action: str = "toggle"):
        """Add or remove a role from a member"""
        if role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
            error_view = create_v2_view(create_error_content("Error", "You cannot manage a role higher than or equal to your highest role."))
            await ctx.send(view=error_view)
            return
        
        if role >= ctx.guild.me.top_role:
            error_view = create_v2_view(create_error_content("Error", "I cannot manage a role higher than or equal to my highest role."))
            await ctx.send(view=error_view)
            return
        
        can_moderate, error_msg = self._check_hierarchy(ctx, member)
        if not can_moderate and member != ctx.author:
            error_view = create_v2_view(create_error_content("Error", error_msg or "Cannot manage this member's roles."))
            await ctx.send(view=error_view)
            return
        
        action = action.lower()
        if action not in ["add", "remove", "toggle"]:
            error_view = create_v2_view(create_error_content("Error", "Action must be 'add', 'remove', or 'toggle'."))
            await ctx.send(view=error_view)
            return
        
        loading_msg = await send_loading_message(ctx, f"managing role for {member.mention}")
        
        try:
            has_role = role in member.roles
            
            if action == "toggle":
                action = "remove" if has_role else "add"
            elif action == "add" and has_role:
                error_view = create_v2_view(create_error_content("Error", f"{member.mention} already has the {role.mention} role."))
                await loading_msg.edit(content=None, embed=None, view=error_view)
                return
            elif action == "remove" and not has_role:
                error_view = create_v2_view(create_error_content("Error", f"{member.mention} doesn't have the {role.mention} role."))
                await loading_msg.edit(content=None, embed=None, view=error_view)
                return
            
            if action == "add":
                await member.add_roles(role)
                content = f"""## {SUCCESS_EMOJI} Role Added
> Added **{role.name}** to {member.display_name}

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.display_name}
{ARROW_EMOJI} **Role:** {role.name}
{ARROW_EMOJI} **Moderator:** {ctx.author.display_name}"""
            else:
                await member.remove_roles(role)
                content = f"""## {SUCCESS_EMOJI} Role Removed
> Removed **{role.name}** from {member.display_name}

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.display_name}
{ARROW_EMOJI} **Role:** {role.name}
{ARROW_EMOJI} **Moderator:** {ctx.author.display_name}"""
            
            view = create_v2_view(content)
            await loading_msg.edit(content=None, embed=None, view=view)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("Permission Error", "I don't have permission to manage this role."))
            await loading_msg.edit(content=None, embed=None, view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error managing role: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)


async def setup(bot):
    await bot.add_cog(RoleManagementCommands(bot))
