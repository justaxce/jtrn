import discord
from discord.ext import commands
from discord import app_commands, ui
from typing import Optional
from Jo1nTrX.utils.embeds import create_embed, create_error_embed
from Jo1nTrX.utils.helpers import format_time_since, send_loading_message, format_custom_datetime
from datetime import datetime, timezone
import math
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)


class InviteStatsLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member, stats: dict, color: int, has_custom: bool = False, custom_text: str = ""):
        super().__init__(timeout=300)
        self.member = member
        self.stats = stats
        self.color = color
        self.has_custom = has_custom
        self.custom_text = custom_text
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        dotz = "<a:Jo1nTrX_Dotz:1415025958251003994>"
        arrow2 = "<:Jo1nTrX_arrow2:1415026780783247420>"
        
        total_lifetime_joins = self.stats['total_joins']
        rejoin_count = self.stats['rejoins']
        fake_count = self.stats['fake']
        left_count = self.stats['left']
        actual_invites = max(0, total_lifetime_joins - (rejoin_count + fake_count + left_count))
        
        content = f"""## <:jo1ntrx_invite:1405093146358190233> Invite Stats for {self.member.display_name}
> Detailed invite statistics for this user

{section} **__Summary__**
{arrow2} This user has **{actual_invites}** actual invites.

{section} **__Breakdown__**
{dotz} **Join** : {total_lifetime_joins}
{dotz} **Rejoins** : {rejoin_count}
{dotz} **Fake** : {fake_count}
{dotz} **Left** : {left_count}"""
        
        if self.has_custom and self.custom_text:
            content += f"\n\n{section} **__Custom Adjustments__**\n{self.custom_text}"
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class InviterLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member, inviter_data: dict = None, color: int = 0x7c28eb):
        super().__init__(timeout=300)
        self.member = member
        self.inviter_data = inviter_data
        self.color = color
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if not self.inviter_data:
            content = f"""## <:jo1ntrx_invite:1405093146358190233> No Inviter Found
> No inviter data found for {self.member.mention}"""
        else:
            inviter_id = self.inviter_data.get('inviter_id')
            invite_code = self.inviter_data.get('invite_code')
            joined_at = self.inviter_data.get('joined_at')
            
            content = f"""## <:jo1ntrx_invite:1405093146358190233> Inviter for {self.member.display_name}
> How this user joined the server"""
            
            if invite_code == "VANITY":
                content += f"\n\n{section} **__Join Method__**\n{arrow} 🌟 Joined via **Vanity URL**"
            elif invite_code == "UNKNOWN":
                content += f"\n\n{section} **__Join Method__**\n{arrow} ❓ **Unknown** join method"
            elif inviter_id:
                content += f"\n\n{section} **__Inviter__**\n{arrow} <@{inviter_id}>"
            else:
                content += f"\n\n{section} **__Join Method__**\n{arrow} 📎 **Unknown Inviter**"
            
            if invite_code and invite_code not in ["VANITY", "UNKNOWN"]:
                content += f"\n\n{section} **__Invite Code__**\n{arrow} `{invite_code}`"
            
            if joined_at:
                if isinstance(joined_at, str):
                    joined_dt = datetime.fromisoformat(joined_at.replace('Z', '+00:00'))
                else:
                    joined_dt = joined_at
                content += f"\n\n{section} **__Joined At__**\n{arrow} {format_custom_datetime(joined_dt)}"
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class InvitedUsersLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member, message: str = "", color: int = 0x7c28eb):
        super().__init__(timeout=300)
        self.member = member
        self.message = message
        self._setup_view()
    
    def _setup_view(self):
        content = f"""## <:jo1ntrx_invite:1405093146358190233> Invited Users
> {self.member.mention} hasn't invited anyone yet."""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class InviteInfoLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member, invite_info: list = None, color: int = 0x7c28eb):
        super().__init__(timeout=300)
        self.member = member
        self.invite_info = invite_info
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if not self.invite_info:
            content = f"""## <:jo1ntrx_invite:1405093146358190233> Active Invites
> {self.member.mention} has no active invite codes."""
        else:
            content = f"""## <:jo1ntrx_invite:1405093146358190233> Active Invites for {self.member.display_name}
> Current active invite codes

{section} **__Invite Codes__**"""
            for code, uses, inviter_id in self.invite_info:
                content += f"\n{arrow} **Code:** `{code}` - **Uses:** {uses}"
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class InvitesResetLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str, success: bool = True, error_msg: str = ""):
        super().__init__(timeout=300)
        self.guild_name = guild_name
        self.success = success
        self.error_msg = error_msg
        self._setup_view()
    
    def _setup_view(self):
        if self.success:
            content = f"""## <:jo1ntrx_tick:1405094884947267715> Invites Reset
> Your invite data has been cleared for **{self.guild_name}**."""
        else:
            content = f"""## <a:Jo1nTrX_cross:1405094904568483880> Error
> {self.error_msg}"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class AccountAgeLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member, account_age: str, color: int = 0x7c28eb):
        super().__init__(timeout=300)
        self.member = member
        self.account_age = account_age
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:jo1ntrx_invite:1405093146358190233> Account Age for {self.member.display_name}
> Account creation and age information

{section} **__Account Created__**
{arrow} {format_custom_datetime(self.member.created_at)}

{section} **__Account Age__**
{arrow} `{self.account_age}`"""
        
        if hasattr(self.member, 'joined_at') and self.member.joined_at:
            content += f"\n\n{section} **__Joined Server__**\n{arrow} {format_custom_datetime(self.member.joined_at)}"
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class ErrorLayoutView(ui.LayoutView):
    def __init__(self, message: str, title: str = "Error"):
        super().__init__(timeout=60)
        self.message = message
        self.title = title
        self._setup_view()
    
    def _setup_view(self):
        content = f"""## <a:Jo1nTrX_cross:1405094904568483880> {self.title}
> {self.message}"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class WarningLayoutView(ui.LayoutView):
    def __init__(self, message: str, title: str = "Warning"):
        super().__init__(timeout=60)
        self.message = message
        self.title = title
        self._setup_view()
    
    def _setup_view(self):
        content = f"""## <:Jo1nTrX_warning:1438450620402237542> {self.title}
> {self.message}"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class PremiumRequiredLayoutView(ui.LayoutView):
    def __init__(self):
        super().__init__(timeout=300)
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <a:Jo1nTrX_cross:1405094904568483880> Premium Required
> You don't have premium access to use this command!

{section} **__Get Premium__**
{arrow} To get premium access, join the support server.

{section} **__Support Server__**
{arrow} [Join our support server](https://discord.gg/PA6UhChxZY)"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class InvitedUsersPaginationLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member, data: list, current_page: int, total_pages: int, author: discord.Member):
        super().__init__(timeout=300)
        self.member = member
        self.data = data
        self.current_page = current_page
        self.total_pages = total_pages
        self.author = author
        self.items_per_page = 10
        self._setup_view()
    
    def _get_page_data(self, page):
        start = page * self.items_per_page
        end = start + self.items_per_page
        return self.data[start:end]
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        page_data = self._get_page_data(self.current_page)
        
        content = f"""## <:jo1ntrx_invite:1405093146358190233> Users Invited by {self.member.display_name}
> Page {self.current_page + 1} of {self.total_pages}

{section} **__Invited Users__**"""
        
        start_index = self.current_page * self.items_per_page
        for i, item in enumerate(page_data):
            global_index = start_index + i + 1
            
            status_indicators = []
            if item['is_fake']:
                status_indicators.append("FAKE")
            if item['is_rejoin']:
                status_indicators.append("REJOINED")
            if item['left']:
                status_indicators.append("LEFT")
            
            status_text = f" [{' | '.join(status_indicators)}]" if status_indicators else ""
            
            content += f"\n**{global_index:02d}.** {item['mention']}{status_text}"
            content += f"\n{arrow} Age : `{item['account_age']}` | Status : {item['status_emoji']}"
        
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = InvitedUsersPaginationLayoutView(self.member, self.data, 0, self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = InvitedUsersPaginationLayoutView(self.member, self.data, max(0, self.current_page - 1), self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = InvitedUsersPaginationLayoutView(self.member, self.data, min(self.total_pages - 1, self.current_page + 1), self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = InvitedUsersPaginationLayoutView(self.member, self.data, self.total_pages - 1, self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class InviteLeaderboardView(discord.ui.View):
    def __init__(self, data: list, current_page: int, total_pages: int, author: discord.Member):
        super().__init__(timeout=300)
        self.data = data
        self.current_page = current_page
        self.total_pages = total_pages
        self.author = author
        self.items_per_page = 10
        self._update_buttons()
    
    def _get_page_data(self, page):
        start = page * self.items_per_page
        end = start + self.items_per_page
        return self.data[start:end]
    
    def _update_buttons(self):
        self.first_btn.disabled = self.current_page == 0
        self.prev_btn.disabled = self.current_page == 0
        self.next_btn.disabled = self.current_page >= self.total_pages - 1
        self.last_btn.disabled = self.current_page >= self.total_pages - 1
    
    def create_embed(self):
        section = "<:jo1ntrx_right:1405095312456024127>"
        page_data = self._get_page_data(self.current_page)
        
        description = f"{section} **__Rankings__**\n"
        start_index = self.current_page * self.items_per_page
        for i, item in enumerate(page_data):
            global_rank = start_index + i + 1
            description += f"\n**{global_rank}.** {item['mention']} : {item['actual_invites']} invite | {item['joins']} joins, {item['left']} leave, {item['rejoins']} rejoins, {item['fake']} fake."
        
        embed = discord.Embed(
            title="<:jo1ntrx_invite:1405093146358190233> Invite Leaderboard",
            description=description,
            color=0x7c28eb
        )
        embed.set_footer(text=f"Page {self.current_page + 1} of {self.total_pages}")
        return embed
    
    @discord.ui.button(emoji='<:jo1ntrx_doubleleft:1405095487710691449>', style=discord.ButtonStyle.gray)
    async def first_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        self.current_page = 0
        self._update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)
    
    @discord.ui.button(emoji='<:jo1ntrx_left:1405095378231099464>', style=discord.ButtonStyle.gray)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        self.current_page = max(0, self.current_page - 1)
        self._update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)
    
    @discord.ui.button(emoji='<:jo1ntrx_delete:1405095625795702895>', style=discord.ButtonStyle.danger)
    async def delete_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        await interaction.message.delete()
    
    @discord.ui.button(emoji='<:jo1ntrx_right:1405095312456024127>', style=discord.ButtonStyle.gray)
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        self.current_page = min(self.total_pages - 1, self.current_page + 1)
        self._update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)
    
    @discord.ui.button(emoji='<:jo1ntrx_doubleright:1405095454395465790>', style=discord.ButtonStyle.gray)
    async def last_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        self.current_page = self.total_pages - 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)


class MultipleAccountAgePaginationLayoutView(ui.LayoutView):
    def __init__(self, data: list, current_page: int, total_pages: int, author: discord.Member):
        super().__init__(timeout=300)
        self.data = data
        self.current_page = current_page
        self.total_pages = total_pages
        self.author = author
        self.items_per_page = 10
        self._setup_view()
    
    def _get_page_data(self, page):
        start = page * self.items_per_page
        end = start + self.items_per_page
        return self.data[start:end]
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        page_data = self._get_page_data(self.current_page)
        
        content = f"""## <:jo1ntrx_invite:1405093146358190233> Multiple Account Ages
> Page {self.current_page + 1} of {self.total_pages}

{section} **__Account Details__**"""
        
        start_index = self.current_page * self.items_per_page
        for i, item in enumerate(page_data):
            index = start_index + i + 1
            
            if item.get('error'):
                content += f"\n**`{index:02d}.`** {item['mention']} ・ {item['account_age']}"
            elif item['has_joined']:
                joined_dt = datetime.fromtimestamp(item['joined_timestamp'], tz=timezone.utc)
                created_dt = datetime.fromtimestamp(item['created_timestamp'], tz=timezone.utc)
                content += f"\n**`{index:02d}.`** {item['mention']} ・ Joined {format_custom_datetime(joined_dt)} ・ Created {format_custom_datetime(created_dt)}"
                content += f"\n{arrow} Account Age: `{item['account_age']}`"
            else:
                created_dt = datetime.fromtimestamp(item['created_timestamp'], tz=timezone.utc)
                content += f"\n**`{index:02d}.`** {item['mention']} ・ Created {format_custom_datetime(created_dt)}"
                content += f"\n{arrow} Account Age: `{item['account_age']}`"
        
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = MultipleAccountAgePaginationLayoutView(self.data, 0, self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = MultipleAccountAgePaginationLayoutView(self.data, max(0, self.current_page - 1), self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = MultipleAccountAgePaginationLayoutView(self.data, min(self.total_pages - 1, self.current_page + 1), self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = MultipleAccountAgePaginationLayoutView(self.data, self.total_pages - 1, self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class InviteCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name='invites', aliases=['i'])
    @app_commands.describe(member='The member to check invite stats for')
    async def invites(self, ctx, member: Optional[discord.Member] = None):
        """Displays the invite stats of a member"""
        if member is None:
            member = ctx.author
        
        loading_msg = await send_loading_message(ctx, f"fetching the invite count of {member.mention}")
        
        try:
            stats = await self.bot.db.get_user_invites(ctx.guild.id, member.id)
            
            has_custom = stats['added'] > 0 or stats['removed'] > 0
            custom_text = ""
            if has_custom:
                arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
                if stats['added'] > 0:
                    custom_text += f"{arrow} **Added** : {stats['added']} invite{'s' if stats['added'] != 1 else ''}\n"
                if stats['removed'] > 0:
                    custom_text += f"{arrow} **Removed** : {stats['removed']} invite{'s' if stats['removed'] != 1 else ''}"
            
            view = InviteStatsLayoutView(member, stats, self.bot.config.embed_color, has_custom, custom_text)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = ErrorLayoutView(f"Error fetching invite stats: {str(e)}")
            await loading_msg.edit(embed=None, view=view)
    
    @commands.hybrid_command(name='inviter')
    @app_commands.describe(member='The member to check the inviter for')
    async def inviter(self, ctx, member: Optional[discord.Member] = None):
        """Displays the inviter of a server member"""
        if member is None:
            member = ctx.author
        
        loading_msg = await send_loading_message(ctx, f"fetching who invited {member.mention}")
        
        try:
            inviter_data = await self.bot.db.get_inviter(ctx.guild.id, member.id)
            view = InviterLayoutView(member, inviter_data, self.bot.config.embed_color)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = ErrorLayoutView(f"Error fetching inviter data: {str(e)}")
            await loading_msg.edit(embed=None, view=view)
    
    @commands.hybrid_command(name='invited')
    @app_commands.describe(member='The member to check invited users for')
    async def invited(self, ctx, member: Optional[discord.Member] = None):
        """Displays the invited list of a member with their account age"""
        if member is None:
            member = ctx.author
        
        loading_msg = await send_loading_message(ctx, f"Fetching users invited by {member.mention}")
        
        try:
            invited_data = await self.bot.db.get_invited_users(ctx.guild.id, member.id)
            
            if not invited_data:
                view = InvitedUsersLayoutView(member)
                await loading_msg.edit(embed=None, view=view)
                return
            
            processed_data = []
            for invite_entry in invited_data:
                if isinstance(invite_entry, dict):
                    user_id = invite_entry['user_id']
                    joined_at = invite_entry['joined_at']
                    left_at = invite_entry['left_at']
                    is_fake = invite_entry.get('is_fake', False)
                    join_count = invite_entry.get('join_count', 1)
                else:
                    user_id, joined_at, left_at, is_fake = invite_entry
                    join_count = 1
                
                guild_member = ctx.guild.get_member(user_id)
                user = guild_member if guild_member else self.bot.get_user(user_id)
                
                if not user:
                    try:
                        user = await self.bot.fetch_user(user_id)
                    except discord.NotFound:
                        user = None
                    except discord.HTTPException:
                        user = None
                
                if user:
                    user_mention = user.mention
                    if guild_member:
                        from Jo1nTrX.utils.helpers import get_member_status_emoji
                        status_emoji = get_member_status_emoji(guild_member)
                    else:
                        status_emoji = "<:jo1ntrX_offline:1405301731583070439>"
                    
                    from Jo1nTrX.utils.helpers import format_account_age_short
                    account_age = format_account_age_short(user.created_at)
                else:
                    user_mention = f"<@{user_id}>"
                    status_emoji = "<:jo1ntrX_offline:1405301731583070439>"
                    account_age = "Unknown"
                
                if left_at is not None:
                    continue
                    
                processed_data.append({
                    'mention': user_mention,
                    'user_id': user_id,
                    'account_age': account_age,
                    'status_emoji': status_emoji,
                    'is_fake': is_fake,
                    'left': left_at is not None,
                    'is_rejoin': join_count > 1,
                    'join_count': join_count
                })
            
            def sort_key(item):
                if item['is_fake']:
                    return (2, item['mention'])
                elif item['is_rejoin']:
                    return (1, item['mention'])
                else:
                    return (0, item['mention'])
            
            processed_data.sort(key=sort_key)
            
            total_pages = math.ceil(len(processed_data) / 10)
            view = InvitedUsersPaginationLayoutView(member, processed_data, 0, total_pages, ctx.author)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = ErrorLayoutView(f"Error fetching invited users: {str(e)}")
            await loading_msg.edit(embed=None, view=view)
    
    @commands.hybrid_command(name='inviteinfo')
    @app_commands.describe(member='The member to check active invites for')
    async def inviteinfo(self, ctx, member: Optional[discord.Member] = None):
        """Displays the active invite code(s) of a user in this guild"""
        if member is None:
            member = ctx.author
        
        loading_msg = await send_loading_message(ctx, f"fetching active invite codes for {member.mention}")
        
        try:
            invite_info = await self.bot.db.get_user_invites_info(ctx.guild.id, member.id)
            view = InviteInfoLayoutView(member, invite_info, self.bot.config.embed_color)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = ErrorLayoutView(f"Error fetching invite info: {str(e)}")
            await loading_msg.edit(embed=None, view=view)
    
    @commands.hybrid_command(name='leaderboard_invites', aliases=['lbi', 'lb i'])
    async def leaderboard_invites(self, ctx):
        """Displays the invite leaderboard with pagination"""
        
        loading_msg = await send_loading_message(ctx, "fetching the invite leaderboard")
        
        try:
            leaderboard_data = await self.bot.db.get_leaderboard(ctx.guild.id, 1000)
            
            if not leaderboard_data:
                view = WarningLayoutView("No invite data found for this server.", "Invite Leaderboard")
                await loading_msg.edit(embed=None, view=view)
                return
            
            processed_data = []
            for user_id, stats in leaderboard_data:
                member = ctx.guild.get_member(user_id)
                user_mention = member.mention if member else f"<@{user_id}>"
                total_joins_by_user = stats.get('total_joins', 0)
                rejoins_count = stats.get('rejoins', 0)
                fake_count = stats.get('fake', 0)
                left_count = stats.get('left', 0)
                
                actual_invites = max(0, total_joins_by_user - (rejoins_count + fake_count + left_count))
                
                processed_data.append({
                    'mention': user_mention,
                    'joins': total_joins_by_user,
                    'actual_invites': actual_invites,
                    'invites': stats['total'],
                    'left': left_count,
                    'fake': fake_count,
                    'rejoins': rejoins_count
                })
            
            total_pages = math.ceil(len(processed_data) / 10)
            view = InviteLeaderboardView(processed_data, 0, total_pages, ctx.author)
            await loading_msg.edit(embed=view.create_embed(), view=view)
            
        except Exception as e:
            view = ErrorLayoutView(f"Error fetching leaderboard: {str(e)}")
            await loading_msg.edit(embed=None, view=view)
    
    @commands.hybrid_command(name='resetmyinvites', aliases=['rmi'])
    async def resetmyinvites(self, ctx):
        """Clears your own invites of a guild"""
        loading_msg = await send_loading_message(ctx, "resetting your invites")
        
        try:
            await self.bot.db.clear_user_invites(ctx.guild.id, ctx.author.id)
            view = InvitesResetLayoutView(ctx.guild.name, True)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = InvitesResetLayoutView(ctx.guild.name, False, f"Error resetting invites: {str(e)}")
            await loading_msg.edit(embed=None, view=view)
    

    @commands.hybrid_command(name='accountage', aliases=['accage'])
    @app_commands.describe(member='The member to check account age for')
    async def accountage(self, ctx, member: Optional[discord.Member] = None):
        """Shows the account age of a user in year:month:day:hour:second format"""
        if member is None:
            member = ctx.author
        
        loading_msg = await send_loading_message(ctx, f"fetching account age for {member.mention}")
        
        try:
            from Jo1nTrX.utils.helpers import format_account_age
            
            account_age = format_account_age(member.created_at)
            view = AccountAgeLayoutView(member, account_age, self.bot.config.embed_color)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = ErrorLayoutView(f"Error fetching account age: {str(e)}")
            await loading_msg.edit(embed=None, view=view)
    

    @commands.hybrid_command(name='multipleaccountage', aliases=['maccage'])
    async def multipleaccountage(self, ctx, *, user_list: str):
        """Shows account ages for multiple users from a formatted list with pagination"""
        premium_status = await self.bot.db.check_premium_user(ctx.author.id, ctx.guild.id)
        if not (premium_status and premium_status.get('has_premium')):
            view = PremiumRequiredLayoutView()
            return await ctx.send(view=view)
        
        loading_msg = await send_loading_message(ctx, "fetching multiple account ages")
        
        try:
            from Jo1nTrX.utils.helpers import format_account_age
            import re
            
            user_id_pattern = r'<@(\d+)>'
            user_ids = re.findall(user_id_pattern, user_list)
            
            if not user_ids:
                view = ErrorLayoutView("No user mentions found in the provided list.")
                await loading_msg.edit(embed=None, view=view)
                return

            processed_data = []
            
            for user_id in user_ids:
                try:
                    member = ctx.guild.get_member(int(user_id))
                    if not member:
                        member = await ctx.guild.fetch_member(int(user_id))
                    
                    if member:
                        account_age = format_account_age(member.created_at)
                        created_timestamp = int(member.created_at.timestamp())
                        
                        if hasattr(member, 'joined_at') and member.joined_at:
                            joined_timestamp = int(member.joined_at.timestamp())
                            processed_data.append({
                                'mention': member.mention,
                                'joined_timestamp': joined_timestamp,
                                'created_timestamp': created_timestamp,
                                'account_age': account_age,
                                'has_joined': True
                            })
                        else:
                            processed_data.append({
                                'mention': member.mention,
                                'joined_timestamp': None,
                                'created_timestamp': created_timestamp,
                                'account_age': account_age,
                                'has_joined': False
                            })
                    else:
                        processed_data.append({
                            'mention': f"<@{user_id}>",
                            'joined_timestamp': None,
                            'created_timestamp': None,
                            'account_age': "User not found",
                            'has_joined': False,
                            'error': True
                        })
                        
                except Exception as member_error:
                    processed_data.append({
                        'mention': f"<@{user_id}>",
                        'joined_timestamp': None,
                        'created_timestamp': None,
                        'account_age': f"Error: {str(member_error)}",
                        'has_joined': False,
                        'error': True
                    })
            
            total_pages = math.ceil(len(processed_data) / 10)
            view = MultipleAccountAgePaginationLayoutView(processed_data, 0, total_pages, ctx.author)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = ErrorLayoutView(f"Error processing multiple account ages: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

async def setup(bot):
    await bot.add_cog(InviteCommands(bot))
