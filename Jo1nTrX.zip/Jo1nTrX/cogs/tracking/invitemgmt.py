import discord
from datetime import datetime, timezone
from discord.ext import commands
from discord import app_commands, ui
from Jo1nTrX.utils.helpers import send_loading_message
from Jo1nTrX.utils.component import BaseView, bot_emoji
from Jo1nTrX.cogs.admin.admin_helper import (
    ARROW_EMOJI, SECTION_EMOJI, SUCCESS_EMOJI, ERROR_EMOJI, ADMIN_ICON,
    create_v2_view, create_success_content, create_error_content
)


class ClearConfirmationViewV2(ui.LayoutView):
    def __init__(self, ctx, clear_type):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.clear_type = clear_type
        self._setup_buttons()
    
    def _setup_buttons(self):
        confirm_btn = ui.Button(label='Confirm', style=discord.ButtonStyle.danger)
        cancel_btn = ui.Button(label='Cancel', style=discord.ButtonStyle.secondary)
        
        async def confirm_callback(interaction: discord.Interaction):
            if interaction.user.id != self.ctx.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            try:
                if self.clear_type == "guild":
                    await self.ctx.bot.db.clear_guild_invites(self.ctx.guild.id)
                    
                    content = f"""## {SUCCESS_EMOJI} Guild Invites Cleared
> All invite data has been cleared for **{self.ctx.guild.name}**!

{SECTION_EMOJI} **__Cleared Data__**

{ARROW_EMOJI} All member invite records deleted
{ARROW_EMOJI} All custom invite adjustments removed"""
                    
                    view = create_v2_view(content)
                    await interaction.response.edit_message(view=view)
            except Exception as e:
                error_view = create_v2_view(create_error_content("Error", f"Error clearing invites: {str(e)}"))
                await interaction.response.edit_message(view=error_view)
        
        async def cancel_callback(interaction: discord.Interaction):
            if interaction.user.id != self.ctx.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            content = f"""## {ERROR_EMOJI} Operation Cancelled
> No data was modified."""
            
            view = create_v2_view(content)
            await interaction.response.edit_message(view=view)
        
        confirm_btn.callback = confirm_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(confirm_btn, cancel_btn)
        self.add_item(button_row)


class AdminInviteCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    async def has_modrole_or_admin(self, ctx):
        if ctx.author.guild_permissions.administrator:
            return True, "admin"
        
        modrole_id = await self.bot.db.get_modrole(ctx.guild.id)
        if modrole_id:
            modrole = ctx.guild.get_role(modrole_id)
            if modrole and modrole in ctx.author.roles:
                return True, "modrole"
        
        return False, None
    
    @commands.hybrid_command(name='addinvites')
    @app_commands.describe(member='The member to add invites to', amount='Number of invites to add')
    @commands.has_permissions(administrator=True)
    async def addinvites(self, ctx, member: discord.Member, amount: int):
        """Adds a number of invites to a user!"""
        if amount <= 0:
            error_view = create_v2_view(create_error_content("Error", "Amount must be a positive number."))
            await ctx.send(view=error_view)
            return
        
        loading_msg = await send_loading_message(ctx, f"adding {amount} invites to {member.mention}")
        
        try:
            await self.bot.db.add_custom_invites(ctx.guild.id, member.id, amount)
            
            content = f"""## {SUCCESS_EMOJI} Invites Added
> Successfully added invites!

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Amount:** +{amount} invites"""
            
            view = create_v2_view(content)
            await loading_msg.edit(content=None, embed=None, view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error adding invites: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)
    
    @commands.hybrid_command(name='removeinvites')
    @app_commands.describe(member='The member to remove invites from', amount='Number of invites to remove')
    @commands.has_permissions(administrator=True)
    async def removeinvites(self, ctx, member: discord.Member, amount: int):
        """Removes a number of invites from a user!"""
        if amount <= 0:
            error_view = create_v2_view(create_error_content("Error", "Amount must be a positive number."))
            await ctx.send(view=error_view)
            return
        
        loading_msg = await send_loading_message(ctx, f"removing {amount} invites from {member.mention}")
        
        try:
            await self.bot.db.remove_custom_invites(ctx.guild.id, member.id, amount)
            
            content = f"""## {SUCCESS_EMOJI} Invites Removed
> Successfully removed invites!

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Amount:** -{amount} invites"""
            
            view = create_v2_view(content)
            await loading_msg.edit(content=None, embed=None, view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error removing invites: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)
    
    @commands.hybrid_command(name='clearinvites', aliases=['ci'])
    @app_commands.describe(target='The member to clear invites for, or "guild"/"server" to clear all (admin only)')
    async def clearinvites(self, ctx, target: str = None):
        """Removes all the invites entries of a member or guild from my database"""
        has_permission, permission_type = await self.has_modrole_or_admin(ctx)
        if not has_permission:
            error_view = create_v2_view(create_error_content("Permission Error", "You need the modrole or administrator permission to use this command."))
            await ctx.send(view=error_view)
            return
        
        if target is None:
            error_view = create_v2_view(create_error_content("Missing Target", "Please specify a member mention, 'guild', or 'server' to clear all invites."))
            await ctx.send(view=error_view)
            return
        
        if target.lower() in ['guild', 'server']:
            if permission_type != "admin":
                error_view = create_v2_view(create_error_content("Permission Error", "Only administrators can clear all guild invites. You can only clear individual user invites."))
                await ctx.send(view=error_view)
                return
            
            confirm_content = f"""## {ERROR_EMOJI} Confirm Guild Clear
> Are you sure you want to clear **ALL** invite data for **{ctx.guild.name}**?

{SECTION_EMOJI} **__This action:__**

{ARROW_EMOJI} Deletes all member invite records
{ARROW_EMOJI} Removes all custom invite adjustments
{ARROW_EMOJI} Cannot be undone

> Choose your action below:"""
            
            try:
                view = ClearConfirmationViewV2(ctx, "guild")
                view.add_item(ui.Container(ui.TextDisplay(confirm_content)))
                await ctx.send(view=view)
                return
            except Exception as e:
                error_view = create_v2_view(create_error_content("Error", f"Error creating confirmation dialog: {str(e)}"))
                await ctx.send(view=error_view)
                return
        
        loading_msg = await send_loading_message(ctx, f"clearing invites for {target}")
        
        try:
            try:
                member = await commands.MemberConverter().convert(ctx, target)
                await self.bot.db.clear_user_invites(ctx.guild.id, member.id)
                
                content = f"""## {SUCCESS_EMOJI} Member Invites Cleared
> All invite data has been cleared!

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}"""
                
                view = create_v2_view(content)
                await loading_msg.edit(content=None, embed=None, view=view)
            except commands.MemberNotFound:
                error_view = create_v2_view(create_error_content("Not Found", "Member not found. Use their mention, 'guild', or 'server' to clear all."))
                await loading_msg.edit(content=None, embed=None, view=error_view)
                return
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error clearing invites: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)
    
    @commands.hybrid_command(name='setinvites')
    @app_commands.describe(inviter='The member who invited the users', user_list='List of users with mentions')
    @commands.has_permissions(administrator=True)
    async def setinvites(self, ctx, inviter: discord.Member, *, user_list: str):
        """Sets multiple users as invites for a specific inviter from a formatted list"""
        premium_status = await self.bot.db.check_premium_user(ctx.author.id, ctx.guild.id)
        if not (premium_status and premium_status.get('has_premium')):
            error_view = create_v2_view(create_error_content("Premium Required", "This command is only available for premium users!\n\nGet premium access by joining our support server!"))
            return await ctx.send(view=error_view)
        
        loading_msg = await send_loading_message(ctx, f"setting invites for {inviter.mention}")
        
        try:
            import re
            
            user_id_pattern = r'<@(\d+)>'
            user_ids = re.findall(user_id_pattern, user_list)
            
            if not user_ids:
                error_view = create_v2_view(create_error_content("Error", "No user mentions found in the provided list."))
                await loading_msg.edit(content=None, embed=None, view=error_view)
                return
            
            if len(user_ids) > 50:
                error_view = create_v2_view(create_error_content("Error", "Maximum 50 users allowed at once."))
                await loading_msg.edit(content=None, embed=None, view=error_view)
                return
            
            successful_adds = []
            failed_adds = []
            already_assigned = []
            current_time = datetime.now(timezone.utc)
            
            for user_id in user_ids:
                try:
                    member = ctx.guild.get_member(int(user_id))
                    if not member:
                        try:
                            member = await ctx.guild.fetch_member(int(user_id))
                        except:
                            failed_adds.append(f"<@{user_id}> (not found in server)")
                            continue
                    
                    existing_inviter_id = await self.bot.db.check_user_has_inviter(ctx.guild.id, int(user_id))
                    if existing_inviter_id:
                        existing_inviter = ctx.guild.get_member(existing_inviter_id)
                        inviter_name = existing_inviter.display_name if existing_inviter else f"User ID {existing_inviter_id}"
                        already_assigned.append(f"{member.mention} (already assigned to {inviter_name})")
                        continue
                    
                    await self.bot.db.add_invite_record(
                        guild_id=ctx.guild.id,
                        user_id=int(user_id),
                        inviter_id=inviter.id,
                        invite_code="manual_set",
                        joined_at=current_time
                    )
                    
                    successful_adds.append(member.mention)
                    
                except Exception as member_error:
                    failed_adds.append(f"<@{user_id}> (error: {str(member_error)})")
            
            content_parts = [f"""## {SUCCESS_EMOJI} Set Invites Complete
> Successfully processed invite assignments!"""]
            
            if successful_adds:
                success_list = ', '.join(successful_adds[:10])
                extra = f"\n{ARROW_EMOJI} ... and {len(successful_adds) - 10} more" if len(successful_adds) > 10 else ""
                content_parts.append(f"""
{SECTION_EMOJI} **__Successfully Set ({len(successful_adds)})__**

{ARROW_EMOJI} Set {success_list} as invites for {inviter.mention}{extra}""")
            
            if already_assigned:
                assigned_list = '\n'.join([f"{ARROW_EMOJI} {a}" for a in already_assigned[:5]])
                extra = f"\n{ARROW_EMOJI} ... and {len(already_assigned) - 5} more" if len(already_assigned) > 5 else ""
                content_parts.append(f"""
{SECTION_EMOJI} **__Already Assigned ({len(already_assigned)})__**

{assigned_list}{extra}""")
            
            if failed_adds:
                failed_list = '\n'.join([f"{ARROW_EMOJI} {f}" for f in failed_adds[:5]])
                extra = f"\n{ARROW_EMOJI} ... and {len(failed_adds) - 5} more" if len(failed_adds) > 5 else ""
                content_parts.append(f"""
{SECTION_EMOJI} **__Failed ({len(failed_adds)})__**

{failed_list}{extra}""")
            
            content_parts.append(f"""
{SECTION_EMOJI} **__Monitoring Status__**

{ARROW_EMOJI} All successfully added users are now being monitored for invite tracking.""")
            
            view = create_v2_view('\n'.join(content_parts))
            await loading_msg.edit(content=None, embed=None, view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error setting invites: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)
    
    @commands.hybrid_command(name='unsetinvites')
    @app_commands.describe(inviter='The member to remove invites from', user_list='List of users with mentions to remove')
    @commands.has_permissions(administrator=True)
    async def unsetinvites(self, ctx, inviter: discord.Member, *, user_list: str):
        """Removes multiple users from a specific inviter's list"""
        loading_msg = await send_loading_message(ctx, f"removing invites from {inviter.mention}")
        
        try:
            import re
            
            user_id_pattern = r'<@(\d+)>'
            user_ids = re.findall(user_id_pattern, user_list)
            
            if not user_ids:
                error_view = create_v2_view(create_error_content("Error", "No user mentions found in the provided list."))
                await ctx.send(view=error_view)
                return
            
            if len(user_ids) > 50:
                error_view = create_v2_view(create_error_content("Error", "Maximum 50 users allowed at once."))
                await ctx.send(view=error_view)
                return
            
            successful_removes = []
            failed_removes = []
            not_assigned = []
            
            for user_id in user_ids:
                try:
                    member = ctx.guild.get_member(int(user_id))
                    if not member:
                        try:
                            member = await ctx.guild.fetch_member(int(user_id))
                        except:
                            failed_removes.append(f"<@{user_id}> (not found in server)")
                            continue
                    
                    existing_inviter_id = await self.bot.db.check_user_has_inviter(ctx.guild.id, int(user_id))
                    if not existing_inviter_id:
                        not_assigned.append(f"{member.mention} (not assigned to anyone)")
                        continue
                    elif existing_inviter_id != inviter.id:
                        existing_inviter = ctx.guild.get_member(existing_inviter_id)
                        inviter_name = existing_inviter.display_name if existing_inviter else f"User ID {existing_inviter_id}"
                        not_assigned.append(f"{member.mention} (assigned to {inviter_name}, not {inviter.display_name})")
                        continue
                    
                    success = await self.bot.db.remove_user_from_inviter(
                        guild_id=ctx.guild.id,
                        user_id=int(user_id),
                        inviter_id=inviter.id
                    )
                    
                    if success:
                        successful_removes.append(member.mention)
                    else:
                        failed_removes.append(f"{member.mention} (database error)")
                    
                except Exception as member_error:
                    failed_removes.append(f"<@{user_id}> (error: {str(member_error)})")
            
            content_parts = [f"""## {SUCCESS_EMOJI} Unset Invites Complete
> Successfully processed invite removals!"""]
            
            if successful_removes:
                success_list = ', '.join(successful_removes[:10])
                extra = f"\n{ARROW_EMOJI} ... and {len(successful_removes) - 10} more" if len(successful_removes) > 10 else ""
                content_parts.append(f"""
{SECTION_EMOJI} **__Successfully Removed ({len(successful_removes)})__**

{ARROW_EMOJI} Removed {success_list} from {inviter.mention}'s invites{extra}""")
            
            if not_assigned:
                not_assigned_list = '\n'.join([f"{ARROW_EMOJI} {n}" for n in not_assigned[:5]])
                extra = f"\n{ARROW_EMOJI} ... and {len(not_assigned) - 5} more" if len(not_assigned) > 5 else ""
                content_parts.append(f"""
{SECTION_EMOJI} **__Not Assigned to This Inviter ({len(not_assigned)})__**

{not_assigned_list}{extra}""")
            
            if failed_removes:
                failed_list = '\n'.join([f"{ARROW_EMOJI} {f}" for f in failed_removes[:5]])
                extra = f"\n{ARROW_EMOJI} ... and {len(failed_removes) - 5} more" if len(failed_removes) > 5 else ""
                content_parts.append(f"""
{SECTION_EMOJI} **__Failed ({len(failed_removes)})__**

{failed_list}{extra}""")
            
            if not successful_removes and not not_assigned and not failed_removes:
                content_parts = [f"""## {ERROR_EMOJI} Unset Invites Complete
> No operations performed."""]
            
            view = create_v2_view('\n'.join(content_parts))
            await ctx.send(view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error unsetting invites: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='modrole')
    @app_commands.describe(action='Setup action for modrole')
    @commands.has_permissions(administrator=True)
    async def modrole(self, ctx, action: str = None):
        """Setup modrole for invite management"""
        if not action or action.lower() != 'setup':
            content = f"""## {ADMIN_ICON} Modrole Command
> Usage: `+modrole setup` - Sets up a moderator role for invite management"""
            view = create_v2_view(content)
            await ctx.send(view=view)
            return
        
        try:
            existing_modrole_id = await self.bot.db.get_modrole(ctx.guild.id)
            if existing_modrole_id:
                existing_role = ctx.guild.get_role(existing_modrole_id)
                if existing_role:
                    content = f"""## {SUCCESS_EMOJI} Modrole Already Setup
> Modrole is already configured!

{SECTION_EMOJI} **__Current Configuration__**

{ARROW_EMOJI} **Role:** {existing_role.mention}
{ARROW_EMOJI} People with this role can use the `ci` command to clear user invites."""
                    view = create_v2_view(content)
                    await ctx.send(view=view)
                    return
            
            role = await ctx.guild.create_role(
                name="Jo1nTrX Mod",
                reason="Created by invite tracker bot for moderating invites"
            )
            
            await self.bot.db.set_modrole(ctx.guild.id, role.id)
            
            content = f"""## {SUCCESS_EMOJI} Modrole Setup Complete
> Successfully created modrole!

{SECTION_EMOJI} **__Configuration__**

{ARROW_EMOJI} **Role:** {role.mention}

{SECTION_EMOJI} **__Permissions__**

{ARROW_EMOJI} People with this role can clear **user invites** using the `ci` command
{ARROW_EMOJI} Administrator permission is still required to clear **server invites**"""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except discord.Forbidden:
            error_view = create_v2_view(create_error_content("Permission Error", "I don't have permission to create roles. Please check my permissions."))
            await ctx.send(view=error_view)
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error setting up modrole: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='refreshinvites')
    @commands.has_permissions(administrator=True)
    async def refreshinvites(self, ctx):
        """Force refresh the invite cache for the server"""
        try:
            invites = await ctx.guild.invites()
            await self.bot.db.cache_invites(ctx.guild.id, invites)
            
            invite_details = ""
            if invites:
                for invite in invites[:10]:
                    inviter_name = invite.inviter.display_name if invite.inviter else "Unknown"
                    invite_details += f"\n{ARROW_EMOJI} `{invite.code}` - {inviter_name} ({invite.uses} uses)"
            
            content = f"""## {SUCCESS_EMOJI} Invites Refreshed
> Cached {len(invites)} invites for this server!

{SECTION_EMOJI} **__Recent Invites (First 10)__**
{invite_details if invite_details else f"{ARROW_EMOJI} No invites found"}"""
            
            view = create_v2_view(content)
            await ctx.send(view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error refreshing invites: {str(e)}"))
            await ctx.send(view=error_view)
    
    @commands.hybrid_command(name='setinviter')
    @app_commands.describe(
        member='The member whose inviter to set',
        inviter='The member who invited them',
        invite_code='The invite code used (optional)'
    )
    @commands.has_permissions(administrator=True)
    async def setinviter(self, ctx, member: discord.Member, inviter: discord.Member, invite_code: str = None):
        """Manually set who invited a member"""
        loading_msg = await send_loading_message(ctx, f"setting inviter for {member.mention}")
        
        try:
            await self.bot.db.record_join(
                ctx.guild.id, 
                member.id, 
                inviter.id,
                invite_code or f"manual_{inviter.id}"
            )
            
            invite_code_line = f"\n{ARROW_EMOJI} **Invite Code:** `{invite_code}`" if invite_code else ""
            content = f"""## {SUCCESS_EMOJI} Inviter Set Successfully
> Set {inviter.mention} as the inviter for {member.mention}

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Inviter:** {inviter.mention}{invite_code_line}"""
            
            view = create_v2_view(content)
            await loading_msg.edit(content=None, embed=None, view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error setting inviter: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)
    
    @commands.hybrid_command(name='setvanity')
    @app_commands.describe(member='The member to mark as vanity join')
    @commands.has_permissions(administrator=True)
    async def setvanity(self, ctx, member: discord.Member):
        """Manually mark a member as joined via vanity URL (Admin only)"""
        loading_msg = await send_loading_message(ctx, f"marking {member.mention} as vanity join")
        
        try:
            await self.bot.db.record_join(
                ctx.guild.id, 
                member.id, 
                None,
                "VANITY"
            )
            
            content = f"""## {SUCCESS_EMOJI} Vanity Join Set
> Marked {member.mention} as joined via **Vanity URL**

{SECTION_EMOJI} **__Details__**

{ARROW_EMOJI} **Member:** {member.mention}
{ARROW_EMOJI} **Join Method:** Vanity URL"""
            
            view = create_v2_view(content)
            await loading_msg.edit(content=None, embed=None, view=view)
            
        except Exception as e:
            error_view = create_v2_view(create_error_content("Error", f"Error setting vanity join: {str(e)}"))
            await loading_msg.edit(content=None, embed=None, view=error_view)


async def setup(bot):
    await bot.add_cog(AdminInviteCommands(bot))
