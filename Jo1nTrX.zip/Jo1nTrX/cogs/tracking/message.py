import discord
from discord.ext import commands
from discord import app_commands, ui
from Jo1nTrX.utils.embeds import create_embed
from Jo1nTrX.utils.helpers import send_loading_message
from datetime import datetime, timedelta
import asyncio
import math
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)


class MessageStatsLayoutView(ui.LayoutView):
    def __init__(self, member: discord.Member, stats: dict):
        super().__init__(timeout=300)
        self.member = member
        self.stats = stats
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        dotz = "<a:Jo1nTrX_Dotz:1415025958251003994>"
        
        content = f"""## <:jo1nTrX_message:1448297267441172581> {self.member.display_name}'s Message Statistics
> Detailed message count for this user

{section} **__Daily__**
{dotz} {self.stats['daily']:,} messages

{section} **__Weekly__**
{dotz} {self.stats['weekly']:,} messages

{section} **__All time__**
{dotz} {self.stats['total']:,} messages"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class MessageSuccessLayoutView(ui.LayoutView):
    def __init__(self, title: str, description: str):
        super().__init__(timeout=300)
        self.title = title
        self.description = description
        self._setup_view()
    
    def _setup_view(self):
        content = f"""## <:jo1ntrx_tick:1405094884947267715> {self.title}
> {self.description}"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class MessageErrorLayoutView(ui.LayoutView):
    def __init__(self, title: str, description: str):
        super().__init__(timeout=300)
        self.title = title
        self.description = description
        self._setup_view()
    
    def _setup_view(self):
        content = f"""## <a:Jo1nTrX_cross:1405094904568483880> {self.title}
> {self.description}"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class MessageWarningLayoutView(ui.LayoutView):
    def __init__(self, title: str, description: str):
        super().__init__(timeout=300)
        self.title = title
        self.description = description
        self._setup_view()
    
    def _setup_view(self):
        content = f"""## <:Jo1nTrX_warning:1438450620402237542> {self.title}
> {self.description}"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class ConfirmClearLayoutView(ui.LayoutView):
    def __init__(self, ctx, bot, clear_type: str = "guild", member: discord.Member = None):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.bot = bot
        self.clear_type = clear_type
        self.member = member
        self.value = None
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:Jo1nTrX_warning:1438450620402237542> Confirmation Required
> Are you sure you want to clear **ALL** message data for this server?

{section} **__Warning__**
{arrow} This action cannot be undone.
{arrow} Click **Confirm** to proceed or **Cancel** to abort."""
        
        text_display = ui.TextDisplay(content)
        
        confirm_btn = ui.Button(label="Confirm", style=discord.ButtonStyle.danger)
        cancel_btn = ui.Button(label="Cancel", style=discord.ButtonStyle.secondary)
        
        async def confirm_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            
            await self.bot.db.clear_guild_messages(self.ctx.guild.id)
            success_view = MessageSuccessLayoutView("All Messages Cleared", "All message data for this server has been cleared.")
            await interaction.response.edit_message(view=success_view)
        
        async def cancel_callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            
            cancel_view = ui.LayoutView(timeout=60)
            cancel_content = """## <:jo1nTrX_message:1448297267441172581> Operation Cancelled
> Message clearing has been cancelled."""
            cancel_container = ui.Container(ui.TextDisplay(cancel_content))
            cancel_view.add_item(cancel_container)
            await interaction.response.edit_message(view=cancel_view)
        
        confirm_btn.callback = confirm_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(confirm_btn, cancel_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class BlacklistPaginationLayoutView(ui.LayoutView):
    def __init__(self, data: list, current_page: int, total_pages: int, title: str, author: discord.Member, format_type: str = "channel"):
        super().__init__(timeout=300)
        self.data = data
        self.current_page = current_page
        self.total_pages = total_pages
        self.title = title
        self.author = author
        self.format_type = format_type
        self.items_per_page = 15
        self._setup_view()
    
    def _get_page_data(self, page):
        start = page * self.items_per_page
        end = start + self.items_per_page
        return self.data[start:end]
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        page_data = self._get_page_data(self.current_page)
        
        content = f"""## <:jo1nTrX_message:1448297267441172581> {self.title}
> Page {self.current_page + 1} of {self.total_pages}

{section} **__Blacklisted {self.format_type.title()}s__**"""
        
        for item in page_data:
            content += f"\n{arrow} {item['display']}"
        
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = BlacklistPaginationLayoutView(self.data, 0, self.total_pages, self.title, self.author, self.format_type)
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = BlacklistPaginationLayoutView(self.data, max(0, self.current_page - 1), self.total_pages, self.title, self.author, self.format_type)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = BlacklistPaginationLayoutView(self.data, min(self.total_pages - 1, self.current_page + 1), self.total_pages, self.title, self.author, self.format_type)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = BlacklistPaginationLayoutView(self.data, self.total_pages - 1, self.total_pages, self.title, self.author, self.format_type)
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class MessageLeaderboardView(discord.ui.View):
    def __init__(self, data: list, current_page: int, total_pages: int, title: str, author: discord.Member, daily: bool = False):
        super().__init__(timeout=300)
        self.data = data
        self.current_page = current_page
        self.total_pages = total_pages
        self.title = title
        self.author = author
        self.daily = daily
        self.items_per_page = 10
        self._update_buttons()
    
    def _get_page_data(self, page):
        start = page * self.items_per_page
        end = start + self.items_per_page
        return self.data[start:end]
    
    def _update_buttons(self):
        self.first_btn.disabled = self.current_page == 0
        self.prev_btn.disabled = self.current_page == 0
        self.next_btn.disabled = self.current_page >= self.total_pages - 1
        self.last_btn.disabled = self.current_page >= self.total_pages - 1
    
    def create_embed(self):
        section = "<:jo1ntrx_right:1405095312456024127>"
        page_data = self._get_page_data(self.current_page)
        
        description = f"{section} **__Rankings__**\n"
        start_index = self.current_page * self.items_per_page
        for i, item in enumerate(page_data):
            global_rank = start_index + i + 1
            if self.daily:
                description += f"\n**{global_rank}.** {item['mention']} : **{item['daily_messages']:,}** messages today"
            else:
                description += f"\n**{global_rank}.** {item['mention']} : **{item['messages']:,}** messages"
        
        embed = discord.Embed(
            title=f"<:jo1nTrX_message:1448297267441172581> {self.title}",
            description=description,
            color=0x7c28eb
        )
        footer_text = f"Page {self.current_page + 1} of {self.total_pages}"
        if self.daily:
            footer_text += " | Daily stats reset at midnight UTC"
        embed.set_footer(text=footer_text)
        return embed
    
    @discord.ui.button(emoji='<:jo1ntrx_doubleleft:1405095487710691449>', style=discord.ButtonStyle.gray)
    async def first_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        self.current_page = 0
        self._update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)
    
    @discord.ui.button(emoji='<:jo1ntrx_left:1405095378231099464>', style=discord.ButtonStyle.gray)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        self.current_page = max(0, self.current_page - 1)
        self._update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)
    
    @discord.ui.button(emoji='<:jo1ntrx_delete:1405095625795702895>', style=discord.ButtonStyle.danger)
    async def delete_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        await interaction.message.delete()
    
    @discord.ui.button(emoji='<:jo1ntrx_right:1405095312456024127>', style=discord.ButtonStyle.gray)
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        self.current_page = min(self.total_pages - 1, self.current_page + 1)
        self._update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)
    
    @discord.ui.button(emoji='<:jo1ntrx_doubleright:1405095454395465790>', style=discord.ButtonStyle.gray)
    async def last_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
        self.current_page = self.total_pages - 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)


class MessageTrackingCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name='messages', aliases=['m'])
    @app_commands.describe(member='The member to check message count for')
    async def messages(self, ctx, member: discord.Member = None):
        """Displays the number of messages sent by you or a user"""
        if member is None:
            member = ctx.author
        
        loading_msg = await send_loading_message(ctx, f"fetching message count for {member.mention}")
        
        try:
            stats = await self.bot.db.get_user_message_stats(ctx.guild.id, member.id)
            view = MessageStatsLayoutView(member, stats)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to fetch message count: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='addmessages', aliases=['addm'])
    @app_commands.describe(member='The member to add messages to', amount='Number of messages to add')
    @commands.has_permissions(manage_guild=True)
    async def addmessages(self, ctx, member: discord.Member, amount: int):
        """Adds the specified number of messages to a user"""
        if amount <= 0:
            view = MessageErrorLayoutView("Invalid Amount", "Please specify a positive number of messages to add.")
            await ctx.send(view=view)
            return

        loading_msg = await send_loading_message(ctx, f"adding {amount:,} messages to {member.mention}")
        
        try:
            await self.bot.db.add_user_messages(ctx.guild.id, member.id, amount)
            new_count = await self.bot.db.get_user_messages(ctx.guild.id, member.id)
            
            view = MessageSuccessLayoutView("Messages Added", f"Added **{amount:,}** messages to {member.mention}.\nNew total: **{new_count['total']:,}** messages.")
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to add messages: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='removemessages', aliases=['removem'])
    @app_commands.describe(member='The member to remove messages from', amount='Number of messages to remove')
    @commands.has_permissions(manage_guild=True)
    async def removemessages(self, ctx, member: discord.Member, amount: int):
        """Removes the specified number of messages from a user"""
        if amount <= 0:
            view = MessageErrorLayoutView("Invalid Amount", "Please specify a positive number of messages to remove.")
            await ctx.send(view=view)
            return

        loading_msg = await send_loading_message(ctx, f"removing {amount:,} messages from {member.mention}")
        
        try:
            await self.bot.db.remove_user_messages(ctx.guild.id, member.id, amount)
            new_count = await self.bot.db.get_user_messages(ctx.guild.id, member.id)
            
            view = MessageSuccessLayoutView("Messages Removed", f"Removed **{amount:,}** messages from {member.mention}.\nNew total: **{new_count['total']:,}** messages.")
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to remove messages: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='blacklistchannel', aliases=['bl'])
    @app_commands.describe(channel='The channel to blacklist from message counting')
    @commands.has_permissions(manage_guild=True)
    async def blacklistchannel(self, ctx, channel: discord.TextChannel = None):
        """Blacklists a channel, bot won't count messages from that channel"""
        if channel is None:
            channel = ctx.channel
        
        loading_msg = await send_loading_message(ctx, f"blacklisting {channel.mention}")
        
        try:
            await self.bot.db.blacklist_channel(ctx.guild.id, channel.id)
            
            view = MessageSuccessLayoutView("Channel Blacklisted", f"Messages from {channel.mention} will no longer be counted.")
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to blacklist channel: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='unblacklistchannel', aliases=['unbl'])
    @app_commands.describe(channel='The channel to remove from blacklist')
    @commands.has_permissions(manage_guild=True)
    async def unblacklistchannel(self, ctx, channel: discord.TextChannel = None):
        """Unblacklists channel"""
        if channel is None:
            channel = ctx.channel
        
        loading_msg = await send_loading_message(ctx, f"unblacklisting {channel.mention}")
        
        try:
            await self.bot.db.unblacklist_channel(ctx.guild.id, channel.id)
            
            view = MessageSuccessLayoutView("Channel Unblacklisted", f"Messages from {channel.mention} will now be counted.")
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to unblacklist channel: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='blacklistedchannels', aliases=['blc'])
    async def blacklistedchannels(self, ctx):
        """Displays the blacklisted channels of a guild"""
        loading_msg = await send_loading_message(ctx, "fetching blacklisted channels")
        
        try:
            blacklisted_channels = await self.bot.db.get_blacklisted_channels(ctx.guild.id)
            
            if not blacklisted_channels:
                view = MessageWarningLayoutView("Blacklisted Channels", "No channels are currently blacklisted in this server.")
                await loading_msg.edit(embed=None, view=view)
                return
            
            processed_data = []
            for channel_id in blacklisted_channels:
                channel = ctx.guild.get_channel(channel_id)
                if channel:
                    processed_data.append({
                        'display': channel.mention,
                        'name': channel.name,
                        'id': channel_id
                    })
                else:
                    processed_data.append({
                        'display': f"Deleted Channel (`{channel_id}`)",
                        'name': 'Deleted Channel',
                        'id': channel_id
                    })
            
            total_pages = math.ceil(len(processed_data) / 15)
            view = BlacklistPaginationLayoutView(processed_data, 0, total_pages, "Blacklisted Channels", ctx.author, "channel")
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to fetch blacklisted channels: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='blacklistcategory', aliases=['blcat'])
    @app_commands.describe(category_id='The category ID to blacklist from message counting')
    @commands.has_permissions(manage_guild=True)
    async def blacklistcategory(self, ctx, category_id: str):
        """Blacklists a category, bot won't count messages from channels in that category"""
        loading_msg = await send_loading_message(ctx, f"blacklisting category")
        
        try:
            cat_id = int(category_id)
            category = ctx.guild.get_channel(cat_id)
            
            if not category or not isinstance(category, discord.CategoryChannel):
                view = MessageErrorLayoutView("Invalid Category", "Please provide a valid category ID.")
                await loading_msg.edit(embed=None, view=view)
                return
            
            await self.bot.db.blacklist_category(ctx.guild.id, cat_id)
            
            view = MessageSuccessLayoutView("Category Blacklisted", f"Messages from channels in **{category.name}** will no longer be counted.")
            await loading_msg.edit(embed=None, view=view)
            
        except ValueError:
            view = MessageErrorLayoutView("Invalid Category ID", "Please provide a valid category ID (numbers only).")
            await loading_msg.edit(embed=None, view=view)
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to blacklist category: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='unblacklistcategory', aliases=['unblcat'])
    @app_commands.describe(category_id='The category ID to remove from blacklist')
    @commands.has_permissions(manage_guild=True)
    async def unblacklistcategory(self, ctx, category_id: str):
        """Unblacklists a category"""
        loading_msg = await send_loading_message(ctx, f"unblacklisting category")
        
        try:
            cat_id = int(category_id)
            category = ctx.guild.get_channel(cat_id)
            
            if not category or not isinstance(category, discord.CategoryChannel):
                view = MessageErrorLayoutView("Invalid Category", "Please provide a valid category ID.")
                await loading_msg.edit(embed=None, view=view)
                return
            
            await self.bot.db.unblacklist_category(ctx.guild.id, cat_id)
            
            view = MessageSuccessLayoutView("Category Unblacklisted", f"Messages from channels in **{category.name}** will now be counted.")
            await loading_msg.edit(embed=None, view=view)
            
        except ValueError:
            view = MessageErrorLayoutView("Invalid Category ID", "Please provide a valid category ID (numbers only).")
            await loading_msg.edit(embed=None, view=view)
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to unblacklist category: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='blacklistedcategories', aliases=['blcats'])
    async def blacklistedcategories(self, ctx):
        """Displays the blacklisted categories of a guild"""
        loading_msg = await send_loading_message(ctx, "fetching blacklisted categories")
        
        try:
            blacklisted_categories = await self.bot.db.get_blacklisted_categories(ctx.guild.id)
            
            if not blacklisted_categories:
                view = MessageWarningLayoutView("Blacklisted Categories", "No categories are currently blacklisted in this server.")
                await loading_msg.edit(embed=None, view=view)
                return
            
            processed_data = []
            for category_id in blacklisted_categories:
                category = ctx.guild.get_channel(category_id)
                if category:
                    processed_data.append({
                        'display': f"**{category.name}** (`{category_id}`)",
                        'name': category.name,
                        'id': category_id
                    })
                else:
                    processed_data.append({
                        'display': f"Deleted Category (`{category_id}`)",
                        'name': 'Deleted Category',
                        'id': category_id
                    })
            
            total_pages = math.ceil(len(processed_data) / 15)
            view = BlacklistPaginationLayoutView(processed_data, 0, total_pages, "Blacklisted Categories", ctx.author, "category")
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to fetch blacklisted categories: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    async def has_modrole_or_admin(self, ctx):
        """Check if user has modrole or administrator permissions"""
        if ctx.author.guild_permissions.administrator:
            return True, "admin"
        
        if ctx.author.guild_permissions.manage_guild:
            return True, "manage_guild"
        
        modrole_id = await self.bot.db.get_modrole(ctx.guild.id)
        if modrole_id:
            modrole = ctx.guild.get_role(modrole_id)
            if modrole and modrole in ctx.author.roles:
                return True, "modrole"
        
        return False, None

    def _check_hierarchy(self, ctx, member):
        """Check if user can moderate the target member based on role hierarchy"""
        if member == ctx.author:
            return True, None
        
        if member == ctx.guild.owner:
            return False, "Cannot clear data for the server owner."
        
        if ctx.author != ctx.guild.owner and member.top_role >= ctx.author.top_role:
            return False, "You cannot clear data for someone with a higher or equal role."
        
        return True, None

    @commands.hybrid_command(name='clearmessages', aliases=['clrmsg'])
    @app_commands.describe(member='The member to clear messages for (leave empty to clear all)')
    async def clearmessages(self, ctx, member: discord.Member = None):
        """Removes all the messages entries of a member or of a guild's from database"""
        has_permission, permission_type = await self.has_modrole_or_admin(ctx)
        if not has_permission:
            view = MessageErrorLayoutView("Permission Error", "You need the modrole, manage server permission, or administrator permission to use this command.")
            await ctx.send(view=view)
            return
        
        if member:
            if permission_type == "modrole":
                can_clear, error_msg = self._check_hierarchy(ctx, member)
                if not can_clear:
                    view = MessageErrorLayoutView("Hierarchy Error", error_msg)
                    await ctx.send(view=view)
                    return
            
            loading_msg = await send_loading_message(ctx, f"clearing messages for {member.mention}")
            
            try:
                await self.bot.db.clear_user_messages(ctx.guild.id, member.id)
                
                view = MessageSuccessLayoutView("Messages Cleared", f"All message data for {member.mention} has been cleared.")
                await loading_msg.edit(embed=None, view=view)
                
            except Exception as e:
                view = MessageErrorLayoutView("Error", f"Failed to clear messages: {str(e)}")
                await loading_msg.edit(embed=None, view=view)
        else:
            if permission_type == "modrole":
                view = MessageErrorLayoutView("Permission Error", "Modrole users can only clear message data for individual members, not the entire guild.\nPlease specify a member to clear messages for.")
                await ctx.send(view=view)
                return
            
            view = ConfirmClearLayoutView(ctx, self.bot)
            await ctx.send(view=view)

    @commands.hybrid_command(name='resetmymessages', aliases=['rmm'])
    async def resetmymessages(self, ctx):
        """Clears your own messages of a guild"""
        loading_msg = await send_loading_message(ctx, "clearing your message data")
        
        try:
            await self.bot.db.clear_user_messages(ctx.guild.id, ctx.author.id)
            
            view = MessageSuccessLayoutView("Your Messages Cleared", "Your message data for this server has been cleared.")
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to clear your messages: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='leaderboard_messages', aliases=['lbm', 'lb m'])
    async def leaderboard_messages(self, ctx):
        """Displays the top 10 messengers of a guild"""
        loading_msg = await send_loading_message(ctx, "fetching the message leaderboard")
        
        try:
            leaderboard_data = await self.bot.db.get_message_leaderboard(ctx.guild.id, 'all', 1000)
            
            if not leaderboard_data:
                view = MessageWarningLayoutView("Message Leaderboard", "No message data found for this server.")
                await loading_msg.edit(embed=None, view=view)
                return
            
            processed_data = []
            for user_id, message_count in leaderboard_data:
                member = ctx.guild.get_member(user_id)
                user_mention = member.mention if member else f"<@{user_id}>"
                processed_data.append({
                    'mention': user_mention,
                    'messages': message_count
                })
            
            total_pages = math.ceil(len(processed_data) / 10)
            view = MessageLeaderboardView(processed_data, 0, total_pages, "Message Leaderboard", ctx.author, daily=False)
            await loading_msg.edit(embed=view.create_embed(), view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to fetch message leaderboard: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='leaderboard_dailymessages', aliases=['lbdm'])
    async def leaderboard_dailymessages(self, ctx):
        """Displays the top 10 daily messengers of a guild"""
        loading_msg = await send_loading_message(ctx, "fetching the daily message leaderboard")
        
        try:
            leaderboard_data = await self.bot.db.get_daily_message_leaderboard(ctx.guild.id, 1000)
            
            if not leaderboard_data:
                view = MessageWarningLayoutView("Daily Message Leaderboard", "No daily message data found for this server.")
                await loading_msg.edit(embed=None, view=view)
                return
            
            processed_data = []
            for user_id, daily_count in leaderboard_data:
                member = ctx.guild.get_member(user_id)
                user_mention = member.mention if member else f"<@{user_id}>"
                processed_data.append({
                    'mention': user_mention,
                    'daily_messages': daily_count
                })
            
            total_pages = math.ceil(len(processed_data) / 10)
            view = MessageLeaderboardView(processed_data, 0, total_pages, "Daily Message Leaderboard", ctx.author, daily=True)
            await loading_msg.edit(embed=view.create_embed(), view=view)
            
        except Exception as e:
            view = MessageErrorLayoutView("Error", f"Failed to fetch daily message leaderboard: {str(e)}")
            await loading_msg.edit(embed=None, view=view)

async def setup(bot):
    await bot.add_cog(MessageTrackingCommands(bot))
