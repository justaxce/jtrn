import discord
from discord.ext import commands
from discord import app_commands
import asyncio
from datetime import datetime, timezone, timedelta
import json
import os
import io
import pytz
import time
import traceback
import aiohttp
import base64
import re
from Jo1nTrX.utils.embeds import create_embed
from Jo1nTrX.utils.emoji_manager import emoji
from Jo1nTrX.core.ticket_database_handler import TicketDatabaseHandler
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)

def validate_emoji(emoji_value):
    """Validate emoji value for Discord API compatibility.
    
    Discord accepts:
    - Valid Unicode emojis (single characters or emoji sequences)
    - Custom emoji format: <:name:id> or <a:name:id>
    - None for no emoji
    
    Returns None if emoji is invalid or empty.
    """
    if not emoji_value:
        return None
    
    # Convert to string and strip whitespace
    emoji_str = str(emoji_value).strip()
    
    if not emoji_str:
        return None
    
    # Check if it's a custom emoji format: <:name:id> or <a:name:id>
    if re.match(r'^<a?:\w+:\d+>$', emoji_str):
        return emoji_str
    
    # For Unicode emojis, just return as-is (Discord validates these internally)
    # Single character emojis or emoji sequences are valid
    if len(emoji_str) <= 2 or not emoji_str.startswith('<'):
        return emoji_str
    
    # Invalid format
    return None

class TicketConfig(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db_handler = TicketDatabaseHandler(bot.db)

    async def load_ticket_config(self, guild_id, global_panel_id=None, create_new=False):
        """Load ticket configuration for a guild from database"""
        try:
            if global_panel_id:
                # Load specific panel by global_panel_id
                return await self.get_panel_by_global_id(global_panel_id)
            elif create_new:
                # Return empty config for creating a new panel
                return {}
            else:
                # Load most recent panel (highest global_panel_id)
                panels = self.db_handler.get_panels(guild_id)
                if panels:
                    # Find the panel with the highest global_panel_id
                    latest_panel_id = None
                    latest_global_id = 0

                    for panel_id, panel_data in panels.items():
                        panel_global_id = panel_data.get('global_panel_id', 0)
                        if panel_global_id > latest_global_id:
                            latest_global_id = panel_global_id
                            latest_panel_id = panel_id

                    if latest_panel_id:
                        latest_panel = panels[latest_panel_id]
                        # Only copy basic configuration, NOT categories
                        panel_data = {
                            'panel_channel': latest_panel.get('panel_channel'),
                            'log_channel': latest_panel.get('log_channel'),
                            'closed_category': latest_panel.get('closed_category'),
                            'ticket_embed': latest_panel.get('ticket_embed'),
                            'panel_type': latest_panel.get('panel_type'),
                            'categories': []  # Always start with empty categories for new panels
                        }
                        return panel_data
        except Exception as e:
            print(f'Error loading ticket config: {e}')
        return {}

    async def get_panel_by_global_id(self, global_panel_id):
        """Get panel configuration by global panel ID"""
        try:
            all_panels = self.db_handler.get_all_panels()
            for guild_id, guild_panels in all_panels.items():
                for panel_id, panel_data in guild_panels.items():
                    if panel_data.get('global_panel_id') == global_panel_id:
                        # Categories are already stored in panel_data, no need to load separately
                        if 'categories' not in panel_data:
                            panel_data['categories'] = []
                        return panel_data
        except Exception as e:
            print(f'Error getting panel by global ID: {e}')
        return None

    async def delete_panel_by_global_id(self, global_panel_id):
        """Delete panel by global panel ID"""
        try:
            all_panels = self.db_handler.get_all_panels()
            for guild_id, guild_panels in all_panels.items():
                for panel_id, panel_data in guild_panels.items():
                    if panel_data.get('global_panel_id') == global_panel_id:
                        self.db_handler.delete_panel(int(guild_id), panel_id)
                        return True
            return False
        except Exception as e:
            print(f'Error deleting panel: {e}')
            return False

    async def get_all_panels(self, guild_id):
        """Get all ticket panels for a guild"""
        try:
            panels = self.db_handler.get_panels(guild_id)
            result_panels = []
            for panel_id, panel_data in panels.items():
                # Categories are already stored in panel_data, no need to load separately
                if 'categories' not in panel_data:
                    panel_data['categories'] = []
                result_panels.append(panel_data)
            return result_panels
        except Exception as e:
            print(f'Error getting all panels: {e}')
            return []

    async def get_next_global_panel_id(self):
        """Get the next available global panel ID"""
        try:
            all_panels = self.db_handler.get_all_panels()
            max_id = 0
            for guild_panels in all_panels.values():
                for panel_data in guild_panels.values():
                    panel_id = panel_data.get('global_panel_id', 0)
                    if panel_id > max_id:
                        max_id = panel_id
            return max_id + 1
        except Exception as e:
            print(f'Error getting next panel ID: {e}')
            return 1


    async def save_ticket_config(self, guild_id, config_data, panel_id=None):
        """Save ticket configuration - always creates new panel unless panel_id is provided for updates"""
        try:
            if panel_id:
                # Update existing panel
                global_panel_id = panel_id
            else:
                # Create new panel
                global_panel_id = await self.get_next_global_panel_id()

            # Add guild_id and global_panel_id to config data
            config_data['guild_id'] = guild_id
            config_data['global_panel_id'] = global_panel_id
            config_data['created_at'] = datetime.now().isoformat()

            # Generate a unique panel_id for JSON storage
            json_panel_id = f"panel_{global_panel_id}"

            # Save panel data (categories are already included in config_data)
            self.db_handler.save_panel(guild_id, json_panel_id, config_data)

            return global_panel_id
        except Exception as e:
            print(f'Error saving ticket config: {e}')
            return False

    async def load_ticket_categories(self, guild_id, panel_id=None):
        """Load ticket categories for a guild or specific panel with enhanced debugging"""
        try:
            if panel_id:
                # Extract numeric global_panel_id
                if isinstance(panel_id, int):
                    global_panel_id = panel_id
                    json_panel_id = f"panel_{panel_id}"
                else:
                    # panel_id is a string like "panel_42"
                    global_panel_id = int(panel_id.replace('panel_', ''))
                    json_panel_id = panel_id

                # Pass numeric global_panel_id to get_categories
                categories = self.db_handler.get_categories(guild_id, global_panel_id)

                # If no categories found via get_categories, try direct panel data access
                if not categories:
                    print(f"⚠️  No categories via get_categories, trying direct panel data access...")
                    panels = self.db_handler.get_panels(guild_id)
                    panel_data = panels.get(json_panel_id, {})
                    categories = panel_data.get('categories', [])

                return categories if isinstance(categories, list) else []
            else:
                return []
        except Exception as e:
            print(f'❌ Error loading ticket categories: {e}')
            import traceback
            traceback.print_exc()
            return []

    async def save_ticket_categories(self, panel_id, categories):
        """Save ticket categories for a specific panel"""
        try:
            # Find the guild_id for this panel from database data
            all_panels = self.db_handler.get_all_panels()
            guild_id = None
            json_panel_id = None

            for g_id, guild_panels in all_panels.items():
                for p_id, panel_data in guild_panels.items():
                    if panel_data.get('global_panel_id') == panel_id:
                        guild_id = int(g_id)
                        json_panel_id = p_id
                        break
                if guild_id:
                    break

            if not guild_id or not json_panel_id:
                return False

            # Save categories using JSON handler
            formatted_categories = []
            for i, category in enumerate(categories):
                formatted_category = {
                    'name': category['name'],
                    'emoji': category['emoji'],
                    'description': category['description'],
                    'category_id': category.get('category_id'),
                    'support_role_id': category.get('support_role_id'),
                    'ping_support': category.get('ping_support', False),
                    'category_order': i
                }
                formatted_categories.append(formatted_category)

            # Update panel data to include categories
            panel_data = self.db_handler.get_panels(guild_id).get(json_panel_id, {})
            panel_data['categories'] = formatted_categories
            self.db_handler.save_panel(guild_id, json_panel_id, panel_data)

            return True
        except Exception as e:
            print(f'Error saving ticket categories: {e}')
            return False

    # Configuration Locking System
    config_locks = {}  # Dictionary to store active configuration locks

    async def is_config_locked(self, guild_id):
        """Check if configuration is locked for this guild"""
        try:
            lock_info = self.config_locks.get(guild_id)
            if lock_info:
                # Check if lock has timed out (30 minutes)
                import time
                if time.time() - lock_info['timestamp'] > 1800:  # 30 minutes in seconds
                    del self.config_locks[guild_id]
                    return False, None
                return True, lock_info
            return False, None
        except Exception as e:
            print(f'Error checking config lock: {e}')
            return False, None

    async def set_config_lock(self, guild_id, user_id, channel_id):
        """Set configuration lock for this guild"""
        try:
            import time
            self.config_locks[guild_id] = {
                'user_id': user_id,
                'channel_id': channel_id,
                'timestamp': time.time()
            }
            return True
        except Exception as e:
            print(f'Error setting config lock: {e}')
            return False

    async def clear_config_lock(self, guild_id):
        """Clear configuration lock for this guild"""
        try:
            if guild_id in self.config_locks:
                del self.config_locks[guild_id]
            return True
        except Exception as e:
            print(f'Error clearing config lock: {e}')
            return False

    async def get_lock_error_message(self, guild_id):
        """Get user-friendly error message when configuration is locked"""
        try:
            is_locked, lock_info = await self.is_config_locked(guild_id)
            if is_locked and lock_info:
                user = self.bot.get_user(lock_info['user_id'])
                username = user.display_name if user else "Unknown User"
                return (f"<:jo1ntrx_cross:1405094904568483880> **Configuration in Progress**\n\n"
                       f"Another user ({username}) is currently configuring ticket settings for this server. "
                       f"Please wait for them to finish or for the configuration to timeout (30 minutes) before starting a new setup.")
            return "<:jo1ntrx_cross:1405094904568483880> Configuration is currently locked. Please try again later."
        except Exception as e:
            pass
            return "<:jo1ntrx_cross:1405094904568483880> Configuration is currently locked. Please try again later."


    async def get_next_ticket_number(self, guild_id, category_name):
        """Get the next ticket number for a specific category in a guild"""
        try:
            # Get active tickets from database
            active_tickets = self.db_handler.get_all_active_tickets()
            guild_tickets = active_tickets.get(str(guild_id), {})

            max_ticket_number = 0
            for ticket_data in guild_tickets.values():
                if ticket_data.get('category_name') == category_name:
                    ticket_number = ticket_data.get('ticket_number', 0)
                    if ticket_number > max_ticket_number:
                        max_ticket_number = ticket_number

            # Return next number (starting from 1)
            return max_ticket_number + 1
        except Exception as e:
            print(f'Error getting next ticket number: {e}')
            return 1

    async def log_ticket_closure(self, guild, ticket_info, action, staff_member):
        """Enhanced logging for ticket closure/deletion with transcript"""
        config = await self.load_ticket_config(guild.id)
        log_channel_id = config.get('log_channel')

        if not log_channel_id:
            return

        log_channel = guild.get_channel(log_channel_id)
        if not log_channel:
            return

        # Get IST timezone
        ist = pytz.timezone('Asia/Kolkata')

        # Get ticket creation time from database
        creation_time_ist = "Unknown"
        if ticket_info:
            try:
                # Get creation time from database ticket data
                channel_id = ticket_info.get('channel_id')
                if channel_id:
                    ticket_data = self.db_handler.get_active_ticket(ticket_info.get('guild_id', 0), channel_id)
                    created_at = ticket_data.get('created_at')

                    if created_at:
                        # Convert timestamp to IST with proper timezone handling
                        if isinstance(created_at, str):
                            utc_time = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                        else:
                            utc_time = created_at

                        # Ensure timezone is properly set to UTC if naive datetime
                        if utc_time.tzinfo is None:
                            from datetime import timezone
                            utc_time = utc_time.replace(tzinfo=timezone.utc)

                    creation_time_ist = utc_time.astimezone(ist).strftime('%A, %B %d, %Y %I:%M %p IST')
            except Exception as e:
                creation_time_ist = "Unknown"

        # Get ticket owner
        ticket_owner = guild.get_member(ticket_info['user_id']) if ticket_info else None
        ticket_owner_mention = ticket_owner.mention if ticket_owner else "Unknown User"

        # Get claim status from database data
        claimed_by_id = None
        if ticket_info:
            # Get ticket data from database to check claim status
            guild_id = ticket_info.get('guild_id', guild.id)
            channel_id = ticket_info.get('channel_id')
            if channel_id:
                ticket_data = self.db_handler.get_active_ticket(guild_id, channel_id)
                claimed_by_id = ticket_data.get('claimed_by')

        if claimed_by_id:
            claimed_user = guild.get_member(claimed_by_id)
            claim_status = f"Claimed by {claimed_user.mention if claimed_user else 'Unknown User'}"
        else:
            claim_status = "Unclaimed"

        # Create the log embed with standard format
        embed = EmbedFactory.create(
            title=f"<:Jo1nTrX_lock_1:1412701461749563463> Ticket {action}",
            timestamp=False
        )

        # Get current IST time for deletion timing
        current_time_ist = datetime.now(ist).strftime('%A, %B %d, %Y %I:%M %p IST')

        embed.add_field(name="➛ Opened by:", value=ticket_owner_mention, inline=False)
        embed.add_field(name="➛ Creation time:", value=creation_time_ist, inline=False)
        embed.add_field(name=f"➛ {action} by:", value=staff_member.mention, inline=False)
        embed.add_field(name=f"➛ {action} time:", value=current_time_ist, inline=False)
        embed.add_field(name="➛ Claim status:", value=claim_status, inline=False)

        embed.set_footer(text="Jo1nTrX™ - Ticket System")

        await log_channel.send(embed=embed)

    async def download_attachment_as_base64(self, url):
        """Download attachment from URL and convert to base64"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.read()
                        return base64.b64encode(data).decode('utf-8')
        except Exception as e:
            print(f"Error downloading attachment: {e}")
        return None

    def process_message_content(self, content, message):
        """Process message content to handle emojis and mentions"""
        try:
            # Replace custom emoji format with HTML img tags
            import re

            # Handle custom emojis: <:name:id> or <a:name:id>
            emoji_pattern = r'<a?:([^:]+):(\d+)>'
            def replace_emoji(match):
                emoji_id = match.group(2)
                emoji_name = match.group(1)
                emoji_url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{'gif' if match.group(0).startswith('<a:') else 'png'}"
                return f'<img src="{emoji_url}" alt="{emoji_name}" title="{emoji_name}" style="height: 1.375em; vertical-align: middle;">'

            content = re.sub(emoji_pattern, replace_emoji, content)

            # Handle user mentions: <@id> or <@!id>
            mention_pattern = r'<@!?(\d+)>'
            def replace_mention(match):
                user_id = match.group(1)
                user = self.bot.get_user(int(user_id))
                if user:
                    return f'<span class="mention">@{user.name}</span>'
                return f'<span class="mention">@Unknown User</span>'

            content = re.sub(mention_pattern, replace_mention, content)

            # Handle role mentions: <@&id>
            role_pattern = r'<@&(\d+)>'
            def replace_role(match):
                role_id = match.group(1)
                role = message.guild.get_role(int(role_id)) if message.guild else None
                if role:
                    return f'<span class="mention">@{role.name}</span>'
                return f'<span class="mention">@Unknown Role</span>'

            content = re.sub(role_pattern, replace_role, content)

            return content
        except Exception as e:
            print(f"Error processing message content: {e}")
            return content

    async def generate_ticket_transcript(self, channel, ticket_info):
        """Generate an HTML transcript of the ticket with Jo1nTrX theme"""
        try:
            ist = pytz.timezone('Asia/Kolkata')

            # Get ticket info
            ticket_owner = channel.guild.get_member(ticket_info['user_id']) if ticket_info else None
            guild_id = channel.guild.id if channel.guild else ticket_info.get('guild_id')
            created_at = None

            if guild_id:
                ticket_data = self.db_handler.get_active_ticket(guild_id, channel.id)
                created_at = ticket_data.get('created_at') if ticket_data else None

            if isinstance(created_at, str):
                created_at = datetime.fromisoformat(created_at.replace('Z', '+00:00'))

            creation_time_ist = created_at.astimezone(ist).strftime('%A, %B %d, %Y %I:%M %p IST') if created_at else 'Unknown'

            # Fetch all messages
            messages = []
            async for message in channel.history(limit=None, oldest_first=True):
                messages.append(message)

            # Jo1nTrX Theme Colors
            primary_color = '#7c28eb'  # Purple
            background = '#1a1b1e'
            message_bg = '#2a2d31'
            header_bg = '#1a1b1e'

            # Start building HTML
            html_lines = []
            html_lines.append('<!DOCTYPE html>')
            html_lines.append('<html lang="en">')
            html_lines.append('<head>')
            html_lines.append('  <meta charset="UTF-8">')
            html_lines.append('  <meta name="viewport" content="width=device-width, initial-scale=1.0">')
            html_lines.append('  <title>Ticket Transcript - ' + channel.name + '</title>')
            html_lines.append('  <style>')
            html_lines.append('    @keyframes twinkle1 { 0%, 100% { opacity: 0.3; } 50% { opacity: 1; } }')
            html_lines.append('    @keyframes twinkle2 { 0%, 100% { opacity: 0.4; } 50% { opacity: 0.9; } }')
            html_lines.append('    @keyframes twinkle3 { 0%, 100% { opacity: 0.2; } 50% { opacity: 0.8; } }')
            html_lines.append('    @keyframes twinkle4 { 0%, 100% { opacity: 0.5; } 50% { opacity: 1; } }')
            html_lines.append('    @keyframes twinkle5 { 0%, 100% { opacity: 0.3; } 50% { opacity: 0.95; } }')
            html_lines.append('    @keyframes glow { 0%, 100% { box-shadow: 0 0 10px rgba(124, 40, 235, 0.3), inset 0 0 10px rgba(124, 40, 235, 0.1); } 50% { box-shadow: 0 0 20px rgba(124, 40, 235, 0.6), inset 0 0 15px rgba(124, 40, 235, 0.2); } }')
            html_lines.append('    * { margin: 0; padding: 0; box-sizing: border-box; }')
            html_lines.append('    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; background: #000000; color: #e4e6eb; line-height: 1.5; position: relative; overflow-x: hidden; }')
            html_lines.append('    body::before { content: ""; position: fixed; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 1; box-shadow: 1px 1px 0 white, 5px 2px 0 white, 8px 5px 0 white, 12px 8px 0 white, 15px 3px 0 white, 22px 10px 0 white, 30px 6px 0 white, 35px 15px 0 white, 42px 9px 0 white, 50px 20px 0 white, 58px 5px 0 white, 65px 18px 0 white, 72px 12px 0 white, 80px 25px 0 white, 88px 8px 0 white, 95px 30px 0 white, 5% 30% 0 white, 15% 45% 0 white, 25% 35% 0 white, 35% 50% 0 white, 45% 42% 0 white, 55% 55% 0 white, 65% 48% 0 white, 75% 60% 0 white, 85% 52% 0 white, 92% 65% 0 white, 10% 70% 0 white, 30% 80% 0 white, 50% 85% 0 white, 70% 75% 0 white, 88% 88% 0 white; animation: twinkle1 3s ease-in-out infinite, twinkle2 4.5s ease-in-out infinite, twinkle3 2.5s ease-in-out infinite, twinkle4 5s ease-in-out infinite, twinkle5 3.5s ease-in-out infinite; }')
            html_lines.append('    .container { max-width: 950px; margin: 0 auto; padding: 20px; position: relative; z-index: 2; }')
            html_lines.append(f'    .header {{ background: rgba(26, 27, 30, 0.95); border-radius: 8px; padding: 24px; margin-bottom: 20px; border-left: 5px solid {primary_color}; }}')
            html_lines.append('    .header h1 { color: #ffffff; margin-bottom: 16px; font-size: 24px; }')
            html_lines.append('    .header-info { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; font-size: 14px; }')
            html_lines.append('    .header-info div { display: flex; flex-direction: column; }')
            html_lines.append(f'    .header-info label {{ color: {primary_color}; font-weight: 600; margin-bottom: 6px; }}')
            html_lines.append('    .header-info value { color: #e4e6eb; }')
            html_lines.append('    .messages { display: flex; flex-direction: column; gap: 8px; }')
            html_lines.append(f'    .message {{ background: rgba(42, 45, 49, 0.95); padding: 14px 16px; border-radius: 6px; margin-bottom: 8px; border: 2px solid ' + primary_color + '; animation: glow 3s ease-in-out infinite; }}')
            html_lines.append('    .message:hover { border-color: #ff00ff; }')
            html_lines.append('    .message.bot { border-color: ' + primary_color + '; }')
            html_lines.append('    .message-header { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }')
            html_lines.append('    .avatar { width: 36px; height: 36px; border-radius: 50%; flex-shrink: 0; }')
            html_lines.append('    .author { font-weight: 600; color: #ffffff; }')
            html_lines.append('    .bot-badge { background: ' + primary_color + '; color: white; padding: 2px 6px; border-radius: 3px; font-size: 11px; font-weight: 600; margin-left: 6px; }')
            html_lines.append('    .timestamp { font-size: 12px; color: #949ba4; margin-left: auto; }')
            html_lines.append('    .message-content { color: #e4e6eb; word-wrap: break-word; white-space: pre-wrap; margin-top: 4px; }')
            html_lines.append('    .mention { color: ' + primary_color + '; font-weight: 500; }')
            html_lines.append('    .attachments { margin-top: 12px; display: flex; flex-wrap: wrap; gap: 10px; }')
            html_lines.append('    .attachment { background: rgba(26, 27, 30, 0.95); border-radius: 6px; padding: 10px; border: 1px solid #404249; }')
            html_lines.append('    .attachment-link { color: #00b0f4; text-decoration: none; word-break: break-all; }')
            html_lines.append('    .attachment-link:hover { text-decoration: underline; }')
            html_lines.append('    .attachment-image { max-width: 100%; max-height: 400px; border-radius: 6px; cursor: pointer; }')
            html_lines.append('    .attachment-file { color: #949ba4; font-size: 12px; margin-top: 6px; }')
            html_lines.append('    .sticker { max-width: 200px; height: auto; margin: 8px 0; }')
            html_lines.append(f'    .embed {{ background: rgba(26, 27, 30, 0.95); border-left: 4px solid {primary_color}; border-radius: 6px; padding: 14px; margin-top: 10px; }}')
            html_lines.append('    .embed-title { color: #ffffff; font-weight: 700; font-size: 15px; margin-bottom: 8px; }')
            html_lines.append('    .embed-description { color: #e4e6eb; margin-bottom: 10px; }')
            html_lines.append('    .embed-field { margin-bottom: 8px; }')
            html_lines.append('    .embed-field-name { color: #ffffff; font-weight: 600; font-size: 13px; margin-bottom: 4px; }')
            html_lines.append('    .embed-field-value { color: #e4e6eb; font-size: 13px; }')
            html_lines.append('    .embed-image { max-width: 100%; border-radius: 4px; margin-top: 10px; }')
            html_lines.append('    .embed-footer { font-size: 12px; color: #949ba4; margin-top: 10px; padding-top: 8px; border-top: 1px solid #404249; }')
            html_lines.append('    .footer { text-align: center; padding: 20px; color: #949ba4; font-size: 12px; margin-top: 30px; }')
            html_lines.append('    .footer a { color: ' + primary_color + '; text-decoration: none; }')
            html_lines.append('    .footer a:hover { text-decoration: underline; }')
            html_lines.append('  </style>')
            html_lines.append('</head>')
            html_lines.append('<body>')
            html_lines.append('  <div class="container">')
            html_lines.append('    <div class="header">')
            html_lines.append(f'      <h1>📋 {channel.name}</h1>')
            html_lines.append('      <div class="header-info">')
            html_lines.append(f'        <div><label>Ticket Owner:</label><value>{ticket_owner.display_name if ticket_owner else "Unknown"}</value></div>')
            html_lines.append(f'        <div><label>User ID:</label><value>{ticket_info.get("user_id") if ticket_info else "Unknown"}</value></div>')
            html_lines.append(f'        <div><label>Created:</label><value>{creation_time_ist}</value></div>')
            html_lines.append(f'        <div><label>Messages:</label><value>{len(messages)}</value></div>')
            html_lines.append('      </div>')
            html_lines.append('    </div>')
            html_lines.append('    <div class="messages">')

            # Add messages
            for message in messages:
                timestamp_ist = message.created_at.astimezone(ist).strftime('%H:%M:%S')
                content = message.content if message.content else ""

                # Process content for emojis and mentions
                content = self.process_message_content(content, message)

                is_bot = message.author.bot
                bot_class = ' bot' if is_bot else ''

                html_lines.append(f'      <div class="message{bot_class}">')
                html_lines.append('        <div class="message-header">')
                html_lines.append(f'          <img src="{message.author.display_avatar.url}" alt="{message.author.name}" class="avatar">')
                html_lines.append(f'          <span class="author">{message.author.display_name} | {message.author.name}</span>')
                if is_bot:
                    html_lines.append('          <span class="bot-badge">BOT</span>')
                html_lines.append(f'          <span class="timestamp">{timestamp_ist}</span>')
                html_lines.append('        </div>')

                if content:
                    html_lines.append(f'        <div class="message-content">{content}</div>')

                # Handle stickers
                if message.stickers:
                    for sticker in message.stickers:
                        if sticker.url:
                            html_lines.append(f'        <img src="{sticker.url}" alt="{sticker.name}" class="sticker" title="{sticker.name}">')

                # Handle attachments
                if message.attachments:
                    html_lines.append('        <div class="attachments">')
                    for attachment in message.attachments:
                        html_lines.append('          <div class="attachment">')

                        # Determine if it's an image
                        is_image = any(attachment.filename.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp'])

                        if is_image:
                            # Embed image with base64
                            base64_data = await self.download_attachment_as_base64(attachment.url)
                            if base64_data:
                                # Determine MIME type
                                ext = attachment.filename.split('.')[-1].lower()
                                mime_types = {'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'gif': 'image/gif', 'webp': 'image/webp'}
                                mime_type = mime_types.get(ext, 'image/png')
                                html_lines.append(f'            <img src="data:{mime_type};base64,{base64_data}" alt="{attachment.filename}" class="attachment-image">')
                            else:
                                html_lines.append(f'            <a href="{attachment.url}" class="attachment-link">{attachment.filename}</a>')
                        else:
                            # Link to file
                            html_lines.append(f'            <a href="{attachment.url}" class="attachment-link">{attachment.filename}</a>')

                        html_lines.append(f'            <div class="attachment-file">{attachment.size / 1024:.2f} KB</div>')
                        html_lines.append('          </div>')
                    html_lines.append('        </div>')

                # Handle embeds
                if message.embeds:
                    for embed in message.embeds:
                        embed_color = embed.color if embed.color else int(primary_color.replace('#', '0x'), 16)
                        hex_color = f'#{embed_color:06x}' if isinstance(embed_color, int) else primary_color

                        html_lines.append(f'        <div class="embed" style="border-left-color: {hex_color};">')

                        if embed.title:
                            html_lines.append(f'          <div class="embed-title">{embed.title}</div>')

                        if embed.description:
                            html_lines.append(f'          <div class="embed-description">{embed.description}</div>')

                        # Add fields
                        if embed.fields:
                            for field in embed.fields:
                                html_lines.append('          <div class="embed-field">')
                                html_lines.append(f'            <div class="embed-field-name">{field.name}</div>')
                                html_lines.append(f'            <div class="embed-field-value">{field.value}</div>')
                                html_lines.append('          </div>')

                        # Add image
                        if embed.image:
                            html_lines.append(f'          <img src="{embed.image.url}" class="embed-image" alt="embed">')

                        # Add footer
                        if embed.footer or embed.timestamp:
                            footer_text = ""
                            if embed.footer and embed.footer.text:
                                footer_text = embed.footer.text
                            if embed.timestamp:
                                footer_text += f" • {embed.timestamp.strftime('%Y-%m-%d %H:%M:%S') if hasattr(embed.timestamp, 'strftime') else embed.timestamp}"
                            if footer_text:
                                html_lines.append(f'          <div class="embed-footer">{footer_text}</div>')

                        html_lines.append('        </div>')

                html_lines.append('      </div>')

            html_lines.append('    </div>')
            html_lines.append('    <div class="footer">')
            html_lines.append('      <p>✨ Generated by <strong>Jo1nTrX™</strong> • Ticket System ✨</p>')
            html_lines.append('    </div>')
            html_lines.append('  </div>')
            html_lines.append('</body>')
            html_lines.append('</html>')

            # Create file
            html_content = '\n'.join(html_lines)
            filename = f"ticket-{channel.name}-transcript.html"

            return discord.File(io.BytesIO(html_content.encode('utf-8')), filename=filename)

        except Exception as e:
            print(f"Error generating HTML transcript: {e}")
            traceback.print_exc()
            return None

    async def get_ticket_info(self, channel_id):
        """Get ticket information by channel ID"""
        try:
            # Search through all guilds for the ticket
            active_tickets = self.db_handler.get_all_active_tickets()

            for guild_id, guild_tickets in active_tickets.items():
                ticket_data = guild_tickets.get(str(channel_id))
                if ticket_data:
                    return {
                        'guild_id': int(guild_id),
                        'user_id': ticket_data.get('user_id'),
                        'category_name': ticket_data.get('category_name'),
                        'ticket_number': ticket_data.get('ticket_number'),
                        'original_channel_name': ticket_data.get('original_channel_name'),
                        'status': ticket_data.get('status', 'open'),
                        'channel_id': int(channel_id),
                        'created_at': ticket_data.get('created_at')
                    }
            return None
        except Exception as e:
            print(f'Error getting ticket info: {e}')
            return None

    async def update_ticket_status(self, channel_id, status):
        """Update ticket status in database"""
        try:
            # Find the ticket and update its status
            active_tickets = self.db_handler.get_all_active_tickets()

            for guild_id, guild_tickets in active_tickets.items():
                if str(channel_id) in guild_tickets:
                    ticket_data = guild_tickets[str(channel_id)]
                    ticket_data['status'] = status

                    # Save the updated ticket data
                    self.db_handler.save_active_ticket(int(guild_id), channel_id, ticket_data)
                    return True

            return False
        except Exception as e:
            print(f'Error updating ticket status: {e}')
            return False

    async def has_close_permission(self, interaction):
        """Check if user can close the ticket"""
        try:
            # Get current ticket info from database for persistence
            ticket_info = await self.get_ticket_info(interaction.channel.id)

            if ticket_info:
                # Ticket owner can always close
                if interaction.user.id == int(ticket_info['user_id']):
                    return True

                # Administrators can always close
                if interaction.user.guild_permissions.administrator:
                    return True

                # Get ticket data to find the specific support role for this category
                ticket_data = self.db_handler.get_active_ticket(ticket_info['guild_id'], interaction.channel.id)
                if ticket_data:
                    support_role_id = ticket_data.get('support_role_id')

                    # Check if user has the specific support role assigned to this ticket category
                    if support_role_id:
                        support_role = interaction.guild.get_role(support_role_id)
                        if support_role and support_role in interaction.user.roles:
                            return True

                # Fallback: Check for general support staff permissions
                user_roles = [role.name.lower() for role in interaction.user.roles]
                support_roles = ['support', 'moderator', 'admin', 'staff']
                if any(role in user_roles for role in support_roles):
                    return True

            return False

        except Exception as e:
            return False

    async def has_close_permission_ctx(self, ctx):
        """Check if user can close the ticket - Context version"""
        try:
            # Get current ticket info from database for persistence
            ticket_info = await self.get_ticket_info(ctx.channel.id)

            if ticket_info:
                # Ticket owner can always close
                if ctx.author.id == int(ticket_info['user_id']):
                    return True

                # Administrators can always close
                if ctx.author.guild_permissions.administrator:
                    return True

                # Get ticket data to find the specific support role for this category
                ticket_data = self.db_handler.get_active_ticket(ticket_info['guild_id'], ctx.channel.id)
                if ticket_data:
                    support_role_id = ticket_data.get('support_role_id')

                    # Check if user has the specific support role assigned to this ticket category
                    if support_role_id:
                        support_role = ctx.guild.get_role(support_role_id)
                        if support_role and support_role in ctx.author.roles:
                            return True

                # Fallback: Check for general support staff permissions
                user_roles = [role.name.lower() for role in ctx.author.roles]
                support_roles = ['support', 'moderator', 'admin', 'staff']
                if any(role in user_roles for role in support_roles):
                    return True

        except Exception as e:
            pass

        return False

    async def load_embeds(self, guild_id):
        """Load all embeds created for a guild from database"""
        try:
            # Use the existing database method
            embeds_list = await self.bot.db.get_guild_embeds(guild_id)
            embeds = {}
            for embed_data in embeds_list:
                embeds[embed_data['name']] = True
            return embeds
        except Exception as e:
            print(f'Error loading embeds: {e}')
        return {}

class TicketPanelView(BaseView):
    def __init__(self, guild_id, config_manager, owner_id=None):
        super().__init__(timeout=1800)  # 30 minutes timeout
        self.guild_id = guild_id
        self.config_manager = config_manager
        self.current_config = {}
        self.owner_id = owner_id  # User who initiated the setup
        self.current_panel_id = None  # Track the current panel being configured

    @discord.ui.button(label="Channel Config", style=discord.ButtonStyle.primary)
    async def channel_config(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is the owner of this configuration session
        if self.owner_id and interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{self.owner_id}>! \n\nYou use `/ticket panel setup` to configure another.",
                ephemeral=True
            )
            return

        await interaction.response.send_message("Starting channel configuration...", ephemeral=True)

        # Initialize panel if not exists, or get the current one
        if not self.current_panel_id:
            # For new panel setup, create the panel ID early so all subsequent operations use the same panel
            config = await self.config_manager.load_ticket_config(self.guild_id, create_new=True)
            if config and config.get('global_panel_id'):
                self.current_panel_id = config.get('global_panel_id')
                print(f"Debug: Set current_panel_id to {self.current_panel_id} during channel config")

        # Start channel configuration process
        await self.setup_channels(interaction)

    @discord.ui.button(label="Ticket Embed", style=discord.ButtonStyle.secondary)
    async def ticket_embed(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is the owner of this configuration session
        if self.owner_id and interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{self.owner_id}>! \n\nYou use `/ticket panel setup` to configure another.",
                ephemeral=True
            )
            return

        # Load available embeds
        embeds = await self.config_manager.load_embeds(self.guild_id)

        if not embeds:
            await interaction.response.send_message(
                "<:jo1ntrx_cross:1405094904568483880> No embeds found! Please create an embed first using `+embed create <name>`", 
                ephemeral=True
            )
            return

        # Create dropdown with available embeds
        embed_view = TicketEmbedSelectView(embeds, self.guild_id, self.config_manager, self.current_panel_id)

        # Panel ID properly passed to embed selection view

        # Create embed selector with standard format
        embed = EmbedFactory.create(
            title="Select Ticket Embed",
            description="Choose an embed for your ticket panel from the dropdown below:",
            timestamp=False
        )

        await interaction.response.send_message(embed=embed, view=embed_view, ephemeral=True)

    @discord.ui.button(label="Save & Continue", style=discord.ButtonStyle.success)
    async def save_continue(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is the owner of this configuration session
        if self.owner_id and interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{self.owner_id}>! \n\nYou use `/ticket panel setup` to configure another.",
                ephemeral=True
            )
            return

        # Defer the interaction to prevent timeout
        await interaction.response.defer()

        # Load fresh configuration from database
        # Use the current panel ID if we have one from the configuration process
        if self.current_panel_id:
            config = await self.config_manager.load_ticket_config(self.guild_id, global_panel_id=self.current_panel_id)
        else:
            config = await self.config_manager.load_ticket_config(self.guild_id)

        # Check if panel_channel and log_channel are configured
        panel_channel_set = config.get('panel_channel') is not None
        log_channel_set = config.get('log_channel') is not None

        if not panel_channel_set or not log_channel_set:
            await interaction.followup.send(
                "<:jo1ntrx_cross:1405094904568483880> Please complete channel configuration first!\n\n"
                f"Panel Channel: {'<:jo1ntrx_tick:1405094884947267715> Set' if panel_channel_set else '<:jo1ntrx_cross:1405094904568483880> Not Set'}\n"
                f"Log Channel: {'<:jo1ntrx_tick:1405094884947267715> Set' if log_channel_set else '<:jo1ntrx_cross:1405094904568483880> Not Set'}", 
                ephemeral=True
            )
            return

        # Check if ticket embed is configured
        embed_set = config.get('ticket_embed') is not None
        if not embed_set:
            # Configuration validation failed
            await interaction.followup.send(
                "<:jo1ntrx_cross:1405094904568483880> Please select a ticket embed first!", 
                ephemeral=True
            )
            return

        # Move to category configuration
        # Check if this is a new panel being created or an existing one being edited
        is_new_panel = not config.get('global_panel_id') or not config.get('panel_message_id')
        category_view = CategoryConfigView(
            self.guild_id, 
            self.config_manager, 
            self.owner_id,
            panel_id=config.get('global_panel_id'),
            is_new_panel=is_new_panel
        )

        # Create category config embed with standard format
        embed = EmbedFactory.create(
            title=f"{interaction.guild.name if interaction.guild else 'Server'}",
            description="Use the buttons below to configure your ticket categories!\n\n"
                       "**Add option**: To add the categories in ticket panel.\n\n"
                       "**Send panel**: To save & send your panel.\n\n"
                       "**__Note__** <:Jo1nTrX_Note:1411930562288943104>\n\n"
                       "• You can choose upto **5** options.",
            timestamp=False
        )
        embed.set_thumbnail(url=interaction.client.user.avatar.url if interaction.client.user.avatar else interaction.client.user.default_avatar.url)

        await interaction.edit_original_response(embed=embed, view=category_view)

    async def setup_channels(self, interaction):
        """Handle channel configuration process"""
        def check(m):
            return m.author == interaction.user and m.channel == interaction.channel

        try:
            # Q1: Panel Channel
            await interaction.followup.send(
                "**Q1.** In which channel, ticket panel will be sent?\n"
                "Enter the channel id or <#channel> or type `cancel` to abort the configuration!",
                ephemeral=True
            )

            msg = await interaction.client.wait_for('message', check=check, timeout=60)
            await msg.delete()  # Delete user's response to keep chat clean

            if msg.content.lower() == 'cancel':
                await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Configuration cancelled!", ephemeral=True)
                # Clear lock on cancellation
                await self.config_manager.clear_config_lock(self.guild_id)
                return

            # Parse channel
            panel_channel = None
            if msg.channel_mentions:
                panel_channel = msg.channel_mentions[0]
            else:
                try:
                    channel_id = int(msg.content.strip('<>#'))
                    panel_channel = interaction.guild.get_channel(channel_id)
                except:
                    await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Invalid channel! Configuration cancelled.", ephemeral=True)
                    # Clear lock on error
                    await self.config_manager.clear_config_lock(self.guild_id)
                    return

            if not panel_channel:
                await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Channel not found! Configuration cancelled.", ephemeral=True)
                # Clear lock on error
                await self.config_manager.clear_config_lock(self.guild_id)
                return

            # Q2: Log Channel
            await interaction.followup.send(
                "**Q2.** In which channel, ticket log's will be sent?\n"
                "Enter the channel id or <#channel> or type `cancel` to abort the configuration!",
                ephemeral=True
            )

            msg = await interaction.client.wait_for('message', check=check, timeout=60)
            await msg.delete()  # Delete user's response to keep chat clean

            if msg.content.lower() == 'cancel':
                await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Configuration cancelled!", ephemeral=True)
                return

            # Parse log channel
            log_channel = None
            if msg.channel_mentions:
                log_channel = msg.channel_mentions[0]
            else:
                try:
                    channel_id = int(msg.content.strip('<>#'))
                    log_channel = interaction.guild.get_channel(channel_id)
                except:
                    await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Invalid channel! Configuration cancelled.", ephemeral=True)
                    return

            if not log_channel:
                await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Channel not found! Configuration cancelled.", ephemeral=True)
                return

            # Q3: Closed Category (Optional)
            await interaction.followup.send(
                "**Q3.** Enter the closed category ID, where all closed tickets will be stored!\n"
                "Type `skip` to skip or `cancel` to abort the configuration!",
                ephemeral=True
            )

            msg = await interaction.client.wait_for('message', check=check, timeout=60)
            await msg.delete()  # Delete user's response to keep chat clean

            if msg.content.lower() == 'cancel':
                await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Configuration cancelled!", ephemeral=True)
                return

            closed_category = None
            if msg.content.lower() != 'skip':
                try:
                    category_id = int(msg.content)
                    closed_category = interaction.guild.get_channel(category_id)
                    if closed_category and not isinstance(closed_category, discord.CategoryChannel):
                        await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Please provide a category channel ID!", ephemeral=True)
                        return
                except:
                    await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Invalid category ID!", ephemeral=True)
                    # Clear lock on error
                    await self.config_manager.clear_config_lock(self.guild_id)
                    return

            # Save configuration
            config = await self.config_manager.load_ticket_config(self.guild_id)

            # If no existing config, create a new one
            if not config:
                config = {
                    'panel_type': 'buttons',  # default type
                    'guild_id': self.guild_id
                }

            config.update({
                'panel_channel': panel_channel.id,
                'log_channel': log_channel.id,
                'closed_category': closed_category.id if closed_category else None
            })

            # Use the current panel_id to update existing panel instead of creating new one
            panel_id = self.current_panel_id if self.current_panel_id else config.get('global_panel_id')
            saved_panel_id = await self.config_manager.save_ticket_config(self.guild_id, config, panel_id)

            # Update our tracking panel_id
            if not self.current_panel_id:
                self.current_panel_id = saved_panel_id
                print(f"Debug channel config: Set current_panel_id to {self.current_panel_id}, saved_panel_id: {saved_panel_id}")

            await interaction.followup.send("<:jo1ntrx_tick:1405094884947267715> Channel configuration saved successfully!", ephemeral=True)
            # Clear lock on successful completion
            await self.config_manager.clear_config_lock(self.guild_id)

        except asyncio.TimeoutError:
            await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Configuration timed out!", ephemeral=True)
            # Clear lock on timeout
            await self.config_manager.clear_config_lock(self.guild_id)

class TicketEmbedSelectView(BaseView):
    def __init__(self, embeds, guild_id, config_manager, current_panel_id=None):
        super().__init__(timeout=300)
        self.guild_id = guild_id
        self.config_manager = config_manager
        self.current_panel_id = current_panel_id

        # Create dropdown with embed options
        options = []
        for embed_name in list(embeds.keys())[:25]:  # Discord limit
            options.append(discord.SelectOption(
                label=embed_name,
                description=f"Use {embed_name} as ticket embed",
                value=embed_name,
                emoji=bot_emoji.embed
            ))

        if options:
            select = TicketEmbedSelect(options, self.guild_id, self.config_manager)
            select.current_panel_id = self.current_panel_id
            self.add_item(select)

class TicketEmbedSelect(BaseSelect):
    def __init__(self, options, guild_id, config_manager):
        super().__init__(
            placeholder="Choose an embed for your ticket panel...",
            options=options,
            min_values=1,
            max_values=1
        )
        self.guild_id = guild_id
        self.config_manager = config_manager
        self.current_panel_id = None

    async def callback(self, interaction: discord.Interaction):
        embed_name = self.values[0]

        # Save selected embed to config using the current panel ID context
        # Always use current_panel_id if available, otherwise load the latest config
        if self.current_panel_id:
            config = await self.config_manager.load_ticket_config(self.guild_id, global_panel_id=self.current_panel_id)
        else:
            config = await self.config_manager.load_ticket_config(self.guild_id)

        # Panel ID should now be properly set through constructor

        # If no existing config, create a new one
        if not config:
            config = {
                'panel_type': 'buttons',  # default type
                'guild_id': self.guild_id
            }
        config['ticket_embed'] = embed_name

        # CRITICAL FIX: Always use current_panel_id to update the existing panel
        # Don't create new panels during embed selection
        panel_id = self.current_panel_id
        if not panel_id:
            # Fallback to existing panel ID if current_panel_id is somehow missing
            panel_id = config.get('global_panel_id')

        saved_panel_id = await self.config_manager.save_ticket_config(self.guild_id, config, panel_id)

        # Update current_panel_id to ensure consistency
        if saved_panel_id:
            self.current_panel_id = saved_panel_id

        # Embed configuration saved successfully

        # Create success embed with standard format
        success_embed = EmbedFactory.create(
            title="<:jo1ntrx_tick:1405094884947267715> Embed Selected",
            description=f"Successfully selected **{embed_name}** as your ticket panel embed.",
            timestamp=False
        )

        await interaction.response.edit_message(embed=success_embed, view=None)

class CategoryConfigView(BaseView):
    def __init__(self, guild_id, config_manager, owner_id=None, panel_id=None, is_new_panel=False):
        super().__init__(timeout=1800)  # 30 minutes timeout
        self.guild_id = guild_id
        self.config_manager = config_manager
        self.owner_id = owner_id  # User who initiated the setup
        self.panel_id = panel_id  # Specific panel ID for this configuration
        self.is_new_panel = is_new_panel  # Flag to indicate if this is a new panel being created

    @discord.ui.button(label="Add option", style=discord.ButtonStyle.primary)
    async def add_option(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is the owner of this configuration session
        if self.owner_id and interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{self.owner_id}>! \n\nYou use `/ticket panel setup` to configure another.",
                ephemeral=True
            )
            return

        # Load the current panel's config specifically, or create new if it's a new panel
        if self.panel_id:
            # We have a panel ID, load that specific panel
            config = await self.config_manager.load_ticket_config(self.guild_id, global_panel_id=self.panel_id)
        else:
            # No panel ID yet, either create new or load the most recent panel
            if self.is_new_panel:
                config = await self.config_manager.load_ticket_config(self.guild_id, create_new=True)
            else:
                # Load most recent panel
                config = await self.config_manager.load_ticket_config(self.guild_id)

        current_options = config.get('categories', [])

        if len(current_options) >= 5:
            await interaction.response.send_message(
                "<:jo1ntrx_cross:1405094904568483880> **You've already reached the option limit!** \n\n"
                "Use `Send Panel` to send the panel!", 
                ephemeral=True
            )
            return

        # Start the enhanced option configuration process
        await interaction.response.send_message("Starting option configuration...", ephemeral=True)
        await self.setup_ticket_option(interaction)

    @discord.ui.button(label="Send panel", style=discord.ButtonStyle.success)
    async def send_panel(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is the owner of this configuration session
        if self.owner_id and interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{self.owner_id}>! \n\nYou use `/ticket panel setup` to configure another.",
                ephemeral=True
            )
            return

        # Load the current panel's config specifically
        if self.panel_id:
            # We have a panel ID, load that specific panel
            config = await self.config_manager.load_ticket_config(self.guild_id, global_panel_id=self.panel_id)
        else:
            # No panel ID yet, either create new or load the most recent panel
            if self.is_new_panel:
                config = await self.config_manager.load_ticket_config(self.guild_id, create_new=True)
            else:
                # Load most recent panel
                config = await self.config_manager.load_ticket_config(self.guild_id)

        categories = config.get('categories', [])

        if not categories:
            await interaction.response.send_message("<:jo1ntrx_cross:1405094904568483880> Please add at least one category option!", ephemeral=True)
            return

        # Send the ticket panel
        await self.create_and_send_panel(interaction, config)

    async def setup_ticket_option(self, interaction):
        """Setup a ticket option with 5 questions"""
        def check(m):
            return m.author == interaction.user and m.channel == interaction.channel

        option_data = {}

        try:
            # Q1: Label
            await interaction.followup.send(
                "**Q1.** Enter the label of the option.",
                ephemeral=True
            )

            msg = await interaction.client.wait_for('message', check=check, timeout=600)
            option_data['label'] = msg.content
            await msg.delete()  # Clean up user message

            # Q2: Emoji
            await interaction.followup.send(
                "**Q2.** Enter the emoji for the option. Type `skip` to skip the emojis!",
                ephemeral=True
            )

            msg = await interaction.client.wait_for('message', check=check, timeout=600)
            if msg.content.lower() == 'skip':
                option_data['emoji'] = None  # No emoji when user skips
            else:
                option_data['emoji'] = msg.content
            await msg.delete()

            # Q3: Category ID
            await interaction.followup.send(
                "**Q3.** Enter the category ID for this option. Type `skip` for no category!",
                ephemeral=True
            )

            msg = await interaction.client.wait_for('message', check=check, timeout=600)
            if msg.content.lower() == 'skip':
                option_data['category_id'] = None
            else:
                try:
                    category_id = int(msg.content)
                    category = interaction.guild.get_channel(category_id)
                    if category and isinstance(category, discord.CategoryChannel):
                        option_data['category_id'] = category_id
                    else:
                        await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Invalid category ID! Configuration cancelled.", ephemeral=True)
                        await msg.delete()
                        return
                except ValueError:
                    await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Please provide a valid category ID! Configuration cancelled.", ephemeral=True)
                    await msg.delete()
                    return
            await msg.delete()

            # Q4: Support Role
            await interaction.followup.send(
                "**Q4.** Enter the support role ID or <@support role> for this ticket.",
                ephemeral=True
            )

            msg = await interaction.client.wait_for('message', check=check, timeout=600)
            support_role = None
            if msg.role_mentions:
                support_role = msg.role_mentions[0]
            else:
                try:
                    role_id = int(msg.content.strip('<@>&'))
                    support_role = interaction.guild.get_role(role_id)
                except:
                    await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Invalid role! Configuration cancelled.", ephemeral=True)
                    await msg.delete()
                    return

            if not support_role:
                await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Role not found! Configuration cancelled.", ephemeral=True)
                await msg.delete()
                return

            option_data['support_role_id'] = support_role.id
            await msg.delete()

            # Q5: Ping Support Role (Dropdown)
            ping_view = PingSupportView()
            await interaction.followup.send(
                "**Q5.** Ping support role? Choose yes or no!",
                view=ping_view,
                ephemeral=True
            )

            # Wait for the dropdown interaction
            ping_interaction = await interaction.client.wait_for(
                'interaction',
                check=lambda i: i.user == interaction.user and i.data.get('custom_id') == 'ping_support_select',
                timeout=600
            )

            option_data['ping_support'] = ping_interaction.data['values'][0] == 'yes'
            await ping_interaction.response.send_message("<:jo1ntrx_tick:1405094884947267715> Ping preference saved!", ephemeral=True)

            # Save the option
            await self.save_ticket_option(option_data)

            # Send completion message
            await interaction.followup.send(
                f"<:jo1ntrx_tick:1405094884947267715> **You've successfully configured your '{option_data['label']}' option.**\n\n"
                f"To add another option, click on `Add Option` or to send the panel, click on `Send Panel` button.",
                ephemeral=True
            )

            # Clear configuration lock on successful completion
            await self.config_manager.clear_config_lock(self.guild_id)

        except asyncio.TimeoutError:
            await interaction.followup.send("<:jo1ntrx_cross:1405094904568483880> Configuration timed out! Do `+ticket panel setup` again to set it up again.")
            # Clear lock on timeout
            await self.config_manager.clear_config_lock(self.guild_id)
        except Exception as e:
            await interaction.followup.send(f"<:jo1ntrx_cross:1405094904568483880> An error occurred: {str(e)}")
            # Clear lock on error
            await self.config_manager.clear_config_lock(self.guild_id)

    async def save_ticket_option(self, option_data):
        """Save the configured option to database"""
        # Load the current panel's config specifically, or create new if it's a new panel
        if self.panel_id:
            # We have a panel ID, load that specific panel
            config = await self.config_manager.load_ticket_config(self.guild_id, global_panel_id=self.panel_id)
        else:
            # No panel ID yet, either create new or load the most recent panel
            if self.is_new_panel:
                config = await self.config_manager.load_ticket_config(self.guild_id, create_new=True)
            else:
                # Load most recent panel
                config = await self.config_manager.load_ticket_config(self.guild_id)

        categories = config.get('categories', [])

        emoji_value = option_data.get('emoji')
        new_category = {
            'name': option_data['label'][:50],
            'emoji': validate_emoji(emoji_value),
            'description': f"Support category for {option_data['label']}"[:100],
            'category_id': option_data['category_id'],
            'support_role_id': option_data['support_role_id'],
            'ping_support': option_data['ping_support']
        }

        categories.append(new_category)
        config['categories'] = categories


        # Use existing global_panel_id to update the same panel instead of creating new one
        # If this is a new panel without an ID, let save_ticket_config generate a new one
        existing_panel_id = config.get('global_panel_id')
        if not existing_panel_id and self.is_new_panel:
            existing_panel_id = None  # Force creation of new panel

        panel_id = await self.config_manager.save_ticket_config(self.guild_id, config, existing_panel_id)

        # Update our panel_id reference for subsequent saves if this was a new panel
        if self.is_new_panel and not self.panel_id:
            self.panel_id = panel_id
            self.is_new_panel = False  # No longer new after first save

        # Also ensure self.panel_id is set for any successful save
        if not self.panel_id:
            self.panel_id = panel_id

    async def create_and_send_panel(self, interaction, config):
        """Create and send the ticket panel to the configured channel"""
        try:
            panel_channel = interaction.guild.get_channel(config['panel_channel'])
            if not panel_channel:
                await interaction.response.send_message("<:jo1ntrx_cross:1405094904568483880> Panel channel not found!", ephemeral=True)
                return

            # Create ticket panel based on type
            panel_type = config.get('panel_type', 'buttons')

            categories = config.get('categories', [])

            # Get panel ID for context
            panel_id = config.get('global_panel_id') or self.panel_id

            if panel_type == 'buttons':
                view = TicketButtonsView(categories, self.config_manager, interaction.guild.id, panel_id)
            else:  # selective menu
                view = TicketSelectView(categories, self.config_manager, interaction.guild.id, panel_id)

            # Get embed data using the selected embed like join messages do
            embed_name = config.get('ticket_embed')
            if embed_name:
                # Import the function here to avoid circular imports
                from Jo1nTrX.cogs.extra.embeds import create_embed_from_database_data
                message_content, embed = await create_embed_from_database_data(interaction.client, interaction.guild.id, embed_name)
                if not embed:
                    # Fallback to default embed if custom embed fails
                    embed = EmbedFactory.create(
                        title="🎫 Support Tickets",
                        description="Click a button below to create a support ticket!",
                        timestamp=False
                    )
            else:
                # Default embed when no embed is selected
                embed = EmbedFactory.create(
                    title="🎫 Support Tickets",
                    description="Click a button below to create a support ticket!",
                    timestamp=False
                )

            # Send the panel and store message ID
            panel_message = await panel_channel.send(embed=embed, view=view)
            config['panel_message_id'] = panel_message.id

            # Save configuration with message ID and get panel ID (use existing panel_id to update instead of creating new)
            existing_panel_id = config.get('global_panel_id')
            panel_id = await self.config_manager.save_ticket_config(interaction.guild.id, config, existing_panel_id)

            await interaction.response.send_message(
                f"<:jo1ntrx_tick:1405094884947267715> **Ticket panel sent to {panel_channel.mention}!**\n"
                f"**Panel ID:** #{panel_id}", 
                ephemeral=True
            )

        except Exception as e:
            await interaction.response.send_message(f"<:jo1ntrx_cross:1405094904568483880> Error sending panel: {str(e)}", ephemeral=True)

class PingSupportView(BaseView):
    def __init__(self):
        super().__init__(timeout=600)  # 10 minutes timeout

        options = [
            discord.SelectOption(
                label="Yes",
                description="Ping the support role when tickets are created",
                value="yes",
                emoji="<:jo1ntrx_tick:1405094884947267715>"
            ),
            discord.SelectOption(
                label="No", 
                description="Don't ping the support role",
                value="no",
                emoji=bot_emoji.cross
            )
        ]

        select = discord.ui.Select(
            placeholder="Choose whether to ping support role...",
            options=options,
            custom_id="ping_support_select"
        )
        self.add_item(select)

class PanelDeleteView(BaseView):
    def __init__(self, panel_id, config_manager):
        super().__init__(timeout=300)
        self.panel_id = panel_id
        self.config_manager = config_manager

    @discord.ui.button(label="Yes, Delete", style=discord.ButtonStyle.danger, emoji=bot_emoji.delete)
    async def confirm_delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Confirm panel deletion"""
        success = await self.config_manager.delete_panel_by_global_id(self.panel_id)

        if success:
            await interaction.response.send_message(
                f"<:jo1ntrx_tick:1405094884947267715> **Panel #{self.panel_id} deleted successfully!**",
                ephemeral=True
            )
        else:
            await interaction.response.send_message(
                f"<:jo1ntrx_cross:1405094904568483880> **Failed to delete panel #{self.panel_id}!**",
                ephemeral=True
            )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary, emoji=bot_emoji.cross)
    async def cancel_delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Cancel panel deletion"""
        await interaction.response.send_message(
            "<:jo1ntrx_tick:1405094884947267715> **Panel deletion cancelled.**",
            ephemeral=True
        )

# ===== NEW TICKET PANEL EDIT FLOW =====
class NewPanelEditMenuView(BaseView):
    """Main menu for ticket panel editing with 3 buttons"""
    def __init__(self, panel_id, config_manager, guild_id):
        super().__init__(timeout=1800)
        self.panel_id = panel_id
        self.config_manager = config_manager
        self.guild_id = guild_id
        self.temp_config = {}

    @discord.ui.button(label="Edit Channels", style=discord.ButtonStyle.primary)
    async def edit_channels(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Open channel editing menu"""
        try:
            await interaction.response.defer(ephemeral=True)
            panel = await self.config_manager.get_panel_by_global_id(self.panel_id)
            if not panel:
                await interaction.followup.send("❌ Panel not found!", ephemeral=True)
                return

            self.temp_config = panel.copy()
            view = EditChannelsMenuView(self.panel_id, self.config_manager, self.guild_id, self.temp_config)

            embed = EmbedFactory.create(
                title="🛠️ Edit Channels",
                description="Select the channels for your ticket panel:",
                timestamp=False
            )

            await interaction.followup.send(embed=embed, view=view, ephemeral=True)
        except Exception as e:
            try:
                await interaction.followup.send(f"❌ Error: {str(e)}", ephemeral=True)
            except:
                print(f"Error in edit_channels: {str(e)}")

    @discord.ui.button(label="Edit Embed", style=discord.ButtonStyle.secondary)
    async def edit_embed(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Open embed selection menu"""
        try:
            panel = await self.config_manager.get_panel_by_global_id(self.panel_id)
            if not panel:
                await interaction.response.send_message("❌ Panel not found!", ephemeral=True)
                return

            self.temp_config = panel.copy()

            embeds = await self.config_manager.load_embeds(self.guild_id)
            if not embeds:
                await interaction.response.send_message("❌ No embeds found! Create embeds first using `+embed create`", ephemeral=True)
                return

            view = TicketEmbedSelectView(embeds, self.guild_id, self.config_manager, self.panel_id)
            view.editing = True
            view.is_panel_edit = True
            view.temp_config = self.temp_config

            embed = EmbedFactory.create(
                title="Select Ticket Embed",
                description="Choose an embed for your ticket panel:",
                timestamp=False
            )

            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

    @discord.ui.button(label="Save & Continue", style=discord.ButtonStyle.success, emoji="<:jo1ntrx_tick:1405094884947267715>")
    async def save_continue(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Move to review configuration"""
        try:
            panel = await self.config_manager.get_panel_by_global_id(self.panel_id)
            if not panel:
                await interaction.response.send_message("❌ Panel not found!", ephemeral=True)
                return

            view = ReviewConfigMenuView(self.panel_id, self.config_manager, self.guild_id, panel)

            embed = EmbedFactory.create(
                title="📋 Review Configuration",
                description="Review and edit your panel configuration below. Use dropdowns to change values.",
                timestamp=False
            )

            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class EditChannelsMenuView(BaseView):
    """Channel configuration menu with 3 dropdowns"""
    def __init__(self, panel_id, config_manager, guild_id, temp_config):
        super().__init__(timeout=600)
        self.panel_id = panel_id
        self.config_manager = config_manager
        self.guild_id = guild_id
        self.temp_config = temp_config
        self.selected_channels = {}

        # Panel channel select
        panel_select = discord.ui.ChannelSelect(
            placeholder="Select Panel Channel...",
            channel_types=[discord.ChannelType.text],
            custom_id="panel_channel_edit"
        )
        panel_select.callback = self.panel_channel_callback
        self.add_item(panel_select)

        # Log channel select
        log_select = discord.ui.ChannelSelect(
            placeholder="Select Log Channel...",
            channel_types=[discord.ChannelType.text],
            custom_id="log_channel_edit"
        )
        log_select.callback = self.log_channel_callback
        self.add_item(log_select)

        # Closed category select
        category_select = discord.ui.ChannelSelect(
            placeholder="Select Closed Category (Optional)...",
            channel_types=[discord.ChannelType.category],
            custom_id="closed_category_edit",
            min_values=0
        )
        category_select.callback = self.closed_category_callback
        self.add_item(category_select)

        # Save button
        save_button = discord.ui.Button(label="Save Changes", style=discord.ButtonStyle.success, custom_id="save_channels_edit")
        save_button.callback = self.save_channels_callback
        self.add_item(save_button)

    async def panel_channel_callback(self, interaction: discord.Interaction):
        try:
            if interaction.data['values']:
                self.selected_channels['panel_channel'] = interaction.data['values'][0].id
            await interaction.response.defer(ephemeral=True)
        except Exception as e:
            print(f"Error in panel_channel_callback: {e}")
            try:
                await interaction.response.defer(ephemeral=True)
            except:
                pass

    async def log_channel_callback(self, interaction: discord.Interaction):
        try:
            if interaction.data['values']:
                self.selected_channels['log_channel'] = interaction.data['values'][0].id
            await interaction.response.defer(ephemeral=True)
        except Exception as e:
            print(f"Error in log_channel_callback: {e}")
            try:
                await interaction.response.defer(ephemeral=True)
            except:
                pass

    async def closed_category_callback(self, interaction: discord.Interaction):
        try:
            if interaction.data['values']:
                self.selected_channels['closed_category'] = interaction.data['values'][0].id
            await interaction.response.defer(ephemeral=True)
        except Exception as e:
            print(f"Error in closed_category_callback: {e}")
            try:
                await interaction.response.defer(ephemeral=True)
            except:
                pass

    async def save_channels_callback(self, interaction: discord.Interaction):
        try:
            self.temp_config.update(self.selected_channels)
            await self.config_manager.save_ticket_config(self.guild_id, self.temp_config, self.panel_id)
            await interaction.response.send_message("✅ Channel configuration saved!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error saving: {str(e)}", ephemeral=True)

class EditCategoryModal(discord.ui.Modal):
    """Modal for editing a ticket category"""
    def __init__(self, category_data, category_index, panel_id, config_manager, guild_id):
        # Get label from either 'label' or 'name' field
        label_value = category_data.get('label') or category_data.get('name', 'Unknown')
        title_text = label_value[:30] if label_value else 'Category'
        super().__init__(title=f"Edit: {title_text}")
        self.category_index = category_index
        self.panel_id = panel_id
        self.config_manager = config_manager
        self.guild_id = guild_id
        self.category_data = category_data

        # Ensure we have a label to show
        default_label = label_value if label_value else ''
        self.label_input = discord.ui.TextInput(
            label="Category Label",
            default=str(default_label)[:50],
            max_length=50
        )
        self.add_item(self.label_input)

        category_id = category_data.get('category_id', '')
        self.category_id_input = discord.ui.TextInput(
            label="Ticket Opening Category ID",
            default=str(category_id) if category_id else '',
            max_length=20,
            required=False,
            placeholder="Discord category channel ID"
        )
        self.add_item(self.category_id_input)

        support_role_id = category_data.get('support_role_id', '')
        self.support_role_input = discord.ui.TextInput(
            label="Support Role ID",
            default=str(support_role_id) if support_role_id else '',
            max_length=20,
            required=False,
            placeholder="Role ID for support team"
        )
        self.add_item(self.support_role_input)

        self.description_input = discord.ui.TextInput(
            label="Description",
            default=category_data.get('description', '')[:100],
            max_length=100,
            required=False,
            style=discord.TextStyle.paragraph
        )
        self.add_item(self.description_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            panel = await self.config_manager.get_panel_by_global_id(self.panel_id)
            if not panel:
                await interaction.followup.send("❌ Panel not found!", ephemeral=True)
                return

            categories = panel.get('categories', [])
            if self.category_index < len(categories):
                categories[self.category_index]['label'] = self.label_input.value[:50]
                categories[self.category_index]['description'] = self.description_input.value[:100]
                
                # Parse category_id
                if self.category_id_input.value.strip():
                    try:
                        categories[self.category_index]['category_id'] = int(self.category_id_input.value.strip())
                    except ValueError:
                        await interaction.followup.send("❌ Invalid Category ID (must be a number)!", ephemeral=True)
                        return
                
                # Parse support_role_id
                if self.support_role_input.value.strip():
                    try:
                        categories[self.category_index]['support_role_id'] = int(self.support_role_input.value.strip())
                    except ValueError:
                        await interaction.followup.send("❌ Invalid Support Role ID (must be a number)!", ephemeral=True)
                        return

                panel['categories'] = categories
                await self.config_manager.save_ticket_config(self.guild_id, panel, self.panel_id)

                await interaction.followup.send(f"✅ Category updated: **{self.label_input.value}**", ephemeral=True)
            else:
                await interaction.followup.send("❌ Category not found!", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Error: {str(e)}", ephemeral=True)

class ReviewConfigMenuView(BaseView):
    """Review and edit all categories"""
    def __init__(self, panel_id, config_manager, guild_id, panel_config):
        super().__init__(timeout=600)
        self.panel_id = panel_id
        self.config_manager = config_manager
        self.guild_id = guild_id
        self.panel_config = panel_config

        categories = panel_config.get('categories', [])

        if categories:
            # Create options for each category
            options = []
            for idx, cat in enumerate(categories):
                label = cat.get('label', f"Category {idx+1}")
                emoji = cat.get('emoji', '🎫')
                options.append(discord.SelectOption(
                    label=label,
                    value=str(idx),
                    emoji=emoji,
                    description=cat.get('description', 'Edit this category')
                ))

            category_select = discord.ui.Select(
                placeholder="Select a category to edit...",
                options=options,
                custom_id="edit_category_select"
            )
            category_select.callback = self.category_select_callback
            self.add_item(category_select)

        # Save Edits button
        save_btn = discord.ui.Button(label="Save Edits", style=discord.ButtonStyle.success, emoji="<:jo1ntrx_tick:1405094884947267715>", custom_id="save_all_edits")
        save_btn.callback = self.save_all_callback
        self.add_item(save_btn)

    async def category_select_callback(self, interaction: discord.Interaction):
        try:
            category_index = int(interaction.data['values'][0])
            # CRITICAL: Reload panel from database to get latest data (includes modal edits)
            latest_panel = await self.config_manager.get_panel_by_global_id(self.panel_id)
            if not latest_panel:
                await interaction.response.send_message("❌ Panel not found!", ephemeral=True)
                return
            
            # Update our reference so we see latest changes
            self.panel_config = latest_panel
            categories = latest_panel.get('categories', [])

            if category_index < len(categories):
                category = categories[category_index]
                modal = EditCategoryModal(category, category_index, self.panel_id, self.config_manager, self.guild_id)
                try:
                    await interaction.response.send_modal(modal)
                except Exception as modal_error:
                    print(f"Error sending modal: {modal_error}")
                    await interaction.response.send_message(f"❌ Error opening editor: {str(modal_error)}", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Category not found!", ephemeral=True)
        except Exception as e:
            try:
                await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)
            except:
                print(f"Error in category_select_callback: {str(e)}")

    async def save_all_callback(self, interaction: discord.Interaction):
        try:
            # Reload the latest panel from database to ensure we have all modal edits
            latest_panel = await self.config_manager.get_panel_by_global_id(self.panel_id)
            if latest_panel:
                self.panel_config = latest_panel
            
            # Save the latest panel configuration
            await self.config_manager.save_ticket_config(self.guild_id, self.panel_config, self.panel_id)
            await interaction.response.send_message("✅ All changes saved successfully!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class AddCategoryModal(discord.ui.Modal):
    def __init__(self, guild_id, config_manager):
        super().__init__(title="Add Ticket Category")
        self.guild_id = guild_id
        self.config_manager = config_manager

        self.category_name = discord.ui.TextInput(
            label="Category Name",
            placeholder="e.g., General Support",
            max_length=50
        )
        self.add_item(self.category_name)

        self.category_emoji = discord.ui.TextInput(
            label="Emoji (unicode or custom emoji)",
            placeholder="e.g., 🎫 or <:emoji:123456789>",
            max_length=30,
            required=False
        )
        self.add_item(self.category_emoji)

        self.category_description = discord.ui.TextInput(
            label="Category Description",
            placeholder="e.g., Get help with general questions",
            style=discord.TextStyle.paragraph,
            max_length=100,
            required=False
        )
        self.add_item(self.category_description)

    async def on_submit(self, interaction: discord.Interaction):
        config = await self.config_manager.load_ticket_config(self.guild_id)
        categories = config.get('categories', [])

        emoji_value = self.category_emoji.value.strip() if self.category_emoji.value else None
        new_category = {
            'name': self.category_name.value[:50],
            'emoji': validate_emoji(emoji_value),
            'description': (self.category_description.value or 'Support category')[:100]
        }

        categories.append(new_category)
        config['categories'] = categories

        await self.config_manager.save_ticket_config(self.guild_id, config)
        await interaction.response.send_message(f"<:jo1ntrx_tick:1405094884947267715> Added category: **{new_category['name']}**", ephemeral=True)

class TicketButtonsView(BaseView):
    def __init__(self, categories, config_manager, guild_id=None, panel_id=None):
        super().__init__(timeout=None)
        self.categories = categories
        self.config_manager = config_manager
        self.guild_id = guild_id
        self.panel_id = panel_id

        for i, category in enumerate(categories[:5]):  # Max 5 buttons
            button = discord.ui.Button(
                label=category['name'],
                emoji=validate_emoji(category.get('emoji')),  # Validate emoji before sending to Discord
                style=discord.ButtonStyle.secondary,
                custom_id=f"ticket_create_{guild_id}_{panel_id}_{i}" if guild_id and panel_id else f"ticket_create_{i}"
            )
            button.callback = lambda inter, idx=i: self.create_ticket(inter, idx)
            self.add_item(button)

    async def create_ticket(self, interaction: discord.Interaction, category_index):
        """Create a new ticket with proper panel context tracking and category identification"""
        try:
            await interaction.response.send_message("🎫 Creating your ticket...", ephemeral=True)

            print(f"   Guild: {interaction.guild.id} ({interaction.guild.name})")
            print(f"   Panel ID: {self.panel_id}")
            print(f"   Category Index: {category_index}")
            print(f"   Available Categories: {len(self.categories)}")

            # Check if user already has an open ticket using JSON
            active_tickets = self.config_manager.db_handler.get_all_active_tickets()
            guild_tickets = active_tickets.get(str(interaction.guild.id), {})

            existing_ticket_channel = None
            for channel_id, ticket_data in guild_tickets.items():
                if (ticket_data.get('user_id') == interaction.user.id and 
                    ticket_data.get('status') == 'open'):
                    existing_ticket_channel = interaction.guild.get_channel(int(channel_id))
                    break

            if existing_ticket_channel:
                await interaction.edit_original_response(content=f"❌ You already have an open ticket: {existing_ticket_channel.mention}")
                return

            # Get the specific category from the panel context
            category = self.categories[category_index] if category_index < len(self.categories) else None

            if not category:
                print(f"❌ Category not found for index {category_index}")
                await interaction.edit_original_response(content="❌ Category not found. Please try again.")
                return


            # If we have panel context, get the full panel data to ensure we have all category details
            if self.panel_id and self.guild_id:
                try:
                    panel_data = await self.config_manager.get_panel_by_global_id(self.panel_id)
                    if panel_data and 'categories' in panel_data:
                        panel_categories = panel_data['categories']
                        if category_index < len(panel_categories):
                            # Use category from panel data which should have complete information
                            category = panel_categories[category_index]
                except Exception as e:
                    print(f"⚠️  Could not load panel data, using view category: {e}")

            # Get ticket configuration (this might be redundant but kept for compatibility)
            config = await self.config_manager.load_ticket_config(interaction.guild.id)

            # Determine where to create the ticket channel
            ticket_category = None
            if category and category.get('category_id'):
                ticket_category = interaction.guild.get_channel(category['category_id'])

            # If no category_id or category not found, create uncategorized ticket
            category_name = category['name'] if category else 'General Support'

            # Get next ticket number for this category
            ticket_number = await self.config_manager.get_next_ticket_number(interaction.guild.id, category_name)

            # Create ticket channel with new naming format
            username = interaction.user.name.lower().replace(" ", "-")
            channel_name = f"ticket-{ticket_number}-{username}"
            original_channel_name = channel_name  # Store original name

            channel = await interaction.guild.create_text_channel(
                name=channel_name,
                category=ticket_category,  # Will be None for uncategorized tickets
                topic=f"Support ticket for {interaction.user.display_name} | {category_name} | Ticket #{ticket_number}"
            )

            # Set up permissions according to requirements
            overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
                interaction.user: discord.PermissionOverwrite(
                    view_channel=True, 
                    send_messages=True, 
                    read_message_history=True,
                    attach_files=True, 
                    embed_links=True,
                    add_reactions=True, 
                    use_voice_activation=True,
                    use_application_commands=True
                ),
                interaction.guild.me: discord.PermissionOverwrite(
                    view_channel=True, 
                    send_messages=True, 
                    manage_messages=True,
                    read_message_history=True
                )
            }

            # Add support role permissions if configured - with moderate permissions
            if category and category.get('support_role_id'):
                support_role = interaction.guild.get_role(category['support_role_id'])
                if support_role:
                    overwrites[support_role] = discord.PermissionOverwrite(
                        view_channel=True, 
                        send_messages=True, 
                        read_message_history=True,
                        attach_files=True, 
                        embed_links=True,
                        add_reactions=True, 
                        use_voice_activation=True,
                        use_application_commands=True,
                        moderate_members=True,
                        manage_messages=True
                    )

            await channel.edit(overwrites=overwrites)

            # Log ticket in database
            ticket_data = {
                'guild_id': interaction.guild.id,
                'channel_id': channel.id,
                'user_id': interaction.user.id,
                'category_name': category_name,
                'ticket_number': ticket_number,
                'original_channel_name': original_channel_name,
                'original_category_id': ticket_category.id if ticket_category else None,  # Save original category for reopening
                'support_role_id': category.get('support_role_id') if category else None,  # Save support role for management
                'status': 'open',
                'created_at': datetime.utcnow().isoformat(),
                'panel_id': self.panel_id,  # Set from view context
                'global_panel_id': self.panel_id  # Store global_panel_id for correct closed_category lookup
            }

            # Create the ticket using JSON handler (which also updates statistics)
            self.config_manager.db_handler.create_ticket(interaction.guild.id, channel.id, ticket_data)

            # Create ticket embed with standard format
            from Jo1nTrX.utils.embeds import create_embed
            ticket_embed = EmbedFactory.create(
                title="🎫 New Support Ticket",
                description=f"**Category:** {category_name}\n**User:** {interaction.user.mention}\n**Status:** Open"
            )
            # Add custom footer with ticket info
            ist_timezone = timezone(timedelta(hours=5, minutes=30))
            current_time = datetime.now(ist_timezone).strftime('%I:%M %p')
            ticket_embed.set_footer(text=f"Ticket #{ticket_number} | ID: {channel.id} | Jo1nTrX ™ — Ticket Management | Requested by {interaction.user} at {current_time}")

            # Send welcome message in ticket
            welcome_content = f"Hello {interaction.user.mention}! Welcome to your support ticket."

            # Add support role ping if configured
            if category and category.get('support_role_id'):
                support_role = interaction.guild.get_role(category['support_role_id'])
                if support_role:
                    # Ping support role by default unless explicitly disabled
                    ping_support = category.get('ping_support', True)  # Default to True if not set
                    if ping_support:
                        welcome_content += f"\n\n{support_role.mention} - New ticket created!"

            # Create the main ticket embed with required fields using standard format
            ticket_embed = EmbedFactory.create(
                title="Ticket Information",
                timestamp=False
            )
            ticket_embed.add_field(name="**Category:**", value=category_name, inline=False)
            ticket_embed.add_field(name="**User:**", value=f"{interaction.user.mention} || {interaction.user.id}", inline=False)
            ticket_embed.add_field(name="**Claim status:**", value="Unclaimed", inline=False)

            # Create the ticket management view with buttons
            ticket_view = TicketManagementView(channel.id, interaction.user.id, category.get('support_role_id') if category else None)

            # Send welcome message and store its ID for later updates
            welcome_message = await channel.send(content=welcome_content, embed=ticket_embed, view=ticket_view)

            # Update ticket data with welcome message ID
            ticket_data['welcome_message_id'] = welcome_message.id
            self.config_manager.db_handler.save_active_ticket(interaction.guild.id, channel.id, ticket_data)

            # Update original interaction with disabled buttons to prevent multiple tickets
            status_msg = "✅ Ticket created successfully!"
            if not ticket_category:
                status_msg += "\n📝 Note: Ticket created as uncategorized (no category channel specified)"

            # Create a disabled version of the SELECT VIEW to prevent more ticket creation
            disabled_view = TicketSelectView(self.categories, self.config_manager, self.guild_id, self.panel_id)

            # Disable the select dropdown and update its placeholder
            for item in disabled_view.children:
                if isinstance(item, discord.ui.Select):
                    item.disabled = True
                    item.placeholder = "✅ Ticket created successfully!"
                    # Clear all options and add a single "completed" option
                    item.options = [discord.SelectOption(
                        label="✅ Ticket Created",
                        description=f"Ticket created in #{channel.name}",
                        value="completed",
                        emoji="✅"
                    )]

            await interaction.edit_original_response(content=f"{status_msg}\nTicket channel: {channel.mention}", view=disabled_view)

        except Exception as e:
            print(f"Error creating ticket: {e}")
            await interaction.edit_original_response(content="❌ Failed to create ticket. Please try again or contact an administrator.")

class LegacyTicketView(BaseView):
    """Special view to handle interactions from old panel messages with generic custom_ids"""
    def __init__(self, config_manager):
        super().__init__(timeout=None)
        self.config_manager = config_manager

        # Add select menu with old generic custom_id
        select = discord.ui.Select(
            placeholder="Select a ticket category...",
            options=[discord.SelectOption(label="Loading...", value="0")],  # Dummy option
            custom_id="ticket_category_select"
        )
        select.callback = self.handle_legacy_select
        self.add_item(select)

        # Add buttons with old generic custom_ids
        for i in range(5):
            button = discord.ui.Button(
                label=f"Option {i+1}",
                style=discord.ButtonStyle.secondary,
                custom_id=f"ticket_create_{i}"
            )
            button.callback = lambda inter, idx=i: self.handle_legacy_button(inter, idx)
            self.add_item(button)

    async def handle_legacy_select(self, interaction: discord.Interaction):
        """Handle select menu interactions from old panels"""
        try:
            # Find the correct panel based on the message ID
            panel_data = await self.find_panel_by_message(interaction.message.id, interaction.guild.id)
            if not panel_data:
                await interaction.response.send_message("❌ Panel not found. Please contact an administrator.", ephemeral=True)
                return

            # Get the category index from the interaction
            category_index = int(interaction.data['values'][0])

            # Create the correct view and delegate the ticket creation
            categories = panel_data.get('categories', [])
            correct_view = TicketSelectView(categories, self.config_manager, interaction.guild.id, panel_data.get('global_panel_id'))
            await correct_view.create_ticket(interaction)

        except Exception as e:
            print(f"Error in legacy select handler: {e}")
            await interaction.response.send_message("❌ An error occurred. Please try again.", ephemeral=True)

    async def handle_legacy_button(self, interaction: discord.Interaction, category_index: int):
        """Handle button interactions from old panels"""
        try:
            # Find the correct panel based on the message ID
            panel_data = await self.find_panel_by_message(interaction.message.id, interaction.guild.id)
            if not panel_data:
                await interaction.response.send_message("❌ Panel not found. Please contact an administrator.", ephemeral=True)
                return

            # Create the correct view and delegate the ticket creation
            categories = panel_data.get('categories', [])
            correct_view = TicketButtonsView(categories, self.config_manager, interaction.guild.id, panel_data.get('global_panel_id'))
            await correct_view.create_ticket(interaction, category_index)

        except Exception as e:
            print(f"Error in legacy button handler: {e}")
            await interaction.response.send_message("❌ An error occurred. Please try again.", ephemeral=True)

    async def find_panel_by_message(self, message_id: int, guild_id: int):
        """Find the panel data by matching the message ID"""
        try:
            all_panels = self.config_manager.db_handler.get_all_panels()
            guild_panels = all_panels.get(str(guild_id), {})

            for panel_id, panel_data in guild_panels.items():
                if panel_data.get('panel_message_id') == message_id:
                    return panel_data

            return None
        except Exception as e:
            print(f"Error finding panel by message ID: {e}")
            return None

class TicketSelectView(BaseView):
    def __init__(self, categories, config_manager, guild_id=None, panel_id=None):
        super().__init__(timeout=None)
        self.categories = categories
        self.config_manager = config_manager
        self.guild_id = guild_id
        self.panel_id = panel_id

        options = []
        for i, category in enumerate(categories[:25]):  # Discord limit
            options.append(discord.SelectOption(
                label=category['name'],
                description=category['description'],
                emoji=validate_emoji(category.get('emoji')),  # Validate emoji before sending to Discord
                value=str(i)
            ))

        # Use unique custom_id for new panels, but support legacy ones for backwards compatibility
        if guild_id and panel_id:
            custom_id = f"ticket_category_select_{guild_id}_{panel_id}"
        else:
            custom_id = "ticket_category_select"

        select = discord.ui.Select(
            placeholder="Select a ticket category...",
            options=options,
            custom_id=custom_id
        )
        select.callback = self.create_ticket
        self.add_item(select)

    async def create_ticket(self, interaction: discord.Interaction):
        """Create a new ticket from select menu with proper panel context tracking"""
        category_index = int(interaction.data['values'][0])

        try:
            await interaction.response.send_message("🎫 Creating your ticket...", ephemeral=True)

            print(f"   Guild: {interaction.guild.id} ({interaction.guild.name})")
            print(f"   Panel ID: {self.panel_id}")
            print(f"   Category Index: {category_index}")
            print(f"   Available Categories: {len(self.categories)}")

            # Check if user already has an open ticket using JSON
            active_tickets = self.config_manager.db_handler.get_all_active_tickets()
            guild_tickets = active_tickets.get(str(interaction.guild.id), {})

            existing_ticket_channel = None
            for channel_id, ticket_data in guild_tickets.items():
                if (ticket_data.get('user_id') == interaction.user.id and 
                    ticket_data.get('status') == 'open'):
                    existing_ticket_channel = interaction.guild.get_channel(int(channel_id))
                    break

            if existing_ticket_channel:
                await interaction.edit_original_response(content=f"❌ You already have an open ticket: {existing_ticket_channel.mention}")
                return

            # Get the specific category from the panel context
            category = self.categories[category_index] if category_index < len(self.categories) else None

            if not category:
                print(f"❌ Category not found for index {category_index}")
                await interaction.edit_original_response(content="❌ Category not found. Please try again.")
                return


            # If we have panel context, get the full panel data to ensure we have all category details
            if self.panel_id and self.guild_id:
                try:
                    panel_data = await self.config_manager.get_panel_by_global_id(self.panel_id)
                    if panel_data and 'categories' in panel_data:
                        panel_categories = panel_data['categories']
                        if category_index < len(panel_categories):
                            # Use category from panel data which should have complete information
                            category = panel_categories[category_index]
                except Exception as e:
                    print(f"⚠️  Could not load panel data, using view category: {e}")

            # Get ticket configuration (this might be redundant but kept for compatibility)
            config = await self.config_manager.load_ticket_config(interaction.guild.id)

            # Determine where to create the ticket channel
            ticket_category = None
            if category and category.get('category_id'):
                ticket_category = interaction.guild.get_channel(category['category_id'])

            # If no category_id or category not found, create uncategorized ticket
            category_name = category['name'] if category else 'General Support'

            # Get next ticket number for this category
            ticket_number = await self.config_manager.get_next_ticket_number(interaction.guild.id, category_name)

            # Create ticket channel with new naming format
            username = interaction.user.name.lower().replace(" ", "-")
            channel_name = f"ticket-{ticket_number}-{username}"
            original_channel_name = channel_name  # Store original name

            channel = await interaction.guild.create_text_channel(
                name=channel_name,
                category=ticket_category,  # Will be None for uncategorized tickets
                topic=f"Support ticket for {interaction.user.display_name} | {category_name} | Ticket #{ticket_number}"
            )

            # Set up permissions according to requirements
            overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
                interaction.user: discord.PermissionOverwrite(
                    view_channel=True, 
                    send_messages=True, 
                    read_message_history=True,
                    attach_files=True, 
                    embed_links=True,
                    add_reactions=True, 
                    use_voice_activation=True,
                    use_application_commands=True
                ),
                interaction.guild.me: discord.PermissionOverwrite(
                    view_channel=True, 
                    send_messages=True, 
                    manage_messages=True,
                    read_message_history=True
                )
            }

            # Add support role permissions if configured - with moderate permissions
            if category and category.get('support_role_id'):
                support_role = interaction.guild.get_role(category['support_role_id'])
                if support_role:
                    overwrites[support_role] = discord.PermissionOverwrite(
                        view_channel=True, 
                        send_messages=True, 
                        read_message_history=True,
                        attach_files=True, 
                        embed_links=True,
                        add_reactions=True, 
                        use_voice_activation=True,
                        use_application_commands=True,
                        moderate_members=True,
                        manage_messages=True
                    )

            await channel.edit(overwrites=overwrites)

            # Log ticket in database with claim status
            ticket_data = {
                'guild_id': interaction.guild.id,
                'channel_id': channel.id,
                'user_id': interaction.user.id,
                'category_name': category_name,
                'ticket_number': ticket_number,
                'original_channel_name': original_channel_name,
                'original_category_id': ticket_category.id if ticket_category else None,  # Save original category for reopening
                'support_role_id': category.get('support_role_id') if category else None,  # Save support role for management
                'status': 'open',
                'created_at': datetime.utcnow().isoformat(),
                'claimed_by': None,
                'panel_id': self.panel_id,  # Set from view context
                'global_panel_id': self.panel_id  # Store global_panel_id for correct closed_category lookup
            }

            # Create the ticket using JSON handler (which also updates statistics)
            self.config_manager.db_handler.create_ticket(interaction.guild.id, channel.id, ticket_data)

            # Send welcome message in ticket
            welcome_content = f"Hello {interaction.user.mention}! Welcome in your ticket!"

            # Add support role ping if configured
            if category and category.get('support_role_id'):
                support_role = interaction.guild.get_role(category['support_role_id'])
                if support_role:
                    welcome_content += f"\n\n{support_role.mention} - New ticket created!"

            # Create the main ticket embed with required fields using standard format
            ticket_embed = EmbedFactory.create(
                title="Ticket Information",
                timestamp=False
            )
            ticket_embed.add_field(name="**Category:**", value=category_name, inline=False)
            ticket_embed.add_field(name="**User:**", value=f"{interaction.user.mention} || {interaction.user.id}", inline=False)
            ticket_embed.add_field(name="**Claim status:**", value="Unclaimed", inline=False)

            # Create the ticket management view with buttons
            ticket_view = TicketManagementView(channel.id, interaction.user.id, category.get('support_role_id') if category else None)

            # Send welcome message and store its ID for later updates
            welcome_message = await channel.send(content=welcome_content, embed=ticket_embed, view=ticket_view)

            # Update ticket data with welcome message ID
            ticket_data['welcome_message_id'] = welcome_message.id
            self.config_manager.db_handler.save_active_ticket(interaction.guild.id, channel.id, ticket_data)

            # Update original interaction with disabled buttons to prevent multiple tickets
            status_msg = "✅ Ticket created successfully!"
            if not ticket_category:
                status_msg += "\n📝 Note: Ticket created as uncategorized (no category channel specified)"

            # Create a disabled version of the SELECT VIEW to prevent more ticket creation
            disabled_view = TicketSelectView(self.categories, self.config_manager, self.guild_id, self.panel_id)

            # Disable the select dropdown and update its placeholder
            for item in disabled_view.children:
                if isinstance(item, discord.ui.Select):
                    item.disabled = True
                    item.placeholder = "✅ Ticket created successfully!"
                    # Clear all options and add a single "completed" option
                    item.options = [discord.SelectOption(
                        label="✅ Ticket Created",
                        description=f"Ticket created in #{channel.name}",
                        value="completed",
                        emoji="✅"
                    )]

            await interaction.edit_original_response(content=f"{status_msg}\nTicket channel: {channel.mention}", view=disabled_view)

        except Exception as e:
            print(f"Error creating ticket: {e}")
            await interaction.edit_original_response(content="❌ Failed to create ticket. Please try again or contact an administrator.")

class PanelTypeSelectView(BaseView):
    def __init__(self, guild_id, config_manager, owner_id=None):
        super().__init__(timeout=60)
        self.guild_id = guild_id
        self.config_manager = config_manager
        self.owner_id = owner_id  # User who initiated the setup

        # Add buttons for panel type selection
        self.add_item(PanelTypeButton("➛ Buttons", "buttons"))
        self.add_item(PanelTypeButton("➛ Selective Menu", "menu"))

class PanelTypeButton(BaseButton):
    def __init__(self, label, panel_type):
        super().__init__(label=label, style=discord.ButtonStyle.primary)
        self.panel_type = panel_type

    async def callback(self, interaction: discord.Interaction):
        # Check if user is the owner of this configuration session
        view = self.view
        if view.owner_id and interaction.user.id != view.owner_id:
            await interaction.response.send_message(
                f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{view.owner_id}>! \n\nYou use `/ticket panel setup` to configure another.",
                ephemeral=True
            )
            return

        # Save panel type - create new panel with create_new=True to avoid copying from existing panels
        config = await view.config_manager.load_ticket_config(view.guild_id, create_new=True)
        config['panel_type'] = self.panel_type
        new_panel_id = await view.config_manager.save_ticket_config(view.guild_id, config)

        # Start main configuration with standard format
        embed = EmbedFactory.create(
            title=f"{interaction.guild.name if interaction.guild else 'Server'}",
            description="Use the buttons below to configure your ticket panel\n\n"
                       "**Channel Config**: Setup your ticket panel channel id!\n\n"
                       "**Ticket Embed**: Setup Ticket Embed message!\n\n"
                       "**Save & Continue**: To save the panel configuration & head toward category config!\n\n"
                       "**__Note__** <:Jo1nTrX_Note:1411930562288943104>\n\n"
                       "• Before setting up **Ticket Embed**, create **Embed** first! `+embed create <name>`.",
            timestamp=False
        )
        embed.set_thumbnail(url=interaction.client.user.avatar.url if interaction.client.user.avatar else interaction.client.user.default_avatar.url)

        panel_view = TicketPanelView(view.guild_id, view.config_manager, view.owner_id)
        panel_view.current_panel_id = new_panel_id  # Set the panel ID to track the correct panel
        await interaction.response.edit_message(embed=embed, view=panel_view)

class ConfirmDeleteView(BaseView):
    def __init__(self, guild_id, config_manager):
        super().__init__(timeout=30)
        self.guild_id = guild_id
        self.config_manager = config_manager

    @discord.ui.button(label="Confirm Delete", style=discord.ButtonStyle.danger, emoji=":jo1ntrx_delete:")
    async def confirm_delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Delete the configuration
        config_file = self.config_manager.config_file
        try:
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    all_configs = json.load(f)

                if str(self.guild_id) in all_configs:
                    del all_configs[str(self.guild_id)]

                    with open(config_file, 'w') as f:
                        json.dump(all_configs, f, indent=2)
        except:
            pass

        await interaction.response.edit_message(
            content="<:jo1ntrx_tick:1405094884947267715> Ticket panel configuration deleted successfully!",
            embed=None,
            view=None
        )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary, emoji=bot_emoji.cross)
    async def cancel_delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            content="<:jo1ntrx_cross:1405094904568483880> Deletion cancelled!",
            embed=None,
            view=None
        )

class TicketCloseView(BaseView):
    def __init__(self, channel, user):
        super().__init__(timeout=30)
        self.channel = channel
        self.user = user

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, emoji=bot_emoji.lock)
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check permissions
        ticket_cog = interaction.client.get_cog('Tickets')
        if not await ticket_cog.has_close_permission(interaction):
            await interaction.response.send_message("❌ You don't have permission to close this ticket.", ephemeral=True)
            return

        # ========== CHECK IF ALREADY CLOSED ==========
        # Check if ticket is already closed (channel name starts with "closed-")
        if interaction.channel.name.startswith("closed-"):
            await interaction.response.send_message("<:jo1ntrx_cross:1405094904568483880> This ticket is already closed! You cannot close it again.", ephemeral=True)
            return

        # ========== INSTANT RESPONSE (2 SECONDS) ==========
        # Get ticket info immediately for PostClosureView
        ticket_info = await ticket_cog.ticket_config.get_ticket_info(interaction.channel.id) if ticket_cog else None

        # Send INSTANT response to user
        await interaction.response.send_message("🔒 Ticket closed!", ephemeral=True)

        # Send close embed and PostClosureView buttons INSTANTLY in channel
        embed = EmbedFactory.create(
            title="🔒 Ticket Closed",
            description=f"This ticket has been closed by {interaction.user.mention}",
            timestamp=False
        )

        # Send PostClosureView (Reopen & Delete buttons) IMMEDIATELY
        view = PostClosureView(ticket_info)
        await interaction.channel.send(embed=embed, view=view)

        # ========== BACKGROUND PROCESSING (NON-BLOCKING) ==========
        # Do ALL heavy operations in background using same method as +close command
        asyncio.create_task(ticket_cog._instant_close_background_operations_button(
            interaction.guild, interaction.channel, ticket_info, interaction.user
        ))

class TicketDeleteView(BaseView):
    def __init__(self, channel, user):
        super().__init__(timeout=30)
        self.channel = channel
        self.user = user

    @discord.ui.button(label="Delete Ticket", style=discord.ButtonStyle.danger)
    async def delete_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Send timer response
        await interaction.response.send_message("⏳ Deleting ticket in 3 seconds...", ephemeral=True)

        # Get ticket info from database before deletion
        tickets_cog = interaction.client.get_cog('Tickets')
        ticket_info = await tickets_cog.ticket_config.get_ticket_info(self.channel.id) if tickets_cog else None

        # Start 3-second timer
        await asyncio.sleep(3)

        # Generate transcript before deletion (only on delete as requested)
        transcript_file = await tickets_cog.ticket_config.generate_ticket_transcript(self.channel, ticket_info)

        # Log ticket deletion with enhanced format
        await tickets_cog.ticket_config.log_ticket_closure(interaction.guild, ticket_info, "Deleted", self.user)

        # Send transcript to log channel if available
        if transcript_file:
            config = await tickets_cog.ticket_config.load_ticket_config(interaction.guild.id)
            log_channel_id = config.get('log_channel')
            if log_channel_id:
                log_channel = interaction.guild.get_channel(log_channel_id)
                if log_channel:
                    await log_channel.send(file=transcript_file)

        # Clean up ticket data from database file
        tickets_cog.ticket_config.db_handler.delete_active_ticket(interaction.guild.id, self.channel.id)

        # Update response before deletion
        await interaction.edit_original_response(content="✅ Ticket deleted successfully!")

        # Delete the ticket channel
        await self.channel.delete(reason=f"Ticket deleted by {self.user}")

class PanelListPaginationView(BaseView):
    def __init__(self, panels_data, current_page, total_pages, create_embed_func, author):
        super().__init__(timeout=300)
        self.panels_data = panels_data
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_embed = create_embed_func
        self.author = author

        # Update button states
        self.update_button_states()

    def update_button_states(self):
        """Update button disabled states based on current page"""
        # First page and previous page buttons
        self.first_page.disabled = self.current_page == 0
        self.previous_page.disabled = self.current_page == 0

        # Last page and next page buttons  
        self.next_page.disabled = self.current_page == self.total_pages - 1
        self.last_page.disabled = self.current_page == self.total_pages - 1

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message(
                "You cannot interact with this menu.", 
                ephemeral=True
            )
            return False
        return True

    @discord.ui.button(emoji=bot_emoji.double_left, style=discord.ButtonStyle.gray, row=0)
    async def first_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to first page"""
        self.current_page = 0
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.left, style=discord.ButtonStyle.gray, row=0)
    async def previous_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to previous page"""
        self.current_page -= 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.delete, style=discord.ButtonStyle.red, row=0)
    async def delete_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Delete the panel list message"""
        await interaction.response.edit_message(content="Panel list deleted.", embed=None, view=None)

    @discord.ui.button(emoji=bot_emoji.right, style=discord.ButtonStyle.gray, row=0)
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to next page"""
        self.current_page += 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.double_right, style=discord.ButtonStyle.gray, row=0)
    async def last_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to last page"""
        self.current_page = self.total_pages - 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    async def on_timeout(self):
        # Disable all buttons when timeout occurs
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True

class PostClosureView(BaseView):
    """View for post-closure buttons (Reopen & Delete) - P H E O N ! X ™"""

    # Class-level cooldown tracking to prevent rapid close/reopen toggling
    cooldowns = {}  # {channel_id: {'last_action': 'close'/'reopen', 'timestamp': time.time()}}

    def __init__(self, ticket_info):
        super().__init__(timeout=None)  # NEVER EXPIRES - Persistent view
        self.ticket_info = ticket_info

    async def has_support_permission(self, interaction):
        """Check if user has support permissions - ENHANCED VERSION"""
        # Administrator permissions always work
        if interaction.user.guild_permissions.administrator:
            return True

        # Check for various support-related roles (more permissive)
        user_roles = [role.name.lower() for role in interaction.user.roles]
        support_keywords = ['support', 'moderator', 'admin', 'staff', 'helper', 'mod', 'ticket']

        # Check if any role contains support keywords
        for role_name in user_roles:
            if any(keyword in role_name for keyword in support_keywords):
                return True

        # Also check for specific role IDs if they have Manage Channels permission
        if interaction.user.guild_permissions.manage_channels:
            return True

        return False

    async def on_error(self, interaction: discord.Interaction, error: Exception, item):
        """Handle errors in the view"""
        print(f"Error in PostClosureView: {error}")
        try:
            if not interaction.response.is_done():
                await interaction.response.send_message("❌ An error occurred. Please try again or contact support.", ephemeral=True)
            else:
                await interaction.followup.send("❌ An error occurred. Please try again or contact support.", ephemeral=True)
        except:
            pass

    async def has_support_permission(self, interaction):
        """Check if user has support permissions"""
        if interaction.user.guild_permissions.administrator:
            return True

        user_roles = [role.name.lower() for role in interaction.user.roles]
        support_roles = ['support', 'moderator', 'admin', 'staff']
        return any(role in user_roles for role in support_roles)


    @discord.ui.button(label="Reopen", style=discord.ButtonStyle.success, custom_id="reopen_ticket")
    async def reopen_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """
        ULTRA-FAST REOPEN - All 10 Steps Under 3 Seconds ⚡
        ==================================================
        """

        # CHECK 10-SECOND COOLDOWN
        channel_id = interaction.channel.id
        current_time = time.time()

        if channel_id in self.cooldowns:
            last_action = self.cooldowns[channel_id]
            if last_action['last_action'] == 'close' and (current_time - last_action['timestamp']) < 10:
                remaining = 10 - int(current_time - last_action['timestamp'])
                await interaction.response.send_message(f"⏰ Please wait {remaining} more seconds before reopening.", ephemeral=True)
                return

        # STEP 1: Start reopen process
        await interaction.response.send_message("🔓 **Step 1/5:** Starting ticket reopen process...", ephemeral=True)

        # Record reopen action for cooldown
        self.cooldowns[channel_id] = {'last_action': 'reopen', 'timestamp': current_time}

        try:
            # STEP 2: Get ticket data and validate status
            await interaction.followup.send("🔍 **Step 2/5:** Validating ticket status and permissions...", ephemeral=True)
            tickets_cog = interaction.client.get_cog('Tickets')
            if not tickets_cog:
                await interaction.followup.send("❌ Ticket system not available!", ephemeral=True)
                return
            ticket_data = tickets_cog.ticket_config.db_handler.get_active_ticket(interaction.guild.id, interaction.channel.id)

            # For reopen, if ticket data doesn't exist (was properly closed), that's expected
            # Check channel name instead to see if it's closed
            if not interaction.channel.name.startswith("closed-"):
                await interaction.followup.send("❌ This ticket is already open!", ephemeral=True)
                return

            # If ticket data exists but status is not closed, ticket is already open
            if ticket_data and ticket_data.get('status') != 'closed':
                await interaction.followup.send("❌ This ticket is already open!", ephemeral=True)
                return

            # STEP 3: Permission check - Handle missing ticket data
            support_role_id = ticket_data.get('support_role_id') if ticket_data else None
            if not (interaction.user.guild_permissions.administrator or 
                   (support_role_id and 
                    interaction.guild.get_role(support_role_id) in interaction.user.roles) or
                   await self.has_support_permission(interaction)):
                await interaction.followup.send("❌ No permission to reopen.", ephemeral=True)
                return

            # STEP 3: Restore ticket owner permissions
            await interaction.followup.send("🔑 **Step 3/5:** Restoring ticket owner permissions...", ephemeral=True)

            # Get ticket owner once - handle missing data
            ticket_owner = None
            if ticket_data and ticket_data.get('user_id'):
                ticket_owner = interaction.guild.get_member(ticket_data['user_id'])

            # Restore permissions for ticket owner
            if ticket_owner:
                await interaction.channel.set_permissions(
                    ticket_owner, view_channel=True, send_messages=True, 
                    read_messages=True, attach_files=True, embed_links=True
                )

            # STEP 4: Rename channel back to active format  
            await interaction.followup.send("✏️ **Step 4/5:** Renaming channel back to active format...", ephemeral=True)

            # Calculate new name for rename - ENHANCED LOGIC
            current_name = interaction.channel.name
            print(f"🔓 Reopening ticket: Current name = {current_name}")

            if current_name.startswith("closed-ticket-"):
                new_name = current_name.replace("closed-ticket-", "ticket-", 1)
            elif current_name.startswith("closed-"):
                new_name = current_name.replace("closed-", "ticket-", 1)
            else:
                new_name = f"ticket-{current_name}"

            print(f"🔓 Reopening ticket: New name will be = {new_name}")

            # STEP 6: Rename channel IMMEDIATELY (not in parallel to ensure it works)
            try:
                await interaction.channel.edit(name=new_name)
            except Exception as e:
                print(f"❌ Failed to rename channel: {e}")
                # Try alternative naming if the original fails
                try:
                    alternative_name = f"ticket-{int(time.time()) % 10000}"
                    await interaction.channel.edit(name=alternative_name)
                except Exception as e2:
                    print(f"❌ Alternative rename also failed: {e2}")

            # STEP 7: Move to original category - ENHANCED LOGIC
            original_category = None

            # Method 1: Try to get original category from ticket data
            if ticket_data and ticket_data.get('original_category_id'):
                original_category = interaction.guild.get_channel(ticket_data['original_category_id'])

            # Method 2: If no ticket data or original_category_id, determine from current location
            # When reopening, we want to move OUT of the closed category back to where tickets should be
            if not original_category:
                config = await tickets_cog.ticket_config.load_ticket_config(interaction.guild.id)
                closed_category_id = config.get('closed_category')

                # If we're currently in the closed category, we need to move to the original category
                if closed_category_id and interaction.channel.category and interaction.channel.category.id == closed_category_id:
                    # Try to find the right category by matching category_name across all panels
                    category_name = ticket_data.get('category_name', 'General') if ticket_data else 'General'

                    # Get all panels for this guild and search for matching category
                    panels = tickets_cog.ticket_config.db_handler.get_panels(interaction.guild.id)
                    for panel_key, panel_data in panels.items():
                        panel_global_id = panel_data.get('global_panel_id')
                        if panel_global_id:
                            categories = tickets_cog.ticket_config.db_handler.get_categories(interaction.guild.id, panel_global_id)
                            for cat in categories:
                                if cat.get('name') == category_name and cat.get('category_id'):
                                    original_category = interaction.guild.get_channel(cat['category_id'])
                                    if original_category:
                                        break
                            if original_category:
                                break

            # Move to original category if found
            if original_category:
                await interaction.channel.edit(category=original_category)

            # Update ticket status first (no panel_id needed)
            tickets_cog.ticket_config.db_handler.reopen_ticket(interaction.guild.id, interaction.channel.id, None)

            # Update with reopen info if we have existing data
            if ticket_data:
                from datetime import datetime
                ticket_data.update({
                    'status': 'open',
                    'reopened_by': interaction.user.id,
                    'reopened_at': datetime.now()
                })
                tickets_cog.ticket_config.db_handler.save_active_ticket(interaction.guild.id, interaction.channel.id, ticket_data)

            # Send reopen embed with buttons
            management_view = TicketManagementView(interaction.channel.id, ticket_owner.id if ticket_owner else 0, None)
            reopen_embed = EmbedFactory.create(
                title="🔓 Ticket Reopened",
                description=f"Reopened by {interaction.user.mention}",
                timestamp=False
            )
            await interaction.channel.send(embed=reopen_embed, view=management_view)

            # Send notification
            if ticket_owner:
                await interaction.channel.send(
                    f"{ticket_owner.mention}, your ticket has been reopened!",
                    allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False)
                )

            # Final success message
            await interaction.followup.send("✅ **Ticket reopened successfully!** All steps completed.", ephemeral=True)

        except Exception as e:
            await interaction.followup.send("❌ Reopen failed. Try again.", ephemeral=True)


    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, custom_id="delete_ticket")
    async def delete_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """
        DELETE BUTTON - ENHANCED TO MATCH COMMAND FUNCTIONALITY
        ======================================================

        PERMISSIONS: Support Staff and Administrators ONLY (not ticket owner)
        ACTIONS: Generates transcript, sends to log channel, 3-second countdown, PERMANENTLY deletes channel
        """
        # STEP 1: Defer interaction to prevent timeout
        await interaction.response.defer()

        try:
            # STEP 2: Get ticket data from closed_tickets
            tickets_cog = interaction.client.get_cog('Tickets')
            if not tickets_cog:
                await interaction.response.send_message("❌ Ticket system not available!", ephemeral=True)
                return
            ticket_data = tickets_cog.ticket_config.db_handler.get_active_ticket(interaction.guild.id, interaction.channel.id)

            # Debug logging
            if ticket_data:
                pass  # Ticket data found, continue

            if not ticket_data:
                await interaction.followup.send(
                    "❌ Ticket data not found! This ticket may have already been deleted.", 
                    ephemeral=True
                )
                return

            if ticket_data.get('status') != 'closed':
                await interaction.followup.send(
                    "❌ This ticket must be closed before deletion! Please close the ticket first using the buttons from the current menu.", 
                    ephemeral=True
                )
                return

            # STEP 3: Check permissions (only staff/admin, NOT ticket owner) - ENHANCED
            ticket_owner_id = ticket_data.get('user_id')

            # Check if user has deletion permissions
            can_delete = False

            # Administrator permissions always work
            if interaction.user.guild_permissions.administrator:
                can_delete = True
            # Check for specific support role assigned to this ticket
            elif ticket_data.get('support_role_id'):
                support_role = interaction.guild.get_role(ticket_data['support_role_id'])
                if support_role and support_role in interaction.user.roles:
                    can_delete = True
            # Check for general support permissions
            elif await self.has_support_permission(interaction):
                can_delete = True
            # Users with Manage Channels permission can delete
            elif interaction.user.guild_permissions.manage_channels:
                can_delete = True

            if not can_delete:
                await interaction.followup.send("❌ You don't have permission to delete this ticket! You need Administrator, Manage Channels, or a Support role.", ephemeral=True)
                return

            # STEP 4: Generate transcript and send to log channel BEFORE deletion (MATCHING COMMAND FUNCTIONALITY)
            try:
                await interaction.followup.send("📋 Generating ticket transcript and sending to log channel...")

                # Generate transcript BEFORE countdown
                transcript_file = await tickets_cog.ticket_config.generate_ticket_transcript(interaction.channel, self.ticket_info)
                await tickets_cog.ticket_config.log_ticket_closure(interaction.guild, self.ticket_info, "Deleted", interaction.user)

                # Send transcript to log channel
                if transcript_file:
                    config = await tickets_cog.ticket_config.load_ticket_config(interaction.guild.id)
                    log_channel_id = config.get('log_channel')
                    if log_channel_id:
                        log_channel = interaction.guild.get_channel(log_channel_id)
                        if log_channel:
                            await log_channel.send(file=transcript_file)

                await interaction.followup.send("✅ Transcript generated and logged!")

            except Exception as e:
                print(f"Error generating transcript: {e}")
                await interaction.followup.send("⚠️ Failed to generate transcript, proceeding with deletion...")

            # STEP 5: Remove ticket from closed_tickets storage
            tickets_cog.ticket_config.db_handler.delete_active_ticket(interaction.guild.id, interaction.channel.id)

            # STEP 6: Show countdown message (3 seconds)
            await interaction.followup.send("⏳ Deleting ticket in 3 seconds...")

            # STEP 7: PERMANENTLY delete channel
            await asyncio.sleep(3)  # 3 second countdown
            await interaction.channel.delete(reason=f"Ticket deleted by {interaction.user}")

        except Exception as e:
            await interaction.followup.send("❌ Failed to delete ticket. Please try again.", ephemeral=True)
            print(f"❌ Error in delete_ticket: {e}")

class Tickets(commands.Cog):
    """🎫 Ticket System - Create and manage support tickets"""

    def __init__(self, bot):
        self.bot = bot
        self.ticket_config = TicketConfig(bot)
        self.db_handler = self.ticket_config.db_handler
        self._panels_loaded = False  # Flag to ensure panels are loaded only once

    # Proxy methods to delegate to ticket_config
    async def load_ticket_config(self, guild_id, global_panel_id=None, create_new=False):
        """Proxy method to delegate to ticket_config"""
        return await self.ticket_config.load_ticket_config(guild_id, global_panel_id, create_new)

    async def get_panel_by_global_id(self, global_panel_id):
        """Proxy method to delegate to ticket_config"""
        return await self.ticket_config.get_panel_by_global_id(global_panel_id)

    async def get_next_ticket_number(self, guild_id, category_name):
        """Proxy method to delegate to ticket_config"""
        return await self.ticket_config.get_next_ticket_number(guild_id, category_name)

    async def save_ticket_config(self, guild_id, config_data, panel_id=None):
        """Proxy method to delegate to ticket_config"""
        return await self.ticket_config.save_ticket_config(guild_id, config_data, panel_id)

    async def cog_load(self):
        """Setup persistent views when cog loads - Schedule background task"""
        self.bot.loop.create_task(self._restore_panels_after_ready())

    async def _restore_panels_after_ready(self):
        """Background task that waits for bot to be ready before loading panels"""
        try:
            await self.bot.wait_until_ready()

            if self._panels_loaded:
                return

            self._panels_loaded = True

            views_to_remove = [view for view in self.bot.persistent_views 
                             if isinstance(view, (TicketButtonsView, TicketSelectView, TicketManagementView, PostClosureView))]
            for view in views_to_remove:
                self.bot.persistent_views.remove(view)

            try:
                all_panels = await asyncio.wait_for(
                    asyncio.to_thread(self.db_handler.get_all_panels),
                    timeout=60.0
                )
            except asyncio.TimeoutError:
                print(f"❌ Database fetch timed out after 60 seconds")
                all_panels = {}
            except Exception as db_error:
                print(f"❌ Failed to fetch panels from database: {db_error}")
                all_panels = {}

            restored_count = 0
            skipped_count = 0

            for guild_id_str, guild_panels in all_panels.items():
                guild_id = int(guild_id_str)

                guild = self.bot.get_guild(guild_id)
                if not guild:
                    skipped_count += len(guild_panels)
                    continue

                for panel_key, panel_data in guild_panels.items():
                    try:
                        global_panel_id = panel_data.get('global_panel_id')
                        panel_type = panel_data.get('panel_type', 'menu')

                        categories = panel_data.get('categories', [])

                        if not categories:
                            categories = self.db_handler.get_categories(guild_id, global_panel_id)

                        if not categories:
                            skipped_count += 1
                            continue

                        valid_categories = []
                        for cat in categories:
                            if cat.get('category_id'):
                                category_channel = guild.get_channel(cat['category_id'])
                                if not category_channel:
                                    continue

                            valid_categories.append({
                                'name': cat.get('name', 'Unknown'),
                                'emoji': cat.get('emoji', '🎫'),
                                'description': cat.get('description', 'Support'),
                                'category_id': cat.get('category_id'),
                                'support_role_id': cat.get('support_role_id'),
                                'ping_support': cat.get('ping_support', False)
                            })

                        if not valid_categories:
                            skipped_count += 1
                            continue

                        if panel_type == 'buttons':
                            view = TicketButtonsView(valid_categories, self.ticket_config, guild_id, global_panel_id)
                        else:
                            view = TicketSelectView(valid_categories, self.ticket_config, guild_id, global_panel_id)

                        panel_channel_id = panel_data.get('panel_channel')
                        panel_message_id = panel_data.get('panel_message_id')

                        if panel_channel_id and panel_message_id:
                            panel_channel = guild.get_channel(panel_channel_id)
                            if panel_channel:
                                self.bot.add_view(view, message_id=panel_message_id)
                                restored_count += 1
                            else:
                                skipped_count += 1
                        else:
                            self.bot.add_view(view)
                            restored_count += 1

                    except Exception as panel_error:
                        print(f"❌ Error loading panel {panel_key} for guild {guild_id}: {panel_error}")
                        skipped_count += 1
                        continue

            print(f"✅ Ticket panels loaded: {restored_count} restored, {skipped_count} skipped")

            management_view = TicketManagementView(0, 0, 0)
            post_closure_view = PostClosureView({})

            self.bot.add_view(management_view)
            self.bot.add_view(post_closure_view)

            try:
                legacy_view = LegacyTicketView(self.ticket_config)
                self.bot.add_view(legacy_view)
            except Exception:
                pass

        except Exception as e:
            traceback.print_exc()

            try:
                management_view = TicketManagementView(0, 0, 0)
                post_closure_view = PostClosureView({})
                self.bot.add_view(management_view)
                self.bot.add_view(post_closure_view)
            except Exception:
                pass
            finally:
                self._panels_loaded = True

    async def cleanup_duplicate_panels(self):
        """Remove duplicate panel entries - handled by database constraints"""
        try:
            # Database constraints prevent duplicates automatically
            # This method is kept for compatibility
            print("🧹 Panel cleanup is handled automatically by database")

        except Exception as e:
            print(f"❌ Error in panel cleanup: {e}")

    @commands.group(name='ticket', aliases=['tickets'], invoke_without_command=True)
    async def ticket(self, ctx):
        """Ticket help menu"""
        # Create ticket help embed with standard format
        embed = EmbedFactory.create(
            title="<:Jo1nTrX_ticket:1412649169801187429> Ticket System Help",
            description="**Ticket Management Commands**\n\n"
                       "**Administration Commands** (Requires Admin Permissions):\n"
                       "`+ticket panel setup <type>` - Setup ticket panel (Buttons/Menu)\n"
                       "`+ticket panel list` - List all ticket panels\n"
                       "`+ticket panel edit <panel_id>` - Edit ticket panel\n"
                       "`+ticket panel send <panel_id> <channel>` - Send panel to channel\n"
                       "`+ticket panel delete <panel_id>` - Delete ticket panel\n\n"
                       "**Support Commands** (Requires Support Role):\n"
                       "`+add <user>` - Add user to ticket\n"
                       "`+remove <user>` - Remove user from ticket\n"
                       "`+close` - Close the ticket\n"
                       "`+delete` - Delete the ticket\n"
                       "`+claim` - Claim the ticket\n"
                       "`+reopen` - Reopen closed ticket",
            timestamp=False
        )
        embed.set_thumbnail(url=(ctx.guild.icon.url if ctx.guild.icon else None) or (ctx.bot.user.avatar.url if ctx.bot.user.avatar else ctx.bot.user.default_avatar.url))
        await ctx.send(embed=embed)

    @ticket.group(name='panel')
    @commands.has_permissions(administrator=True)
    async def panel(self, ctx):
        """Ticket panel management"""
        if ctx.invoked_subcommand is None:
            await ctx.send("Use `+ticket panel setup`, `list`, `edit`, `send`, or `delete`")

    @panel.command(name='debug')
    async def panel_debug(self, ctx, panel_id: int = None):
        """Debug ticket panel configuration to troubleshoot category and support role issues"""
        config = await self.ticket_config.load_ticket_config(ctx.guild.id, panel_id)

        if not config:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> No ticket panel configuration found!")
            return

        categories = config.get('categories', [])

        if not categories:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> No categories configured in this panel!")
            return

        # Create detailed debug embed
        embed = EmbedFactory.create(
            title="🔍 Ticket Panel Debug Information",
            description=f"**Panel ID:** {config.get('global_panel_id', 'Unknown')}\n"
                       f"**Panel Type:** {config.get('panel_type', 'Unknown')}\n"
                       f"**Categories Found:** {len(categories)}",
            timestamp=False
        )

        for i, category in enumerate(categories[:10]):  # Limit to first 10 categories
            category_name = category.get('name', 'Unknown')
            category_id = category.get('category_id')
            support_role_id = category.get('support_role_id')
            ping_support = category.get('ping_support', False)

            category_info = f"**Category ID:** {category_id if category_id else 'Not Set'}\n"
            category_info += f"**Support Role ID:** {support_role_id if support_role_id else 'Not Set'}\n"
            category_info += f"**Ping Support:** {'✅ Yes' if ping_support else '❌ No'}\n"

            if support_role_id:
                role = ctx.guild.get_role(support_role_id)
                if role:
                    category_info += f"**Role Found:** {role.mention}"
                else:
                    category_info += f"**Role Found:** ❌ Role not found!"

            embed.add_field(
                name=f"{i+1}. {category_name} {category.get('emoji', '🎫')}",
                value=category_info,
                inline=False
            )

        await ctx.send(embed=embed)

    @panel.command(name='setup')
    async def panel_setup(self, ctx, panel_type: str = None):
        """Setup ticket panel with type selection"""
        if not panel_type:
            # Show type selection with standard format
            embed = EmbedFactory.create(
                title="🎫 Ticket Panel Setup",
                description="Please select the type of ticket panel you want to create:",
                timestamp=False
            )

            view = PanelTypeSelectView(ctx.guild.id, self.ticket_config, ctx.author.id)
            await ctx.send(embed=embed, view=view)
        else:
            if panel_type.lower() not in ['buttons', 'menu']:
                await ctx.send("<:jo1ntrx_cross:1405094904568483880> Invalid type! Use `buttons` or `menu`")
                return

            # Start with a new panel configuration
            config = {'panel_type': panel_type.lower()}

            # Start panel configuration
            embed = discord.Embed(
                title=f"{ctx.guild.name}",
                description="Use the buttons below to configure your ticket panel\n\n"
                           "**Channel Config**: Setup your ticket panel channel id!\n\n"
                           "**Ticket Embed**: Setup Ticket Embed message!\n\n"
                           "**Save & Continue**: To save the panel configuration & head toward category config!\n\n"
                           "**__Note__** <:Jo1nTrX_Note:1411930562288943104>\n\n"
                           "• Before setting up **Ticket Embed**, create **Embed** first! `+embed create <name>`.",
                color=0x2b2d31
            )
            embed.set_thumbnail(url=self.bot.user.avatar.url if self.bot.user.avatar else self.bot.user.default_avatar.url)
            ist_timezone = timezone(timedelta(hours=5, minutes=30))
            current_time = datetime.now(ist_timezone).strftime('%I:%M %p')
            embed.set_footer(text=f"Jo1nTrX ™ — Ticket Management | Requested by {ctx.author} at {current_time}")

            view = TicketPanelView(ctx.guild.id, self.ticket_config)
            await ctx.send(embed=embed, view=view)


    @panel.command(name='list')
    async def panel_list(self, ctx, page: int = 1):
        """List all ticket panels with animated navigation"""
        panels = await self.ticket_config.get_all_panels(ctx.guild.id)

        if not panels:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> No ticket panels configured!")
            return

        # Pagination settings
        panels_per_page = 5
        total_pages = (len(panels) + panels_per_page - 1) // panels_per_page

        if page < 1 or page > total_pages:
            await ctx.send(f"<:jo1ntrx_cross:1405094904568483880> Invalid page number! Please use a page between 1 and {total_pages}.")
            return

        # Calculate start and end indices
        start_idx = (page - 1) * panels_per_page
        end_idx = min(start_idx + panels_per_page, len(panels))
        page_panels = panels[start_idx:end_idx]

        panel_list = []
        for panel in page_panels:
            panel_id = panel.get('global_panel_id')
            embed_name = panel.get('ticket_embed', 'Not set')

            # Format creation date
            from datetime import datetime, timezone, timedelta
            try:
                created_at = panel.get('created_at')
                if created_at:
                    if isinstance(created_at, str):
                        created_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                    else:
                        created_date = created_at

                    # Convert to IST timezone (UTC+5:30)
                    ist_timezone = timezone(timedelta(hours=5, minutes=30))
                    if created_date.tzinfo is None:
                        created_date = created_date.replace(tzinfo=timezone.utc)

                    ist_time = created_date.astimezone(ist_timezone)
                    formatted_date = ist_time.strftime("%B %d, %Y at %I:%M %p IST")
                else:
                    formatted_date = "Date not available"
            except:
                formatted_date = "Date not available"

            panel_entry = (
                f"--------------------------------------------\n"
                f"➛ | Panel ID : #{panel_id}\n"
                f"➛ | Created on : {formatted_date}\n"
                f"➛ | Ticket Embed : {embed_name}\n"
                f"--------------------------------------------"
            )
            panel_list.append(panel_entry)

        description = "\n\n".join(panel_list)

        from Jo1nTrX.utils.embeds import create_embed
        embed = EmbedFactory.create(
            title="🎫 Ticket Panels",
            description=description,
            color=0x7c28eb
        )

        embed.set_footer(text=f"Page {page}/{total_pages} | Total: {len(panels)} panels")

        # If only one page, show without navigation
        if total_pages == 1:
            await ctx.send(embed=embed)
            return

        # Create pagination view
        def create_panel_embed(page_num):
            start_index = page_num * panels_per_page
            end_index = start_index + panels_per_page
            page_panels = panels[start_index:end_index]

            panel_list_data = []
            for panel in page_panels:
                panel_id = panel.get('global_panel_id')
                embed_name = panel.get('ticket_embed', 'Not set')

                # Format creation date
                from datetime import datetime, timezone, timedelta
                try:
                    created_at = panel.get('created_at')
                    if created_at:
                        if isinstance(created_at, str):
                            created_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                        else:
                            created_date = created_at

                        # Convert to IST timezone (UTC+5:30)
                        ist_timezone = timezone(timedelta(hours=5, minutes=30))
                        if created_date.tzinfo is None:
                            created_date = created_date.replace(tzinfo=timezone.utc)

                        ist_time = created_date.astimezone(ist_timezone)
                        formatted_date = ist_time.strftime("%B %d, %Y at %I:%M %p IST")
                    else:
                        formatted_date = "Date not available"
                except:
                    formatted_date = "Date not available"

                panel_entry = (
                    f"--------------------------------------------\n"
                    f"➛ | Panel ID : #{panel_id}\n"
                    f"➛ | Created on : {formatted_date}\n"
                    f"➛ | Ticket Embed : {embed_name}\n"
                    f"--------------------------------------------"
                )
                panel_list_data.append(panel_entry)

            description = "\n\n".join(panel_list_data)

            from Jo1nTrX.utils.embeds import create_embed
            embed = EmbedFactory.create(
                title="🎫 Ticket Panels",
                description=description,
                color=0x7c28eb
            )

            embed.set_footer(text=f"Page {page_num + 1}/{total_pages} | Total: {len(panels)} panels")
            return embed

        view = PanelListPaginationView(panels, page - 1, total_pages, create_panel_embed, ctx.author)
        await ctx.send(embed=embed, view=view)

    @panel.command(name='edit')
    async def panel_edit(self, ctx, panel_id: str = None):
        """Edit ticket panel configuration"""
        # For simplicity, we'll just restart the setup process
        await ctx.send("🔄 Starting panel reconfiguration...")
        await self.panel_setup(ctx)

    @panel.command(name='send')
    @app_commands.describe(
        panel_id="The panel ID to send",
        channel="The channel to send the panel to"
    )
    async def panel_send(self, ctx, panel_id: int, channel: discord.TextChannel):
        """Send an existing ticket panel to a channel"""
        loading_msg = None
        try:
            # Check permissions
            if not ctx.author.guild_permissions.manage_channels:
                await ctx.send("❌ You need `Manage Channels` permission to use this command.", ephemeral=True)
                return

            # Show loading message
            loading_msg = await ctx.send(f"{emoji.loading or '⏳'} Sending ticket panel...")

            # Get panel data using global_panel_id directly from database handler
            all_panels = self.db_handler.get_panels(ctx.guild.id)
            panel_data = None

            for key, panel in all_panels.items():
                if panel.get('global_panel_id') == panel_id:
                    panel_data = panel
                    break

            if not panel_data:
                await loading_msg.edit(content="❌ Panel not found. Use `+ticket panel list` to see available panels.")
                return

            # Get categories for the panel
            categories = panel_data.get('categories', [])
            if not categories:
                await loading_msg.edit(content="❌ This panel has no categories configured.")
                return

            # Create the embed using the custom ticket embed if configured
            embed_name = panel_data.get('ticket_embed')
            if embed_name:
                # Use the custom embed configured during setup
                from Jo1nTrX.cogs.extra.embeds import create_embed_from_database_data
                message_content, embed = await create_embed_from_database_data(self.bot, ctx.guild.id, embed_name)
                if not embed:
                    # Fallback to default embed if custom embed fails
                    from Jo1nTrX.utils.embeds import create_embed
                    embed = EmbedFactory.create(
                        title="🎫 Support Tickets",
                        description="Click a button below to create a support ticket!",
                        timestamp=False
                    )
            else:
                # Default embed when no custom embed is selected
                from Jo1nTrX.utils.embeds import create_embed
                embed = EmbedFactory.create(
                    title="🎫 Support Tickets",
                    description="Click a button below to create a support ticket!",
                    timestamp=False
                )

            # Create the appropriate view
            panel_type = panel_data.get('panel_type', 'buttons')
            if panel_type == 'buttons':
                view = TicketButtonsView(categories, self)
            else:
                view = TicketSelectView(categories, self)

            # Send the panel
            panel_message = await channel.send(embed=embed, view=view)

            # Update panel data with new message info
            panel_data['panel_channel'] = channel.id
            panel_data['panel_message_id'] = panel_message.id
            panel_data['global_panel_id'] = panel_id

            # Save to JSON storage
            self.db_handler.save_panel(ctx.guild.id, f"panel_{panel_id}", panel_data)

            # Also save to MySQL database for bot restart persistence
            await self.bot.db.save_ticket_panel(ctx.guild.id, panel_id, panel_data)

            # Add persistent view
            self.bot.add_view(view)

            await loading_msg.edit(content=f"✅ Successfully sent panel **#{panel_id}** to {channel.mention}!")

        except Exception as e:
            if loading_msg:
                await loading_msg.edit(content=f"❌ Error sending panel: {str(e)}")
            else:
                await ctx.send(f"❌ Error sending panel: {str(e)}")
            print(f"Error in ticket panel send: {e}")

    @panel.command(name='delete')
    async def panel_delete(self, ctx, panel_id: str = None):
        """Delete ticket panel"""
        config = await self.ticket_config.load_ticket_config(ctx.guild.id)

        if not config:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> No ticket panel to delete!")
            return

        # Confirmation with standard format
        embed = EmbedFactory.create(
            title="⚠️ Confirm Deletion",
            description="Are you sure you want to delete the ticket panel configuration?\n\n"
                       "This action cannot be undone!",
            timestamp=False
        )

        view = ConfirmDeleteView(ctx.guild.id, self.ticket_config)
        await ctx.send(embed=embed, view=view)

    # Support role commands - standalone commands
    @commands.command(name='add')
    async def ticket_add(self, ctx, *, user_input: str = None):
        """Add user to the current ticket"""
        # Check if user has required roles or administrator permissions
        has_permission = False
        if ctx.author.guild_permissions.administrator:
            has_permission = True
        else:
            # Check for ticket-specific support role first
            ticket_data = self.db_handler.get_active_ticket(ctx.guild.id, ctx.channel.id)
            if ticket_data:
                support_role_id = ticket_data.get('support_role_id')
                if support_role_id:
                    support_role = ctx.guild.get_role(support_role_id)
                    if support_role and support_role in ctx.author.roles:
                        has_permission = True

            # If not ticket support role, check for general support roles (case-insensitive)
            if not has_permission:
                user_roles = [role.name.lower() for role in ctx.author.roles]
                required_roles = ['support', 'moderator', 'admin']
                if any(role in user_roles for role in required_roles):
                    has_permission = True

        if not has_permission:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> You need Support, Moderator, Admin role or Administrator permissions to use this command!")
            return

        if not self.is_ticket_channel(ctx.channel):
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> This command can only be used in ticket channels!")
            return

        # Additional permission check - ensure user has channel access (unless admin)
        if not ctx.author.guild_permissions.administrator:
            channel_perms = ctx.channel.permissions_for(ctx.author)
            if not channel_perms.read_messages:
                await ctx.send("<:jo1ntrx_cross:1405094904568483880> You don't have permission to manage this ticket!")
                return

        if not user_input:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> Please provide a user ID or mention. Usage: `+add @user` or `+add 123456789`")
            return

        user = None

        # Try to parse user mention first
        if user_input.startswith('<@') and user_input.endswith('>'):
            # Extract user ID from mention
            user_id_str = user_input[2:-1]
            if user_id_str.startswith('!'):
                user_id_str = user_id_str[1:]  # Remove nickname indicator
            try:
                user_id = int(user_id_str)
                user = ctx.guild.get_member(user_id)
            except ValueError:
                pass
        else:
            # Try to parse as direct user ID
            try:
                user_id = int(user_input.strip())
                user = ctx.guild.get_member(user_id)
            except ValueError:
                await ctx.send("<:jo1ntrx_cross:1405094904568483880> Invalid user format! Please provide a user ID or mention.")
                return

        if not user:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> User not found in this server.")
            return

        try:
            await ctx.channel.set_permissions(user, view_channel=True, send_messages=True, attach_files=True, add_reactions=True, use_voice_activation=True)
            await ctx.send(f"<:jo1ntrx_tick:1405094884947267715> Added {user.mention} to the ticket!")

            # Log the action
            await self.log_ticket_action(ctx.guild, "User Added", f"{ctx.author.mention} added {user.mention} to {ctx.channel.mention}")

        except discord.Forbidden:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> I don't have permission to modify channel permissions!")

    @commands.command(name='remove')
    async def ticket_remove(self, ctx, user: discord.Member):
        """Remove user from the current ticket"""
        # Check if user has required roles or administrator permissions
        has_permission = False
        if ctx.author.guild_permissions.administrator:
            has_permission = True
        else:
            # Check for ticket-specific support role first
            ticket_data = self.db_handler.get_active_ticket(ctx.guild.id, ctx.channel.id)
            if ticket_data:
                support_role_id = ticket_data.get('support_role_id')
                if support_role_id:
                    support_role = ctx.guild.get_role(support_role_id)
                    if support_role and support_role in ctx.author.roles:
                        has_permission = True

            # If not ticket support role, check for general support roles (case-insensitive)
            if not has_permission:
                user_roles = [role.name.lower() for role in ctx.author.roles]
                required_roles = ['support', 'moderator', 'admin']
                if any(role in user_roles for role in required_roles):
                    has_permission = True

        if not has_permission:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> You need Support, Moderator, Admin role or Administrator permissions to use this command!")
            return

        if not self.is_ticket_channel(ctx.channel):
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> This command can only be used in ticket channels!")
            return

        # Additional permission check - ensure user has channel access (unless admin)
        if not ctx.author.guild_permissions.administrator:
            channel_perms = ctx.channel.permissions_for(ctx.author)
            if not channel_perms.read_messages:
                await ctx.send("<:jo1ntrx_cross:1405094904568483880> You don't have permission to manage this ticket!")
                return

        try:
            await ctx.channel.set_permissions(user, overwrite=None)
            await ctx.send(f"<:jo1ntrx_tick:1405094884947267715> Removed {user.mention} from the ticket!")

            # Log the action
            await self.log_ticket_action(ctx.guild, "User Removed", f"{ctx.author.mention} removed {user.mention} from {ctx.channel.mention}")

        except discord.Forbidden:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> I don't have permission to modify channel permissions!")

    @commands.command(name='rename')
    async def ticket_rename(self, ctx, *, new_name: str = None):
        """Rename the current ticket"""
        # Check if user has required roles or administrator permissions
        has_permission = False
        if ctx.author.guild_permissions.administrator:
            has_permission = True
        else:
            # Check for modrole from database first
            modrole_id = await self.bot.db.get_modrole(ctx.guild.id)
            if modrole_id:
                modrole = ctx.guild.get_role(modrole_id)
                if modrole and modrole in ctx.author.roles:
                    has_permission = True

            # Check for ticket-specific support role
            if not has_permission:
                ticket_data = self.db_handler.get_active_ticket(ctx.guild.id, ctx.channel.id)
                if ticket_data:
                    support_role_id = ticket_data.get('support_role_id')
                    if support_role_id:
                        support_role = ctx.guild.get_role(support_role_id)
                        if support_role and support_role in ctx.author.roles:
                            has_permission = True

            # If not modrole or ticket support role, check for general support roles (case-insensitive)
            if not has_permission:
                user_roles = [role.name.lower() for role in ctx.author.roles]
                required_roles = ['support', 'moderator', 'admin', 'staff']
                if any(role in user_roles for role in required_roles):
                    has_permission = True

        if not has_permission:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> You need Support, Moderator, Admin role or Administrator permissions to use this command!")
            return

        if not self.is_ticket_channel(ctx.channel):
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> This command can only be used in ticket channels!")
            return

        # Additional permission check - ensure user has channel access (unless admin)
        if not ctx.author.guild_permissions.administrator:
            channel_perms = ctx.channel.permissions_for(ctx.author)
            if not channel_perms.read_messages:
                await ctx.send("<:jo1ntrx_cross:1405094904568483880> You don't have permission to manage this ticket!")
                return

        if not new_name:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> Please provide a new name. Usage: `+rename <new name>`")
            return

        # Clean the name for Discord channel naming while preserving prefixes
        # Replace spaces with dashes, then filter invalid characters
        clean_name = new_name.replace(' ', '-').lower()
        clean_name = ''.join(c for c in clean_name if c.isalnum() or c in '-_')
        if not clean_name:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> Invalid name format.")
            return

        old_name = ctx.channel.name

        # Preserve important prefixes (closed-, ✅-)
        final_name = clean_name
        if old_name.startswith("closed-"):
            final_name = f"closed-{clean_name}"
        elif old_name.startswith("✅-"):
            final_name = f"✅-{clean_name}"

        try:
            await ctx.channel.edit(name=final_name)
            await ctx.send(f"<:jo1ntrx_tick:1405094884947267715> Ticket renamed successfully!")
            await ctx.channel.send(f"📝 Ticket renamed from `{old_name}` to `{final_name}` by {ctx.author.mention}")

            # Log the action
            await self.log_ticket_action(ctx.guild, "Ticket Renamed", f"{ctx.author.mention} renamed {ctx.channel.mention} from `{old_name}` to `{final_name}`")

        except discord.Forbidden:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> I don't have permission to rename this channel!")

    def check_command_cooldown(self, channel_id, action_name):
        """Check if command action is on cooldown and return remaining time"""
        import time
        # Use shared cooldown with buttons - FIXED to use cooldowns instead of action_cooldowns
        if not hasattr(PostClosureView, 'cooldowns'):
            PostClosureView.cooldowns = {}

        current_time = time.time()

        # Check if there's a recent action
        if channel_id in PostClosureView.cooldowns:
            last_action_data = PostClosureView.cooldowns[channel_id]
            time_since_last = current_time - last_action_data['timestamp']

            if time_since_last < 10:  # 10 second cooldown
                remaining = 10 - time_since_last
                return False, remaining

        # Update cooldown
        PostClosureView.cooldowns[channel_id] = {'last_action': action_name, 'timestamp': current_time}
        return True, 0

    @commands.command(name='close')
    async def ticket_close(self, ctx):
        """Close the current ticket - ENHANCED TO MATCH BUTTON FUNCTIONALITY"""
        # CHECK IF THIS IS A TICKET CHANNEL FIRST
        if not self.is_ticket_channel(ctx.channel):
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> This command can only be used in ticket channels!", delete_after=10)
            return

        # CHECK 10-SECOND COOLDOWN (prevent rapid reopen→close)
        channel_id = ctx.channel.id
        current_time = time.time()

        # Access the cooldowns from PostClosureView class
        if hasattr(PostClosureView, 'cooldowns') and channel_id in PostClosureView.cooldowns:
            last_action = PostClosureView.cooldowns[channel_id]
            if last_action['last_action'] == 'reopen' and (current_time - last_action['timestamp']) < 10:
                remaining = 10 - int(current_time - last_action['timestamp'])
                await ctx.send(f"⏰ Please wait {remaining} more seconds before closing again.", delete_after=5)
                return

        # Create ticket_config instance for permission check and other operations
        ticket_config = TicketConfig(ctx.bot)

        # Check permissions using enhanced method (matches button system)
        # Create a mock interaction-like object for permission check
        class CtxWrapper:
            def __init__(self, ctx):
                self.user = ctx.author
                self.guild = ctx.guild
                self.channel = ctx.channel
                self.guild_permissions = ctx.author.guild_permissions

        ctx_wrapper = CtxWrapper(ctx)

        # Simple permission check for command
        ticket_info = await ticket_config.get_ticket_info(ctx.channel.id)
        if ticket_info:
            ticket_owner_id = ticket_info.get('user_id')
            if not (ctx.author.id == ticket_owner_id or 
                   ctx.author.guild_permissions.administrator):
                # Check for support roles
                user_roles = [role.name.lower() for role in ctx.author.roles]
                support_keywords = ['support', 'moderator', 'admin', 'staff', 'helper', 'mod', 'ticket']
                has_support_role = any(keyword in role_name for role_name in user_roles for keyword in support_keywords)

                if not has_support_role:
                    await ctx.send("❌ You don't have permission to close this ticket.", delete_after=10)
                    return

        # ========== CHECK IF ALREADY CLOSED ==========
        # Check if ticket is already closed (channel name starts with "closed-")
        if ctx.channel.name.startswith("closed-"):
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> This ticket is already closed! You cannot close it again.", delete_after=10)
            return

        # ========== INSTANT RESPONSE (2 SECONDS) ==========
        # Get ticket info immediately for PostClosureView
        if not ticket_info:
            ticket_info = await ticket_config.get_ticket_info(ctx.channel.id)

        # Send INSTANT response to user
        timer_msg = await ctx.send("🔒 Ticket closed!")

        # Send close embed and PostClosureView buttons INSTANTLY in channel
        embed = EmbedFactory.create(
            title="🔒 Ticket Closed",
            description=f"This ticket has been closed by {ctx.author.mention}",
            timestamp=False
        )

        # Send PostClosureView (Reopen & Delete buttons) IMMEDIATELY
        view = PostClosureView(ticket_info)
        await ctx.channel.send(embed=embed, view=view)

        # TRACK CLOSE ACTION FOR COOLDOWN
        if not hasattr(PostClosureView, 'cooldowns'):
            PostClosureView.cooldowns = {}
        PostClosureView.cooldowns[channel_id] = {'last_action': 'close', 'timestamp': current_time}

        # ========== BACKGROUND PROCESSING (NON-BLOCKING) ==========
        # Do ALL heavy operations in background using same method as close button
        asyncio.create_task(self._instant_close_background_operations_button(
            ctx.guild, ctx.channel, ticket_info, ctx.author
        ))


    async def _instant_close_background_operations(self, guild, channel, ticket_info, closer_user):
        """ULTRA-FAST background operations - Complete ALL tasks in 3 seconds with parallel execution"""
        import time
        start_time = time.time()

        try:

            # Load config for the specific panel that this ticket belongs to
            # This ensures we get the correct closed_category for this ticket's panel
            global_panel_id = None
            if ticket_info:
                global_panel_id = ticket_info.get('global_panel_id') or ticket_info.get('panel_id')

            if global_panel_id:
                config = await self.ticket_config.load_ticket_config(guild.id, global_panel_id=global_panel_id)
            else:
                config = await self.ticket_config.load_ticket_config(guild.id)

            # ========== PARALLEL TASK EXECUTION ==========
            # Group ALL operations into parallel tasks for MAXIMUM SPEED

            tasks = []

            # Task 1: Update ticket status in database (INSTANT)
            tasks.append(self.ticket_config.update_ticket_status(channel.id, 'closed'))

            # Task 2: Rename channel with closed prefix - ENHANCED LOGIC
            current_name = channel.name

            # Remove ✅ prefix if present (claimed tickets)
            if current_name.startswith("✅-"):
                current_name = current_name[2:]  # Remove ✅- prefix

            # Only rename if not already closed
            if not current_name.startswith("closed-"):
                # Proper ticket renaming logic
                if current_name.startswith("ticket-"):
                    new_name = current_name.replace("ticket-", "closed-ticket-", 1)
                else:
                    new_name = f"closed-ticket-{current_name}"

                tasks.append(channel.edit(name=new_name))

            # Task 3: Move to closed category (with channel limit handling - parallel execution)
            closed_category_id = config.get('closed_category')
            move_task_info = {'success': False, 'reason': None, 'category_full': False}

            async def safe_move_to_closed_category():
                """Safely move ticket to closed category with proper error handling"""
                try:
                    if not closed_category_id:
                        return

                    closed_category = guild.get_channel(closed_category_id)
                    if not closed_category:
                        move_task_info['reason'] = 'not_found'
                        print(f"⚠️ Closed category not found: {closed_category_id}")
                        return

                    # Check if closed category has reached Discord's 50 channel limit
                    if len(closed_category.channels) >= 50:
                        move_task_info['category_full'] = True
                        move_task_info['reason'] = 'full'
                        print(f"⚠️ Closed category '{closed_category.name}' is full (50/50 channels). Cannot move ticket.")
                        return

                    # Attempt to move the ticket
                    await channel.edit(category=closed_category)
                    move_task_info['success'] = True

                except discord.HTTPException as e:
                    if "category" in str(e).lower() and ("full" in str(e).lower() or "limit" in str(e).lower()):
                        move_task_info['category_full'] = True
                        move_task_info['reason'] = 'full'
                        print(f"⚠️ Discord API: Closed category is full. Error: {e}")
                    else:
                        move_task_info['reason'] = 'discord_error'
                        print(f"⚠️ Discord API error moving to closed category: {e}")
                except Exception as e:
                    move_task_info['reason'] = 'unexpected_error'
                    print(f"⚠️ Unexpected error moving to closed category: {e}")

            # Add the move task to parallel execution if closed category is configured
            if closed_category_id:
                tasks.append(safe_move_to_closed_category())

            # Execute quick tasks in parallel FIRST
            await asyncio.gather(*tasks, return_exceptions=True)
            quick_time = time.time() - start_time

            # ========== SEND APPROPRIATE LOG NOTIFICATION ==========
            # Send specific log notification based on move result
            if closed_category_id and not move_task_info['success']:
                try:
                    log_channel_id = config.get('log_channel')
                    if log_channel_id:
                        log_channel = guild.get_channel(log_channel_id)
                        if log_channel:
                            if move_task_info['category_full']:
                                # Only send "full" embed when category is actually full
                                embed = discord.Embed(
                                    title="⚠️ Closed Category Full",
                                    description=f"**Ticket:** {channel.mention}\n"
                                               f"**Issue:** Closed category has reached Discord's 50 channel limit\n"
                                               f"**Action Required:** Please create a new closed category or clean up old tickets\n"
                                               f"**Ticket Status:** Closed successfully but remained in original category",
                                    color=0xFFA500  # Orange color for warning
                                )
                            else:
                                # Send generic move failure embed for other issues
                                reason_text = {
                                    'not_found': 'Configured closed category not found',
                                    'discord_error': 'Discord API error during move operation',
                                    'unexpected_error': 'Unexpected error during move operation'
                                }.get(move_task_info['reason'], 'Unknown error during move operation')

                                embed = discord.Embed(
                                    title="⚠️ Ticket Move Failed",
                                    description=f"**Ticket:** {channel.mention}\n"
                                               f"**Issue:** {reason_text}\n"
                                               f"**Action Required:** Check ticket panel configuration\n"
                                               f"**Ticket Status:** Closed successfully but remained in original category",
                                    color=0xFFA500  # Orange color for warning
                                )

                            embed.set_footer(text="Jo1nTrX™ - Ticket System")
                            await log_channel.send(embed=embed)
                except Exception as e:
                    print(f"Error sending move failure notification to log channel: {e}")

            # ========== PERMISSION UPDATE (OPTIMIZED) ==========
            # Remove access for ALL users (including ticket owner and added users)
            support_roles = ['support', 'moderator', 'admin']
            overwrites = dict(channel.overwrites)

            # Process permissions efficiently - remove access for everyone except support staff
            for member in channel.members:
                if not member.bot:
                    if member.guild_permissions.administrator:
                        overwrites[member] = discord.PermissionOverwrite(
                            view_channel=True, send_messages=False, read_message_history=True
                        )
                    else:
                        user_roles = [role.name.lower() for role in member.roles]
                        has_support_role = any(role in user_roles for role in support_roles)

                        if has_support_role:
                            overwrites[member] = discord.PermissionOverwrite(
                                view_channel=True, send_messages=False, read_message_history=True
                            )
                        else:
                            # Remove access for ALL regular users (including ticket owner and added users)
                            overwrites[member] = discord.PermissionOverwrite(view_channel=False)

            # ========== FINAL PARALLEL EXECUTION ==========
            # Run remaining heavy operations in parallel
            final_tasks = [
                # Permission update
                channel.edit(overwrites=overwrites),
                # Transcript and logging (heaviest operation)
                self._background_transcript_and_log(guild, channel, ticket_info, "Closed", closer_user)
            ]

            await asyncio.gather(*final_tasks, return_exceptions=True)

            total_time = time.time() - start_time
            print(f"🏆 ALL background operations completed in {total_time:.2f}s (Target: 3s)")

            if total_time <= 3.0:
                print(f"✅ Completed within target time")
            else:
                print(f"⚠️ WARNING: Took {total_time:.2f}s (over 3s target)")

        except Exception as e:
            total_time = time.time() - start_time
            print(f"❌ Error in background operations after {total_time:.2f}s: {e}")

    async def _instant_close_background_operations_button(self, guild, channel, ticket_info, closer_user):
        """Background operations for button-based closing - identical to command version"""
        await self._instant_close_background_operations(guild, channel, ticket_info, closer_user)

    async def _background_transcript_and_log(self, guild, channel, ticket_info, action_type, user):
        """OPTIMIZED transcript and logging - Target: Complete within overall 3-second budget"""
        import time
        start_time = time.time()
        try:
            # Generate transcript
            transcript_file = await self.ticket_config.generate_ticket_transcript(channel, ticket_info)

            # Log ticket closure
            await self.ticket_config.log_ticket_closure(guild, ticket_info, action_type, user)

            # Send transcript to log channel if available
            if transcript_file:
                config = await self.ticket_config.load_ticket_config(guild.id)
                log_channel_id = config.get('log_channel')
                if log_channel_id:
                    log_channel = guild.get_channel(log_channel_id)
                    if log_channel:
                        await log_channel.send(file=transcript_file)
        except Exception as e:
            print(f"Error in background transcript generation: {e}")

    @commands.command(name='delete')
    async def ticket_delete(self, ctx):
        """Delete the current ticket - ENHANCED TO MATCH BUTTON FUNCTIONALITY"""
        try:
            # Get ticket data for enhanced permission checking
            ticket_config = TicketConfig(ctx.bot)
            ticket_data = ticket_config.db_handler.get_active_ticket(ctx.guild.id, ctx.channel.id)

            # Check if user has deletion permissions - ENHANCED LOGIC
            can_delete = False

            # Administrator permissions always work
            if ctx.author.guild_permissions.administrator:
                can_delete = True
            # Check for specific support role assigned to this ticket
            elif ticket_data and ticket_data.get('support_role_id'):
                support_role = ctx.guild.get_role(ticket_data['support_role_id'])
                if support_role and support_role in ctx.author.roles:
                    can_delete = True
            # Check for general support permissions
            elif await self.has_close_permission_ctx(ctx):
                can_delete = True
            # Users with Manage Channels permission can delete
            elif ctx.author.guild_permissions.manage_channels:
                can_delete = True

            if not can_delete:
                await ctx.send("❌ You don't have permission to delete this ticket! You need Administrator, Manage Channels, or a Support role.", delete_after=10)
                return

            if not self.is_ticket_channel(ctx.channel):
                await ctx.send("<:jo1ntrx_cross:1405094904568483880> This command can only be used in ticket channels!", delete_after=10)
                return

            # Send ticket log BEFORE deletion
            try:
                await ctx.send("📋 Generating ticket transcript and sending to log channel...")

                # Get ticket info for logging
                ticket_info = await ticket_config.get_ticket_info(ctx.channel.id)

                # Generate transcript and log BEFORE countdown
                transcript_file = await ticket_config.generate_ticket_transcript(ctx.channel, ticket_info)
                await ticket_config.log_ticket_closure(ctx.guild, ticket_info, "Deleted", ctx.author)

                # Send transcript to log channel
                if transcript_file:
                    config = await ticket_config.load_ticket_config(ctx.guild.id)
                    log_channel_id = config.get('log_channel')
                    if log_channel_id:
                        log_channel = ctx.guild.get_channel(log_channel_id)
                        if log_channel:
                            await log_channel.send(file=transcript_file)

                await ctx.send("✅ Transcript generated and logged!")

            except Exception as e:
                print(f"Error generating transcript: {e}")
                await ctx.send("⚠️ Failed to generate transcript, proceeding with deletion...")

            # Send 3-second countdown
            timer_msg = await ctx.send("⏳ Deleting ticket in 3 seconds...")
            await asyncio.sleep(3)

            # Remove from database storage
            if ticket_info:
                ticket_config.db_handler.delete_active_ticket(ctx.guild.id, ctx.channel.id)

            # Update timer message before deletion
            await timer_msg.edit(content="✅ Ticket deleted successfully!")

            # Delete the ticket channel
            await ctx.channel.delete(reason=f"Ticket deleted by {ctx.author}")

        except Exception as e:
            await ctx.send("❌ Failed to delete ticket. Please try again.", delete_after=10)
            print(f"❌ Error in ticket_delete: {e}")

    @commands.command(name='claim')
    async def ticket_claim(self, ctx):
        """Claim the current ticket with 3-second timer"""
        # Get ticket data to check for specific support role
        ticket_data = self.ticket_config.db_handler.get_active_ticket(ctx.guild.id, ctx.channel.id)

        # Quick permission check
        has_permission = ctx.author.guild_permissions.administrator

        # Check for specific support role assigned to this ticket category
        if not has_permission and ticket_data and ticket_data.get('support_role_id'):
            support_role = ctx.guild.get_role(ticket_data['support_role_id'])
            if support_role and support_role in ctx.author.roles:
                has_permission = True

        # Fallback to general support roles
        if not has_permission:
            has_permission = any(role.name.lower() in ['support', 'moderator', 'admin', 'staff'] for role in ctx.author.roles)

        if not has_permission:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> You need Support, Moderator, Admin role or Administrator permissions to use this command!")
            return

        if not self.is_ticket_channel(ctx.channel):
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> This command can only be used in ticket channels!")
            return

        # Get ticket info
        ticket_info = await self.ticket_config.get_ticket_info(ctx.channel.id)
        if not ticket_info:
            await ctx.send("<:jo1ntrx_cross:1405094904568483880> Could not find ticket information!")
            return

        # Check if ticket is closed - must reopen first
        active_tickets = self.ticket_config.db_handler.get_all_active_tickets()
        guild_tickets = active_tickets.get(str(ctx.guild.id), {})
        if str(ctx.channel.id) in guild_tickets:
            ticket_data = guild_tickets[str(ctx.channel.id)]
            if ticket_data.get('status') == 'closed':
                await ctx.send("<:jo1ntrx_cross:1405094904568483880> This ticket is closed! Please reopen it first before claiming.")
                return

        # Check if already claimed
        if str(ctx.channel.id) in guild_tickets:
            ticket_data = guild_tickets[str(ctx.channel.id)]
            if ticket_data.get('claimed_by'):
                claimed_user = ctx.guild.get_member(ticket_data['claimed_by'])
                claimed_name = claimed_user.display_name if claimed_user else "Unknown User"
                await ctx.send(f"<:jo1ntrx_cross:1405094904568483880> This ticket is already claimed by {claimed_name}!")
                return

        # Send timer message
        timer_msg = await ctx.send("⏳ Claiming ticket in 3 seconds...")

        # Get ticket owner
        ticket_owner = ctx.guild.get_member(ticket_info['user_id'])

        # Start 3-second timer
        await asyncio.sleep(3)

        # Update ticket data
        if str(ctx.channel.id) in guild_tickets:
            ticket_data = guild_tickets[str(ctx.channel.id)]
            ticket_data['claimed_by'] = ctx.author.id
            self.db_handler.save_active_ticket(ctx.guild.id, ctx.channel.id, ticket_data)

        # Execute operations in parallel
        tasks = []

        # Add ✅ prefix to channel name
        current_name = ctx.channel.name
        if not current_name.startswith("✅-"):
            tasks.append(ctx.channel.edit(name=f"✅-{current_name}"))

        # Update channel topic
        topic = ctx.channel.topic or ""
        if "| Claimed by" not in topic:
            tasks.append(ctx.channel.edit(topic=f"{topic} | Claimed by {ctx.author.display_name}"))

        # Execute all tasks
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        # Update timer message
        await timer_msg.edit(content="✅ Ticket claimed successfully!")

        # Update the original welcome message embed with claimed status
        welcome_message_id = ticket_data.get('welcome_message_id')
        if welcome_message_id:
            try:
                welcome_message = await ctx.channel.fetch_message(welcome_message_id)
                if welcome_message.embeds:
                    # Get the original embed
                    original_embed = welcome_message.embeds[0]

                    # Create updated embed with claimed status
                    from Jo1nTrX.utils.embeds import create_embed
                    updated_embed = EmbedFactory.create(
                        title="Ticket Information",
                        timestamp=False
                    )

                    # Copy fields and update claim status
                    for field in original_embed.fields:
                        if field.name == "**Claim status:**":
                            updated_embed.add_field(
                                name="**Claim status:**", 
                                value=f"Claimed by {ctx.author.mention}",
                                inline=False
                            )
                        else:
                            updated_embed.add_field(
                                name=field.name,
                                value=field.value,
                                inline=field.inline
                            )

                    # Create updated management view with claimed state
                    from Jo1nTrX.cogs.Tickets_config import TicketManagementView
                    claimed_management_view = TicketManagementView(
                        ctx.channel.id, 
                        ticket_info['user_id'], 
                        None, 
                        is_claimed=True
                    )

                    # Update the welcome message
                    await welcome_message.edit(embed=updated_embed, view=claimed_management_view)
            except Exception as e:
                print(f"⚠️ Failed to update welcome message: {e}")

        # Send notification to ticket owner
        if ticket_owner:
            await ctx.channel.send(
                f"{ticket_owner.mention}, your ticket has been claimed by support staff {ctx.author.mention}!",
                allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False)
            )

    async def _background_channel_rename_cmd(self, channel, new_name, max_retries=10):
        """Background task to retry channel renaming with exponential backoff for commands"""
        for attempt in range(max_retries):
            try:
                delay = min(2 ** attempt, 30)  # Exponential backoff, max 30 seconds
                await asyncio.sleep(delay)

                await asyncio.wait_for(channel.edit(name=new_name), timeout=10.0)
                print(f"🎉 Background rename (cmd): Success! Channel renamed to {new_name}")
                return
            except asyncio.TimeoutError:
                print(f"⏰ Background rename (cmd): Attempt {attempt + 1} timed out")
            except Exception as e:
                print(f"❌ Background rename (cmd): Attempt {attempt + 1} failed: {e}")

        print(f"💔 Background rename (cmd): All {max_retries} attempts failed for {channel.name} -> {new_name}")

    @commands.command(name='reopen')
    async def ticket_reopen(self, ctx):
        """Reopen a closed ticket with 10-second cooldown"""
        try:
            # Check cooldown first
            can_proceed, remaining_time = self.check_command_cooldown(ctx.channel.id, "reopen")
            if not can_proceed:
                await ctx.send(f"⏳ Please wait {remaining_time:.1f} more seconds before reopening this ticket.")
                return

            # Get ticket data to check for specific support role
            ticket_data = self.db_handler.get_active_ticket(ctx.guild.id, ctx.channel.id)

            # Quick permission check
            has_permission = ctx.author.guild_permissions.administrator

            # Check for specific support role assigned to this ticket category
            if not has_permission and ticket_data and ticket_data.get('support_role_id'):
                support_role = ctx.guild.get_role(ticket_data['support_role_id'])
                if support_role and support_role in ctx.author.roles:
                    has_permission = True

            # Fallback to general support roles
            if not has_permission:
                has_permission = any(role.name.lower() in ['support', 'moderator', 'admin', 'staff'] for role in ctx.author.roles)

            if not has_permission:
                await ctx.send("<:jo1ntrx_cross:1405094904568483880> You need Support, Moderator, Admin role or Administrator permissions to use this command!")
                return

            if not self.is_ticket_channel(ctx.channel):
                await ctx.send("<:jo1ntrx_cross:1405094904568483880> This command can only be used in ticket channels!")
                return

            # Send instant response
            timer_msg = await ctx.send("⚡ Reopening ticket...")

            # Get ticket info and owner - try multiple methods for reliability
            ticket_info = await self.ticket_config.get_ticket_info(ctx.channel.id)
            ticket_owner = None

            if ticket_info and ticket_info.get('user_id'):
                try:
                    ticket_owner = ctx.guild.get_member(int(ticket_info['user_id']))
                except (ValueError, TypeError):
                    print(f"Error converting user_id to int: {ticket_info.get('user_id')}")

            # Alternative method: try to get from database directly
            if not ticket_owner:
                try:
                    ticket_data = self.db_handler.get_active_ticket(ctx.guild.id, ctx.channel.id)
                    if ticket_data and ticket_data.get('user_id'):
                        ticket_owner = ctx.guild.get_member(int(ticket_data['user_id']))
                except Exception as e:
                    print(f"Error getting ticket owner from database: {e}")

            # Update ticket status and setup all tasks for parallel execution

            # Update ticket status in database immediately
            self.db_handler.reopen_ticket(ctx.guild.id, ctx.channel.id)

            # Execute operations sequentially with individual timeouts for reliability
            if ticket_owner:
                print(f"👤 Command reopen: Restoring permissions for {ticket_owner.display_name}")
                try:
                    await asyncio.wait_for(
                        ctx.channel.set_permissions(
                            ticket_owner,
                            view_channel=True,
                            send_messages=True,
                            read_message_history=True,
                            attach_files=True,
                            embed_links=True
                        ),
                        timeout=5.0
                    )
                except asyncio.TimeoutError:
                    print(f"⏰ Command reopen: Permission update timed out after 5 seconds")
                except Exception as e:
                    print(f"❌ Command reopen: Permission update failed: {e}")
            else:
                print(f"⚠️ Command reopen: No ticket owner found")

            # Handle channel renaming with multiple retry strategies
            if ctx.channel.name.startswith("closed-"):
                new_name = ctx.channel.name[7:]  # Remove "closed-" prefix
                print(f"📝 Command reopen: Renaming {ctx.channel.name} -> {new_name}")

                # Strategy 1: Try direct rename with shorter timeout first
                try:
                    await asyncio.wait_for(
                        ctx.channel.edit(name=new_name),
                        timeout=3.0
                    )
                except asyncio.TimeoutError:
                    print(f"⏰ Command reopen: First attempt timed out, trying with delay...")

                    # Strategy 2: Try with a small delay (Discord rate limiting)
                    try:
                        await asyncio.sleep(1)  # 1-second delay for rate limiting
                        await asyncio.wait_for(
                            ctx.channel.edit(name=new_name),
                            timeout=5.0
                        )
                    except asyncio.TimeoutError:
                        print(f"⏰ Command reopen: Second attempt timed out, scheduling background rename...")

                        # Strategy 3: Background task that retries every few seconds
                        asyncio.create_task(self._background_channel_rename_cmd(ctx.channel, new_name))
                    except Exception as e:
                        print(f"❌ Command reopen: Channel rename failed on retry: {e}")
                except Exception as e:
                    print(f"❌ Command reopen: Channel rename failed immediately: {e}")
            else:
                print(f"📝 Command reopen: Channel name doesn't start with 'closed-', skipping rename")

            # Execute final operations with proper error handling

            try:
                # Update timer message
                await timer_msg.edit(content="✅ Ticket has been reopened!")
            except Exception as e:
                print(f"❌ Command reopen: Timer message update failed: {e}")

            try:
                # Create embed and management view with standard format
                embed = EmbedFactory.create(
                    title="Ticket Reopened",
                    description=f"This ticket has been reopened by {ctx.author.mention}",
                    timestamp=False
                )
                management_view = TicketManagementView(ctx.channel.id, ticket_owner.id if ticket_owner else 0, None)

                # Send notification
                if ticket_owner:
                    ping_message = f"{ticket_owner.mention}, your ticket has been reopened!"
                    await ctx.channel.send(
                        ping_message, embed=embed, view=management_view,
                        allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False)
                    )
                else:
                    embed.description = f"This ticket has been reopened by {ctx.author.mention}\n\n*Note: Original ticket owner could not be found for notification.*"
                    await ctx.channel.send(embed=embed, view=management_view)

            except Exception as e:
                print(f"❌ Command reopen: Notification failed: {e}")


        except Exception as e:
            print(f"Error in ticket_reopen: {e}")
            try:
                await ctx.send(f"<:jo1ntrx_cross:1405094904568483880> Error reopening ticket: {str(e)}")
            except:
                pass

    async def auto_close_member_tickets(self, member):
        """Auto-close tickets owned by a member who left the server"""
        try:

            # Get all active tickets for this guild
            active_tickets = self.db_handler.get_all_active_tickets()
            guild_tickets = active_tickets.get(str(member.guild.id), {})

            tickets_to_close = []

            # Find tickets owned by this member
            for channel_id, ticket_data in guild_tickets.items():
                if ticket_data.get('user_id') == member.id and ticket_data.get('status') == 'open':
                    tickets_to_close.append((channel_id, ticket_data))

            if not tickets_to_close:
                return

            print(f"🎫 Auto-close: Found {len(tickets_to_close)} open tickets to close for {member}")

            # Close each ticket
            for channel_id, ticket_data in tickets_to_close:
                try:
                    channel = member.guild.get_channel(int(channel_id))
                    if not channel:
                        print(f"❌ Auto-close: Channel {channel_id} not found, removing from database")
                        self.db_handler.remove_active_ticket(member.guild.id, int(channel_id))
                        continue


                    # Update ticket status in database
                    ticket_data['status'] = 'closed'
                    self.db_handler.save_active_ticket(member.guild.id, int(channel_id), ticket_data)

                    # SIMPLIFIED AUTO-CLOSE: Always just add "closed-" prefix
                    current_name = channel.name
                    new_name = f"closed-{current_name}"

                    # Execute channel operations
                    tasks = []

                    # Rename channel
                    if new_name != current_name:
                        tasks.append(channel.edit(name=new_name))

                    # FIXED: Only remove ticket owner and manually added users
                    permission_updates = []

                    if ticket_data:
                        # Get ticket owner
                        ticket_owner_id = ticket_data.get('user_id')

                        # Get manually added users from database tracking
                        added_users = self.db_handler.get_ticket_added_users(member.guild.id, int(channel_id))

                        users_to_remove = set()
                        if ticket_owner_id:
                            users_to_remove.add(ticket_owner_id)

                        for user_id in added_users:
                            users_to_remove.add(user_id)

                        # Only remove permissions for tracked users
                        for user_id in users_to_remove:
                            user_member = member.guild.get_member(user_id)
                            if user_member:
                                permission_updates.append(
                                    channel.set_permissions(user_member, view_channel=False)
                                )

                    tasks.extend(permission_updates)

                    # Execute all tasks
                    if tasks:
                        await asyncio.gather(*tasks, return_exceptions=True)

                    # Send auto-close embed with PostClosureView buttons - CRITICAL FIX
                    try:
                        # Create auto-close embed with standard format
                        embed = EmbedFactory.create(
                            title="🔒 Ticket Auto-Closed",
                            description=f"This ticket has been automatically closed because the ticket owner **{member}** left the server.",
                            timestamp=False
                        )

                        # Get ticket info for PostClosureView
                        ticket_info = await self.ticket_config.get_ticket_info(int(channel_id))
                        view = PostClosureView(ticket_info)

                        await channel.send(embed=embed, view=view)

                    except Exception as embed_error:
                        print(f"❌ Auto-close: Error sending close menu: {embed_error}")
                        # Send fallback message
                        try:
                            # Create fallback auto-close embed with standard format
                            fallback_embed = EmbedFactory.create(
                                title="🔒 Ticket Auto-Closed",
                                description=f"This ticket has been automatically closed because the ticket owner **{member}** left the server.\n\n**Note:** Close menu failed to load. Please use slash commands if needed.",
                                timestamp=False
                            )
                            await channel.send(embed=fallback_embed)
                        except Exception as fallback_error:
                            print(f"❌ Auto-close: Failed to send fallback message: {fallback_error}")

                except Exception as e:
                    print(f"❌ Auto-close: Error closing ticket {channel_id}: {e}")


        except Exception as e:
            print(f"❌ Auto-close: Error in auto_close_member_tickets: {e}")

    # ============== SLASH COMMANDS ==============

    # Ticket panel slash commands
    ticket_group = app_commands.Group(name='ticket', description='Ticket system management')

    @ticket_group.command(name='panel_setup', description='Setup a new ticket panel')
    @app_commands.describe(panel_type='Type of panel: buttons or menu')
    @app_commands.choices(panel_type=[
        app_commands.Choice(name='Buttons', value='buttons'),
        app_commands.Choice(name='Dropdown Menu', value='menu')
    ])
    async def slash_panel_setup(self, interaction: discord.Interaction, panel_type: str = None):
        """Setup ticket panel using slash command"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("<:jo1ntrx_cross:1405094904568483880> You need Administrator permissions to use this command!", ephemeral=True)
            return

        # Check if configuration is locked
        is_locked, lock_info = await self.ticket_config.is_config_locked(interaction.guild.id)
        if is_locked:
            error_msg = await self.ticket_config.get_lock_error_message(interaction.guild.id)
            await interaction.response.send_message(error_msg, ephemeral=True)
            return

        # Set configuration lock to prevent concurrent setups
        await self.ticket_config.set_config_lock(interaction.guild.id, interaction.user.id, interaction.channel.id)

        if not panel_type:
            embed = discord.Embed(
                title="🎫 Ticket Panel Setup",
                description="Please select the type of ticket panel you want to create:",
                color=0x2b2d31
            )

            view = PanelTypeSelectView(interaction.guild.id, self.ticket_config, interaction.user.id)
            await interaction.response.send_message(embed=embed, view=view)
        else:
            embed = discord.Embed(
                title="🎫 Ticket Panel Configuration",
                description=f"Setting up **{panel_type.title()}** ticket panel...",
                color=0x2b2d31
            )

            view = TicketPanelView(interaction.guild.id, self.ticket_config, interaction.user.id)
            view.current_config['panel_type'] = panel_type
            # Initialize panel ID early to prevent creating multiple panels
            config = await self.ticket_config.load_ticket_config(interaction.guild.id, create_new=True)
            if config and config.get('global_panel_id'):
                view.current_panel_id = config.get('global_panel_id')
                print(f"Debug: Initial panel setup - set current_panel_id to {view.current_panel_id}")
            await interaction.response.send_message(embed=embed, view=view)

    @ticket_group.command(name='panel_list', description='List all configured ticket panels')
    @app_commands.describe(page='Page number (5 panels per page)')
    async def slash_panel_list(self, interaction: discord.Interaction, page: int = 1):
        """List ticket panels using slash command with pagination"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("<:jo1ntrx_cross:1405094904568483880> You need Administrator permissions to use this command!", ephemeral=True)
            return

        panels = await self.ticket_config.get_all_panels(interaction.guild.id)

        if not panels:
            await interaction.response.send_message("<:jo1ntrx_cross:1405094904568483880> No ticket panels configured!", ephemeral=True)
            return

        # Pagination settings
        panels_per_page = 5
        total_pages = (len(panels) + panels_per_page - 1) // panels_per_page

        if page < 1 or page > total_pages:
            await interaction.response.send_message(f"<:jo1ntrx_cross:1405094904568483880> Invalid page number! Please use a page between 1 and {total_pages}.", ephemeral=True)
            return

        # Calculate start and end indices
        start_idx = (page - 1) * panels_per_page
        end_idx = min(start_idx + panels_per_page, len(panels))
        page_panels = panels[start_idx:end_idx]

        panel_list = []
        for panel in page_panels:
            panel_id = panel.get('global_panel_id')
            embed_name = panel.get('ticket_embed', 'Not set')

            # Format creation date
            from datetime import datetime, timezone, timedelta
            try:
                created_at = panel.get('created_at')
                if created_at:
                    if isinstance(created_at, str):
                        created_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                    else:
                        created_date = created_at

                    # Convert to IST timezone (UTC+5:30)
                    ist_timezone = timezone(timedelta(hours=5, minutes=30))
                    if created_date.tzinfo is None:
                        created_date = created_date.replace(tzinfo=timezone.utc)

                    ist_time = created_date.astimezone(ist_timezone)
                    formatted_date = ist_time.strftime("%B %d, %Y at %I:%M %p IST")
                else:
                    formatted_date = "Date not available"
            except:
                formatted_date = "Date not available"

            panel_entry = (
                f"--------------------------------------------\n"
                f"➛ | Panel ID : #{panel_id}\n"
                f"➛ | Created on : {formatted_date}\n"
                f"➛ | Ticket Embed : {embed_name}\n"
                f"--------------------------------------------"
            )
            panel_list.append(panel_entry)

        description = "\n\n".join(panel_list)

        from Jo1nTrX.utils.embeds import create_embed
        embed = EmbedFactory.create(
            title="🎫 Ticket Panels",
            description=description,
            color=0x7c28eb
        )

        embed.set_footer(text=f"Page {page}/{total_pages} | Total: {len(panels)} panels")

        # If only one page, show without navigation
        if total_pages == 1:
            await interaction.response.send_message(embed=embed)
            return

        # Create pagination view
        def create_panel_embed(page_num):
            start_index = page_num * panels_per_page
            end_index = start_index + panels_per_page
            page_panels = panels[start_index:end_index]

            panel_list_data = []
            for panel in page_panels:
                panel_id = panel.get('global_panel_id')
                embed_name = panel.get('ticket_embed', 'Not set')

                # Format creation date
                from datetime import datetime, timezone, timedelta
                try:
                    created_at = panel.get('created_at')
                    if created_at:
                        if isinstance(created_at, str):
                            created_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                        else:
                            created_date = created_at

                        # Convert to IST timezone (UTC+5:30)
                        ist_timezone = timezone(timedelta(hours=5, minutes=30))
                        if created_date.tzinfo is None:
                            created_date = created_date.replace(tzinfo=timezone.utc)

                        ist_time = created_date.astimezone(ist_timezone)
                        formatted_date = ist_time.strftime("%B %d, %Y at %I:%M %p IST")
                    else:
                        formatted_date = "Date not available"
                except:
                    formatted_date = "Date not available"

                panel_entry = (
                    f"--------------------------------------------\n"
                    f"➛ | Panel ID : #{panel_id}\n"
                    f"➛ | Created on : {formatted_date}\n"
                    f"➛ | Ticket Embed : {embed_name}\n"
                    f"--------------------------------------------"
                )
                panel_list_data.append(panel_entry)

            description = "\n\n".join(panel_list_data)

            from Jo1nTrX.utils.embeds import create_embed
            embed = EmbedFactory.create(
                title="🎫 Ticket Panels",
                description=description,
                color=0x7c28eb
            )

            embed.set_footer(text=f"Page {page_num + 1}/{total_pages} | Total: {len(panels)} panels")
            return embed

        view = PanelListPaginationView(panels, page - 1, total_pages, create_panel_embed, interaction.user)
        await interaction.response.send_message(embed=embed, view=view)

    @ticket_group.command(name='panel_edit', description='Edit an existing ticket panel')
    @app_commands.describe(panel_id='The global panel ID to edit')
    async def slash_panel_edit(self, interaction: discord.Interaction, panel_id: int):
        """Edit ticket panel using slash command"""
        try:
            if not interaction.user.guild_permissions.manage_channels:
                await interaction.response.send_message("<:jo1ntrx_cross:1405094904568483880> You need Manage Channels permissions to use this command!", ephemeral=True)
                return

            # Check if panel exists and belongs to this guild
            panel = await self.ticket_config.get_panel_by_global_id(panel_id)
            if not panel:
                await interaction.response.send_message(
                    f"<:jo1ntrx_cross:1405094904568483880> **Panel ID #{panel_id} not found!**", 
                    ephemeral=True
                )
                return

            if panel['guild_id'] != interaction.guild.id:
                await interaction.response.send_message(
                    f"<:jo1ntrx_cross:1405094904568483880> **Panel ID #{panel_id} doesn't belong to this server!**", 
                    ephemeral=True
                )
                return

            # Show main edit menu with new multi-step flow
            view = NewPanelEditMenuView(panel_id, self.ticket_config, interaction.guild.id)

            embed = EmbedFactory.create(
                title=f"🛠️ Edit Ticket Panel #{panel_id}",
                description="Select what you want to edit:",
                timestamp=False
            )

            await interaction.response.send_message(embed=embed, view=view)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)
            print(f"Error in slash_panel_edit: {e}")

    @ticket_group.command(name='panel_send', description='Send an existing ticket panel to a channel')
    @app_commands.describe(
        panel_id='The global panel ID to send',
        channel='The channel to send the panel to'
    )
    async def slash_panel_send(self, interaction: discord.Interaction, panel_id: int, channel: discord.TextChannel):
        """Send an existing ticket panel to a channel using slash command"""
        try:
            # Check permissions
            if not interaction.user.guild_permissions.manage_channels:
                await interaction.response.send_message("❌ You need `Manage Channels` permission to use this command!", ephemeral=True)
                return

            # Show loading message
            await interaction.response.send_message(f"{emoji.loading or '⏳'} Sending ticket panel...", ephemeral=True)

            # Check if panel exists
            panel_data = self.db_handler.get_panels(interaction.guild.id).get(f"panel_{panel_id}")
            if not panel_data:
                await interaction.edit_original_response(content="❌ Panel not found. Use `/ticket panel_list` to see available panels.")
                return

            # Get categories for the panel
            categories = panel_data.get('categories', [])
            if not categories:
                await interaction.edit_original_response(content="❌ This panel has no categories configured.")
                return

            # Create the embed using the custom ticket embed if configured
            embed_name = panel_data.get('ticket_embed')
            if embed_name:
                # Use the custom embed configured during setup
                from Jo1nTrX.cogs.extra.embeds import create_embed_from_database_data
                message_content, embed = await create_embed_from_database_data(self.bot, interaction.guild.id, embed_name)
                if not embed:
                    # Fallback to default embed if custom embed fails
                    from Jo1nTrX.utils.embeds import create_embed
                    embed = EmbedFactory.create(
                        title="🎫 Support Tickets",
                        description="Click a button below to create a support ticket!",
                        timestamp=False
                    )
            else:
                # Default embed when no custom embed is selected
                from Jo1nTrX.utils.embeds import create_embed
                embed = EmbedFactory.create(
                    title="🎫 Support Tickets",
                    description="Click a button below to create a support ticket!",
                    timestamp=False
                )

            # Create the appropriate view
            panel_type = panel_data.get('panel_type', 'buttons')
            if panel_type == 'buttons':
                view = TicketButtonsView(categories, self)
            else:
                view = TicketSelectView(categories, self)

            # Send the panel
            panel_message = await channel.send(embed=embed, view=view)

            # Update panel data with new message info (only update message location, don't create new panel)
            panel_data['panel_channel'] = channel.id
            panel_data['panel_message_id'] = panel_message.id
            panel_data['global_panel_id'] = panel_id

            # Save to JSON storage only (just update the message location)
            self.db_handler.save_panel(interaction.guild.id, f"panel_{panel_id}", panel_data)

            # Add persistent view
            self.bot.add_view(view)

            await interaction.edit_original_response(content=f"✅ Successfully sent panel **#{panel_id}** to {channel.mention}!")

        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Error sending panel: {str(e)}")
            print(f"Error in slash panel send: {e}")

    @ticket_group.command(name='panel_delete', description='Delete a ticket panel')
    @app_commands.describe(panel_id='The global panel ID to delete')
    async def slash_panel_delete(self, interaction: discord.Interaction, panel_id: int):
        """Delete ticket panel using slash command"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("<:jo1ntrx_cross:1405094904568483880> You need Administrator permissions to use this command!", ephemeral=True)
            return

        # Check if panel exists and belongs to this guild
        panel = await self.ticket_config.get_panel_by_global_id(panel_id)
        if not panel:
            await interaction.response.send_message(
                f"<:jo1ntrx_cross:1405094904568483880> **Panel ID #{panel_id} not found!**", 
                ephemeral=True
            )
            return

        if panel['guild_id'] != interaction.guild.id:
            await interaction.response.send_message(
                f"<:jo1ntrx_cross:1405094904568483880> **Panel ID #{panel_id} doesn't belong to this server!**", 
                ephemeral=True
            )
            return

        # Show confirmation
        embed = discord.Embed(
            title=f"<:jo1ntrx_delete:1405095625795702895> Delete Panel #{panel_id}",
            description="Are you sure you want to permanently delete this ticket panel?",
            color=0xff0000
        )

        view = PanelDeleteView(panel_id, self)
        await interaction.response.send_message(embed=embed, view=view)








    def is_ticket_channel(self, channel):
        """Check if the channel is a ticket channel"""
        # Primary check: Verify channel is actually in active_tickets JSON storage
        try:
            active_tickets = self.db_handler.get_all_active_tickets()
            for guild_id, guild_tickets in active_tickets.items():
                if str(channel.id) in guild_tickets:
                    return True
        except Exception as e:
            print(f'Error checking ticket channel: {e}')

        # Fallback check: Look for common ticket naming patterns
        # This includes original ticket names, renamed tickets, closed tickets, and claimed tickets
        channel_name = channel.name.lower()
        ticket_patterns = [
            'ticket-',          # Original tickets
            'closed-ticket-',   # Closed tickets
            'closed-',          # Renamed closed tickets
            '✅-',              # Claimed tickets
            '✅'                # Alternative claimed format
        ]

        # Check if channel matches any ticket pattern OR contains "ticket"
        if any(channel_name.startswith(pattern) for pattern in ticket_patterns) or 'ticket' in channel_name:
            return True

        return False

    async def log_ticket_action(self, guild, action, description):
        """Log ticket actions to the configured log channel"""
        config = await self.ticket_config.load_ticket_config(guild.id)
        log_channel_id = config.get('log_channel')

        if log_channel_id:
            log_channel = guild.get_channel(log_channel_id)
            if log_channel:
                embed = discord.Embed(
                    title=f"📝 {action}",
                    description=description,
                    color=0x2b2d31,
                    timestamp=datetime.utcnow()
                )
                await log_channel.send(embed=embed)

class TicketManagementView(BaseView):
    """View for active ticket management buttons (Close & Claim) - P H E O N ! X ™"""

    def __init__(self, channel_id, ticket_owner_id, support_role_id, is_claimed=False):
        super().__init__(timeout=None)  # Persistent - never expires
        self.channel_id = channel_id
        self.ticket_owner_id = ticket_owner_id
        self.support_role_id = support_role_id
        self.is_claimed = is_claimed

        # NOTE: Close button is added via @discord.ui.button decorator below
        # NOTE: Claim button is also added via @discord.ui.button decorator - no manual add needed

    def add_claim_button(self):
        """Add the correct claim button based on claimed status"""
        if self.is_claimed:
            # CLAIMED STATE - Green, disabled button
            claim_button = discord.ui.Button(
                label="Claimed",
                style=discord.ButtonStyle.success,  # GREEN
                emoji="✅",
                custom_id=f"claimed_ticket_{self.channel_id}",
                disabled=True  # Cannot be clicked
            )
        else:
            # UNCLAIMED STATE - Blue, active button
            claim_button = discord.ui.Button(
                label="Claim",
                style=discord.ButtonStyle.primary,  # BLUE
                custom_id=f"claim_ticket_{self.channel_id}"
            )
            claim_button.callback = self.claim_ticket

        self.add_item(claim_button)

    async def is_support_staff(self, interaction):
        """Check if user has support staff permissions"""
        if interaction.user.guild_permissions.administrator:
            return True

        user_roles = [role.name.lower() for role in interaction.user.roles]
        support_roles = ['support', 'moderator', 'admin', 'staff']
        return any(role in user_roles for role in support_roles)

    async def has_close_permission(self, interaction):
        """Check if user can close the ticket"""
        # Ticket owner, support staff, or administrators can close
        if interaction.user.id == self.ticket_owner_id:
            return True
        if interaction.user.guild_permissions.administrator:
            return True

        # Check for specific support role assigned to this ticket category
        if self.support_role_id:
            support_role = interaction.guild.get_role(self.support_role_id)
            if support_role and support_role in interaction.user.roles:
                return True

        # Fallback to general support staff check
        return await self.is_support_staff(interaction)

    @discord.ui.button(label="Close", style=discord.ButtonStyle.danger, custom_id="close_ticket", row=0)
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """
        CLOSE TICKET - Step by step as requested
        =======================================
        1. Remove ticket owner permissions
        2. Rename ticket with closed- prefix  
        3. Move to close category (if set)
        4. Send close menu
        """

        # CHECK 10-SECOND COOLDOWN (prevent rapid reopen→close)
        channel_id = interaction.channel.id
        current_time = time.time()

        # Access the cooldowns from PostClosureView class
        if hasattr(PostClosureView, 'cooldowns') and channel_id in PostClosureView.cooldowns:
            last_action = PostClosureView.cooldowns[channel_id]
            if last_action['last_action'] == 'reopen' and (current_time - last_action['timestamp']) < 10:
                remaining = 10 - int(current_time - last_action['timestamp'])
                await interaction.response.send_message(f"⏰ Please wait {remaining} more seconds before closing again.", ephemeral=True)
                return

        try:
            # Get ticket data and config
            tickets_cog = interaction.client.get_cog('Tickets')
            if not tickets_cog:
                await interaction.response.send_message("❌ Ticket system not available!", ephemeral=True)
                return

            ticket_data = tickets_cog.ticket_config.db_handler.get_active_ticket(interaction.guild.id, interaction.channel.id)

            if not ticket_data:
                await interaction.response.send_message("❌ Ticket not found!", ephemeral=True)
                return

            # Permission check
            ticket_owner_id = ticket_data.get('user_id')
            if not (interaction.user.id == ticket_owner_id or 
                   interaction.user.guild_permissions.administrator or
                   await self.is_support_staff(interaction)):
                await interaction.response.send_message("❌ No permission to close!", ephemeral=True)
                return

            await interaction.response.send_message("🔒 **Step 1/4:** Removing ticket owner permissions...", ephemeral=True)

            # Load config for the specific panel that this ticket belongs to
            # This ensures we get the correct closed_category for this ticket's panel
            global_panel_id = ticket_data.get('global_panel_id') or ticket_data.get('panel_id')
            if global_panel_id:
                config = await tickets_cog.ticket_config.load_ticket_config(interaction.guild.id, global_panel_id=global_panel_id)
            else:
                config = await tickets_cog.ticket_config.load_ticket_config(interaction.guild.id)

            # STEP 1: Remove ticket owner permissions (and other users except support role)

            # Get ticket owner
            ticket_owner = interaction.guild.get_member(ticket_owner_id) if ticket_owner_id else None

            # Remove ticket owner permissions
            if ticket_owner:
                await interaction.channel.set_permissions(ticket_owner, view_channel=False)

            # Remove permissions for other added users (not support roles)
            added_users = tickets_cog.ticket_config.db_handler.get_ticket_added_users(interaction.guild.id, interaction.channel.id)
            for user_id in added_users:
                member = interaction.guild.get_member(user_id)
                if member:
                    # Check if user is support staff (don't remove support staff permissions)
                    is_support = False
                    if member.guild_permissions.administrator:
                        is_support = True
                    else:
                        user_roles = [role.name.lower() for role in member.roles]
                        support_roles = ['support', 'moderator', 'admin', 'staff']
                        is_support = any(role in user_roles for role in support_roles)

                    if not is_support:
                        await interaction.channel.set_permissions(member, view_channel=False)
                    else:
                        print(f"👮 User {member} is support staff, keeping permissions")

            # STEP 2: Rename ticket with closed- prefix
            await interaction.followup.send("✏️ **Step 2/4:** Renaming ticket with closed- prefix...", ephemeral=True)

            current_name = interaction.channel.name
            if not current_name.startswith("closed-"):
                if current_name.startswith("✅-"):
                    # Handle claimed tickets
                    new_name = current_name.replace("✅-", "closed-", 1)
                else:
                    new_name = f"closed-{current_name}"

                # Add error handling and timeout protection for channel rename
                try:
                    # Ensure the new name is valid (Discord channel name rules)
                    new_name = new_name.lower().replace(" ", "-").replace("_", "-")
                    # Remove any invalid characters
                    import re
                    new_name = re.sub(r'[^a-z0-9\-]', '', new_name)
                    # Ensure it doesn't exceed 100 characters
                    if len(new_name) > 100:
                        new_name = new_name[:100]

                    # Use asyncio.wait_for to add timeout protection
                    await asyncio.wait_for(
                        interaction.channel.edit(name=new_name), 
                        timeout=10.0  # 10 second timeout
                    )
                except asyncio.TimeoutError:
                    print(f"⚠️ Timeout during rename operation, continuing anyway...")
                    await interaction.followup.send("⚠️ Rename operation timed out but ticket will still be closed...", ephemeral=True)
                except discord.HTTPException as e:
                    print(f"⚠️ Discord API error during rename: {e}")
                    await interaction.followup.send("⚠️ Could not rename channel, but ticket will still be closed...", ephemeral=True)
                except Exception as e:
                    print(f"⚠️ Unexpected error during rename: {e}")
                    await interaction.followup.send("⚠️ Rename failed, but ticket will still be closed...", ephemeral=True)

            # STEP 3: Move to close category (if set) with channel limit handling
            await interaction.followup.send("📁 **Step 3/4:** Moving to close category...", ephemeral=True)

            closed_category_id = config.get('closed_category')
            if closed_category_id:
                closed_category_id = int(closed_category_id)
            move_to_closed_success = False
            move_failure_reason = None
            if closed_category_id:
                closed_category = interaction.guild.get_channel(closed_category_id)
                if closed_category:
                    # Store original category for potential reopening
                    if interaction.channel.category and not ticket_data.get("original_category_id"):
                        ticket_data["original_category_id"] = interaction.channel.category.id

                    # Check if closed category has reached Discord's 50 channel limit
                    if len(closed_category.channels) >= 50:
                        print(f"⚠️ Closed category '{closed_category.name}' is full (50/50 channels). Cannot move ticket.")
                        await interaction.followup.send(
                            f"⚠️ **Category Full:** The closed category has reached Discord's 50 channel limit. "
                            f"Ticket was closed successfully but will remain in the current category. "
                            f"Please contact an administrator to clean up old tickets or create a new closed category.",
                            ephemeral=True
                        )
                        move_failure_reason = 'full'
                    else:
                        try:
                            await interaction.channel.edit(category=closed_category)
                            move_to_closed_success = True
                        except discord.HTTPException as e:
                            if "category" in str(e).lower() and ("full" in str(e).lower() or "limit" in str(e).lower()):
                                print(f"⚠️ Discord API: Closed category is full. Error: {e}")
                                await interaction.followup.send(
                                    f"⚠️ **Category Full:** Unable to move ticket to closed category due to Discord's channel limit. "
                                    f"Ticket was closed successfully but remains in current category.",
                                    ephemeral=True
                                )
                                move_failure_reason = 'full'
                            else:
                                print(f"⚠️ Discord API error moving to closed category: {e}")
                                await interaction.followup.send(
                                    f"⚠️ **Move Failed:** Could not move ticket to closed category due to a Discord API error. "
                                    f"Ticket was closed successfully but remains in current category.",
                                    ephemeral=True
                                )
                                move_failure_reason = 'discord_error'
                        except Exception as e:
                            print(f"⚠️ Unexpected error moving to closed category: {e}")
                            await interaction.followup.send(
                                f"⚠️ **Move Failed:** Unexpected error moving to closed category. "
                                f"Ticket was closed successfully but remains in current category.",
                                ephemeral=True
                            )
                            move_failure_reason = 'unexpected_error'
                else:
                    print(f"⚠️ Close category not found: {closed_category_id}")
                    await interaction.followup.send(
                        f"⚠️ **Category Not Found:** Configured closed category not found. "
                        f"Ticket was closed successfully but remains in current category.",
                        ephemeral=True
                    )
                    move_failure_reason = 'not_found'
            else:
                print("ℹ️ No closed category configured, ticket remains in current category")

            # Send accurate notification to log channel based on specific failure reason
            if not move_to_closed_success and closed_category_id:
                try:
                    log_channel_id = config.get('log_channel')
                    if log_channel_id:
                        log_channel_id = int(log_channel_id)
                        log_channel = interaction.guild.get_channel(log_channel_id)
                        if log_channel:
                            if move_failure_reason == 'full':
                                # Only send "full" embed when category is actually full
                                embed = discord.Embed(
                                    title="⚠️ Closed Category Full",
                                    description=f"**Ticket:** {interaction.channel.mention}\n"
                                               f"**Closed By:** {interaction.user.mention}\n"
                                               f"**Issue:** Closed category has reached Discord's 50 channel limit\n"
                                               f"**Action Required:** Please create a new closed category or clean up old tickets\n"
                                               f"**Ticket Status:** Closed successfully but remained in original category",
                                    color=0xFFA500  # Orange color for warning
                                )
                            else:
                                # Send specific failure reason for other issues
                                reason_text = {
                                    'not_found': 'Configured closed category not found',
                                    'discord_error': 'Discord API error during move operation',
                                    'unexpected_error': 'Unexpected error during move operation'
                                }.get(move_failure_reason, 'Unknown error during move operation')

                                embed = discord.Embed(
                                    title="⚠️ Ticket Move Failed",
                                    description=f"**Ticket:** {interaction.channel.mention}\n"
                                               f"**Closed By:** {interaction.user.mention}\n"
                                               f"**Issue:** {reason_text}\n"
                                               f"**Action Required:** Check ticket panel configuration\n"
                                               f"**Ticket Status:** Closed successfully but remained in original category",
                                    color=0xFFA500  # Orange color for warning
                                )

                            embed.set_footer(text="Jo1nTrX™ - Ticket System")
                            await log_channel.send(embed=embed)
                except Exception as e:
                    print(f"Error sending move failure notification to log channel: {e}")

            # Update ticket status
            from datetime import datetime
            ticket_data.update({
                'status': 'closed',
                'closed_by': interaction.user.id,
                'closed_at': datetime.now()
            })
            tickets_cog.ticket_config.db_handler.save_active_ticket(interaction.guild.id, interaction.channel.id, ticket_data)

            # STEP 4: Send close menu
            await interaction.followup.send("🔒 **Step 4/4:** Sending close menu...", ephemeral=True)

            # Create close menu with post-closure view (reopen & delete buttons)
            from Jo1nTrX.utils.embeds import create_embed
            close_embed = EmbedFactory.create(
                title="🔒 Ticket Closed",
                description=f"Closed by {interaction.user.mention}",
                timestamp=False
            )

            # Create post-closure view for reopen/delete options
            post_closure_view = PostClosureView(ticket_data)

            await interaction.channel.send(embed=close_embed, view=post_closure_view)
            await interaction.followup.send("✅ **Ticket closed successfully!** All steps completed.", ephemeral=True)

            # TRACK CLOSE ACTION FOR COOLDOWN
            if not hasattr(PostClosureView, 'cooldowns'):
                PostClosureView.cooldowns = {}
            PostClosureView.cooldowns[channel_id] = {'last_action': 'close', 'timestamp': current_time}

        except Exception as e:
            print(f"❌ Error closing ticket: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message("❌ Failed to close ticket. Please try again.", ephemeral=True)
                else:
                    await interaction.followup.send("❌ Failed to close ticket. Please try again.", ephemeral=True)
            except:
                pass

    @discord.ui.button(label="Claim", style=discord.ButtonStyle.primary, custom_id="claim_ticket", row=0)
    async def claim_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """
        CLAIM TICKET - Step by step as requested
        =======================================
        1. Rename ticket with ✅- prefix
        2. Claim the ticket  
        3. Send claimed menu and notify owner
        """

        try:
            # Get ticket data and config
            tickets_cog = interaction.client.get_cog('Tickets')
            if not tickets_cog:
                await interaction.response.send_message("❌ Ticket system not available!", ephemeral=True)
                return

            ticket_data = tickets_cog.ticket_config.db_handler.get_active_ticket(interaction.guild.id, interaction.channel.id)

            if not ticket_data:
                await interaction.response.send_message("❌ Ticket not found!", ephemeral=True)
                return

            # Check if ticket is closed - must reopen first
            if ticket_data.get('status') == 'closed':
                await interaction.response.send_message("❌ This ticket is closed! Please reopen it first before claiming.", ephemeral=True)
                return

            # Check if already claimed
            if ticket_data.get('claimed_by'):
                claimed_user = interaction.guild.get_member(ticket_data['claimed_by'])
                claimed_name = claimed_user.display_name if claimed_user else "Unknown User"
                await interaction.response.send_message(f"❌ This ticket is already claimed by {claimed_name}!", ephemeral=True)
                return

            # Permission check (only support staff/admin, NOT ticket owner)
            ticket_owner_id = ticket_data.get('user_id')

            # Ticket owner CANNOT claim their own ticket
            if interaction.user.id == ticket_owner_id:
                await interaction.response.send_message("❌ You cannot claim your own ticket!", ephemeral=True)
                return

            # Only support staff and administrators can claim
            can_claim = False
            if interaction.user.guild_permissions.administrator:
                can_claim = True
            # Check for specific support role assigned to this ticket category
            elif ticket_data.get('support_role_id'):
                support_role = interaction.guild.get_role(ticket_data['support_role_id'])
                if support_role and support_role in interaction.user.roles:
                    can_claim = True
            # Fallback to general support staff check
            elif await self.is_support_staff(interaction):
                can_claim = True

            if not can_claim:
                await interaction.response.send_message("❌ Only support staff can claim tickets.", ephemeral=True)
                return

            await interaction.response.send_message("✏️ **Step 1/3:** Renaming ticket with ✅- prefix...", ephemeral=True)

            # STEP 1: Rename ticket with ✅- prefix

            current_name = interaction.channel.name
            if not current_name.startswith("✅-"):
                new_name = f"✅-{current_name}"
                await interaction.channel.edit(name=new_name)

            # STEP 2: Claim the ticket
            await interaction.followup.send("🎯 **Step 2/3:** Claiming the ticket...", ephemeral=True)

            # Update ticket data with claimer info
            from datetime import datetime
            ticket_data.update({
                'claimed_by': interaction.user.id,
                'claimed_at': datetime.now()
            })
            tickets_cog.ticket_config.db_handler.save_active_ticket(interaction.guild.id, interaction.channel.id, ticket_data)

            # STEP 3: Send claimed menu and notify owner
            await interaction.followup.send("📢 **Step 3/3:** Updating ticket welcome menu and notifying owner...", ephemeral=True)

            # Update the original welcome message embed with claimed status
            welcome_message_id = ticket_data.get('welcome_message_id')
            if welcome_message_id:
                try:
                    welcome_message = await interaction.channel.fetch_message(welcome_message_id)
                    if welcome_message.embeds:
                        # Get the original embed
                        original_embed = welcome_message.embeds[0]

                        # Create updated embed with claimed status
                        from Jo1nTrX.utils.embeds import create_embed
                        updated_embed = EmbedFactory.create(
                            title="Ticket Information",
                            timestamp=False
                        )

                        # Copy fields and update claim status
                        for field in original_embed.fields:
                            if field.name == "**Claim status:**":
                                updated_embed.add_field(
                                    name="**Claim status:**", 
                                    value=f"Claimed by {interaction.user.mention}",
                                    inline=False
                                )
                            else:
                                updated_embed.add_field(
                                    name=field.name,
                                    value=field.value,
                                    inline=field.inline
                                )

                        # Create updated management view with claimed state
                        claimed_management_view = TicketManagementView(
                            interaction.channel.id, 
                            ticket_owner_id, 
                            None, 
                            is_claimed=True
                        )

                        # Update the welcome message
                        await welcome_message.edit(embed=updated_embed, view=claimed_management_view)
                except Exception as e:
                    print(f"⚠️ Failed to update welcome message: {e}")

            # Create claimed notification embed
            from Jo1nTrX.utils.embeds import create_embed
            claim_embed = EmbedFactory.create(
                title="✅ Ticket Claimed",
                description=f"Claimed by {interaction.user.mention}",
                timestamp=False
            )

            await interaction.channel.send(embed=claim_embed)

            # Notify the ticket owner
            ticket_owner = interaction.guild.get_member(ticket_owner_id) if ticket_owner_id else None
            if ticket_owner:
                await interaction.channel.send(
                    f"{ticket_owner.mention}, your ticket has been claimed by {interaction.user.mention}!",
                    allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False)
                )

            await interaction.followup.send("✅ **Ticket claimed successfully!** All steps completed.", ephemeral=True)

        except Exception as e:
            print(f"❌ Error claiming ticket: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message("❌ Failed to claim ticket. Please try again.", ephemeral=True)
                else:
                    await interaction.followup.send("❌ Failed to claim ticket. Please try again.", ephemeral=True)
            except:
                pass


    @discord.ui.button(label="Add", style=discord.ButtonStyle.secondary, custom_id="ticket_add")
    async def add_user(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Add user to ticket - support staff only"""
        # Check if ticket is still active (not closed)
        tickets_cog = interaction.client.get_cog('Tickets')
        if not tickets_cog:
            await interaction.response.send_message("❌ Ticket system not available!", ephemeral=True)
            return
        ticket_data = tickets_cog.ticket_config.db_handler.get_active_ticket(interaction.guild.id, interaction.channel.id)

        if not ticket_data or ticket_data.get('status') != 'open':
            await interaction.response.send_message(
                "Since this ticket is closed, you can't interact with this button! Kindly reopen the ticket & try using buttons from reopened menu.", 
                ephemeral=True
            )
            return

        if not await self.is_support_staff(interaction):
            await interaction.response.send_message("❌ Only support staff can add users to tickets.", ephemeral=True)
            return

        await interaction.response.send_message("Please provide the user ID or mention (e.g., @user or 123456789), or type `cancel` to cancel:", ephemeral=True)

        def check(m):
            return m.author == interaction.user and m.channel == interaction.channel

        try:
            msg = await interaction.client.wait_for('message', check=check, timeout=60)
            await msg.delete()  # Delete user's message

            if msg.content.lower() == 'cancel':
                await interaction.followup.send("❌ User addition cancelled.", ephemeral=True)
                return

            user = None
            content = msg.content.strip()

            # Try to parse user mention first
            if content.startswith('<@') and content.endswith('>'):
                # Extract user ID from mention
                user_id_str = content[2:-1]
                if user_id_str.startswith('!'):
                    user_id_str = user_id_str[1:]  # Remove nickname indicator
                try:
                    user_id = int(user_id_str)
                    user = interaction.guild.get_member(user_id)
                except ValueError:
                    pass
            else:
                # Try to parse as direct user ID
                try:
                    user_id = int(content)
                    user = interaction.guild.get_member(user_id)
                except ValueError:
                    await interaction.followup.send("❌ Invalid user format! Please provide a user ID or mention.", ephemeral=True)
                    return

            if not user:
                await interaction.followup.send("❌ User not found in this server.", ephemeral=True)
                return

            # Add user to channel permissions
            await interaction.channel.set_permissions(
                user, 
                view_channel=True, 
                send_messages=True, 
                attach_files=True, 
                add_reactions=True, 
                use_voice_activation=True
            )

            # Track user in database system
            tickets_cog.ticket_config.db_handler.add_user_to_ticket(interaction.guild.id, interaction.channel.id, user.id)

            await interaction.followup.send(f"✅ {user.mention} has been added to the ticket!", ephemeral=True)
            await interaction.channel.send(f"📨 {user.mention} has been added to this ticket by {interaction.user.mention}")

        except asyncio.TimeoutError:
            await interaction.followup.send("⏰ Request timed out.", ephemeral=True)

    @discord.ui.button(label="Remove", style=discord.ButtonStyle.secondary, custom_id="ticket_remove")
    async def remove_user(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Remove user from ticket - support staff only"""
        # Check if ticket is still active (not closed)
        tickets_cog = interaction.client.get_cog('Tickets')
        if not tickets_cog:
            await interaction.response.send_message("❌ Ticket system not available!", ephemeral=True)
            return
        ticket_data = tickets_cog.ticket_config.db_handler.get_active_ticket(interaction.guild.id, interaction.channel.id)

        if not ticket_data or ticket_data.get('status') != 'open':
            await interaction.response.send_message(
                "Since this ticket is closed, you can't interact with this button! Kindly reopen the ticket & try using buttons from reopened menu.", 
                ephemeral=True
            )
            return

        if not await self.is_support_staff(interaction):
            await interaction.response.send_message("❌ Only support staff can remove users from tickets.", ephemeral=True)
            return

        await interaction.response.send_message("Please provide the user ID or mention (e.g., @user or 123456789), or type `cancel` to cancel:", ephemeral=True)

        def check(m):
            return m.author == interaction.user and m.channel == interaction.channel

        try:
            msg = await interaction.client.wait_for('message', check=check, timeout=60)
            await msg.delete()  # Delete user's message

            if msg.content.lower() == 'cancel':
                await interaction.followup.send("❌ User removal cancelled.", ephemeral=True)
                return

            user = None
            content = msg.content.strip()

            # Try to parse user mention first
            if content.startswith('<@') and content.endswith('>'):
                # Extract user ID from mention
                user_id_str = content[2:-1]
                if user_id_str.startswith('!'):
                    user_id_str = user_id_str[1:]  # Remove nickname indicator
                try:
                    user_id = int(user_id_str)
                    user = interaction.guild.get_member(user_id)
                except ValueError:
                    pass
            else:
                # Try to parse as direct user ID
                try:
                    user_id = int(content)
                    user = interaction.guild.get_member(user_id)
                except ValueError:
                    await interaction.followup.send("❌ Invalid user format! Please provide a user ID or mention.", ephemeral=True)
                    return

            if not user:
                await interaction.followup.send("❌ User not found in this server.", ephemeral=True)
                return

            if user.id == self.ticket_owner_id:
                await interaction.followup.send("❌ Cannot remove the ticket owner.", ephemeral=True)
                return

            # Remove user from channel permissions
            await interaction.channel.set_permissions(user, overwrite=None)

            # Remove user from database tracking system
            tickets_cog.ticket_config.db_handler.remove_user_from_ticket(interaction.guild.id, interaction.channel.id, user.id)

            await interaction.followup.send(f"✅ {user.mention} has been removed from the ticket!", ephemeral=True)
            await interaction.channel.send(f"📤 {user.mention} has been removed from this ticket by {interaction.user.mention}")
        except asyncio.TimeoutError:
            await interaction.followup.send("⏰ Request timed out.", ephemeral=True)

    @discord.ui.button(label="Rename", style=discord.ButtonStyle.secondary, custom_id="ticket_rename")
    async def rename_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Rename the ticket - support staff only"""
        # Check if ticket is still active (not closed)
        tickets_cog = interaction.client.get_cog('Tickets')
        if not tickets_cog:
            await interaction.response.send_message("❌ Ticket system not available!", ephemeral=True)
            return
        ticket_data = tickets_cog.ticket_config.db_handler.get_active_ticket(interaction.guild.id, interaction.channel.id)

        if not ticket_data or ticket_data.get('status') != 'open':
            await interaction.response.send_message(
                "Since this ticket is closed, you can't interact with this button! Kindly reopen the ticket & try using buttons from reopened menu.", 
                ephemeral=True
            )
            return

        if not await self.is_support_staff(interaction):
            await interaction.response.send_message("❌ Only support staff can rename tickets.", ephemeral=True)
            return

        await interaction.response.send_message("Please provide the new name for the ticket, or type `cancel` to cancel:", ephemeral=True)

        def check(m):
            return m.author == interaction.user and m.channel == interaction.channel

        try:
            msg = await interaction.client.wait_for('message', check=check, timeout=60)
            await msg.delete()  # Delete user's message

            if msg.content.lower() == 'cancel':
                await interaction.followup.send("❌ Ticket rename cancelled.", ephemeral=True)
                return

            new_name = msg.content.strip()

            if not new_name:
                await interaction.followup.send("❌ Please provide a valid name.", ephemeral=True)
                return

            # Clean the name for Discord channel naming while preserving prefixes
            # Replace spaces with dashes, then filter invalid characters
            clean_name = new_name.replace(' ', '-').lower()
            clean_name = ''.join(c for c in clean_name if c.isalnum() or c in '-_')
            if not clean_name:
                await interaction.followup.send("❌ Invalid name format.", ephemeral=True)
                return

            old_name = interaction.channel.name

            # Preserve important prefixes (closed-, ✅-)
            final_name = clean_name
            if old_name.startswith("closed-"):
                final_name = f"closed-{clean_name}"
            elif old_name.startswith("✅-"):
                final_name = f"✅-{clean_name}"

            await interaction.channel.edit(name=final_name)

            await interaction.followup.send(f"✅ Ticket renamed successfully!", ephemeral=True)
            await interaction.channel.send(f"📝 Ticket renamed from `{old_name}` to `{final_name}` by {interaction.user.mention}")

        except asyncio.TimeoutError:
            await interaction.followup.send("⏰ Request timed out.", ephemeral=True)

    async def has_close_permission(self, interaction):
        """Check if user can close the ticket"""
        # Get current ticket info from database for persistence
        tickets_cog = interaction.client.get_cog('Tickets')
        if not tickets_cog:
            return False
        ticket_info = await tickets_cog.ticket_config.get_ticket_info(interaction.channel.id)

        if ticket_info:
            # Ticket owner can always close
            if interaction.user.id == int(ticket_info['user_id']):
                return True
        elif self.ticket_owner_id:
            # Fallback to stored ID if database lookup fails
            if interaction.user.id == self.ticket_owner_id:
                return True

        # Support staff can close
        if await self.is_support_staff(interaction):
            return True

        return False

    async def is_support_staff(self, interaction):
        """Check if user is support staff"""
        if self.support_role_id:
            support_role = interaction.guild.get_role(self.support_role_id)
            if support_role and support_role in interaction.user.roles:
                return True

        # Fallback to admin permissions
        return interaction.user.guild_permissions.administrator

    async def update_ticket_embed(self, interaction, claim_status):
        """Update the ticket embed with new claim status"""
        # Find the ticket embed message (should be one of the first messages)
        async for message in interaction.channel.history(limit=10, oldest_first=True):
            if message.author == interaction.client.user and message.embeds:
                embed = message.embeds[0]
                if embed.title == "Ticket Information":
                    # Update the claim status field
                    new_embed = discord.Embed(
                        title="Ticket Information",
                        color=0x2b2d31
                    )

                    # Keep existing fields but update claim status
                    for field in embed.fields:
                        if field.name == "**Claim status:**":
                            new_embed.add_field(name="**Claim status:**", value=claim_status, inline=False)
                        else:
                            new_embed.add_field(name=field.name, value=field.value, inline=field.inline)

                    await message.edit(embed=new_embed)
                    break


async def setup(bot):
    await bot.add_cog(Tickets(bot))