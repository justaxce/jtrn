import discord
from discord import ui
import time
import asyncio
from Jo1nTrX.utils.embeds import create_embed

class AutomodCache:
    """High-performance in-memory cache for automod data"""
    
    def __init__(self, ttl=60):
        self.ttl = ttl
        self.cache = {}
        self.timestamps = {}
    
    def get(self, key):
        """Get value from cache if not expired"""
        if key in self.cache:
            if time.time() - self.timestamps[key] < self.ttl:
                return self.cache[key]
            else:
                del self.cache[key]
                del self.timestamps[key]
        return None
    
    def set(self, key, value):
        """Set value in cache"""
        self.cache[key] = value
        self.timestamps[key] = time.time()
    
    def invalidate(self, guild_id):
        """Invalidate all cache entries for a guild"""
        keys_to_delete = [k for k in self.cache.keys() if k.startswith(f"{guild_id}_")]
        for key in keys_to_delete:
            del self.cache[key]
            del self.timestamps[key]

class AutomodHelper:
    """Helper class for common automod functionality with caching"""
    
    def __init__(self, bot):
        self.bot = bot
        self.cache = AutomodCache(ttl=60)
    
    async def is_guild_owner_or_extra_owner(self, guild_id, user_id):
        """Check if user is guild owner or extra owner"""
        guild = self.bot.get_guild(guild_id)
        if not guild:
            return False
        
        if guild.owner_id == user_id:
            return True
        
        is_extra = await self.bot.db.is_extra_owner(guild_id, user_id)
        return is_extra
    
    async def is_automod_enabled(self, guild_id):
        """Check if automod is enabled for a guild (cached)"""
        cache_key = f"{guild_id}_automod_enabled"
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        result = await self.bot.db.is_automod_enabled(guild_id)
        self.cache.set(cache_key, result)
        return result
    
    async def is_bypassed(self, guild_id, user_id, role_ids):
        """Check if user or any of their roles is bypassed from automod"""
        cache_key = f"{guild_id}_bypass_{user_id}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        result = await self.bot.db.is_automod_bypassed(guild_id, user_id, role_ids)
        self.cache.set(cache_key, result)
        return result
    
    async def get_module_config(self, guild_id, module_name):
        """Get configuration for a specific automod module (cached)"""
        cache_key = f"{guild_id}_module_{module_name}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        result = await self.bot.db.get_automod_module_config(guild_id, module_name)
        self.cache.set(cache_key, result)
        return result
    
    def invalidate_guild(self, guild_id):
        """Invalidate all cache for a guild"""
        self.cache.invalidate(guild_id)
    
    async def log_action(self, guild_id, violation_type, violator, action_taken, channel=None, reason=None):
        """Log an automod action to the log channel (component v2 format)"""
        asyncio.create_task(self._log_action_background(guild_id, violation_type, violator, action_taken, channel, reason))
    
    async def apply_punishment(self, member, punishment, config, violation_type):
        """
        Apply punishment to a member and return action description.
        
        Args:
            member: Discord member to punish
            punishment: Type of punishment (Warn, Mute, Kick, Ban)
            config: Module configuration dict containing mute_duration
            violation_type: Type of violation for logging
            
        Returns:
            str: Description of action taken
            
        Raises:
            discord.Forbidden: If bot lacks permission to punish
            discord.HTTPException: If Discord API call fails
            Exception: If database operation fails critically
        """
        from datetime import timedelta
        
        if punishment == "Warn":
            await self.bot.db.add_warning(
                member.guild.id,
                member.id,
                self.bot.user.id,
                f"Automod: {violation_type}"
            )
            
            try:
                warning_count = await self.bot.db.get_warning_count(member.guild.id, member.id)
                
                arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
                section = "<:jo1ntrx_right:1405095312456024127>"
                
                dm_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Warning
> You received a warning in **{member.guild.name}**

{section} **__Details__**
{arrow} **Violation:** {violation_type}
{arrow} **Warning #:** {warning_count}

> Please follow the server rules."""
                
                dm_view = ui.LayoutView(timeout=None)
                dm_container = ui.Container(ui.TextDisplay(dm_content))
                dm_view.add_item(dm_container)
                await member.send(view=dm_view)
            except (discord.Forbidden, discord.HTTPException):
                pass
            
            return "warned"
            
        elif punishment == "Mute":
            try:
                timeout_duration = discord.utils.utcnow() + timedelta(minutes=config.get('mute_duration', 5))
                await member.edit(timed_out_until=timeout_duration, reason=f"Automod: {violation_type}")
                return f"muted for {config.get('mute_duration', 5)} minutes"
            except discord.Forbidden:
                raise discord.Forbidden(None, "Missing permissions to timeout members")
            except discord.HTTPException as e:
                raise discord.HTTPException(None, f"Failed to timeout member: {e}")
            
        elif punishment == "Kick":
            try:
                await member.kick(reason=f"Automod: {violation_type}")
                return "kicked"
            except discord.Forbidden:
                raise discord.Forbidden(None, "Missing permissions to kick members")
            except discord.HTTPException as e:
                raise discord.HTTPException(None, f"Failed to kick member: {e}")
            
        elif punishment == "Ban":
            try:
                await member.ban(reason=f"Automod: {violation_type}")
                return "banned"
            except discord.Forbidden:
                raise discord.Forbidden(None, "Missing permissions to ban members")
            except discord.HTTPException as e:
                raise discord.HTTPException(None, f"Failed to ban member: {e}")
            
        else:
            return "warned"
    
    async def _log_action_background(self, guild_id, violation_type, violator, action_taken, channel, reason):
        """Background task for logging - doesn't block the critical path (component v2 format)"""
        try:
            log_channel_id = await self.bot.db.get_automod_log_channel(guild_id)
            
            if not log_channel_id:
                return
            
            guild = self.bot.get_guild(guild_id)
            if not guild:
                return
            
            log_channel = guild.get_channel(log_channel_id)
            if not log_channel:
                return
            
            arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
            section = "<:jo1ntrx_right:1405095312456024127>"
            
            channel_text = f"\n{arrow} **Channel:** {channel.mention}" if channel else ""
            reason_text = f"\n{arrow} **Reason:** {reason}" if reason else ""
            
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Detection
> Crime detected in **{guild.name}**

{section} **__Crime Details__**
{arrow} **Criminal:** {violator.mention}
{arrow} **Crime:** {violation_type}
{arrow} **Counter Action:** {action_taken}{channel_text}{reason_text}

{section} **__Response__**
{arrow} **Status:** Action Taken
{arrow} **Response Time:** Instant"""
            
            log_view = ui.LayoutView(timeout=None)
            log_container = ui.Container(ui.TextDisplay(content))
            log_view.add_item(log_container)
            
            await log_channel.send(view=log_view)
        except Exception as e:
            print(f"Error sending to automod log channel: {e}")
