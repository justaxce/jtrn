import discord
from discord.ext import commands
from discord import ui, app_commands
from datetime import datetime, timezone, timedelta
from Jo1nTrX.utils.embeds import create_embed, create_error_embed
from .automod_helper import AutomodHelper
import math
import asyncio
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)

AUTOMOD_MODULES = [
    "Anti Spam",
    "Anti Attachment Spam",
    "Anti Emoji Spam",
    "Anti Mention Spam",
    "Anti Links",
    "Anti Discord Invites",
    "Anti Caps"
]

def get_automod_help_content(category: str = "main") -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    if category == "main":
        return f"""## <:Jo1nTrX_automod:1439086767293861998> Automod System
> Automated moderation and content filtering for your server.

{section} **__Main Commands__**

{arrow} `automod enable` - Enable automod modules
{arrow} `automod disable` - Disable automod modules
{arrow} `automod status` - View automod status
{arrow} `automod config` - Configure thresholds"""
    
    elif category == "modules":
        return f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Modules
> Configure individual protection modules.

{section} **__Available Modules__**

{arrow} **Anti Spam** - Prevent message flooding
{arrow} **Anti Attachment Spam** - Prevent attachment spamming
{arrow} **Anti Emoji Spam** - Limit emoji usage
{arrow} **Anti Mention Spam** - Prevent mass mentions
{arrow} **Anti Links** - Block external links
{arrow} **Anti Discord Invites** - Block invite links
{arrow} **Anti Caps** - Prevent excessive caps"""
    
    elif category == "bypass":
        return f"""## <:Jo1nTrX_automod:1439086767293861998> Bypass Commands
> Manage automod bypass permissions.

{section} **__Available Commands__**

{arrow} `automod bypass add <type> <entity>` - Add to bypass
{arrow} `automod bypass remove <type> <entity>` - Remove from bypass
{arrow} `automod bypass list` - Show bypassed entities

{section} **__Entity Types__**
{arrow} member, role, category, channel"""
    
    elif category == "punishment":
        return f"""## <:Jo1nTrX_automod:1439086767293861998> Punishment Settings
> Configure how violations are handled.

{section} **__Available Punishments__**

{arrow} **Warn** - Delete message and warn user
{arrow} **Mute** - Timeout the user
{arrow} **Kick** - Remove user from server

{section} **__Commands__**
{arrow} `automod punishment <module>` - Set punishment"""
    
    return get_automod_help_content("main")


def get_automod_status_content(guild_name: str, is_enabled: bool, log_channel_mention: str = None) -> str:
    arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
    section = "<:jo1ntrx_right:1405095312456024127>"
    
    enabled_emoji = "<:enabled_Jo1nTrX:1437649148223557795>"
    disabled_emoji = "<:disabled_Jo1nTrX:1437649234957434993>"
    
    status_text = f"{enabled_emoji} **Enabled**" if is_enabled else f"{disabled_emoji} **Disabled**"
    
    content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Status
> Protection status for **{guild_name}**

{section} **__Status__**
{status_text}"""
    
    if is_enabled and log_channel_mention:
        content += f"\n\n{section} **__Log Channel__**\n{arrow} {log_channel_mention}"
    
    return content


class AutomodHelpLayoutView(ui.LayoutView):
    def __init__(self, requester: discord.Member = None, category: str = "main"):
        super().__init__(timeout=300)
        self.requester = requester
        self.current_category = category
        self._setup_view()
    
    def _setup_view(self):
        content = get_automod_help_content(self.current_category)
        text_display = ui.TextDisplay(content)
        
        main_btn = ui.Button(label="Main", style=discord.ButtonStyle.primary, custom_id="am_main")
        modules_btn = ui.Button(label="Modules", style=discord.ButtonStyle.secondary, custom_id="am_modules")
        bypass_btn = ui.Button(label="Bypass", style=discord.ButtonStyle.secondary, custom_id="am_bypass")
        punishment_btn = ui.Button(label="Punishment", style=discord.ButtonStyle.secondary, custom_id="am_punishment")
        
        async def main_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutomodHelpLayoutView(self.requester, "main")
            await interaction.response.edit_message(view=new_view)
        
        async def modules_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutomodHelpLayoutView(self.requester, "modules")
            await interaction.response.edit_message(view=new_view)
        
        async def bypass_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutomodHelpLayoutView(self.requester, "bypass")
            await interaction.response.edit_message(view=new_view)
        
        async def punishment_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = AutomodHelpLayoutView(self.requester, "punishment")
            await interaction.response.edit_message(view=new_view)
        
        main_btn.callback = main_callback
        modules_btn.callback = modules_callback
        bypass_btn.callback = bypass_callback
        punishment_btn.callback = punishment_callback
        
        button_row = ui.ActionRow(main_btn, modules_btn, bypass_btn, punishment_btn)
        
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class AutomodStatusLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str, is_enabled: bool, log_channel_mention: str = None, requester: discord.Member = None):
        super().__init__(timeout=300)
        self.requester = requester
        self.guild_name = guild_name
        self.is_enabled = is_enabled
        self.log_channel_mention = log_channel_mention
        self._setup_view()
    
    def _setup_view(self):
        content = get_automod_status_content(self.guild_name, self.is_enabled, self.log_channel_mention)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class AutomodConfigLayoutView(ui.LayoutView):
    def __init__(self, ctx, bot, current_config, requester: discord.Member = None):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.bot = bot
        self.current_config = current_config
        self.requester = requester
        self.config_updates = {}
        self._setup_view()
    
    def _get_content(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        tick = "<:enabled_Jo1nTrX:1437649148223557795>"
        
        settings = {
            "max_message_spam": ("Max Message Spam (5 sec)", self.config_updates.get("max_message_spam", self.current_config.get("max_message_spam", 5))),
            "max_attachment_spam": ("Max Attachment Spam (5 sec)", self.config_updates.get("max_attachment_spam", self.current_config.get("max_attachment_spam", 4))),
            "max_emoji_in_message": ("Max Emoji in Message", self.config_updates.get("max_emoji_in_message", self.current_config.get("max_emoji_in_message", 5))),
            "max_emoji_spam": ("Max Emoji Spam (5 sec)", self.config_updates.get("max_emoji_spam", self.current_config.get("max_emoji_spam", 15))),
            "max_mention_in_message": ("Max Mention in Message", self.config_updates.get("max_mention_in_message", self.current_config.get("max_mention_in_message", 3))),
            "max_mention_spam": ("Max Mention Spam (5 sec)", self.config_updates.get("max_mention_spam", self.current_config.get("max_mention_spam", 5)))
        }
        
        settings_text = ""
        for key, (display, value) in settings.items():
            modified = f" {tick}" if key in self.config_updates else ""
            settings_text += f"{arrow} **{display}:** `{value}`{modified}\n"
        
        footer_text = "Modified settings shown with tick | Click 'Save Changes' to apply" if self.config_updates else "Select a setting from the dropdown to configure"
        
        return f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Threshold Configuration
> Configure threshold limits for automod protection.

{section} **__Current Settings__**

{settings_text}
> {footer_text}"""
    
    def _setup_view(self):
        content = self._get_content()
        text_display = ui.TextDisplay(content)
        
        select_options = [
            discord.SelectOption(label="Max Message Spam (5 sec)", value="max_message_spam", description="Threshold for message spam"),
            discord.SelectOption(label="Max Attachment Spam (5 sec)", value="max_attachment_spam", description="Threshold for attachment spam"),
            discord.SelectOption(label="Max Emoji in Message", value="max_emoji_in_message", description="Max emojis per message"),
            discord.SelectOption(label="Max Emoji Spam (5 sec)", value="max_emoji_spam", description="Threshold for emoji spam"),
            discord.SelectOption(label="Max Mention in Message", value="max_mention_in_message", description="Max mentions per message"),
            discord.SelectOption(label="Max Mention Spam (5 sec)", value="max_mention_spam", description="Threshold for mention spam"),
        ]
        
        config_select = ui.Select(
            placeholder="Select a setting to configure...",
            min_values=1,
            max_values=1,
            options=select_options
        )
        
        async def select_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await self.show_threshold_modal(interaction, config_select.values[0])
        
        config_select.callback = select_callback
        select_row = ui.ActionRow(config_select)
        
        save_btn = ui.Button(label="Save Changes", style=discord.ButtonStyle.success)
        reset_btn = ui.Button(label="Reset to Defaults", style=discord.ButtonStyle.secondary)
        
        async def save_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await self.confirm_callback(interaction)
        
        async def reset_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await self.reset_callback_handler(interaction)
        
        save_btn.callback = save_callback
        reset_btn.callback = reset_callback
        
        button_row = ui.ActionRow(save_btn, reset_btn)
        
        container = ui.Container(text_display, select_row, button_row)
        self.add_item(container)
    
    async def show_threshold_modal(self, interaction: discord.Interaction, setting_name):
        setting_display_names = {
            "max_message_spam": "Max Message Spam (5 sec)",
            "max_attachment_spam": "Max Attachment Spam (5 sec)",
            "max_emoji_in_message": "Max Emoji in Message",
            "max_emoji_spam": "Max Emoji Spam (5 sec)",
            "max_mention_in_message": "Max Mention in Message",
            "max_mention_spam": "Max Mention Spam (5 sec)"
        }
        
        current_value = self.config_updates.get(setting_name, self.current_config.get(setting_name, 5))
        modal = AutomodThresholdModal(setting_name, setting_display_names[setting_name], current_value, self)
        await interaction.response.send_modal(modal)
    
    async def update_display(self, interaction: discord.Interaction):
        new_view = AutomodConfigLayoutView(self.ctx, self.bot, self.current_config, self.requester)
        new_view.config_updates = self.config_updates
        await interaction.response.edit_message(view=new_view)
    
    async def confirm_callback(self, interaction: discord.Interaction):
        if not self.config_updates:
            await interaction.response.send_message(f"{bot_emoji.cross} No changes to save!", ephemeral=True)
            return
        
        await self.bot.db.update_automod_thresholds(self.ctx.guild.id, self.config_updates)
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        setting_names = {
            "max_message_spam": "Max Message Spam (5 sec)",
            "max_attachment_spam": "Max Attachment Spam (5 sec)",
            "max_emoji_in_message": "Max Emoji in Message",
            "max_emoji_spam": "Max Emoji Spam (5 sec)",
            "max_mention_in_message": "Max Mention in Message",
            "max_mention_spam": "Max Mention Spam (5 sec)"
        }
        
        updates_text = ""
        for key, value in self.config_updates.items():
            updates_text += f"{arrow} **{setting_names[key]}:** `{value}`\n"
        
        content = f"""## <:Jo1nTrX_automod:1439086767293861998> Configuration Updated
> Successfully updated {len(self.config_updates)} setting(s)!

{section} **__Updated Settings__**

{updates_text}"""
        
        success_view = ui.LayoutView(timeout=60)
        success_container = ui.Container(ui.TextDisplay(content))
        success_view.add_item(success_container)
        
        self.bot.get_cog('AutomodCommands').helper.invalidate_guild(self.ctx.guild.id)
        await interaction.response.edit_message(view=success_view)
    
    async def reset_callback_handler(self, interaction: discord.Interaction):
        defaults = {
            "max_message_spam": 5,
            "max_attachment_spam": 4,
            "max_emoji_in_message": 5,
            "max_emoji_spam": 15,
            "max_mention_in_message": 3,
            "max_mention_spam": 5
        }
        
        await self.bot.db.update_automod_thresholds(self.ctx.guild.id, defaults)
        
        content = f"""## <:Jo1nTrX_automod:1439086767293861998> Reset to Defaults
> All threshold settings have been reset to default values!"""
        
        success_view = ui.LayoutView(timeout=60)
        success_container = ui.Container(ui.TextDisplay(content))
        success_view.add_item(success_container)
        
        self.bot.get_cog('AutomodCommands').helper.invalidate_guild(self.ctx.guild.id)
        await interaction.response.edit_message(view=success_view)


class AutomodThresholdModal(ui.Modal):
    def __init__(self, setting_name, setting_display, current_value, view):
        super().__init__(title=f"Configure {setting_display}")
        self.setting_name = setting_name
        self.parent_view = view
        
        self.value_input = ui.TextInput(
            label="New Value",
            placeholder=f"Current: {current_value}",
            default=str(current_value),
            min_length=1,
            max_length=3,
            required=True
        )
        self.add_item(self.value_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            new_value = int(self.value_input.value)
            
            if new_value < 1 or new_value > 100:
                await interaction.response.send_message(f"{bot_emoji.cross} Value must be between 1 and 100!", ephemeral=True)
                return
            
            self.parent_view.config_updates[self.setting_name] = new_value
            await self.parent_view.update_display(interaction)
        except ValueError:
            await interaction.response.send_message(f"{bot_emoji.cross} Please enter a valid number!", ephemeral=True)


class AutomodModuleStatusLayoutView(ui.LayoutView):
    def __init__(self, guild_name: str, modules_status: dict, requester: discord.Member = None):
        super().__init__(timeout=300)
        self.requester = requester
        self.guild_name = guild_name
        self.modules_status = modules_status
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        enabled_emoji = "<:jo1ntrx_tick:1405094884947267715>"
        disabled_emoji = "<a:Jo1nTrX_cross:1405094904568483880>"
        
        modules_text = ""
        for module, is_enabled in self.modules_status.items():
            status = enabled_emoji if is_enabled else disabled_emoji
            modules_text += f"{arrow} **{module}:** {status}\n"
        
        content = f"""## <:Jo1nTrX_automod:1439086767293861998> Module Status
> Module status for **{self.guild_name}**

{section} **__Modules__**

{modules_text}"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class AutomodBypassLayoutView(ui.LayoutView):
    def __init__(self, ctx, entity, entity_type, action, bot, requester: discord.Member = None):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.entity = entity
        self.entity_type = entity_type
        self.action = action
        self.bot = bot
        self.requester = requester
        self.selected_modules = []
        self._setup_view()
    
    def _get_content(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        entity_display = f"{self.entity.mention if hasattr(self.entity, 'mention') else self.entity.name}"
        
        if self.selected_modules:
            modules_text = "\n".join([f"{arrow} {mod}" for mod in self.selected_modules])
        else:
            modules_text = f"{arrow} *No modules selected*"
        
        action_text = "Add to" if self.action == "add" else "Remove from"
        
        return f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Bypass Configuration
> {action_text} bypass for {self.entity_type}

{section} **__Entity Details__**
{arrow} **{self.entity_type.title()}:** {entity_display}
{arrow} **Action:** {self.action.title()}

{section} **__Selected Modules ({len(self.selected_modules)})__**
{modules_text}

> Click 'Apply Changes' to save."""
    
    def _setup_view(self):
        content = self._get_content()
        text_display = ui.TextDisplay(content)
        
        options = []
        for module in AUTOMOD_MODULES:
            options.append(discord.SelectOption(
                label=module,
                value=module,
                description=f"Bypass {module}"
            ))
        
        module_select = ui.Select(
            placeholder=f"Select modules to {self.action}...",
            min_values=1,
            max_values=len(AUTOMOD_MODULES),
            options=options
        )
        
        async def select_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.selected_modules = module_select.values
            new_view = AutomodBypassLayoutView(self.ctx, self.entity, self.entity_type, self.action, self.bot, self.requester)
            new_view.selected_modules = self.selected_modules
            await interaction.response.edit_message(view=new_view)
        
        module_select.callback = select_callback
        select_row = ui.ActionRow(module_select)
        
        all_btn = ui.Button(label="All Modules", style=discord.ButtonStyle.success)
        apply_btn = ui.Button(label="Apply Changes", style=discord.ButtonStyle.primary)
        cancel_btn = ui.Button(label="Cancel", style=discord.ButtonStyle.danger)
        
        async def all_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.selected_modules = AUTOMOD_MODULES.copy()
            await self.apply_changes(interaction)
        
        async def apply_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await self.apply_changes(interaction)
        
        async def cancel_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            cancel_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Bypass Cancelled
> Operation cancelled by user"""
            cancel_view = ui.LayoutView(timeout=60)
            cancel_container = ui.Container(ui.TextDisplay(cancel_content))
            cancel_view.add_item(cancel_container)
            await interaction.response.edit_message(view=cancel_view)
        
        all_btn.callback = all_callback
        apply_btn.callback = apply_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(all_btn, apply_btn, cancel_btn)
        
        container = ui.Container(text_display, select_row, button_row)
        self.add_item(container)
    
    async def apply_changes(self, interaction: discord.Interaction):
        if not self.selected_modules:
            await interaction.response.send_message(f"{bot_emoji.cross} Please select at least one module!", ephemeral=True)
            return
        
        await interaction.response.defer()
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if self.action == "add":
            is_premium = await self.bot.db.check_premium_user(self.ctx.author.id, self.ctx.guild.id)
            has_premium = is_premium['has_premium']
            
            limits = {
                'user': 15 if has_premium else 5,
                'role': 5 if has_premium else 2,
                'category': 5 if has_premium else 2,
                'channel': 15 if has_premium else 5
            }
            
            counts = await self.bot.db.get_automod_bypass_counts(self.ctx.guild.id)
            current_count = counts.get(self.entity_type, 0)
            
            entity_type_name = 'member' if self.entity_type == 'user' else self.entity_type
            
            if current_count >= limits[self.entity_type]:
                premium_text = "" if has_premium else "\n\n*Upgrade to premium for higher limits!*"
                error_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Limit Reached
> You've reached the bypass limit!

{section} **__Details__**
{arrow} **Limit:** {limits[self.entity_type]} {entity_type_name}s
{arrow} **Current:** {current_count}/{limits[self.entity_type]}{premium_text}"""
                
                error_view = ui.LayoutView(timeout=60)
                error_container = ui.Container(ui.TextDisplay(error_content))
                error_view.add_item(error_container)
                await interaction.followup.send(view=error_view)
                return
            
            for module in self.selected_modules:
                await self.bot.db.add_automod_bypass(self.ctx.guild.id, self.entity.id, self.entity_type, module)
        elif self.action == "remove":
            for module in self.selected_modules:
                await self.bot.db.remove_automod_bypass(self.ctx.guild.id, self.entity.id, self.entity_type, module)
        
        entity_display = f"{self.entity.mention if hasattr(self.entity, 'mention') else self.entity.name}"
        modules_text = ", ".join(self.selected_modules) if self.selected_modules else "selected modules"
        action_word = "added to" if self.action == "add" else "removed from"
        
        success_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Bypass Updated
> Successfully updated bypass configuration!

{section} **__Details__**
{arrow} **Entity:** {entity_display}
{arrow} **Action:** {action_word.title()} bypass
{arrow} **Modules:** {modules_text}"""
        
        success_view = ui.LayoutView(timeout=60)
        success_container = ui.Container(ui.TextDisplay(success_content))
        success_view.add_item(success_container)
        
        self.bot.get_cog('AutomodCommands').helper.invalidate_guild(self.ctx.guild.id)
        await interaction.followup.send(view=success_view)


class AutomodBypassListLayoutView(ui.LayoutView):
    def __init__(self, bypass_data: list, page: int, total_pages: int, counts: dict, requester: discord.Member = None):
        super().__init__(timeout=300)
        self.requester = requester
        self.bypass_data = bypass_data
        self.current_page = page
        self.total_pages = total_pages
        self.counts = counts
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if not self.bypass_data:
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Bypass
> No users, roles, categories, or channels are currently bypassed from automod."""
        else:
            entries_text = ""
            for idx, entry in enumerate(self.bypass_data, start=1):
                entries_text += f"{arrow} **{idx}.** {entry['display']}\n"
                entries_text += f"   └ **Type:** {entry['type']} | **Modules:** {entry['modules']}\n"
            
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Bypass List
> Page {self.current_page + 1}/{self.total_pages}

{section} **__Bypassed Entities__**

{entries_text}
> Total: {self.counts.get('member', 0)} members, {self.counts.get('role', 0)} roles, {self.counts.get('category', 0)} categories, {self.counts.get('channel', 0)} channels"""
        
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        self.add_item(container)


class AutomodPunishmentLayoutView(ui.LayoutView):
    def __init__(self, ctx, bot, module_name: str, requester: discord.Member = None):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.bot = bot
        self.module_name = module_name
        self.requester = requester
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:Jo1nTrX_automod:1439086767293861998> Set Punishment
> Configure punishment for **{self.module_name}**

{section} **__Instructions__**
{arrow} Select a punishment type from the dropdown
{arrow} Click 'Apply' to save the configuration"""
        
        text_display = ui.TextDisplay(content)
        
        punishment_select = ui.Select(
            placeholder="Select punishment type...",
            min_values=1,
            max_values=1,
            options=[
                discord.SelectOption(label="Warn", value="Warn", description="Just delete message and warn"),
                discord.SelectOption(label="Mute", value="Mute", description="Timeout the user"),
                discord.SelectOption(label="Kick", value="Kick", description="Kick from server")
            ]
        )
        
        self.selected_punishment = None
        
        async def select_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.selected_punishment = punishment_select.values[0]
            await interaction.response.defer()
        
        punishment_select.callback = select_callback
        select_row = ui.ActionRow(punishment_select)
        
        apply_btn = ui.Button(label="Apply", style=discord.ButtonStyle.success)
        cancel_btn = ui.Button(label="Cancel", style=discord.ButtonStyle.danger)
        
        async def apply_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            if not self.selected_punishment:
                return await interaction.response.send_message(f"{bot_emoji.cross} Please select a punishment type!", ephemeral=True)
            
            if self.selected_punishment == "Mute":
                modal = MuteDurationModal(self.ctx, self.bot, self.module_name, self)
                await interaction.response.send_modal(modal)
            else:
                await self.bot.db.set_automod_module(
                    self.ctx.guild.id,
                    self.module_name,
                    punishment=self.selected_punishment
                )
                
                success_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Punishment Set
> Successfully configured punishment!

{section} **__Details__**
{arrow} **Module:** {self.module_name}
{arrow} **Punishment:** {self.selected_punishment}"""
                
                success_view = ui.LayoutView(timeout=60)
                success_container = ui.Container(ui.TextDisplay(success_content))
                success_view.add_item(success_container)
                
                self.bot.get_cog('AutomodCommands').helper.invalidate_guild(self.ctx.guild.id)
                await interaction.response.edit_message(view=success_view)
        
        async def cancel_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            cancel_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Operation Cancelled
> Punishment configuration cancelled."""
            cancel_view = ui.LayoutView(timeout=60)
            cancel_container = ui.Container(ui.TextDisplay(cancel_content))
            cancel_view.add_item(cancel_container)
            await interaction.response.edit_message(view=cancel_view)
        
        apply_btn.callback = apply_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(apply_btn, cancel_btn)
        
        container = ui.Container(text_display, select_row, button_row)
        self.add_item(container)


class MuteDurationModal(ui.Modal):
    def __init__(self, ctx, bot, module_name, parent_view):
        super().__init__(title=f"Set Mute Duration")
        self.ctx = ctx
        self.bot = bot
        self.module_name = module_name
        self.parent_view = parent_view
        
        self.duration_input = ui.TextInput(
            label="Mute Duration (in minutes)",
            placeholder="Enter duration in minutes (e.g., 10, 30, 60)",
            min_length=1,
            max_length=4,
            required=True
        )
        self.add_item(self.duration_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            duration = int(self.duration_input.value)
            
            if duration < 1 or duration > 1440:
                await interaction.response.send_message(f"{bot_emoji.cross} Duration must be between 1 and 1440 minutes (24 hours)!", ephemeral=True)
                return
            
            arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
            section = "<:jo1ntrx_right:1405095312456024127>"
            
            await self.bot.db.set_automod_module(
                self.ctx.guild.id,
                self.module_name,
                punishment="Mute",
                mute_duration=duration
            )
            
            success_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Punishment Set
> Successfully configured punishment!

{section} **__Details__**
{arrow} **Module:** {self.module_name}
{arrow} **Punishment:** Mute
{arrow} **Duration:** {duration} minutes"""
            
            success_view = ui.LayoutView(timeout=60)
            success_container = ui.Container(ui.TextDisplay(success_content))
            success_view.add_item(success_container)
            
            self.bot.get_cog('AutomodCommands').helper.invalidate_guild(self.ctx.guild.id)
            await interaction.response.edit_message(view=success_view)
        except ValueError:
            await interaction.response.send_message(f"{bot_emoji.cross} Please enter a valid number!", ephemeral=True)


class AutomodModuleSelectLayoutView(ui.LayoutView):
    def __init__(self, ctx, bot, action: str, enabled_modules: list = None, requester: discord.Member = None):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.bot = bot
        self.action = action
        self.enabled_modules = enabled_modules or []
        self.requester = requester
        self.selected_modules = []
        self._setup_view()
    
    def _setup_view(self):
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        enabled_emoji = "<:Jo1nTrX_enabled:1439106152804737096>"
        disabled_emoji = "<:Jo1nTrX_disabled:1439106133892505660>"
        
        modules_text = ""
        for module in AUTOMOD_MODULES:
            status = enabled_emoji if module in self.enabled_modules else disabled_emoji
            modules_text += f"{arrow} {status} **{module}**\n"
        
        action_text = "enable" if self.action == "enable" else "disable"
        
        content = f"""## <:Jo1nTrX_automod:1439086767293861998> {action_text.title()} Modules
> Select modules to {action_text}

{section} **__Current Status__**

{modules_text}
> Select modules from the dropdown below."""
        
        text_display = ui.TextDisplay(content)
        
        if self.action == "enable":
            available = [m for m in AUTOMOD_MODULES if m not in self.enabled_modules]
        else:
            available = [m for m in AUTOMOD_MODULES if m in self.enabled_modules]
        
        if not available:
            no_modules_text = "All modules are already enabled!" if self.action == "enable" else "No modules are enabled!"
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> {action_text.title()} Modules
> {no_modules_text}"""
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            self.add_item(container)
            return
        
        options = []
        for module in available:
            options.append(discord.SelectOption(
                label=module,
                value=module,
                description=f"{action_text.title()} {module}"
            ))
        
        module_select = ui.Select(
            placeholder=f"Select modules to {action_text}...",
            min_values=1,
            max_values=len(options),
            options=options
        )
        
        async def select_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.selected_modules = module_select.values
            await interaction.response.defer()
        
        module_select.callback = select_callback
        select_row = ui.ActionRow(module_select)
        
        all_btn = ui.Button(label=f"{action_text.title()} All", style=discord.ButtonStyle.success if self.action == "enable" else discord.ButtonStyle.danger)
        confirm_btn = ui.Button(label="Confirm", style=discord.ButtonStyle.primary)
        cancel_btn = ui.Button(label="Cancel", style=discord.ButtonStyle.secondary)
        
        async def all_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.selected_modules = available
            await self.apply_changes(interaction)
        
        async def confirm_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await self.apply_changes(interaction)
        
        async def cancel_callback(interaction: discord.Interaction):
            if self.requester and interaction.user.id != self.requester.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            cancel_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Operation Cancelled
> Module configuration cancelled."""
            cancel_view = ui.LayoutView(timeout=60)
            cancel_container = ui.Container(ui.TextDisplay(cancel_content))
            cancel_view.add_item(cancel_container)
            await interaction.response.edit_message(view=cancel_view)
        
        all_btn.callback = all_callback
        confirm_btn.callback = confirm_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(all_btn, confirm_btn, cancel_btn)
        
        container = ui.Container(text_display, select_row, button_row)
        self.add_item(container)
    
    async def apply_changes(self, interaction: discord.Interaction):
        if not self.selected_modules:
            await interaction.response.send_message(f"{bot_emoji.cross} Please select at least one module!", ephemeral=True)
            return
        
        await interaction.response.defer()
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        is_enable = self.action == "enable"
        for module in self.selected_modules:
            await self.bot.db.set_automod_module(self.ctx.guild.id, module, enabled=is_enable)
        
        modules_text = "\n".join([f"{arrow} {m}" for m in self.selected_modules])
        action_word = "enabled" if is_enable else "disabled"
        
        success_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Modules {action_word.title()}
> Successfully {action_word} {len(self.selected_modules)} module(s)!

{section} **__Updated Modules__**

{modules_text}"""
        
        success_view = ui.LayoutView(timeout=60)
        success_container = ui.Container(ui.TextDisplay(success_content))
        success_view.add_item(success_container)
        
        self.bot.get_cog('AutomodCommands').helper.invalidate_guild(self.ctx.guild.id)
        await interaction.followup.send(view=success_view)


class AutomodCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.helper = AutomodHelper(bot)
    
    async def check_automod_permission(self, ctx):
        if ctx.author == ctx.guild.owner:
            return True
        if await self.bot.db.is_extra_owner(ctx.guild.id, ctx.author.id):
            return True
        
        error_content = f"""## <:Jo1nTrX_automod:1439086767293861998> Permission Denied
> Only server owner or extra owners can manage automod."""
        
        error_view = ui.LayoutView(timeout=60)
        error_container = ui.Container(ui.TextDisplay(error_content))
        error_view.add_item(error_container)
        await ctx.send(view=error_view)
        return False
    
    @commands.hybrid_group(name="automod", aliases=["am"], invoke_without_command=True)
    async def automod(self, ctx):
        view = AutomodHelpLayoutView(requester=ctx.author)
        await ctx.send(view=view)
    
    @automod.command(name="enable")
    async def automod_enable(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        enabled_modules = []
        for module in AUTOMOD_MODULES:
            config = await self.bot.db.get_automod_module_config(ctx.guild.id, module)
            if config and config['enabled']:
                enabled_modules.append(module)
        
        view = AutomodModuleSelectLayoutView(ctx, self.bot, "enable", enabled_modules, requester=ctx.author)
        await ctx.send(view=view)
    
    @automod.command(name="disable")
    async def automod_disable(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        enabled_modules = []
        for module in AUTOMOD_MODULES:
            config = await self.bot.db.get_automod_module_config(ctx.guild.id, module)
            if config and config['enabled']:
                enabled_modules.append(module)
        
        view = AutomodModuleSelectLayoutView(ctx, self.bot, "disable", enabled_modules, requester=ctx.author)
        await ctx.send(view=view)
    
    @automod.command(name="status")
    async def automod_status(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        is_enabled = await self.bot.db.is_automod_enabled(ctx.guild.id)
        log_channel_id = await self.bot.db.get_automod_log_channel(ctx.guild.id)
        log_channel = ctx.guild.get_channel(log_channel_id) if log_channel_id else None
        log_channel_mention = log_channel.mention if log_channel else None
        
        view = AutomodStatusLayoutView(ctx.guild.name, is_enabled, log_channel_mention, requester=ctx.author)
        await ctx.send(view=view)
    
    @automod.command(name="config")
    async def automod_config(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        current_config = await self.bot.db.get_automod_thresholds(ctx.guild.id) or {}
        view = AutomodConfigLayoutView(ctx, self.bot, current_config, requester=ctx.author)
        await ctx.send(view=view)
    
    @automod.group(name="module", invoke_without_command=True)
    async def automod_module(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        modules_status = {}
        for module in AUTOMOD_MODULES:
            config = await self.bot.db.get_automod_module_config(ctx.guild.id, module)
            modules_status[module] = config['enabled'] if config else False
        
        view = AutomodModuleStatusLayoutView(ctx.guild.name, modules_status, requester=ctx.author)
        await ctx.send(view=view)
    
    @automod_module.command(name="enable")
    async def module_enable(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        enabled_modules = []
        for module in AUTOMOD_MODULES:
            config = await self.bot.db.get_automod_module_config(ctx.guild.id, module)
            if config and config['enabled']:
                enabled_modules.append(module)
        
        view = AutomodModuleSelectLayoutView(ctx, self.bot, "enable", enabled_modules, requester=ctx.author)
        await ctx.send(view=view)
    
    @automod_module.command(name="disable")
    async def module_disable(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        enabled_modules = []
        for module in AUTOMOD_MODULES:
            config = await self.bot.db.get_automod_module_config(ctx.guild.id, module)
            if config and config['enabled']:
                enabled_modules.append(module)
        
        view = AutomodModuleSelectLayoutView(ctx, self.bot, "disable", enabled_modules, requester=ctx.author)
        await ctx.send(view=view)
    
    @automod.command(name="punishment")
    @app_commands.describe(module="Select the module to set punishment for")
    @app_commands.choices(module=[
        app_commands.Choice(name="Anti Spam", value="Anti Spam"),
        app_commands.Choice(name="Anti Attachment Spam", value="Anti Attachment Spam"),
        app_commands.Choice(name="Anti Emoji Spam", value="Anti Emoji Spam"),
        app_commands.Choice(name="Anti Mention Spam", value="Anti Mention Spam"),
        app_commands.Choice(name="Anti Links", value="Anti Links"),
        app_commands.Choice(name="Anti Discord Invites", value="Anti Discord Invites"),
        app_commands.Choice(name="Anti Caps", value="Anti Caps"),
    ])
    async def automod_punishment(self, ctx, module: str):
        if not await self.check_automod_permission(ctx):
            return
        
        view = AutomodPunishmentLayoutView(ctx, self.bot, module, requester=ctx.author)
        await ctx.send(view=view)
    
    @automod.group(name="logs", invoke_without_command=True)
    async def automod_logs(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        log_channel_id = await self.bot.db.get_automod_log_channel(ctx.guild.id)
        log_channel = ctx.guild.get_channel(log_channel_id) if log_channel_id else None
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        if log_channel:
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Logs
> Log channel configuration

{section} **__Current Setting__**
{arrow} **Log Channel:** {log_channel.mention}

{section} **__Commands__**
{arrow} `automod logs set <#channel>` - Set log channel
{arrow} `automod logs remove` - Remove log channel"""
        else:
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Logs
> Log channel configuration

{section} **__Current Setting__**
{arrow} **Log Channel:** Not set

{section} **__Commands__**
{arrow} `automod logs set <#channel>` - Set log channel"""
        
        view = ui.LayoutView(timeout=60)
        container = ui.Container(ui.TextDisplay(content))
        view.add_item(container)
        await ctx.send(view=view)
    
    @automod_logs.command(name="set")
    @app_commands.describe(channel="The channel to send automod logs to")
    async def logs_set(self, ctx, channel: discord.TextChannel):
        if not await self.check_automod_permission(ctx):
            return
        
        await self.bot.db.set_automod_log_channel(ctx.guild.id, channel.id)
        self.helper.invalidate_guild(ctx.guild.id)
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:Jo1nTrX_automod:1439086767293861998> Log Channel Set
> Successfully configured log channel!

{section} **__Details__**
{arrow} **Channel:** {channel.mention}"""
        
        view = ui.LayoutView(timeout=60)
        container = ui.Container(ui.TextDisplay(content))
        view.add_item(container)
        await ctx.send(view=view)
    
    @automod_logs.command(name="remove")
    async def logs_remove(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        await self.bot.db.set_automod_log_channel(ctx.guild.id, None)
        self.helper.invalidate_guild(ctx.guild.id)
        
        content = f"""## <:Jo1nTrX_automod:1439086767293861998> Log Channel Removed
> Automod log channel has been removed."""
        
        view = ui.LayoutView(timeout=60)
        container = ui.Container(ui.TextDisplay(content))
        view.add_item(container)
        await ctx.send(view=view)
    
    @automod.group(name="bypass", invoke_without_command=True)
    async def automod_bypass(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
        section = "<:jo1ntrx_right:1405095312456024127>"
        
        content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Bypass
> Manage bypass permissions for automod

{section} **__Available Commands__**

{arrow} `automod bypass add <type> <entity>` - Add to bypass
{arrow} `automod bypass remove <type> <entity>` - Remove from bypass
{arrow} `automod bypass list` - Show all bypassed entities

{section} **__Entity Types__**
{arrow} **member** - Bypass a specific user
{arrow} **role** - Bypass a role
{arrow} **category** - Bypass a category
{arrow} **channel** - Bypass a channel"""
        
        view = ui.LayoutView(timeout=60)
        container = ui.Container(ui.TextDisplay(content))
        view.add_item(container)
        await ctx.send(view=view)
    
    @automod_bypass.command(name="add")
    @app_commands.describe(
        entity_type="Select the type of entity to add to bypass (member, role, category, or channel)",
        entity="Enter the role, channel, member or category ID/mention"
    )
    @app_commands.choices(entity_type=[
        app_commands.Choice(name="Member", value="member"),
        app_commands.Choice(name="Role", value="role"),
        app_commands.Choice(name="Category", value="category"),
        app_commands.Choice(name="Channel", value="channel")
    ])
    async def bypass_add(self, ctx, entity_type: str, entity: str):
        if not await self.check_automod_permission(ctx):
            return
        
        entity_type = entity_type.lower()
        if entity_type not in ['member', 'role', 'category', 'channel']:
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Invalid Type
> Invalid entity type! Use: member, role, category, or channel"""
            view = ui.LayoutView(timeout=60)
            container = ui.Container(ui.TextDisplay(content))
            view.add_item(container)
            return await ctx.send(view=view)
        
        try:
            db_entity_type = 'user' if entity_type == 'member' else entity_type
            
            if entity_type == 'member':
                target = await commands.MemberConverter().convert(ctx, entity)
                entity_obj = target
            elif entity_type == 'role':
                target = await commands.RoleConverter().convert(ctx, entity)
                entity_obj = target
            elif entity_type == 'category':
                target = await commands.CategoryChannelConverter().convert(ctx, entity)
                entity_obj = target
            elif entity_type == 'channel':
                target = await commands.TextChannelConverter().convert(ctx, entity)
                entity_obj = target
            
            view = AutomodBypassLayoutView(ctx, entity_obj, db_entity_type, "add", self.bot, requester=ctx.author)
            await ctx.send(view=view)
        except Exception as e:
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Error
> {entity_type.title()} not found!"""
            view = ui.LayoutView(timeout=60)
            container = ui.Container(ui.TextDisplay(content))
            view.add_item(container)
            await ctx.send(view=view)
    
    @automod_bypass.command(name="remove")
    @app_commands.describe(
        entity_type="Select the type of entity to remove from bypass (member, role, category, or channel)",
        entity="Enter the role, channel, member or category ID/mention"
    )
    @app_commands.choices(entity_type=[
        app_commands.Choice(name="Member", value="member"),
        app_commands.Choice(name="Role", value="role"),
        app_commands.Choice(name="Category", value="category"),
        app_commands.Choice(name="Channel", value="channel")
    ])
    async def bypass_remove(self, ctx, entity_type: str, entity: str):
        if not await self.check_automod_permission(ctx):
            return
        
        entity_type = entity_type.lower()
        if entity_type not in ['member', 'role', 'category', 'channel']:
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Invalid Type
> Invalid entity type! Use: member, role, category, or channel"""
            view = ui.LayoutView(timeout=60)
            container = ui.Container(ui.TextDisplay(content))
            view.add_item(container)
            return await ctx.send(view=view)
        
        try:
            if entity_type == 'member':
                target = await commands.MemberConverter().convert(ctx, entity)
                entity_id = target.id
            elif entity_type == 'role':
                target = await commands.RoleConverter().convert(ctx, entity)
                entity_id = target.id
            elif entity_type == 'category':
                target = await commands.CategoryChannelConverter().convert(ctx, entity)
                entity_id = target.id
            elif entity_type == 'channel':
                target = await commands.TextChannelConverter().convert(ctx, entity)
                entity_id = target.id
            
            db_entity_type = 'user' if entity_type == 'member' else entity_type
            success = await self.bot.db.remove_automod_bypass(ctx.guild.id, entity_id, db_entity_type)
            
            arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
            section = "<:jo1ntrx_right:1405095312456024127>"
            
            if success:
                content = f"""## <:Jo1nTrX_automod:1439086767293861998> Bypass Removed
> Successfully removed from bypass!

{section} **__Details__**
{arrow} **Entity:** {target.mention if hasattr(target, 'mention') else target.name}"""
                self.helper.invalidate_guild(ctx.guild.id)
            else:
                content = f"""## <:Jo1nTrX_automod:1439086767293861998> Not Found
> {target.mention if hasattr(target, 'mention') else target.name} is not in the bypass list!"""
            
            view = ui.LayoutView(timeout=60)
            container = ui.Container(ui.TextDisplay(content))
            view.add_item(container)
            await ctx.send(view=view)
        except Exception as e:
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Error
> {entity_type.title()} not found!"""
            view = ui.LayoutView(timeout=60)
            container = ui.Container(ui.TextDisplay(content))
            view.add_item(container)
            await ctx.send(view=view)
    
    @automod_bypass.command(name="list")
    async def bypass_list(self, ctx):
        if not await self.check_automod_permission(ctx):
            return
        
        all_bypasses = await self.bot.db.get_automod_bypassed_list_extended(ctx.guild.id)
        
        if not all_bypasses:
            content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod Bypass
> No users, roles, categories, or channels are currently bypassed from automod."""
            view = ui.LayoutView(timeout=60)
            container = ui.Container(ui.TextDisplay(content))
            view.add_item(container)
            return await ctx.send(view=view)
        
        entity_map = {}
        for bypass in all_bypasses:
            entity_id = bypass['entity_id']
            entity_type = bypass['entity_type']
            module_name = bypass['module_name']
            key = (entity_id, entity_type)
            if key not in entity_map:
                entity_map[key] = {
                    'entity_id': entity_id,
                    'entity_type': entity_type,
                    'modules': []
                }
            entity_map[key]['modules'].append(module_name)
        
        bypass_data = []
        counts = {'member': 0, 'role': 0, 'category': 0, 'channel': 0}
        
        for entity_info in entity_map.values():
            entity_type = entity_info['entity_type']
            entity_id = entity_info['entity_id']
            modules = entity_info['modules']
            
            if entity_type == 'role':
                role = ctx.guild.get_role(entity_id)
                display = role.mention if role else f"Deleted Role (ID: {entity_id})"
                type_name = "Role"
                counts['role'] += 1
            elif entity_type == 'user':
                display = f"<@{entity_id}>"
                type_name = "Member"
                counts['member'] += 1
            elif entity_type == 'category':
                category = ctx.guild.get_channel(entity_id)
                display = category.mention if category else f"Deleted Category (ID: {entity_id})"
                type_name = "Category"
                counts['category'] += 1
            elif entity_type == 'channel':
                channel = ctx.guild.get_channel(entity_id)
                display = channel.mention if channel else f"Deleted Channel (ID: {entity_id})"
                type_name = "Channel"
                counts['channel'] += 1
            else:
                continue
            
            if len(modules) == len(AUTOMOD_MODULES):
                modules_text = "All Modules"
            else:
                modules_text = ", ".join(modules)
            
            bypass_data.append({
                'type': type_name,
                'display': display,
                'modules': modules_text
            })
        
        items_per_page = 5
        total_items = len(bypass_data)
        total_pages = math.ceil(total_items / items_per_page)
        current_page = 0
        
        page_data = bypass_data[:items_per_page]
        view = AutomodBypassListLayoutView(page_data, current_page, total_pages, counts, requester=ctx.author)
        await ctx.send(view=view)


async def setup(bot):
    await bot.add_cog(AutomodCommands(bot))
