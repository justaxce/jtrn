from .automod_commands import AutomodCommands
from .anti_spam import AntiSpam
from .anti_attachment_spam import AntiAttachmentSpam
from .anti_emoji_spam import AntiEmojiSpam
from .anti_mention_spam import AntiMentionSpam
from .anti_links import AntiLinks
from .anti_invites import AntiInvites
from .anti_caps import AntiCaps

async def setup(bot):
    await bot.add_cog(AutomodCommands(bot))
    await bot.add_cog(AntiSpam(bot))
    await bot.add_cog(AntiAttachmentSpam(bot))
    await bot.add_cog(AntiEmojiSpam(bot))
    await bot.add_cog(AntiMentionSpam(bot))
    await bot.add_cog(AntiLinks(bot))
    await bot.add_cog(AntiInvites(bot))
    await bot.add_cog(AntiCaps(bot))
