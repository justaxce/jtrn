import discord
from discord.ext import commands
from discord import ui
from .automod_helper import AutomodHelper

class AntiSpam(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.helper = AutomodHelper(bot)
        self.message_cache = {}
    
    @commands.Cog.listener()
    async def on_message(self, message):
        if not message.guild or message.author.bot:
            return
        
        guild_id = message.guild.id
        user_id = message.author.id
        
        if not await self.helper.is_automod_enabled(guild_id):
            return
        
        config = await self.helper.get_module_config(guild_id, "Anti Spam")
        if not config or not config['enabled']:
            return
        
        if message.author == message.guild.owner or message.author.id == self.bot.user.id:
            return
        
        is_bypassed = await self.helper.is_bypassed(
            guild_id,
            user_id,
            [role.id for role in message.author.roles]
        )
        if is_bypassed:
            return
        
        cache_key = f"{guild_id}_{user_id}"
        current_time = message.created_at.timestamp()
        
        if cache_key not in self.message_cache:
            self.message_cache[cache_key] = []
        
        self.message_cache[cache_key] = [
            t for t in self.message_cache[cache_key]
            if current_time - t < 5
        ]
        self.message_cache[cache_key].append(current_time)
        
        threshold = config['threshold_value'] or 5
        
        if len(self.message_cache[cache_key]) > threshold:
            punishment = config['punishment'] or "Warn"
            
            try:
                await message.delete()
            except:
                pass
            
            try:
                action = await self.helper.apply_punishment(
                    message.author,
                    punishment,
                    config,
                    "Anti Spam"
                )
                
                arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
                section = "<:jo1ntrx_right:1405095312456024127>"
                
                content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod: Anti Spam
> Spam detected and action taken

{section} **__Details__**
{arrow} **User:** {message.author.mention}
{arrow} **Action:** {action.title()}
{arrow} **Reason:** Message spamming"""
                
                notification_view = ui.LayoutView(timeout=10)
                notification_container = ui.Container(ui.TextDisplay(content))
                notification_view.add_item(notification_container)
                await message.channel.send(view=notification_view, delete_after=10)
                
                await self.helper.log_action(
                    guild_id=guild_id,
                    violation_type="Anti Spam",
                    violator=message.author,
                    action_taken=action.title(),
                    channel=message.channel,
                    reason="Message spamming"
                )
                
                self.message_cache[cache_key] = []
                
            except discord.Forbidden:
                await self.helper.log_action(
                    guild_id=guild_id,
                    violation_type="Anti Spam",
                    violator=message.author,
                    action_taken=f"FAILED: Missing permissions to {punishment}",
                    channel=message.channel,
                    reason="Bot lacks required permissions"
                )
            except Exception as e:
                await self.helper.log_action(
                    guild_id=guild_id,
                    violation_type="Anti Spam",
                    violator=message.author,
                    action_taken=f"FAILED: {str(e)}",
                    channel=message.channel,
                    reason=f"Punishment error: {type(e).__name__}"
                )

async def setup(bot):
    await bot.add_cog(AntiSpam(bot))
