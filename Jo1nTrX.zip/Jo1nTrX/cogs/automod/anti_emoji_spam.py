import discord
from discord.ext import commands
from discord import ui
import re
from .automod_helper import AutomodHelper

class AntiEmojiSpam(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.helper = AutomodHelper(bot)
        self.emoji_cache = {}
        self.emoji_pattern = re.compile(
            r"<a?:[a-zA-Z0-9_]+:([0-9]+)>|"
            r"([\U0001F600-\U0001F64F]|"
            r"[\U0001F300-\U0001F5FF]|"
            r"[\U0001F680-\U0001F6FF]|"
            r"[\U0001F700-\U0001F77F]|"
            r"[\U0001F780-\U0001F7FF]|"
            r"[\U0001F800-\U0001F8FF]|"
            r"[\U0001F900-\U0001F9FF]|"
            r"[\U0001FA00-\U0001FAFF]|"
            r"[\U00002700-\U000027BF]|"
            r"[\U0001F1E6-\U0001F1FF]|"
            r"[\U0001F004-\U0001F0CF]|"
            r"[\U0001F9B0-\U0001F9FF]"
            r")"
        )
    
    @commands.Cog.listener()
    async def on_message(self, message):
        if not message.guild or message.author.bot:
            return
        
        guild_id = message.guild.id
        user_id = message.author.id
        
        if not await self.helper.is_automod_enabled(guild_id):
            return
        
        config = await self.helper.get_module_config(guild_id, "Anti Emoji Spam")
        if not config or not config['enabled']:
            return
        
        if message.author == message.guild.owner or message.author.id == self.bot.user.id:
            return
        
        is_bypassed = await self.helper.is_bypassed(
            guild_id,
            user_id,
            [role.id for role in message.author.roles]
        )
        if is_bypassed:
            return
        
        emoji_count = len(self.emoji_pattern.findall(message.content))
        threshold = config['threshold_value'] or 10
        
        if emoji_count > threshold:
            punishment = config['punishment'] or "Warn"
            
            try:
                await message.delete()
            except:
                pass
            
            try:
                action = await self.helper.apply_punishment(
                    message.author,
                    punishment,
                    config,
                    "Anti Emoji Spam"
                )
                
                arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
                section = "<:jo1ntrx_right:1405095312456024127>"
                
                content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod: Anti Emoji Spam
> Emoji spam detected and action taken

{section} **__Details__**
{arrow} **User:** {message.author.mention}
{arrow} **Action:** {action.title()}
{arrow} **Reason:** Spamming emojis ({emoji_count} emojis)"""
                
                notification_view = ui.LayoutView(timeout=10)
                notification_container = ui.Container(ui.TextDisplay(content))
                notification_view.add_item(notification_container)
                await message.channel.send(view=notification_view, delete_after=10)
                
                await self.helper.log_action(
                    guild_id=guild_id,
                    violation_type="Anti Emoji Spam",
                    violator=message.author,
                    action_taken=action.title(),
                    channel=message.channel,
                    reason=f"Emoji spam ({emoji_count} emojis)"
                )
                
            except discord.Forbidden:
                await self.helper.log_action(
                    guild_id=guild_id,
                    violation_type="Anti Emoji Spam",
                    violator=message.author,
                    action_taken=f"FAILED: Missing permissions to {punishment}",
                    channel=message.channel,
                    reason="Bot lacks required permissions"
                )
            except Exception as e:
                await self.helper.log_action(
                    guild_id=guild_id,
                    violation_type="Anti Emoji Spam",
                    violator=message.author,
                    action_taken=f"FAILED: {str(e)}",
                    channel=message.channel,
                    reason=f"Punishment error: {type(e).__name__}"
                )

async def setup(bot):
    await bot.add_cog(AntiEmojiSpam(bot))
