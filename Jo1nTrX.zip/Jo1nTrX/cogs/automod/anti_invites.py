import discord
from discord.ext import commands
from discord import ui
import re
from .automod_helper import AutomodHelper

class AntiInvites(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.helper = AutomodHelper(bot)
        self.invite_pattern = re.compile(
            r'(https?://)?(www\.)?(discord\.gg|discordapp\.com/invite|discord\.com/invite|dsc\.gg|dc\.gg|invite\.gg)/[a-zA-Z0-9]+',
            re.IGNORECASE
        )
    
    @commands.Cog.listener()
    async def on_message(self, message):
        if not message.guild or message.author.bot:
            return
        
        guild_id = message.guild.id
        user_id = message.author.id
        
        if not await self.helper.is_automod_enabled(guild_id):
            return
        
        config = await self.helper.get_module_config(guild_id, "Anti Discord Invites")
        if not config or not config['enabled']:
            return
        
        if message.author == message.guild.owner or message.author.id == self.bot.user.id:
            return
        
        is_bypassed = await self.helper.is_bypassed(
            guild_id,
            user_id,
            [role.id for role in message.author.roles]
        )
        if is_bypassed:
            return
        
        match = self.invite_pattern.search(message.content)
        if match:
            invite_link = match.group(0)
            invite_code = invite_link.split('/')[-1]
            
            try:
                guild_invites = await message.guild.invites()
                if any(invite.code == invite_code for invite in guild_invites):
                    return
            except:
                pass
            
            punishment = config['punishment'] or "Warn"
            
            try:
                await message.delete()
            except:
                pass
            
            try:
                action = await self.helper.apply_punishment(
                    message.author,
                    punishment,
                    config,
                    "Anti Discord Invites"
                )
                
                arrow = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
                section = "<:jo1ntrx_right:1405095312456024127>"
                
                content = f"""## <:Jo1nTrX_automod:1439086767293861998> Automod: Anti Discord Invites
> Invite link detected and action taken

{section} **__Details__**
{arrow} **User:** {message.author.mention}
{arrow} **Action:** {action.title()}
{arrow} **Reason:** Posted an invite link"""
                
                notification_view = ui.LayoutView(timeout=10)
                notification_container = ui.Container(ui.TextDisplay(content))
                notification_view.add_item(notification_container)
                await message.channel.send(view=notification_view, delete_after=10)
                
                await self.helper.log_action(
                    guild_id=guild_id,
                    violation_type="Anti Discord Invites",
                    violator=message.author,
                    action_taken=action.title(),
                    channel=message.channel,
                    reason="Posted an invite link"
                )
                
            except discord.Forbidden:
                await self.helper.log_action(
                    guild_id=guild_id,
                    violation_type="Anti Discord Invites",
                    violator=message.author,
                    action_taken=f"FAILED: Missing permissions to {punishment}",
                    channel=message.channel,
                    reason="Bot lacks required permissions"
                )
            except Exception as e:
                await self.helper.log_action(
                    guild_id=guild_id,
                    violation_type="Anti Discord Invites",
                    violator=message.author,
                    action_taken=f"FAILED: {str(e)}",
                    channel=message.channel,
                    reason=f"Punishment error: {type(e).__name__}"
                )

async def setup(bot):
    await bot.add_cog(AntiInvites(bot))
