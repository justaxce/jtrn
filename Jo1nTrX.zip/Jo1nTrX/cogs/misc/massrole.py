import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import typing
from datetime import datetime
from Jo1nTrX.utils.embeds import create_embed
from Jo1nTrX.cogs.extra.embeds import create_embed_from_database_data
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji, LayoutViewFactory
)

class MassRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_group(name='massrole', fallback='help')
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def massrole(self, ctx):
        """Mass role management commands"""
        view = LayoutViewFactory.create(
            title="<:Jo1nTrX_misc:1422793178746060812> Mass Role Commands",
            description="**Available Commands:**\n\n"
                       "• `massrole add <type> <roles>` - Add roles to multiple users\n"
                       "• `massrole remove <type> <roles>` - Remove roles from multiple users\n\n"
                       "**Types:**\n"
                       "• `only humans` - Apply to human users only\n"
                       "• `only bots` - Apply to bot users only\n"
                       "• `all users` - Apply to all users\n\n"
                       "**Example:**\n"
                       "`+massrole add only humans @Member, @Active`",
            timestamp=False
        )
        await ctx.send(view=view)
    
    @massrole.command(name='add')
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_roles=True)
    @app_commands.choices(type=[
        app_commands.Choice(name="only humans", value="only humans"),
        app_commands.Choice(name="only bots", value="only bots"),
        app_commands.Choice(name="all users", value="all users")
    ])
    async def massrole_add(self, ctx, type: str, *, roles: str):
        """Add roles to multiple users based on type"""
        # Validate type
        valid_types = ['only humans', 'only bots', 'all users']
        type_lower = type.lower()
        
        if type_lower not in valid_types:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> Invalid Type",
                description=f"Invalid type: `{type}`\n\n"
                           "**Valid types:**\n"
                           "• `only humans`\n"
                           "• `only bots`\n"
                           "• `all users`",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Parse roles from string (supports mentions and IDs, comma or space separated)
        import re
        role_mentions = []
        role_ids = set()
        
        # Extract role mentions (<@&ID>) and plain IDs
        mention_pattern = r'<@&(\d+)>'
        id_pattern = r'\b(\d{17,20})\b'
        
        # Find all mentioned roles
        for match in re.finditer(mention_pattern, roles):
            role_id = int(match.group(1))
            if role_id not in role_ids:
                role = ctx.guild.get_role(role_id)
                if role:
                    role_mentions.append(role)
                    role_ids.add(role_id)
        
        # Find all plain IDs that aren't already found
        for match in re.finditer(id_pattern, roles):
            role_id = int(match.group(1))
            if role_id not in role_ids:
                role = ctx.guild.get_role(role_id)
                if role:
                    role_mentions.append(role)
                    role_ids.add(role_id)
        
        if not role_mentions:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> No Valid Roles",
                description="No valid roles found. Please mention roles or provide role IDs.",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Get members based on type
        members_to_update = []
        if type_lower == 'only humans':
            members_to_update = [m for m in ctx.guild.members if not m.bot]
        elif type_lower == 'only bots':
            members_to_update = [m for m in ctx.guild.members if m.bot]
        elif type_lower == 'all users':
            members_to_update = list(ctx.guild.members)
        
        # Send loading message
        loading_view = LayoutViewFactory.create(
            title="<a:jo1ntrx_loading:1405094057499295806> Adding Roles",
            description=f"Adding {len(role_mentions)} role(s) to {len(members_to_update)} members...",
            timestamp=False
        )
        loading_msg = await ctx.send(view=loading_view)
        
        # Add roles to members who don't have them
        success_count = 0
        failed_count = 0
        skipped_count = 0
        
        for i, member in enumerate(members_to_update):
            try:
                # Only add roles they don't already have
                roles_to_add = [r for r in role_mentions if r not in member.roles]
                if roles_to_add:
                    await member.add_roles(*roles_to_add, reason=f"Mass role add by {ctx.author}")
                    success_count += 1
                    # Rate limiting: 1 second delay per operation to prevent Discord rate limits
                    await asyncio.sleep(1)
                else:
                    skipped_count += 1
            except:
                failed_count += 1
        
        # Send success message
        roles_text = ", ".join([r.mention for r in role_mentions])
        success_view = LayoutViewFactory.create(
            description=f"<:Jo1nTrX_Yes:1408288995477159987> Successfully added {roles_text} to {success_count} {type_lower}!",
            timestamp=False
        )
        await loading_msg.edit(view=success_view)
    
    @massrole.command(name='remove')
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_roles=True)
    @app_commands.choices(type=[
        app_commands.Choice(name="only humans", value="only humans"),
        app_commands.Choice(name="only bots", value="only bots"),
        app_commands.Choice(name="all users", value="all users")
    ])
    async def massrole_remove(self, ctx, type: str, *, roles: str):
        """Remove roles from multiple users based on type"""
        # Validate type
        valid_types = ['only humans', 'only bots', 'all users']
        type_lower = type.lower()
        
        if type_lower not in valid_types:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> Invalid Type",
                description=f"Invalid type: `{type}`\n\n"
                           "**Valid types:**\n"
                           "• `only humans`\n"
                           "• `only bots`\n"
                           "• `all users`",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Parse roles from string (supports mentions and IDs, comma or space separated)
        import re
        role_mentions = []
        role_ids = set()
        
        # Extract role mentions (<@&ID>) and plain IDs
        mention_pattern = r'<@&(\d+)>'
        id_pattern = r'\b(\d{17,20})\b'
        
        # Find all mentioned roles
        for match in re.finditer(mention_pattern, roles):
            role_id = int(match.group(1))
            if role_id not in role_ids:
                role = ctx.guild.get_role(role_id)
                if role:
                    role_mentions.append(role)
                    role_ids.add(role_id)
        
        # Find all plain IDs that aren't already found
        for match in re.finditer(id_pattern, roles):
            role_id = int(match.group(1))
            if role_id not in role_ids:
                role = ctx.guild.get_role(role_id)
                if role:
                    role_mentions.append(role)
                    role_ids.add(role_id)
        
        if not role_mentions:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> No Valid Roles",
                description="No valid roles found. Please mention roles or provide role IDs.",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Get members based on type
        members_to_update = []
        if type_lower == 'only humans':
            members_to_update = [m for m in ctx.guild.members if not m.bot]
        elif type_lower == 'only bots':
            members_to_update = [m for m in ctx.guild.members if m.bot]
        elif type_lower == 'all users':
            members_to_update = list(ctx.guild.members)
        
        # Send loading message
        loading_view = LayoutViewFactory.create(
            title="<a:jo1ntrx_loading:1405094057499295806> Removing Roles",
            description=f"Removing {len(role_mentions)} role(s) from {len(members_to_update)} members...",
            timestamp=False
        )
        loading_msg = await ctx.send(view=loading_view)
        
        # Remove roles from members who have them
        success_count = 0
        failed_count = 0
        skipped_count = 0
        
        for i, member in enumerate(members_to_update):
            try:
                # Only remove roles they actually have
                roles_to_remove = [r for r in role_mentions if r in member.roles]
                if roles_to_remove:
                    await member.remove_roles(*roles_to_remove, reason=f"Mass role remove by {ctx.author}")
                    success_count += 1
                    # Rate limiting: 1 second delay per operation to prevent Discord rate limits
                    await asyncio.sleep(1)
                else:
                    skipped_count += 1
            except:
                failed_count += 1
        
        # Send success message
        roles_text = ", ".join([r.mention for r in role_mentions])
        success_view = LayoutViewFactory.create(
            description=f"<:Jo1nTrX_Yes:1408288995477159987> Successfully removed {roles_text} from {success_count} {type_lower}!",
            timestamp=False
        )
        await loading_msg.edit(view=success_view)

async def setup(bot):
    await bot.add_cog(MassRole(bot))
