import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import typing
from datetime import datetime
from Jo1nTrX.utils.embeds import create_embed
from Jo1nTrX.cogs.extra.embeds import create_embed_from_database_data
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji, LayoutViewFactory
)

class IgnoreManagement(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_group(name='temprole', fallback='help')
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def temprole(self, ctx):
        """Temporary role management commands"""
        view = LayoutViewFactory.create(
            title="<:Jo1nTrX_misc:1422793178746060812> Temporary Role Commands",
            description="**Available Commands:**\n\n"
                       "• `temprole add <time> <user> <role>` - Add a temporary role to a user\n\n"
                       "**Time Formats:**\n"
                       "• `s` - Seconds\n"
                       "• `m` - Minutes\n"
                       "• `h` - Hours\n"
                       "• `d` - Days\n\n"
                       "**Examples:**\n"
                       "`+temprole add 30m @User @Role` - Add role for 30 minutes\n"
                       "`+temprole add 2h @User @Role` - Add role for 2 hours\n"
                       "`+temprole add 7d @User @Role` - Add role for 7 days",
            timestamp=False
        )
        await ctx.send(view=view)
    
    @temprole.command(name='add')
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    @app_commands.describe(
        time='Duration (e.g., 30s, 5m, 2h, 7d)',
        user='The user to give the temporary role',
        role='The role to temporarily assign'
    )
    async def temprole_add(self, ctx, time: str, user: discord.Member, role: discord.Role):
        """Add a temporary role to a user"""
        import re
        
        # Parse time format
        time_pattern = r'^(\d+)([smhd])$'
        match = re.match(time_pattern, time.lower())
        
        if not match:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> Invalid Time Format",
                description="Please use the format: `<number><unit>`\n\n"
                           "**Valid units:**\n"
                           "• `s` - Seconds\n"
                           "• `m` - Minutes\n"
                           "• `h` - Hours\n"
                           "• `d` - Days\n\n"
                           "**Examples:** `30s`, `5m`, `2h`, `7d`",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        amount = int(match.group(1))
        unit = match.group(2)
        
        # Convert to seconds
        time_multipliers = {
            's': 1,
            'm': 60,
            'h': 3600,
            'd': 86400
        }
        
        duration_seconds = amount * time_multipliers[unit]
        
        # Check if bot can manage the role
        if role.position >= ctx.guild.me.top_role.position:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> Permission Error",
                description=f"I cannot manage {role.mention} because it's higher than or equal to my highest role.",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Check if role is @everyone
        if role.id == ctx.guild.id:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> Invalid Role",
                description="Cannot assign @everyone as a temporary role.",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Check if user already has the role
        if role in user.roles:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> Role Already Assigned",
                description=f"{user.mention} already has the role {role.mention}.",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Add the role
        try:
            await user.add_roles(role, reason=f"Temporary role added by {ctx.author} for {time}")
            
            # Format time display
            time_display = f"{amount}{unit}"
            unit_names = {'s': 'second', 'm': 'minute', 'h': 'hour', 'd': 'day'}
            time_text = f"{amount} {unit_names[unit]}{'s' if amount > 1 else ''}"
            
            view = LayoutViewFactory.create(
                description=f"<:Jo1nTrX_Yes:1408288995477159987> Successfully added {role.mention} to {user.mention} for {time_text}!",
                timestamp=False
            )
            await ctx.send(view=view)
            
            # Wait and then remove the role
            await asyncio.sleep(duration_seconds)
            
            # Check if user still has the role before removing
            if role in user.roles:
                await user.remove_roles(role, reason=f"Temporary role expired (was set for {time})")
                
                # Try to notify in the same channel
                try:
                    notify_view = LayoutViewFactory.create(
                        description=f"⏰ Temporary role {role.mention} has been removed from {user.mention}",
                        timestamp=False
                    )
                    await ctx.send(view=notify_view)
                except:
                    pass  # Fail silently if we can't send the notification
                    
        except discord.Forbidden:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> Permission Error",
                description=f"I don't have permission to manage roles for {user.mention}.",
                timestamp=False
            )
            await ctx.send(view=view)
        except Exception as e:
            view = LayoutViewFactory.create(
                title="<:jo1ntrx_cross:1405094904568483880> Error",
                description=f"Failed to add temporary role: {str(e)}",
                timestamp=False
            )
            await ctx.send(view=view)
    
    @commands.command(name='icadd', aliases=['ignorechannel-add'])
    @commands.has_permissions(administrator=True)
    async def icadd(self, ctx, channel: discord.TextChannel):
        """Add a channel to the ignore list"""
        # Check if already ignored
        is_ignored = await self.bot.db.is_channel_ignored(ctx.guild.id, channel.id)
        if is_ignored:
            view = LayoutViewFactory.create(
                description=f"<:Jo1nTrX_arrow2:1415026780783247420> {channel.mention} is already in the ignore list!",
                timestamp=False
            )
        else:
            await self.bot.db.add_ignored_channel(ctx.guild.id, channel.id)
            view = LayoutViewFactory.create(
                description=f"<:Jo1nTrX_Yes:1408288995477159987> Now i'll successfully ignore channel {channel.mention} | {ctx.author.mention}!",
                timestamp=False
            )
        await ctx.send(view=view)

    @commands.command(name='icremove', aliases=['ignorechannel-remove'])
    @commands.has_permissions(administrator=True)
    async def icremove(self, ctx, channel: discord.TextChannel):
        """Remove a channel from the ignore list"""
        # Check if channel is in ignore list
        is_ignored = await self.bot.db.is_channel_ignored(ctx.guild.id, channel.id)
        if not is_ignored:
            view = LayoutViewFactory.create(
                description=f"<:Jo1nTrX_arrow2:1415026780783247420> {channel.mention} is not in the ignore list!",
                timestamp=False
            )
        else:
            await self.bot.db.remove_ignored_channel(ctx.guild.id, channel.id)
            view = LayoutViewFactory.create(
                description=f"<:Jo1nTrX_arrow2:1415026780783247420> Successfully removed {channel.mention} from ignore list!",
                timestamp=False
            )
        await ctx.send(view=view)

    @commands.command(name='iclist', aliases=['ignorechannel-list'])
    @commands.has_permissions(administrator=True)
    async def iclist(self, ctx):
        """View all ignored channels"""
        ignored_channels = await self.bot.db.get_ignored_channels(ctx.guild.id)
        
        if not ignored_channels:
            view = LayoutViewFactory.create(
                description="<:Jo1nTrX_arrow2:1415026780783247420> No ignored channels configured.",
                timestamp=False
            )
        else:
            channel_mentions = [f"<#{ch_id}>" for ch_id in ignored_channels]
            view = LayoutViewFactory.create(
                title="<:Jo1nTrX_misc:1422793178746060812> Ignored Channels",
                description=f"**Ignored Channels ({len(ignored_channels)}):**\n\n" + "\n".join(channel_mentions),
                timestamp=False
            )
        
        await ctx.send(view=view)

    @commands.group(name='ibypass', aliases=['ignorebypass'], invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def ibypass(self, ctx):
        """Manage bypass roles/members for ignored channels"""
        bypass_data = await self.bot.db.get_ignore_bypass(ctx.guild.id)
        
        role_mentions = []
        for role_id in bypass_data['roles']:
            role = ctx.guild.get_role(role_id)
            if role:
                role_mentions.append(f"<@&{role_id}>")
        
        member_mentions = []
        for member_id in bypass_data['members']:
            member_mentions.append(f"<@{member_id}>")
        
        if not role_mentions and not member_mentions:
            view = LayoutViewFactory.create(
                description="<:Jo1nTrX_arrow2:1415026780783247420> No bypass roles or members configured.\n\n**Usage:**\n`+ibypass add <@role/@member>` to add bypass\n`+ibypass remove <@role/@member>` to remove bypass",
                timestamp=False
            )
        else:
            description = "**Bypass Roles and Members:**\n\n"
            if role_mentions:
                description += f"**Roles ({len(role_mentions)}):**\n" + "\n".join(role_mentions) + "\n\n"
            if member_mentions:
                description += f"**Members ({len(member_mentions)}):**\n" + "\n".join(member_mentions)
            
            view = LayoutViewFactory.create(
                title="<:Jo1nTrX_misc:1422793178746060812> Ignore Bypass List",
                description=description,
                timestamp=False
            )
        
        await ctx.send(view=view)

    @ibypass.command(name='add')
    @commands.has_permissions(administrator=True)
    async def ibypass_add(self, ctx, entity: typing.Union[discord.Role, discord.Member]):
        """Add a role or member to bypass list"""
        if isinstance(entity, discord.Role):
            await self.bot.db.add_ignore_bypass(ctx.guild.id, entity.id, 'role')
            view = LayoutViewFactory.create(
                description=f"<:Jo1nTrX_arrow2:1415026780783247420> Successfully added {entity.mention} to bypass list!\n\nMembers with this role can now use commands in ignored channels.",
                timestamp=False
            )
        else:
            await self.bot.db.add_ignore_bypass(ctx.guild.id, entity.id, 'member')
            view = LayoutViewFactory.create(
                description=f"<:Jo1nTrX_arrow2:1415026780783247420> Successfully added {entity.mention} to bypass list!\n\nThis member can now use commands in ignored channels.",
                timestamp=False
            )
        
        await ctx.send(view=view)

    @ibypass.command(name='remove')
    @commands.has_permissions(administrator=True)
    async def ibypass_remove(self, ctx, entity: typing.Union[discord.Role, discord.Member]):
        """Remove a role or member from bypass list"""
        if isinstance(entity, discord.Role):
            await self.bot.db.remove_ignore_bypass(ctx.guild.id, entity.id, 'role')
            view = LayoutViewFactory.create(
                description=f"<:Jo1nTrX_arrow2:1415026780783247420> Successfully removed {entity.mention} from bypass list!",
                timestamp=False
            )
        else:
            await self.bot.db.remove_ignore_bypass(ctx.guild.id, entity.id, 'member')
            view = LayoutViewFactory.create(
                description=f"<:Jo1nTrX_arrow2:1415026780783247420> Successfully removed {entity.mention} from bypass list!",
                timestamp=False
            )
        
        await ctx.send(view=view)

async def setup(bot):
    await bot.add_cog(IgnoreManagement(bot))
