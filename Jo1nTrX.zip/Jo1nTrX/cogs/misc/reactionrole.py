import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import typing
from datetime import datetime
from Jo1nTrX.utils.embeds import create_embed
from Jo1nTrX.cogs.extra.embeds import create_embed_from_database_data
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji, LayoutViewFactory
)

class ReactionRoleConfig(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    async def cog_load(self):
        """Restore persistent views when the cog is loaded (similar to ticket system)"""
        await asyncio.sleep(12)
        
        try:
            restored_count = 0
            skipped_count = 0
            
            cursor = self.bot.db.get_cursor()
            cursor.execute('''
                SELECT id, guild_id, panel_id, panel_type, channel_id, message_id
                FROM reaction_role_panels
                WHERE panel_type IN ('button', 'selective')
                AND message_id IS NOT NULL
                AND channel_id IS NOT NULL
                ORDER BY guild_id, panel_id
            ''')
            panels = cursor.fetchall()
            cursor.close()
            
            for panel_data in panels:
                panel_db_id, guild_id, panel_id, panel_type, channel_id, message_id = panel_data
                
                try:
                    guild = self.bot.get_guild(guild_id)
                    
                    if not guild:
                        try:
                            guild = await self.bot.fetch_guild(guild_id)
                        except:
                            skipped_count += 1
                            continue
                    
                    channel = guild.get_channel(channel_id)
                    if not channel:
                        try:
                            channel = await self.bot.fetch_channel(channel_id)
                        except:
                            skipped_count += 1
                            continue
                    
                    try:
                        message = await channel.fetch_message(message_id)
                    except discord.NotFound:
                        skipped_count += 1
                        continue
                    except Exception:
                        skipped_count += 1
                        continue
                    
                    if panel_type == 'button':
                        view = ReactionRoleButtonView(panel_db_id, guild_id, self.bot.db)
                        await view.setup_buttons()
                    else:
                        view = ReactionRoleSelectView(panel_db_id, guild_id, self.bot.db)
                        await view.setup_select()
                    
                    self.bot.add_view(view, message_id=message.id)
                    restored_count += 1
                    
                except Exception as e:
                    print(f"❌ Error restoring reaction role panel {panel_id}: {e}")
                    skipped_count += 1
            
        except Exception as e:
            print(f"❌ Critical error in reaction role view restoration: {e}")
            import traceback
            traceback.print_exc()
    
    @commands.hybrid_group(name='reactionrole', aliases=['rr'])
    async def reactionrole(self, ctx):
        """Reaction role management commands"""
        if ctx.invoked_subcommand is None:
            view = LayoutViewFactory.create(
                title="<:Jo1nTrX_misc:1422793178746060812> Reaction Role Commands",
                description="**Available Commands:**\n\n"
                           "• `reactionrole setup` - Setup a new reaction role panel\n"
                           "• `reactionrole list` - View all reaction role panels\n"
                           "• `reactionrole panelsend <panel_id> <channel>` - Resend an existing panel\n"
                           "• `reactionrole delete <panel_id>` - Delete a reaction role panel\n\n"
                           "**Usage:**\n"
                           "`+reactionrole setup` or `/reactionrole setup`",
                timestamp=False
            )
            await ctx.send(view=view)
    
    @reactionrole.command(name='setup')
    @commands.has_permissions(administrator=True)
    async def setup(self, ctx):
        """Setup a new reaction role panel"""
        
        # Create panel type selection view
        panel_type_view = PanelTypeSelectView(ctx.guild.id, self.bot.db, ctx.author.id)
        
        view = LayoutViewFactory.create(
            title=f"{ctx.guild.name}",
            description="**Please select the type of Reaction role panel you want to create:**\n\n"
                       "__Limits__: \n"
                       "**Button Type** : Total 5 | for both normal & premium user\n"
                       "**Reaction Type** : Normal User = 8 | Premium User = 15\n"
                       "**Selective Type** : Normal User = 8 | Premium User = 15\n\n"
                       "Use the buttons below to select your panel type.",
            timestamp=False
        )
        
        await ctx.send(view=panel_type_view)
    
    @reactionrole.command(name='list')
    async def list_panels(self, ctx):
        """List all reaction role panels"""
        panels = await self.bot.db.get_all_reaction_role_panels(ctx.guild.id)
        
        if not panels:
            view = LayoutViewFactory.create(
                description="<:jo1ntrx_cross:1405094904568483880> No reaction role panels found!",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        panel_list = []
        for panel in panels:
            panel_type = panel['panel_type'].replace('_', ' ').title()
            channel = ctx.guild.get_channel(panel['channel_id']) if panel['channel_id'] else None
            channel_mention = channel.mention if channel else "Not Set"
            
            # Get options count
            options = await self.bot.db.get_reaction_role_options(panel['id'])
            
            panel_list.append(
                f"**Panel {panel['panel_id']}**\n"
                f"**Type:** {panel_type}\n"
                f"**Embed:** {panel['panel_embed'] or 'Not Set'}\n"
                f"**Channel:** {channel_mention}\n"
                f"**Options:** {len(options)}"
            )
        
        view = LayoutViewFactory.create(
            title="<:Jo1nTrX_misc:1422793178746060812> Reaction Role Panels",
            description=f"**Total Panels:** {len(panels)}\n\n" + "\n\n".join(panel_list),
            timestamp=False
        )
        
        await ctx.send(view=view)
    
    @reactionrole.command(name='delete')
    @commands.has_permissions(administrator=True)
    async def delete_panel(self, ctx, panel_id: int):
        """Delete a reaction role panel"""
        
        # Check if panel exists
        panel = await self.bot.db.get_reaction_role_panel(ctx.guild.id, panel_id)
        if not panel:
            view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> Panel {panel_id} not found!",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Delete the message if it exists
        if panel['message_id'] and panel['channel_id']:
            try:
                channel = ctx.guild.get_channel(panel['channel_id'])
                if channel:
                    message = await channel.fetch_message(panel['message_id'])
                    await message.delete()
            except:
                pass
        
        # Delete from database
        success = await self.bot.db.delete_reaction_role_panel(ctx.guild.id, panel_id)
        
        if success:
            view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_tick:1405094884947267715> Panel {panel_id} deleted successfully!",
                timestamp=False
            )
            await ctx.send(view=view)
        else:
            view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> Failed to delete panel {panel_id}!",
                timestamp=False
            )
            await ctx.send(view=view)
    
    @reactionrole.command(name='panelsend')
    @commands.has_permissions(administrator=True)
    async def panel_send(self, ctx, panel_id: int, channel: discord.TextChannel):
        """Resend an existing reaction role panel to a channel"""
        
        # Check if panel exists
        panel = await self.bot.db.get_reaction_role_panel(ctx.guild.id, panel_id)
        if not panel:
            view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> Panel {panel_id} not found!",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Get panel options
        options = await self.bot.db.get_reaction_role_options(panel['id'])
        if not options:
            view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> Panel {panel_id} has no options!",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        # Create embed from database
        message_content, panel_embed = await create_embed_from_database_data(
            self.bot,
            ctx.guild.id,
            panel['panel_embed']
        )
        
        if not panel_embed:
            view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> Failed to load panel embed!",
                timestamp=False
            )
            await ctx.send(view=view)
            return
        
        try:
            sent_message = None
            
            # Create view based on panel type
            if panel['panel_type'] == 'reaction':
                # For reaction type, send message and add reactions
                sent_message = await channel.send(content=message_content, embed=panel_embed)
                
                # Add reactions
                for option in options:
                    try:
                        await sent_message.add_reaction(option['emoji'])
                    except:
                        pass
                
            elif panel['panel_type'] == 'button':
                # For button type, create button view
                button_view = ReactionRoleButtonView(panel['id'], ctx.guild.id, self.bot.db)
                await button_view.setup_buttons()
                sent_message = await channel.send(content=message_content, embed=panel_embed, view=button_view)
                self.bot.add_view(button_view, message_id=sent_message.id)
                
            elif panel['panel_type'] == 'selective':
                # For selective type, create select menu view
                select_view = ReactionRoleSelectView(panel['id'], ctx.guild.id, self.bot.db)
                await select_view.setup_select()
                sent_message = await channel.send(content=message_content, embed=panel_embed, view=select_view)
                self.bot.add_view(select_view, message_id=sent_message.id)
            
            # Update panel with new channel and message ID
            await self.bot.db.save_reaction_role_panel(
                ctx.guild.id,
                panel_id,
                panel['panel_type'],
                panel['panel_embed'],
                channel.id,
                sent_message.id
            )
            
            view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_tick:1405094884947267715> Panel {panel_id} sent successfully to {channel.mention}!",
                timestamp=False
            )
            await ctx.send(view=view)
            
        except Exception as e:
            view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> Failed to send panel: {e}",
                timestamp=False
            )
            await ctx.send(view=view)
    
class PanelTypeSelectView(BaseView):
    def __init__(self, guild_id, db, owner_id=None):
        super().__init__(timeout=60)
        self.guild_id = guild_id
        self.db = db
        self.owner_id = owner_id
        
        # Add buttons for panel type selection
        self.add_item(PanelTypeButton("➛ Reaction Type", "reaction"))
        self.add_item(PanelTypeButton("➛ Button Type", "button"))
        self.add_item(PanelTypeButton("➛ Selective Type", "selective"))

class PanelTypeButton(BaseButton):
    def __init__(self, label, panel_type):
        super().__init__(label=label, style=discord.ButtonStyle.primary)
        self.panel_type = panel_type
    
    async def callback(self, interaction: discord.Interaction):
        # Check if user is the owner of this configuration session
        view = self.view
        if view.owner_id and interaction.user.id != view.owner_id:
            error_view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{view.owner_id}>!",
                timestamp=False
            )
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        # Get next panel ID
        panel_id = await view.db.get_next_reaction_role_panel_id(view.guild_id)
        
        # Save panel type
        await view.db.save_reaction_role_panel(
            view.guild_id, 
            panel_id, 
            self.panel_type
        )
        
        # Start main configuration
        panel_view = ReactionRolePanelView(view.guild_id, view.db, view.owner_id, panel_id)
        
        config_view = LayoutViewFactory.create(
            title=f"{interaction.guild.name if interaction.guild else 'Server'}",
            description="Use the buttons below to configure your Reaction Role panel\n\n"
                       "**Panel Embed**: Setup Reaction Role Panel Embed message!\n\n"
                       "**Save & Continue**: To save the panel configuration & head toward option config!\n\n"
                       "**__Note__** <:Jo1nTrX_Note:1411930562288943104>\n\n"
                       "• Before setting up **Panel Embed**, create **Embed** first! `+embed create <name>`.",
            timestamp=False
        )
        
        await interaction.response.edit_message(view=panel_view)

class ReactionRolePanelView(BaseView):
    def __init__(self, guild_id, db, owner_id=None, panel_id=None):
        super().__init__(timeout=None)
        self.guild_id = guild_id
        self.db = db
        self.owner_id = owner_id
        self.panel_id = panel_id
    
    @discord.ui.button(label="Panel Embed", style=discord.ButtonStyle.primary)
    async def panel_embed(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is the owner
        if self.owner_id and interaction.user.id != self.owner_id:
            error_view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{self.owner_id}>!",
                timestamp=False
            )
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        # Load available embeds using database method
        embeds_list = await self.db.get_guild_embeds(self.guild_id)
        embeds = {embed['name']: embed['name'] for embed in embeds_list}
        
        if not embeds:
            error_view = LayoutViewFactory.create(
                description="<:jo1ntrx_cross:1405094904568483880> No embeds found! Please create an embed first using `+embed create <name>`",
                timestamp=False
            )
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        # Create dropdown with available embeds
        embed_view = ReactionRoleEmbedSelectView(embeds, self.guild_id, self.db, self.panel_id)
        
        select_view = LayoutViewFactory.create(
            title="Select Reaction Role Embed",
            description="Choose an embed for your reaction role panel from the dropdown below:",
            timestamp=False
        )
        
        await interaction.response.send_message(view=embed_view, ephemeral=True)
    
    @discord.ui.button(label="Save & Continue", style=discord.ButtonStyle.success)
    async def save_continue(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is the owner
        if self.owner_id and interaction.user.id != self.owner_id:
            error_view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{self.owner_id}>!",
                timestamp=False
            )
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        # Load panel configuration
        panel = await self.db.get_reaction_role_panel(self.guild_id, self.panel_id)
        
        # Check if panel embed is configured
        if not panel or not panel['panel_embed']:
            error_view = LayoutViewFactory.create(
                description="<:jo1ntrx_cross:1405094904568483880> Please select a panel embed first!",
                timestamp=False
            )
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        # Move to option configuration
        option_view = OptionConfigView(
            self.guild_id,
            self.db,
            self.owner_id,
            panel_id=self.panel_id
        )
        
        config_view = LayoutViewFactory.create(
            title=f"{interaction.guild.name if interaction.guild else 'Server'}",
            description="Use the buttons below to configure your options!\n\n"
                       "**Add option**: To add the reaction role in the panel.\n\n"
                       "**Send panel**: To save & send your panel.",
            timestamp=False
        )
        
        await interaction.response.edit_message(view=option_view)

class ReactionRoleEmbedSelectView(BaseView):
    def __init__(self, embeds, guild_id, db, panel_id=None):
        super().__init__(timeout=300)
        self.guild_id = guild_id
        self.db = db
        self.panel_id = panel_id
        
        # Create dropdown with embed options
        options = []
        for embed_name in list(embeds.keys())[:25]:  # Discord limit
            options.append(discord.SelectOption(
                label=embed_name,
                description=f"Use {embed_name} as reaction role embed",
                value=embed_name,
                emoji=bot_emoji.embed
            ))
        
        if options:
            select = ReactionRoleEmbedSelect(options, self.guild_id, self.db, self.panel_id)
            self.add_item(select)

class ReactionRoleEmbedSelect(BaseSelect):
    def __init__(self, options, guild_id, db, panel_id):
        super().__init__(
            placeholder="Choose an embed for your reaction role panel...",
            options=options,
            min_values=1,
            max_values=1
        )
        self.guild_id = guild_id
        self.db = db
        self.panel_id = panel_id
    
    async def callback(self, interaction: discord.Interaction):
        embed_name = self.values[0]
        
        # Load panel
        panel = await self.db.get_reaction_role_panel(self.guild_id, self.panel_id)
        
        # Update panel with selected embed
        await self.db.save_reaction_role_panel(
            self.guild_id,
            self.panel_id,
            panel['panel_type'],
            panel_embed=embed_name,
            channel_id=panel.get('channel_id'),
            message_id=panel.get('message_id')
        )
        
        # Create success view
        success_view = LayoutViewFactory.create(
            title="<:jo1ntrx_tick:1405094884947267715> Embed Selected",
            description=f"Successfully selected **{embed_name}** as your reaction role panel embed.",
            timestamp=False
        )
        
        await interaction.response.edit_message(view=success_view)

class OptionConfigView(BaseView):
    def __init__(self, guild_id, db, owner_id=None, panel_id=None):
        super().__init__(timeout=1800)  # 30 minutes timeout
        self.guild_id = guild_id
        self.db = db
        self.owner_id = owner_id
        self.panel_id = panel_id
    
    @discord.ui.button(label="Add option", style=discord.ButtonStyle.primary)
    async def add_option(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is the owner
        if self.owner_id and interaction.user.id != self.owner_id:
            error_view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{self.owner_id}>!",
                timestamp=False
            )
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        # Get panel info
        panel = await self.db.get_reaction_role_panel(self.guild_id, self.panel_id)
        
        # Get current options
        current_options = await self.db.get_reaction_role_options(panel['id'])
        
        # Check premium status
        premium_status = await self.db.check_premium_user(interaction.user.id, self.guild_id)
        has_premium = premium_status['has_premium']
        
        # Determine limits based on panel type and premium status
        if panel['panel_type'] == 'button':
            max_options = 5
        elif panel['panel_type'] in ['reaction', 'selective']:
            max_options = 15 if has_premium else 8
        else:
            max_options = 15 if has_premium else 8
        
        if len(current_options) >= max_options:
            premium_msg = "" if has_premium or panel['panel_type'] == 'button' else "\n\n<:Jo1nTrX_Note:1411930562288943104> **Premium users** can add up to 15 options!"
            error_view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> **You've reached the maximum option limit ({max_options})!**{premium_msg}\n\nUse `Send Panel` to send the panel!",
                timestamp=False
            )
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        # Different flows based on panel type
        def check(m):
            return m.author == interaction.user and m.channel == interaction.channel
        
        try:
            if panel['panel_type'] == 'reaction':
                # Reaction type: Ask emoji first, then role
                step1_view = LayoutViewFactory.create(
                    description="**Adding Option**\n\n**1.** Enter the emoji you want as a reaction:",
                    timestamp=False
                )
                await interaction.response.send_message(view=step1_view, ephemeral=True)
                
                msg = await interaction.client.wait_for('message', check=check, timeout=60)
                emoji = msg.content.strip()
                await msg.delete()
                
                step2_view = LayoutViewFactory.create(
                    description="**Adding Option**\n\n**2.** Mention the role or enter role ID:",
                    timestamp=False
                )
                await interaction.followup.send(view=step2_view, ephemeral=True)
                
                msg = await interaction.client.wait_for('message', check=check, timeout=60)
                await msg.delete()
                
                # Parse role
                role = None
                if msg.role_mentions:
                    role = msg.role_mentions[0]
                else:
                    try:
                        role_id = int(msg.content.strip('<@&>'))
                        role = interaction.guild.get_role(role_id)
                    except:
                        error_view = LayoutViewFactory.create(
                            description="<:jo1ntrx_cross:1405094904568483880> Invalid role!",
                            timestamp=False
                        )
                        await interaction.followup.send(view=error_view, ephemeral=True)
                        return
                
                if not role:
                    error_view = LayoutViewFactory.create(
                        description="<:jo1ntrx_cross:1405094904568483880> Role not found!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=error_view, ephemeral=True)
                    return
                
                # Save option for reaction type (no label)
                await self.db.save_reaction_role_option(
                    panel['id'],
                    self.guild_id,
                    role.id,
                    emoji,
                    None,  # description
                    len(current_options),
                    None  # label
                )
                
                success_view = LayoutViewFactory.create(
                    description=f"<:jo1ntrx_tick:1405094884947267715> Option added successfully!\n**Emoji:** {emoji}\n**Role:** {role.mention}",
                    timestamp=False
                )
                await interaction.followup.send(view=success_view, ephemeral=True)
                
            else:
                # Button/Selective type: Ask label, emoji (skip option), role
                step1_view = LayoutViewFactory.create(
                    description="**Adding Option**\n\n**1.** Enter the label for the option:",
                    timestamp=False
                )
                await interaction.response.send_message(view=step1_view, ephemeral=True)
                
                msg = await interaction.client.wait_for('message', check=check, timeout=60)
                label = msg.content.strip()
                await msg.delete()
                
                step2_view = LayoutViewFactory.create(
                    description="**Adding Option**\n\n**2.** Enter the emoji for the option. Type `skip` to skip the emoji!",
                    timestamp=False
                )
                await interaction.followup.send(view=step2_view, ephemeral=True)
                
                msg = await interaction.client.wait_for('message', check=check, timeout=60)
                emoji = None if msg.content.lower() == 'skip' else msg.content.strip()
                await msg.delete()
                
                step3_view = LayoutViewFactory.create(
                    description="**Adding Option**\n\n**3.** Mention the role or enter role ID, that you want to assign your user:",
                    timestamp=False
                )
                await interaction.followup.send(view=step3_view, ephemeral=True)
                
                msg = await interaction.client.wait_for('message', check=check, timeout=60)
                await msg.delete()
                
                # Parse role
                role = None
                if msg.role_mentions:
                    role = msg.role_mentions[0]
                else:
                    try:
                        role_id = int(msg.content.strip('<@&>'))
                        role = interaction.guild.get_role(role_id)
                    except:
                        error_view = LayoutViewFactory.create(
                            description="<:jo1ntrx_cross:1405094904568483880> Invalid role!",
                            timestamp=False
                        )
                        await interaction.followup.send(view=error_view, ephemeral=True)
                        return
                
                if not role:
                    error_view = LayoutViewFactory.create(
                        description="<:jo1ntrx_cross:1405094904568483880> Role not found!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=error_view, ephemeral=True)
                    return
                
                # Save option for button/selective type (with label)
                await self.db.save_reaction_role_option(
                    panel['id'],
                    self.guild_id,
                    role.id,
                    emoji,
                    None,  # description
                    len(current_options),
                    label  # label
                )
                
                emoji_text = emoji if emoji else "None"
                success_view = LayoutViewFactory.create(
                    description=f"<:jo1ntrx_tick:1405094884947267715> Option added successfully!\n**Label:** {label}\n**Emoji:** {emoji_text}\n**Role:** {role.mention}",
                    timestamp=False
                )
                await interaction.followup.send(view=success_view, ephemeral=True)
            
        except asyncio.TimeoutError:
            error_view = LayoutViewFactory.create(
                description="<:jo1ntrx_cross:1405094904568483880> Option addition timed out!",
                timestamp=False
            )
            await interaction.followup.send(view=error_view, ephemeral=True)
    
    @discord.ui.button(label="Send panel", style=discord.ButtonStyle.success)
    async def send_panel(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is the owner
        if self.owner_id and interaction.user.id != self.owner_id:
            error_view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_cross:1405094904568483880> This menu is for <@{self.owner_id}>!",
                timestamp=False
            )
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        # Get panel info
        panel = await self.db.get_reaction_role_panel(self.guild_id, self.panel_id)
        
        # Get options
        options = await self.db.get_reaction_role_options(panel['id'])
        
        if len(options) == 0:
            error_view = LayoutViewFactory.create(
                description="<:jo1ntrx_cross:1405094904568483880> Please add at least one option before sending the panel!",
                timestamp=False
            )
            await interaction.response.send_message(view=error_view, ephemeral=True)
            return
        
        # Ask for channel
        channel_prompt_view = LayoutViewFactory.create(
            description="**Send Panel**\n\nIn which channel should the panel be sent? (mention or ID):",
            timestamp=False
        )
        await interaction.response.send_message(view=channel_prompt_view, ephemeral=True)
        
        def check(m):
            return m.author == interaction.user and m.channel == interaction.channel
        
        try:
            msg = await interaction.client.wait_for('message', check=check, timeout=60)
            await msg.delete()
            
            # Parse channel
            channel = None
            if msg.channel_mentions:
                channel = msg.channel_mentions[0]
            else:
                try:
                    channel_id = int(msg.content.strip('<>#'))
                    channel = interaction.guild.get_channel(channel_id)
                except:
                    error_view = LayoutViewFactory.create(
                        description="<:jo1ntrx_cross:1405094904568483880> Invalid channel!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=error_view, ephemeral=True)
                    return
            
            if not channel:
                error_view = LayoutViewFactory.create(
                    description="<:jo1ntrx_cross:1405094904568483880> Channel not found!",
                    timestamp=False
                )
                await interaction.followup.send(view=error_view, ephemeral=True)
                return
            
            # Create embed from database
            message_content, panel_embed = await create_embed_from_database_data(
                interaction.client,
                self.guild_id,
                panel['panel_embed']
            )
            
            if not panel_embed:
                error_view = LayoutViewFactory.create(
                    description="<:jo1ntrx_cross:1405094904568483880> Failed to load panel embed!",
                    timestamp=False
                )
                await interaction.followup.send(view=error_view, ephemeral=True)
                return
            
            # Create view based on panel type
            if panel['panel_type'] == 'reaction':
                # For reaction type, send message and add reactions
                sent_message = await channel.send(content=message_content, embed=panel_embed)
                
                # Add reactions
                for option in options:
                    try:
                        await sent_message.add_reaction(option['emoji'])
                    except:
                        pass
                
            elif panel['panel_type'] == 'button':
                # For button type, create button view
                button_view = ReactionRoleButtonView(panel['id'], self.guild_id, interaction.client.db)
                await button_view.setup_buttons()  # Populate buttons from database
                sent_message = await channel.send(content=message_content, embed=panel_embed, view=button_view)
                interaction.client.add_view(button_view, message_id=sent_message.id)  # Register persistent view
                
            elif panel['panel_type'] == 'selective':
                # For selective type, create select menu view
                select_view = ReactionRoleSelectView(panel['id'], self.guild_id, interaction.client.db)
                await select_view.setup_select()  # Populate select menu from database
                sent_message = await channel.send(content=message_content, embed=panel_embed, view=select_view)
                interaction.client.add_view(select_view, message_id=sent_message.id)  # Register persistent view
            
            # Update panel with channel and message ID
            await self.db.save_reaction_role_panel(
                self.guild_id,
                self.panel_id,
                panel['panel_type'],
                panel['panel_embed'],
                channel.id,
                sent_message.id
            )
            
            success_view = LayoutViewFactory.create(
                description=f"<:jo1ntrx_tick:1405094884947267715> Panel {self.panel_id} sent successfully to {channel.mention}!",
                timestamp=False
            )
            await interaction.followup.send(view=success_view, ephemeral=True)
            
        except asyncio.TimeoutError:
            error_view = LayoutViewFactory.create(
                description="<:jo1ntrx_cross:1405094904568483880> Panel sending timed out!",
                timestamp=False
            )
            await interaction.followup.send(view=error_view, ephemeral=True)

class ReactionRoleButtonView(BaseView):
    def __init__(self, panel_db_id, guild_id, db):
        super().__init__(timeout=None)
        self.panel_db_id = panel_db_id
        self.guild_id = guild_id
        self.db = db
        
        # This will be populated when the bot starts
        # For now, we'll create a placeholder
    
    async def setup_buttons(self):
        """Setup buttons from database options"""
        options = await self.db.get_reaction_role_options(self.panel_db_id)
        
        for i, option in enumerate(options[:5]):  # Max 5 buttons for button type
            button = discord.ui.Button(
                label=option['label'] or "Role",
                emoji=option['emoji'] if option['emoji'] else None,
                style=discord.ButtonStyle.primary,
                custom_id=f"rr_button_{self.panel_db_id}_{option['id']}"
            )
            
            async def button_callback(interaction: discord.Interaction, opt=option, all_opts=options):
                try:
                    role = interaction.guild.get_role(opt['role_id'])
                    if not role:
                        error_view = LayoutViewFactory.create(
                            description="<:jo1ntrx_cross:1405094904568483880> Role not found!",
                            timestamp=False
                        )
                        await interaction.response.send_message(view=error_view, ephemeral=True)
                        return
                    
                    # Check bot permissions
                    bot_member = interaction.guild.get_member(interaction.client.user.id)
                    if not bot_member.guild_permissions.manage_roles:
                        error_view = LayoutViewFactory.create(
                            description="<:jo1ntrx_cross:1405094904568483880> I don't have permission to manage roles!",
                            timestamp=False
                        )
                        await interaction.response.send_message(view=error_view, ephemeral=True)
                        return
                    
                    # Check if bot's role is high enough
                    if role >= bot_member.top_role:
                        error_view = LayoutViewFactory.create(
                            description=f"<:jo1ntrx_cross:1405094904568483880> I can't manage {role.mention} because it's higher than or equal to my highest role!",
                            timestamp=False
                        )
                        await interaction.response.send_message(view=error_view, ephemeral=True)
                        return
                    
                    # Remove all other roles from this panel first
                    roles_to_remove = []
                    for other_opt in all_opts:
                        if other_opt['id'] != opt['id']:
                            other_role = interaction.guild.get_role(other_opt['role_id'])
                            if other_role and other_role in interaction.user.roles:
                                roles_to_remove.append(other_role)
                    
                    if roles_to_remove:
                        await interaction.user.remove_roles(*roles_to_remove)
                    
                    # Toggle the selected role
                    if role in interaction.user.roles:
                        await interaction.user.remove_roles(role)
                        success_view = LayoutViewFactory.create(
                            description=f"<:jo1ntrx_tick:1405094884947267715> Removed {role.mention}!",
                            timestamp=False
                        )
                        await interaction.response.send_message(view=success_view, ephemeral=True)
                    else:
                        await interaction.user.add_roles(role)
                        success_view = LayoutViewFactory.create(
                            description=f"<:jo1ntrx_tick:1405094884947267715> Added {role.mention}!",
                            timestamp=False
                        )
                        await interaction.response.send_message(view=success_view, ephemeral=True)
                except discord.Forbidden:
                    error_view = LayoutViewFactory.create(
                        description="<:jo1ntrx_cross:1405094904568483880> I don't have permission to manage roles for this user!",
                        timestamp=False
                    )
                    await interaction.response.send_message(view=error_view, ephemeral=True)
                except Exception as e:
                    error_view = LayoutViewFactory.create(
                        description=f"<:jo1ntrx_cross:1405094904568483880> An error occurred: {str(e)}",
                        timestamp=False
                    )
                    await interaction.response.send_message(view=error_view, ephemeral=True)
            
            button.callback = button_callback
            self.add_item(button)

class ReactionRoleSelectView(BaseView):
    def __init__(self, panel_db_id, guild_id, db):
        super().__init__(timeout=None)
        self.panel_db_id = panel_db_id
        self.guild_id = guild_id
        self.db = db
        
        # This will be populated when the bot starts
    
    async def setup_select(self):
        """Setup select menu from database options"""
        options = await self.db.get_reaction_role_options(self.panel_db_id)
        
        select_options = []
        for option in options[:24]:  # Max 24 options (leave room for Remove Role option)
            select_options.append(discord.SelectOption(
                label=option['label'] or "Role",
                value=str(option['id']),
                emoji=option['emoji'] if option['emoji'] else None,
                description=option['description'] or "Select to assign this role"
            ))
        
        # Add "Remove Role" option at the end
        select_options.append(discord.SelectOption(
            label="Remove Role",
            value="remove_all",
            emoji="<:Jo1nTrX_No:1408289044470960129>",
            description="Remove all roles from this panel"
        ))
        
        select = discord.ui.Select(
            placeholder="Select a role...",
            options=select_options,
            custom_id=f"rr_select_{self.panel_db_id}"
        )
        
        # Capture variables for the callback closure
        db = self.db
        panel_db_id = self.panel_db_id
        
        async def select_callback(interaction: discord.Interaction):
            try:
                await interaction.response.defer(ephemeral=True)
                
                selected_value = select.values[0]
                
                # Get all options from database
                options = await db.get_reaction_role_options(panel_db_id)
                
                # Check bot permissions
                bot_member = interaction.guild.get_member(interaction.client.user.id)
                if not bot_member.guild_permissions.manage_roles:
                    error_view = LayoutViewFactory.create(
                        description="<:jo1ntrx_cross:1405094904568483880> I don't have permission to manage roles!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=error_view, ephemeral=True)
                    return
                
                # Check if "Remove All" was selected
                if selected_value == "remove_all":
                    # Remove all roles from this panel
                    roles_to_remove = []
                    for opt in options:
                        role = interaction.guild.get_role(opt['role_id'])
                        if role and role in interaction.user.roles:
                            # Check if bot can manage this role
                            if role < bot_member.top_role:
                                roles_to_remove.append(role)
                    
                    if roles_to_remove:
                        await interaction.user.remove_roles(*roles_to_remove)
                        success_view = LayoutViewFactory.create(
                            description=f"<:jo1ntrx_tick:1405094884947267715> Removed all roles from this panel!",
                            timestamp=False
                        )
                        await interaction.followup.send(view=success_view, ephemeral=True)
                    else:
                        info_view = LayoutViewFactory.create(
                            description=f"<:Jo1nTrX_Note:1411930562288943104> You don't have any roles from this panel!",
                            timestamp=False
                        )
                        await interaction.followup.send(view=info_view, ephemeral=True)
                    return
                
                # Normal option selected
                option_id = int(selected_value)
                selected_option = next((opt for opt in options if opt['id'] == option_id), None)
                
                if not selected_option:
                    error_view = LayoutViewFactory.create(
                        description="<:jo1ntrx_cross:1405094904568483880> Option not found!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=error_view, ephemeral=True)
                    return
                
                role = interaction.guild.get_role(selected_option['role_id'])
                if not role:
                    error_view = LayoutViewFactory.create(
                        description="<:jo1ntrx_cross:1405094904568483880> Role not found!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=error_view, ephemeral=True)
                    return
                
                # Check if bot's role is high enough
                if role >= bot_member.top_role:
                    error_view = LayoutViewFactory.create(
                        description=f"<:jo1ntrx_cross:1405094904568483880> I can't manage {role.mention} because it's higher than or equal to my highest role!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=error_view, ephemeral=True)
                    return
                
                # Remove all other roles from this panel first
                roles_to_remove = []
                for other_opt in options:
                    if other_opt['id'] != option_id:
                        other_role = interaction.guild.get_role(other_opt['role_id'])
                        if other_role and other_role in interaction.user.roles:
                            # Only remove if bot can manage this role
                            if other_role < bot_member.top_role:
                                roles_to_remove.append(other_role)
                
                if roles_to_remove:
                    await interaction.user.remove_roles(*roles_to_remove)
                
                # Add the selected role if not already present
                if role not in interaction.user.roles:
                    await interaction.user.add_roles(role)
                    success_view = LayoutViewFactory.create(
                        description=f"<:jo1ntrx_tick:1405094884947267715> Added {role.mention}!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=success_view, ephemeral=True)
                else:
                    info_view = LayoutViewFactory.create(
                        description=f"<:Jo1nTrX_Note:1411930562288943104> You already have {role.mention}!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=info_view, ephemeral=True)
            except discord.Forbidden:
                try:
                    error_view = LayoutViewFactory.create(
                        description="<:jo1ntrx_cross:1405094904568483880> I don't have permission to manage roles for this user!",
                        timestamp=False
                    )
                    await interaction.followup.send(view=error_view, ephemeral=True)
                except:
                    pass
            except Exception as e:
                try:
                    error_view = LayoutViewFactory.create(
                        description=f"<:jo1ntrx_cross:1405094904568483880> An error occurred: {str(e)}",
                        timestamp=False
                    )
                    await interaction.followup.send(view=error_view, ephemeral=True)
                except:
                    pass
        
        select.callback = select_callback
        self.add_item(select)

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload):
        """Handle reaction additions for reaction role panels"""
        if payload.user_id == self.bot.user.id:
            return
        
        # Check if this message is a reaction role panel
        panel = await self.bot.db.get_reaction_role_panel_by_message(payload.message_id)
        if not panel or panel['panel_type'] != 'reaction':
            return
        
        # Get panel options
        options = await self.bot.db.get_reaction_role_options(panel['id'])
        
        # Find the matching option by emoji
        selected_option = None
        for option in options:
            if str(payload.emoji) == option['emoji']:
                selected_option = option
                break
        
        if not selected_option:
            return
        
        # Get guild and member
        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        
        member = guild.get_member(payload.user_id)
        if not member:
            return
        
        # Get the role
        role = guild.get_role(selected_option['role_id'])
        if not role:
            return
        
        # Remove all other roles from this panel first
        roles_to_remove = []
        for other_opt in options:
            if other_opt['id'] != selected_option['id']:
                other_role = guild.get_role(other_opt['role_id'])
                if other_role and other_role in member.roles:
                    roles_to_remove.append(other_role)
        
        if roles_to_remove:
            await member.remove_roles(*roles_to_remove)
        
        # Add the selected role
        if role not in member.roles:
            await member.add_roles(role)
    
    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload):
        """Handle reaction removals for reaction role panels"""
        if payload.user_id == self.bot.user.id:
            return
        
        # Check if this message is a reaction role panel
        panel = await self.bot.db.get_reaction_role_panel_by_message(payload.message_id)
        if not panel or panel['panel_type'] != 'reaction':
            return
        
        # Get panel options
        options = await self.bot.db.get_reaction_role_options(panel['id'])
        
        # Find the matching option by emoji
        selected_option = None
        for option in options:
            if str(payload.emoji) == option['emoji']:
                selected_option = option
                break
        
        if not selected_option:
            return
        
        # Get guild and member
        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        
        member = guild.get_member(payload.user_id)
        if not member:
            return
        
        # Get the role and remove it
        role = guild.get_role(selected_option['role_id'])
        if role and role in member.roles:
            await member.remove_roles(role)

async def setup(bot):
    cog = ReactionRoleConfig(bot)
    await bot.add_cog(cog)

async def setup(bot):
    await bot.add_cog(ReactionRoleConfig(bot))
