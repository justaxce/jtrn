import discord
from discord.ext import commands
from discord import app_commands, ui
from Jo1nTrX.utils.embeds import create_embed
from Jo1nTrX.utils.loading import send_loading_message
import asyncio
import math
import re
import os
import time
from datetime import datetime, timedelta
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)

LOADING = "<a:jo1ntrx_loading:1405094057499295806>"
TICK = "<:Jo1nTrX_Yes:1408288995477159987>"
CROSS = "<:red_cross_Jo1nTrX:1438801479334101012>"
ARROW = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION = "<:jo1ntrx_right:1405095312456024127>"
DOTS = "<a:Jo1nTrX_Dotz:1415025958251003994>"

class ActivityTypeSelect(BaseSelect):
    def __init__(self, parent_view):
        self.parent_view = parent_view
        options = [
            discord.SelectOption(
                label="Playing",
                value="playing",
                description="Set bot activity to Playing",
                emoji=bot_emoji.right
            ),
            discord.SelectOption(
                label="Listening",
                value="listening",
                description="Set bot activity to Listening",
                emoji=bot_emoji.right
            ),
            discord.SelectOption(
                label="Watching",
                value="watching",
                description="Set bot activity to Watching",
                emoji=bot_emoji.right
            ),
            discord.SelectOption(
                label="Competing",
                value="competing",
                description="Set bot activity to Competing in",
                emoji=bot_emoji.right
            ),
            discord.SelectOption(
                label="Clear Activity",
                value="clear",
                description="Clear bot activity",
                emoji=bot_emoji.right
            ),
        ]
        super().__init__(placeholder="Select activity type...", options=options, min_values=1, max_values=1)
    
    async def callback(self, interaction: discord.Interaction):
        selected_type = self.values[0]
        
        if selected_type == "clear":
            self.parent_view.current_activity_type = None
            self.parent_view.current_activity = ""
            content = f"""## {TICK} Activity Cleared
> Bot activity has been cleared. Click **Save Activity** to apply!"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await interaction.response.send_message(view=view, ephemeral=True)
        else:
            modal = ActivityValueModal(self.parent_view, selected_type)
            await interaction.response.send_modal(modal)

class ActivityValueModal(discord.ui.Modal, title='Enter Activity Value'):
    def __init__(self, parent_view, activity_type):
        super().__init__()
        self.parent_view = parent_view
        self.activity_type = activity_type
        
        type_display = activity_type.capitalize()
        placeholder_text = 'e.g., {member.count} users' if activity_type == "watching" else "Enter activity text"
        self.activity_value = discord.ui.TextInput(
            label=f'{type_display} Activity Value',
            placeholder=placeholder_text,
            required=True,
            max_length=128
        )
        self.add_item(self.activity_value)
    
    async def on_submit(self, interaction: discord.Interaction):
        self.parent_view.current_activity_type = self.activity_type
        self.parent_view.current_activity = self.activity_value.value
        
        content = f"""## {TICK} Activity Value Set
> Configuration updated successfully

{SECTION} **__Details__**
{ARROW} **Type:** {self.activity_type.capitalize()}
{ARROW} **Value:** `{self.activity_value.value}`

Click **Save Activity** to apply!"""
        view = ui.LayoutView(timeout=300)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        await interaction.response.send_message(view=view, ephemeral=True)
class ActivityManagementView(BaseView):
    def __init__(self, bot, author=None):
        super().__init__(timeout=300, author=author)
        self.bot = bot
        self.current_activity_type = None
        self.current_activity = ""
        self.current_presence_status = "online"
        self.add_item(ActivityTypeSelect(self))
        self.variables = {
            '{member.count}': 'Total members across all servers',
            '{guild.count}': 'Total servers bot is in',
            '{bot.name}': "Bot's display name",
            '{bot.id}': "Bot's user ID",
            '{bot.ping}': "Bot latency in ms",
            '{uptime}': "Bot uptime duration",
            '{timestamp}': "Current time (HH:MM)",
        }
    
    def replace_variables(self, text):
        """Replace variables in text with actual values"""
        if not text:
            return text
        
        total_members = sum(guild.member_count for guild in self.bot.guilds if guild.member_count)
        guild_count = len(self.bot.guilds)
        bot_ping = round(self.bot.latency * 1000)
        
        if hasattr(self.bot, 'start_time') and isinstance(self.bot.start_time, datetime):
            from datetime import timezone
            uptime_delta = datetime.now(timezone.utc) - self.bot.start_time
            hours = uptime_delta.seconds // 3600
            minutes = (uptime_delta.seconds % 3600) // 60
            uptime_str = f"{uptime_delta.days}d {hours}h {minutes}m" if uptime_delta.days > 0 else f"{hours}h {minutes}m"
        else:
            uptime_str = "calculating..."
        
        current_time = datetime.now().strftime('%H:%M')
        
        replacements = {
            '{member.count}': str(total_members),
            '{guild.count}': str(guild_count),
            '{bot.name}': self.bot.user.display_name,
            '{bot.id}': str(self.bot.user.id),
            '{bot.ping}': str(bot_ping),
            '{uptime}': uptime_str,
            '{timestamp}': current_time
        }
        
        for var, value in replacements.items():
            text = text.replace(var, value)
        
        return text
    
    def get_current_status_content(self):
        """Create content showing current bot status and activity"""
        activity = self.bot.activity
        status = self.bot.status
        
        activity_text = "None"
        activity_type_text = "None"
        if activity and hasattr(activity, 'name'):
            activity_text = activity.name
            if activity.type == discord.ActivityType.playing:
                activity_type_text = "Playing"
            elif activity.type == discord.ActivityType.listening:
                activity_type_text = "Listening"
            elif activity.type == discord.ActivityType.watching:
                activity_type_text = "Watching"
            elif activity.type == discord.ActivityType.competing:
                activity_type_text = "Competing"
        
        content = f"""## {TICK} Bot Activity & Presence Manager
> Configure bot activity (Playing/Listening/Watching/Competing) with variables and presence status

{SECTION} **__Current Activity__**
{ARROW} **Type:** {activity_type_text}
{ARROW} **Value:** `{activity_text}`

{SECTION} **__Presence Status__**
{ARROW} **Status:** {status.name.title()}

{SECTION} **__Live Stats__**
{ARROW} **Members:** {sum(guild.member_count for guild in self.bot.guilds)}
{ARROW} **Servers:** {len(self.bot.guilds)}"""
        
        return content
    
    @discord.ui.button(label="Set Presence", style=discord.ButtonStyle.primary)
    async def set_presence(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = PresenceStatusModal(self)
        await interaction.response.send_modal(modal)
    
    
    @discord.ui.button(label="Save Activity", style=discord.ButtonStyle.success)
    async def save_activity(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        
        try:
            activity_type_map = {
                'playing': discord.ActivityType.playing,
                'listening': discord.ActivityType.listening,
                'watching': discord.ActivityType.watching,
                'competing': discord.ActivityType.competing,
            }
            
            activity = None
            if self.current_activity_type and self.current_activity:
                processed = self.replace_variables(self.current_activity)
                activity_discord_type = activity_type_map.get(self.current_activity_type, discord.ActivityType.watching)
                activity = discord.Activity(type=activity_discord_type, name=processed)
            
            status_map = {
                'online': discord.Status.online,
                'idle': discord.Status.idle,
                'dnd': discord.Status.dnd,
                'invisible': discord.Status.invisible
            }
            presence_status = status_map.get(self.current_presence_status.lower(), discord.Status.online)
            
            # Apply presence - only if we have an activity to show
            # If no activity is set, keep the current presence (don't clear it to avoid showing profile)
            if activity:
                await self.bot.change_presence(activity=activity, status=presence_status)
            
            # Still save the settings for next restart
            await self.bot.db.save_bot_activity(self.current_activity or "", "", self.current_presence_status, self.current_activity_type or "watching")
            
            content = self.get_current_status_content()
            content += f"\n\n{TICK} **Changes Applied!** Bot activity has been updated!"
            
            success_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            success_view.add_item(container)
            
            await interaction.edit_original_response(embed=None, view=success_view)
        except Exception as e:
            content = f"""## {CROSS} Failed to Apply
> An error occurred while applying settings

{SECTION} **__Error__**
{ARROW} {str(e)}"""
            error_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            error_view.add_item(container)
            await interaction.edit_original_response(embed=None, view=error_view)

class PresenceStatusModal(discord.ui.Modal, title='Set Presence Status'):
    def __init__(self, parent_view):
        super().__init__()
        self.parent_view = parent_view
        
        self.presence_text = discord.ui.TextInput(
            label='Presence Status',
            placeholder='online, idle, dnd, invisible',
            required=True,
            max_length=20
        )
        self.add_item(self.presence_text)
    
    async def on_submit(self, interaction: discord.Interaction):
        valid = ['online', 'idle', 'dnd', 'invisible']
        if self.presence_text.value.lower() not in valid:
            content = f"""## {CROSS} Error
> Invalid presence status provided

{SECTION} **__Valid Options__**
{ARROW} {', '.join(valid)}"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await interaction.response.send_message(view=view, ephemeral=True)
            return
        
        self.parent_view.current_presence_status = self.presence_text.value.lower()
        content = f"""## {TICK} Presence Status Set
> Configuration updated successfully

{SECTION} **__Status__**
{ARROW} **Status:** {self.presence_text.value}

Click **Save Activity** to apply!"""
        view = ui.LayoutView(timeout=300)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        await interaction.response.send_message(view=view, ephemeral=True)

class PremiumListPaginationView(BaseView):
    def __init__(self, premium_data, current_page, total_pages, create_embed_func, author, bot):
        super().__init__(timeout=300, author=author)
        self.premium_data = premium_data
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_embed = create_embed_func
        self.author = author
        self.bot = bot
        
        # Update button states
        self.update_button_states()

    def update_button_states(self):
        """Update button disabled states based on current page"""
        # First page and previous page buttons
        self.first_page.disabled = self.current_page == 0
        self.previous_page.disabled = self.current_page == 0
        
        # Last page and next page buttons  
        self.next_page.disabled = self.current_page == self.total_pages - 1
        self.last_page.disabled = self.current_page == self.total_pages - 1

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message(
                "You cannot interact with this menu.", 
                ephemeral=True
            )
            return False
        return True

    @discord.ui.button(emoji=bot_emoji.double_left, style=discord.ButtonStyle.gray, row=0)
    async def first_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to first page"""
        self.current_page = 0
        self.update_button_states()
        embed = await self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.left, style=discord.ButtonStyle.gray, row=0)
    async def previous_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to previous page"""
        self.current_page -= 1
        self.update_button_states()
        embed = await self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.delete, style=discord.ButtonStyle.red, row=0)
    async def delete_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Delete the premium list message"""
        await interaction.response.edit_message(content="Premium list deleted.", embed=None, view=None)

    @discord.ui.button(emoji=bot_emoji.right, style=discord.ButtonStyle.gray, row=0)
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to next page"""
        self.current_page += 1
        self.update_button_states()
        embed = await self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.double_right, style=discord.ButtonStyle.gray, row=0)
    async def last_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to last page"""
        self.current_page = self.total_pages - 1
        self.update_button_states()
        embed = await self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    async def on_timeout(self):
        """Disable all buttons when the view times out"""
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True

class ServerListPaginationView(BaseView):
    def __init__(self, servers_data, current_page, total_pages, create_embed_func, author):
        super().__init__(timeout=300, author=author)
        self.servers_data = servers_data
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_embed = create_embed_func
        self.author = author
        
        # Update button states
        self.update_button_states()

    def update_button_states(self):
        """Update button disabled states based on current page"""
        # First page and previous page buttons
        self.first_page.disabled = self.current_page == 0
        self.previous_page.disabled = self.current_page == 0
        
        # Last page and next page buttons  
        self.next_page.disabled = self.current_page == self.total_pages - 1
        self.last_page.disabled = self.current_page == self.total_pages - 1

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message(
                "You cannot interact with this menu.", 
                ephemeral=True
            )
            return False
        return True

    @discord.ui.button(emoji=bot_emoji.double_left, style=discord.ButtonStyle.gray, row=0)
    async def first_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to first page"""
        self.current_page = 0
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.left, style=discord.ButtonStyle.gray, row=0)
    async def previous_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to previous page"""
        self.current_page -= 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.delete, style=discord.ButtonStyle.red, row=0)
    async def delete_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Delete the serverlist message"""
        await interaction.response.edit_message(content="Serverlist deleted.", embed=None, view=None)

    @discord.ui.button(emoji=bot_emoji.right, style=discord.ButtonStyle.gray, row=0)
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to next page"""
        self.current_page += 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.double_right, style=discord.ButtonStyle.gray, row=0)
    async def last_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to last page"""
        self.current_page = self.total_pages - 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    async def on_timeout(self):
        # Disable all buttons when timeout occurs
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True

class ServerListPaginationViewV2(ui.LayoutView):
    """Component V2 compatible pagination view for server list"""
    def __init__(self, servers_data, current_page, total_pages, create_content_func, author):
        super().__init__(timeout=300)
        self.servers_data = servers_data
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_content = create_content_func
        self.author = author
        self._setup_view()

    def _setup_view(self):
        """Setup the view with content and buttons"""
        content = self.create_content(self.current_page)
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = ServerListPaginationViewV2(self.servers_data, 0, self.total_pages, self.create_content, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = ServerListPaginationViewV2(self.servers_data, max(0, self.current_page - 1), self.total_pages, self.create_content, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = ServerListPaginationViewV2(self.servers_data, min(self.total_pages - 1, self.current_page + 1), self.total_pages, self.create_content, self.author)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_view = ServerListPaginationViewV2(self.servers_data, self.total_pages - 1, self.total_pages, self.create_content, self.author)
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)

class PremiumListPaginationViewV2(ui.LayoutView):
    """Component V2 compatible pagination view for premium list"""
    def __init__(self, premium_data, current_page, total_pages, create_content_func, author, bot, initial_content=None):
        super().__init__(timeout=300)
        self.premium_data = premium_data
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_content = create_content_func
        self.author = author
        self.bot = bot
        self.initial_content = initial_content
        self._setup_view()

    def _setup_view(self):
        """Setup the view with content and buttons"""
        if self.initial_content:
            content = self.initial_content
        else:
            content = ""
        text_display = ui.TextDisplay(content)
        
        first_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleleft:1405095487710691449>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_left:1405095378231099464>'), style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_delete:1405095625795702895>'), style=discord.ButtonStyle.danger)
        next_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_right:1405095312456024127>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=discord.PartialEmoji.from_str('<:jo1ntrx_doubleright:1405095454395465790>'), style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        
        async def first_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            content = await self.create_content(0)
            new_view = PremiumListPaginationViewV2(self.premium_data, 0, self.total_pages, self.create_content, self.author, self.bot, content)
            await interaction.response.edit_message(view=new_view)
        
        async def prev_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_page = max(0, self.current_page - 1)
            content = await self.create_content(new_page)
            new_view = PremiumListPaginationViewV2(self.premium_data, new_page, self.total_pages, self.create_content, self.author, self.bot, content)
            await interaction.response.edit_message(view=new_view)
        
        async def delete_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            await interaction.message.delete()
        
        async def next_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            new_page = min(self.total_pages - 1, self.current_page + 1)
            content = await self.create_content(new_page)
            new_view = PremiumListPaginationViewV2(self.premium_data, new_page, self.total_pages, self.create_content, self.author, self.bot, content)
            await interaction.response.edit_message(view=new_view)
        
        async def last_callback(interaction: discord.Interaction):
            if interaction.user != self.author:
                return await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
            content = await self.create_content(self.total_pages - 1)
            new_view = PremiumListPaginationViewV2(self.premium_data, self.total_pages - 1, self.total_pages, self.create_content, self.author, self.bot, content)
            await interaction.response.edit_message(view=new_view)
        
        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback
        
        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)

class OwnerCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
    async def cog_check(self, ctx):
        """Check if the user is the bot owner"""
        if ctx.author.id not in self.bot.config.BOT_OWNER_IDS:
            content = f"""## {CROSS} Access Denied
> You're Not Allowed To Use This Command! Only Main Bot Owner Can Use It."""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await ctx.send(view=view)
            return False
        return True
    
    @commands.command(name='forcesync', hidden=True)
    async def force_sync(self, ctx):
        """Force sync all slash commands with proper parameters (Owner Only)"""
        # Create animated loading message using component v2
        loading_content = f"""## {LOADING} Force Syncing Commands
> Scanning entire bot for commands..."""
        loading_view = ui.LayoutView(timeout=300)
        loading_display = ui.TextDisplay(loading_content)
        loading_container = ui.Container(loading_display)
        loading_view.add_item(loading_container)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            # Count commands before sync
            commands_before = len(self.bot.tree.get_commands())
            
            # Update loading message
            loading_content = f"""## {LOADING} Force Syncing Commands
> Syncing commands to Discord..."""
            loading_view2 = ui.LayoutView(timeout=300)
            loading_display2 = ui.TextDisplay(loading_content)
            loading_container2 = ui.Container(loading_display2)
            loading_view2.add_item(loading_container2)
            await loading_msg.edit(view=loading_view2)
            
            # Force sync commands
            synced = await self.bot.tree.sync()
            commands_after = len(synced)
            
            # Update loading message
            loading_content = f"""## {LOADING} Force Syncing Commands
> Gathering sync statistics..."""
            loading_view3 = ui.LayoutView(timeout=300)
            loading_display3 = ui.TextDisplay(loading_content)
            loading_container3 = ui.Container(loading_display3)
            loading_view3.add_item(loading_container3)
            await loading_msg.edit(view=loading_view3)
            
            # Wait a moment for effect
            await asyncio.sleep(1)
            
            cog_info = []
            for cog_name, cog in self.bot.cogs.items():
                command_count = len([cmd for cmd in cog.get_commands()])
                if command_count > 0:
                    cog_info.append(f"{ARROW} **{cog_name}:** {command_count} commands")
            
            cog_info_str = "\n".join(cog_info[:8]) if cog_info else f"{ARROW} No cogs loaded"
            
            content = f"""## {TICK} Force Sync Complete
> Successfully scanned and synced all commands!

{SECTION} **__Sync Statistics__**
{ARROW} **Commands Synced:** {commands_after}
{ARROW} **Cogs Loaded:** {len(self.bot.cogs)}
{ARROW} **Guilds Connected:** {len(self.bot.guilds)}
{ARROW} **Total Members:** {sum(guild.member_count for guild in self.bot.guilds if guild.member_count)}

{SECTION} **__Command Categories__**
{cog_info_str}

{SECTION} **__Notice__**
{ARROW} All slash commands now have proper parameters and descriptions!"""
            
            success_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            success_view.add_item(container)
            
            await loading_msg.edit(embed=None, view=success_view)
            
        except Exception as e:
            content = f"""## {CROSS} Sync Failed
> Failed to sync commands

{SECTION} **__Error__**
{ARROW} {str(e)}"""
            error_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            error_view.add_item(container)
            await loading_msg.edit(embed=None, view=error_view)
    
    @commands.command(name='activity', hidden=True)
    async def activity_manager(self, ctx):
        """Manage bot presence and custom status with variables (Owner Only)"""
        view = ActivityManagementView(self.bot, author=ctx.author)
        
        # Load saved settings from database
        saved_data = await self.bot.db.get_bot_activity()
        if saved_data:
            view.current_activity = saved_data.get('activity_text') or ""
            view.current_activity_type = saved_data.get('activity_type') or "watching"
            view.current_presence_status = saved_data.get('status') or "online"
        
        content = view.get_current_status_content()
        embed = discord.Embed(description=content, color=discord.Color.blurple())
        await ctx.send(embed=embed, view=view)
    
    @commands.command(name='serverlist', hidden=True)
    async def serverlist(self, ctx):
        """List all servers the bot is in with pagination (Owner Only)"""
        # Send loading message using component v2
        loading_content = f"""## {LOADING} Loading Server List
> Fetching server information and generating invite links..."""
        loading_view = ui.LayoutView(timeout=300)
        loading_display = ui.TextDisplay(loading_content)
        loading_container = ui.Container(loading_display)
        loading_view.add_item(loading_container)
        loading_msg = await ctx.send(view=loading_view)
        
        guilds = self.bot.guilds
        
        if not guilds:
            content = f"""## {CROSS} Server List
> The bot is not in any servers."""
            empty_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            empty_view.add_item(container)
            await loading_msg.edit(view=empty_view)
            return
        
        # Prepare server data
        servers_data = []
        for guild in guilds:
            try:
                # Try to get an invite link
                invite_link = None
                if guild.text_channels:
                    # Find a channel the bot can create invites in
                    for channel in guild.text_channels:
                        if channel.permissions_for(guild.me).create_instant_invite:
                            try:
                                invite = await channel.create_invite(
                                    max_age=0,  # Never expires
                                    max_uses=0,  # Unlimited uses
                                    unique=False
                                )
                                invite_link = invite.url
                                break
                            except discord.Forbidden:
                                continue
                            except Exception:
                                continue
                
                servers_data.append({
                    'name': guild.name,
                    'id': guild.id,
                    'invite': invite_link,
                    'member_count': guild.member_count
                })
            except Exception as e:
                # If there's an error getting server info, still add basic data
                servers_data.append({
                    'name': guild.name,
                    'id': guild.id,
                    'invite': None,
                    'member_count': getattr(guild, 'member_count', 'Unknown')
                })
        
        # Sort servers by member count from highest to lowest
        servers_data.sort(key=lambda x: x['member_count'] if isinstance(x['member_count'], int) else 0, reverse=True)
        
        # Setup pagination - 10 servers per page
        servers_per_page = 10
        
        # Setup pagination with custom view
        total_pages = math.ceil(len(servers_data) / servers_per_page)
        current_page = 0
        
        def create_server_content(page):
            start_index = page * servers_per_page
            end_index = start_index + servers_per_page
            page_servers = servers_data[start_index:end_index]
            
            content = f"""## {TICK} Server List
> Showing servers {start_index + 1}-{min(end_index, len(servers_data))} of {len(servers_data)}

"""
            for i, server in enumerate(page_servers):
                global_rank = start_index + i + 1
                
                # Format server name with invite link if available
                if server['invite']:
                    server_name_display = f"**[{server['name']}]({server['invite']})**"
                else:
                    server_name_display = f"**{server['name']}**"
                
                content += f"{SECTION} **__{global_rank}. {server_name_display}__**\n"
                content += f"{ARROW} **ID:** `{server['id']}`\n"
                content += f"{ARROW} **Members:** {server['member_count']}\n\n"
            
            content += f"*Page {page + 1} of {total_pages} | Total servers: {len(servers_data)}*"
            return content
        
        # Create the pagination view (handles its own layout)
        view = ServerListPaginationViewV2(servers_data, current_page, total_pages, create_server_content, ctx.author)
        await loading_msg.edit(view=view)
    
    def parse_time_duration(self, time_str):
        """Parse time duration string like '30d', '2h', '6m' into datetime"""
        from datetime import timezone
        pattern = r'^(\d+)([hdm])$'
        match = re.match(pattern, time_str.lower())
        
        if not match:
            return None
        
        amount = int(match.group(1))
        unit = match.group(2)
        
        now = datetime.now(timezone.utc)
        
        if unit == 'h':
            return now + timedelta(hours=amount)
        elif unit == 'd':
            return now + timedelta(days=amount)
        elif unit == 'm':
            return now + timedelta(days=amount * 30)  # Approximate month
        
        return None
    
    @commands.group(name='prem', hidden=True, invoke_without_command=True)
    async def premium_management(self, ctx):
        """Premium user management commands (Owner Only)"""
        content = f"""## {TICK} Premium Management
> Available premium management commands

{SECTION} **__Commands__**
{ARROW} `+prem add @user <time> <global/guild>` - Add premium access
{ARROW} `+prem remove @user` - Remove premium access
{ARROW} `+prem list` - List all premium users

{SECTION} **__Time Formats__**
{ARROW} `30d` - 30 days
{ARROW} `24h` - 24 hours
{ARROW} `6m` - 6 months"""
        view = ui.LayoutView(timeout=300)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        await ctx.send(view=view)
    
    @premium_management.command(name='add')
    async def add_premium(self, ctx, user: discord.User, duration: str, scope: str):
        """Add premium access to a user"""
        if scope.lower() not in ['global', 'guild']:
            content = f"""## {CROSS} Invalid Scope
> Invalid scope provided

{SECTION} **__Valid Options__**
{ARROW} `global` - Works in all servers
{ARROW} `guild` - Works only in specific server"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await ctx.send(view=view)
            return
        
        expiry_date = self.parse_time_duration(duration)
        if not expiry_date:
            content = f"""## {CROSS} Invalid Time Format
> Invalid time format provided

{SECTION} **__Valid Formats__**
{ARROW} `30d` - 30 days
{ARROW} `24h` - 24 hours
{ARROW} `6m` - 6 months"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await ctx.send(view=view)
            return
        
        guild_id = ctx.guild.id if scope.lower() == 'guild' else None
        
        try:
            # Add premium access
            success = await self.bot.db.add_premium_user(
                user.id, 
                scope.lower(), 
                expiry_date, 
                ctx.author.id,
                guild_id
            )
            
            if success:
                # Send DM to user
                try:
                    # Calculate time remaining from now to expiry
                    from datetime import timezone
                    time_remaining = expiry_date - datetime.now(timezone.utc)
                    days = time_remaining.days
                    hours, remainder = divmod(time_remaining.seconds, 3600)
                    
                    if days > 0:
                        time_text = f"{days} day{'s' if days != 1 else ''}"
                        if hours > 0:
                            time_text += f" and {hours} hour{'s' if hours != 1 else ''}"
                    elif hours > 0:
                        time_text = f"{hours} hour{'s' if hours != 1 else ''}"
                    else:
                        time_text = "Less than 1 hour"
                    
                    dm_embed = EmbedFactory.create(
                        title="You've Got The Jo1nTrX Premium Access <:Jo1nTrX_premium:1413365658187731075>",
                        description=f"<:Jo1nTrX_love:1413366391905587230> **Thanks {user.display_name} for buying our premium!**\n\n"
                                   f"**Now enjoy your premium privileges like**:\n"
                                   f"➛ __No Prefix Command Use__\n"
                                   f"➛ __Steal Upto 20 Emojis At once__\n"
                                   f"➛ __Special Command Access__\n\n"
                                   f"**Time** : {time_text}\n\n"
                                   f"<:jo1ntrx_right:1405095312456024127> **Use `+phelp` for premium section help menu**\n\n"
                                   f"<:Jo1nTrX_link:1415182665912418409> **Join Our [Support Server](https://discord.gg/PA6UhChxZY) for more info! **",
                        color=0x00FF00
                    )
                    dm_embed.set_thumbnail(url=user.avatar.url if user.avatar else user.default_avatar.url)
                    dm_embed.set_footer(text="Congratulations For Having Bot's premium Access!")
                    await user.send(embed=dm_embed)
                except:
                    pass  # User might have DMs disabled
                
                content = f"""## {TICK} Premium Access Added
> Successfully added premium access

{SECTION} **__Details__**
{ARROW} **User:** {user.mention}
{ARROW} **Scope:** {scope.upper()}
{ARROW} **Expires:** <t:{int(expiry_date.timestamp())}:F>"""
                success_view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                success_view.add_item(container)
                await ctx.send(view=success_view)
            else:
                content = f"""## {CROSS} Database Error
> Failed to add premium access. Please try again."""
                error_view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                error_view.add_item(container)
                await ctx.send(view=error_view)
        except Exception as e:
            content = f"""## {CROSS} Error
> An error occurred

{SECTION} **__Details__**
{ARROW} {str(e)}"""
            error_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            error_view.add_item(container)
            await ctx.send(view=error_view)
    
    @premium_management.command(name='remove')
    async def remove_premium(self, ctx, user: discord.User):
        """Remove premium access from a user"""
        try:
            # Remove premium access
            success = await self.bot.db.remove_premium_user(user.id)
            
            if success:
                # Send DM to user
                try:
                    dm_embed = EmbedFactory.create(
                        title="❌ Premium Access Removed",
                        description=f"Your premium access has been removed.\n"
                                   f"**Removed by:** {ctx.author.mention}\n\n"
                                   f"Thank you for using our premium features!",
                        color=0xFF0000
                    )
                    await user.send(embed=dm_embed)
                except:
                    pass  # User might have DMs disabled
                
                content = f"""## {TICK} Premium Access Removed
> Successfully removed premium access for {user.mention}"""
                success_view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                success_view.add_item(container)
                await ctx.send(view=success_view)
            else:
                content = f"""## {CROSS} No Premium Access Found
> {user.mention} doesn't have premium access or it's already expired."""
                error_view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                error_view.add_item(container)
                await ctx.send(view=error_view)
        except Exception as e:
            content = f"""## {CROSS} Error
> An error occurred

{SECTION} **__Details__**
{ARROW} {str(e)}"""
            error_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            error_view.add_item(container)
            await ctx.send(view=error_view)
    
    @premium_management.command(name='list')
    async def list_premium(self, ctx):
        """List all premium users with pagination"""
        # Send loading message using component v2
        loading_content = f"""## {LOADING} Loading Premium Users
> Fetching premium user information..."""
        loading_view = ui.LayoutView(timeout=300)
        loading_display = ui.TextDisplay(loading_content)
        loading_container = ui.Container(loading_display)
        loading_view.add_item(loading_container)
        loading_msg = await ctx.send(view=loading_view)
        
        try:
            premium_users = await self.bot.db.list_premium_users()
            
            if not premium_users:
                content = f"""## {CROSS} Premium Users
> No active premium users found."""
                empty_view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                empty_view.add_item(container)
                await loading_msg.edit(view=empty_view)
                return
            
            # Setup pagination - 5 users per page  
            users_per_page = 5
            total_pages = math.ceil(len(premium_users) / users_per_page)
            current_page = 0
            
            async def create_premium_content(page):
                start_index = page * users_per_page
                end_index = start_index + users_per_page
                page_users = premium_users[start_index:end_index]
                
                content = f"""## {TICK} Premium Users List
> Showing users {start_index + 1}-{min(end_index, len(premium_users))} of {len(premium_users)}

"""
                
                for i, user_data in enumerate(page_users):
                    user_id, guild_id, premium_type, expiry_date, granted_by, granted_at = user_data
                    global_rank = start_index + i + 1
                    
                    try:
                        user = await self.bot.fetch_user(user_id)
                        user_display = f"{user.display_name} ( [{user_id}](https://discord.com/users/{user_id}) )"
                    except:
                        user_display = f"Unknown User ( [{user_id}](https://discord.com/users/{user_id}) )"
                    
                    scope_text = "Global" if premium_type == 'global' else f"Guild: {guild_id}"
                    from datetime import timezone
                    # Make expiry_date timezone-aware if it's naive
                    if expiry_date.tzinfo is None:
                        expiry_date = expiry_date.replace(tzinfo=timezone.utc)
                    # Make granted_at timezone-aware if it's naive
                    if granted_at.tzinfo is None:
                        granted_at = granted_at.replace(tzinfo=timezone.utc)
                    time_left = expiry_date - datetime.now(timezone.utc)
                    days_left = time_left.days
                    
                    content += f"{SECTION} **__{global_rank}. {user_display}__**\n"
                    content += f"{ARROW} **Type:** {premium_type.title()}\n"
                    content += f"{ARROW} **Scope:** {scope_text}\n"
                    content += f"{ARROW} **Expires:** <t:{int(expiry_date.timestamp())}:R> ({days_left} days left)\n"
                    content += f"{ARROW} **Granted:** <t:{int(granted_at.timestamp())}:d>\n\n"
                
                content += f"*Page {page + 1} of {total_pages} | Total premium users: {len(premium_users)}*"
                return content
            
            # Create initial content
            initial_content = await create_premium_content(current_page)
            
            # Create the pagination view (handles its own layout)
            view = PremiumListPaginationViewV2(premium_users, current_page, total_pages, create_premium_content, ctx.author, self.bot, initial_content)
            await loading_msg.edit(view=view)
            
        except Exception as e:
            content = f"""## {CROSS} Error
> An error occurred

{SECTION} **__Details__**
{ARROW} {str(e)}"""
            error_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            error_view.add_item(container)
            await loading_msg.edit(embed=None, view=error_view)
    
    @commands.command(name='cleanup_owner_premium', hidden=True)
    async def cleanup_owner_premium(self, ctx):
        """Remove duplicate bot owner premium entries and keep only one (Owner Only)"""
        bot_owner_id = self.bot.config.BOT_OWNER_IDS[0]
        
        try:
            # First, check current entries
            current_entries = await self.bot.db.list_premium_users()
            owner_entries = [entry for entry in current_entries if entry[0] == bot_owner_id]
            
            content = f"""## {LOADING} Premium Cleanup Started
> Scanning for duplicate entries

{SECTION} **__Status__**
{ARROW} Found {len(owner_entries)} premium entries for bot owner
{ARROW} Proceeding with cleanup..."""
            start_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            start_view.add_item(container)
            await ctx.send(view=start_view)
            
            if len(owner_entries) <= 1:
                content = f"""## {TICK} No Cleanup Needed
> Bot owner has 1 or fewer premium entries. No duplicates to remove."""
                done_view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                done_view.add_item(container)
                await ctx.send(view=done_view)
                return
            
            # Remove all owner entries
            cursor = self.bot.db.get_cursor()
            cursor.execute('DELETE FROM premium_users WHERE user_id = %s', (bot_owner_id,))
            deleted_count = cursor.rowcount
            self.bot.db.connection.commit()
            cursor.close()
            
            # Add back one permanent entry
            from datetime import timezone
            permanent_expiry = datetime.now(timezone.utc) + timedelta(days=365 * 10)
            
            await self.bot.db.add_premium_user(
                bot_owner_id,
                'global',
                permanent_expiry,
                bot_owner_id  # Self-granted
            )
            
            content = f"""## {TICK} Premium Cleanup Complete
> Cleanup completed successfully

{SECTION} **__Results__**
{ARROW} **Removed:** {deleted_count} duplicate entries
{ARROW} **Added:** 1 clean premium entry
{ARROW} **Result:** Bot owner now has exactly 1 premium entry"""
            complete_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            complete_view.add_item(container)
            await ctx.send(view=complete_view)
            
        except Exception as e:
            content = f"""## {CROSS} Cleanup Failed
> Error during cleanup

{SECTION} **__Details__**
{ARROW} {str(e)}"""
            error_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            error_view.add_item(container)
            await ctx.send(view=error_view)
    
    @commands.command(name='ohelp', hidden=True)
    async def owner_help(self, ctx):
        """Owner-only help command"""
        content = f"""## {TICK} Owner Commands Help
> Special commands available only to the bot owner

{SECTION} **__Bot Management__**
{ARROW} `activity` - Manage bot activity and status
{ARROW} `serverlist` - List all servers the bot is in
{ARROW} `status` - Show bot status information

{SECTION} **__Premium Management__**
{ARROW} `prem add @user <time> <global/guild>` - Add premium access
{ARROW} `prem remove @user` - Remove premium access
{ARROW} `prem list` - List all premium users

{SECTION} **__Time Formats__**
{ARROW} `30d` - 30 days
{ARROW} `24h` - 24 hours
{ARROW} `6m` - 6 months

{SECTION} **__Premium Features__**
{ARROW} No-prefix commands - Use any command without prefix
{ARROW} Global scope - Works in all servers
{ARROW} Guild scope - Works only in specific server
{ARROW} DM notifications - Users get notified about status changes

*These commands are restricted to bot owner only*"""
        view = ui.LayoutView(timeout=300)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        await ctx.send(view=view)

    @commands.command(name='status', aliases=['stats'])
    async def status_command(self, ctx):
        """Show bot status information"""
        # Create animated loading message using component v2
        loading_content = f"""## {LOADING} Getting Bot's Current Status
> Fetching bot statistics..."""
        loading_view = ui.LayoutView(timeout=300)
        loading_display = ui.TextDisplay(loading_content)
        loading_container = ui.Container(loading_display)
        loading_view.add_item(loading_container)
        loading_msg = await ctx.send(view=loading_view)
        
        # Calculate uptime using the same method as uptime command
        if hasattr(self.bot, 'start_time') and self.bot.start_time:
            if isinstance(self.bot.start_time, datetime):
                from datetime import timezone
                uptime_delta = datetime.now(timezone.utc) - self.bot.start_time
                uptime_seconds = int(uptime_delta.total_seconds())
            else:
                # start_time is a float (unix timestamp)
                current_time = time.time()
                uptime_seconds = int(current_time - self.bot.start_time)
        else:
            # Fallback to current time if start_time is not set
            uptime_seconds = 0
            # Log the issue for debugging
            print("Warning: bot.start_time not found, uptime will show 0")
        
        # Format uptime using the same method as uptime command
        days = uptime_seconds // 86400
        hours = (uptime_seconds % 86400) // 3600
        minutes = (uptime_seconds % 3600) // 60
        seconds = uptime_seconds % 60
        
        if days > 0:
            uptime_str = f"{days}d {hours}h {minutes}m {seconds}s"
        elif hours > 0:
            uptime_str = f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            uptime_str = f"{minutes}m {seconds}s"
        else:
            uptime_str = f"{seconds}s"
        
        # Get comprehensive bot stats
        total_users = sum(guild.member_count for guild in self.bot.guilds)
        total_guilds = len(self.bot.guilds)
        latency = round(self.bot.latency * 1000, 2)  # Convert to ms
        
        # Get detailed statistics
        total_text_channels = sum(len([c for c in guild.text_channels]) for guild in self.bot.guilds)
        total_voice_channels = sum(len([c for c in guild.voice_channels]) for guild in self.bot.guilds)
        total_categories = sum(len([c for c in guild.categories]) for guild in self.bot.guilds)
        total_roles = sum(len(guild.roles) for guild in self.bot.guilds)
        total_emojis = sum(len(guild.emojis) for guild in self.bot.guilds)
        
        # Memory and system stats
        import psutil
        import platform
        import sys
        
        # Memory usage
        process = psutil.Process()
        memory_usage = process.memory_info().rss / 1024 / 1024  # Convert to MB
        cpu_usage = process.cpu_percent()
        
        # System info
        python_version = platform.python_version()
        system_platform = platform.system()
        
        # Command statistics
        total_commands = len(self.bot.commands)
        total_slash_commands = len([cmd for cmd in self.bot.tree.get_commands()])
        
        # Cached entities
        cached_users = len(self.bot.users)
        cached_messages = getattr(self.bot, '_connection', {}).max_messages or 0
        
        content = f"""## <:Jo1nTrX_status:1418436869846339760> Jo1nTrX Status
> Current bot statistics and information

{SECTION} **__📊 Statistics__**
{ARROW} **User Count:** {total_users:,}
{ARROW} **Guild Count:** {total_guilds:,}
{ARROW} **Latency:** {latency}ms
{ARROW} **Uptime:** {uptime_str}"""
        
        status_view = ui.LayoutView(timeout=300)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        status_view.add_item(container)
        
        if loading_msg:
            await loading_msg.edit(embed=None, view=status_view)
        else:
            await ctx.send(view=status_view)

    @commands.command(name='leave', hidden=True)
    async def leave_guild(self, ctx, guild_id: int = None):
        """Leave a server with confirmation (Owner Only)"""
        # If no guild_id provided, use current guild
        if guild_id is None:
            guild = ctx.guild
            if not guild:
                content = f"""## {CROSS} No Guild Specified
> This command must be used in a server or you must provide a guild ID."""
                error_view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                error_view.add_item(container)
                await ctx.send(view=error_view)
                return
        else:
            # Try to get the guild by ID
            guild = self.bot.get_guild(guild_id)
            if not guild:
                content = f"""## {CROSS} Guild Not Found
> Could not find a guild with ID: `{guild_id}`"""
                error_view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                error_view.add_item(container)
                await ctx.send(view=error_view)
                return
        
        # Create confirmation content using component v2
        confirm_content = f"""## {LOADING} Leave Server Confirmation
> Are you sure you want the bot to leave **{guild.name}**?

{SECTION} **__Server Information__**
{ARROW} **Name:** {guild.name}
{ARROW} **ID:** {guild.id}
{ARROW} **Members:** {guild.member_count:,}
{ARROW} **Owner:** <@{guild.owner_id}>

*This action cannot be undone*"""
        
        # Create LayoutView with buttons
        layout_view = ui.LayoutView(timeout=60)
        text_display = ui.TextDisplay(confirm_content)
        
        confirm_btn = ui.Button(label='Yes, Leave', style=discord.ButtonStyle.danger, emoji='✅')
        cancel_btn = ui.Button(label='Cancel', style=discord.ButtonStyle.secondary, emoji='❌')
        
        async def confirm_callback(interaction: discord.Interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("Only the command user can confirm this action.", ephemeral=True)
            
            leaving_content = f"""## {LOADING} Leaving Server
> Leaving **{guild.name}**..."""
            leaving_view = ui.LayoutView(timeout=300)
            leaving_display = ui.TextDisplay(leaving_content)
            leaving_container = ui.Container(leaving_display)
            leaving_view.add_item(leaving_container)
            await interaction.response.edit_message(view=leaving_view)
            
            try:
                await guild.leave()
                
                success_content = f"""## {TICK} Successfully Left Server
> Bot has left **{guild.name}** (ID: {guild.id})"""
                success_view = ui.LayoutView(timeout=300)
                success_display = ui.TextDisplay(success_content)
                success_container = ui.Container(success_display)
                success_view.add_item(success_container)
                await interaction.edit_original_response(view=success_view)
            except Exception as e:
                error_content = f"""## {CROSS} Error Leaving Server
> Failed to leave server: {str(e)}"""
                error_view = ui.LayoutView(timeout=300)
                error_display = ui.TextDisplay(error_content)
                error_container = ui.Container(error_display)
                error_view.add_item(error_container)
                await interaction.edit_original_response(view=error_view)
        
        async def cancel_callback(interaction: discord.Interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("Only the command user can cancel this action.", ephemeral=True)
            
            cancelled_content = f"""## {CROSS} Cancelled
> Cancelled leaving **{guild.name}**"""
            cancelled_view = ui.LayoutView(timeout=300)
            cancelled_display = ui.TextDisplay(cancelled_content)
            cancelled_container = ui.Container(cancelled_display)
            cancelled_view.add_item(cancelled_container)
            await interaction.response.edit_message(view=cancelled_view)
        
        confirm_btn.callback = confirm_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(confirm_btn, cancel_btn)
        container = ui.Container(text_display, button_row)
        layout_view.add_item(container)
        await ctx.send(view=layout_view)
    
    @commands.command(name='restart')
    async def restart_bot(self, ctx):
        """Restart the bot (Owner only)"""
        # Check if user is a bot owner
        if ctx.author.id not in self.bot.config.BOT_OWNER_IDS:
            content = f"""## {CROSS} Access Denied
> Only bot owners can use this command."""
            error_view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            error_view.add_item(container)
            await ctx.send(view=error_view)
            return

        # Create confirmation content using component v2
        confirm_content = f"""## {LOADING} Confirm Bot Restart
> Are you sure you want to restart the bot?

{SECTION} **__Warning__**
{ARROW} This will disconnect all active connections
{ARROW} The bot process will restart

*You have 30 seconds to confirm*"""

        # Create LayoutView with buttons
        layout_view = ui.LayoutView(timeout=30)
        text_display = ui.TextDisplay(confirm_content)
        
        confirm_btn = ui.Button(label='Confirm Restart', style=discord.ButtonStyle.danger, emoji=bot_emoji.tick)
        cancel_btn = ui.Button(label='Cancel', style=discord.ButtonStyle.secondary, emoji=bot_emoji.cross)
        
        async def confirm_callback(interaction: discord.Interaction):
            if interaction.user.id != ctx.author.id:
                return await interaction.response.send_message("Only the command user can confirm this action.", ephemeral=True)
            
            restart_content = f"""## {LOADING} Restarting Bot...
> The bot is restarting now. Please wait a moment..."""
            restart_view = ui.LayoutView(timeout=300)
            restart_display = ui.TextDisplay(restart_content)
            restart_container = ui.Container(restart_display)
            restart_view.add_item(restart_container)
            await interaction.response.edit_message(view=restart_view)
            
            print(f"Bot restart initiated by {ctx.author} ({ctx.author.id})")
            
            await self.bot.close()
            os.system("kill 1")
        
        async def cancel_callback(interaction: discord.Interaction):
            if interaction.user.id != ctx.author.id:
                return await interaction.response.send_message("Only the command user can cancel this action.", ephemeral=True)
            
            cancel_content = f"""## {CROSS} Restart Cancelled
> Bot restart has been cancelled."""
            cancel_view = ui.LayoutView(timeout=300)
            cancel_display = ui.TextDisplay(cancel_content)
            cancel_container = ui.Container(cancel_display)
            cancel_view.add_item(cancel_container)
            await interaction.response.edit_message(view=cancel_view)
        
        confirm_btn.callback = confirm_callback
        cancel_btn.callback = cancel_callback
        
        button_row = ui.ActionRow(confirm_btn, cancel_btn)
        container = ui.Container(text_display, button_row)
        layout_view.add_item(container)
        await ctx.send(view=layout_view)

async def setup(bot):
    await bot.add_cog(OwnerCommands(bot))