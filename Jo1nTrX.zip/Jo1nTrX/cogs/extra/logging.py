import discord
from discord.ext import commands
from discord import app_commands, ui
from datetime import datetime, timezone, timedelta
from typing import Optional, Literal
import asyncio
import aiohttp
import base64
import io
import re
import pytz
from Jo1nTrX.utils.embeds import create_embed, create_error_embed
from Jo1nTrX.utils.helpers import send_loading_message
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)

LOG_TYPES = {
    'message': 'Message Logs',
    'moderation': 'Moderation Logs',
    'voice': 'Voice Logs',
    'join_leave': 'Join-Leave Logs',
    'role': 'Role Updation Logs',
    'emoji': 'Emoji Logs',
    'webhook': 'Webhook Logs',
    'channel': 'Channel Management Logs'
}

ARROW = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION = "<:jo1ntrx_right:1405095312456024127>"
LOGS_EMOJI = "<:Jo1nTrX_logs:1430762798606061621>"
TICK = "<:jo1ntrx_tick:1405094884947267715>"
CROSS = "<a:Jo1nTrX_cross:1405094904568483880>"
LOADING = "<a:Jo1nTrX_loading:1405188056067067966>"


def get_ist_time():
    ist_timezone = timezone(timedelta(hours=5, minutes=30))
    ist_time = datetime.now(ist_timezone)
    time_12hr = ist_time.strftime("%I:%M %p").lower()
    if time_12hr.startswith('0'):
        time_12hr = time_12hr[1:]
    return time_12hr


def escape_mentions(content: str) -> str:
    """Escape user and role mentions to prevent pinging in logs."""
    if not content:
        return content
    content = re.sub(r'<@!?(\d+)>', r'<@\u200b\1>', content)
    content = re.sub(r'<@&(\d+)>', r'<@\u200b&\1>', content)
    content = content.replace('@everyone', '@\u200beveryone')
    content = content.replace('@here', '@\u200bhere')
    return content


class LoggingLayoutView(ui.LayoutView):
    def __init__(self, content: str, user: discord.User = None, timeout: int = 300):
        super().__init__(timeout=timeout)
        self.requester = user
        time_str = get_ist_time()
        footer = f"\n\n> Executed by {user.name} | {time_str}" if user else f"\n\n> Executed by Bot | {time_str}"
        full_content = content + footer
        text_display = ui.TextDisplay(full_content)
        container = ui.Container(text_display)
        self.add_item(container)


class LoggingCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def download_attachment_as_base64(self, url):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.read()
                        return base64.b64encode(data).decode('utf-8')
        except Exception as e:
            print(f"Error downloading attachment: {e}")
        return None

    def process_message_content(self, content, message):
        try:
            emoji_pattern = r'<a?:([^:]+):(\d+)>'
            def replace_emoji(match):
                emoji_id = match.group(2)
                emoji_name = match.group(1)
                emoji_url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{'gif' if match.group(0).startswith('<a:') else 'png'}"
                return f'<img src="{emoji_url}" alt="{emoji_name}" title="{emoji_name}" style="height: 1.375em; vertical-align: middle;">'
            
            content = re.sub(emoji_pattern, replace_emoji, content)
            
            mention_pattern = r'<@!?(\d+)>'
            def replace_mention(match):
                user_id = match.group(1)
                user = self.bot.get_user(int(user_id))
                if user:
                    return f'<span class="mention">@{user.name}</span>'
                return f'<span class="mention">@Unknown User</span>'
            
            content = re.sub(mention_pattern, replace_mention, content)
            
            role_pattern = r'<@&(\d+)>'
            def replace_role(match):
                role_id = match.group(1)
                role = message.guild.get_role(int(role_id)) if message.guild else None
                if role:
                    return f'<span class="mention">@{role.name}</span>'
                return f'<span class="mention">@Unknown Role</span>'
            
            content = re.sub(role_pattern, replace_role, content)
            
            channel_pattern = r'<#(\d+)>'
            def replace_channel(match):
                channel_id = match.group(1)
                channel = self.bot.get_channel(int(channel_id))
                if channel:
                    return f'<span class="mention">#{channel.name}</span>'
                return f'<span class="mention">#deleted-channel</span>'
            
            content = re.sub(channel_pattern, replace_channel, content)
            
            return content
        except Exception as e:
            print(f"Error processing message content: {e}")
            return content

    async def generate_message_log_html(self, messages, channel, deleted_by=None, is_bulk=False):
        try:
            ist = pytz.timezone('Asia/Kolkata')
            current_time_ist = datetime.now(ist).strftime('%A, %B %d, %Y %I:%M %p IST')
            
            primary_color = '#7c28eb'
            
            html_lines = []
            html_lines.append('<!DOCTYPE html>')
            html_lines.append('<html lang="en">')
            html_lines.append('<head>')
            html_lines.append('  <meta charset="UTF-8">')
            html_lines.append('  <meta name="viewport" content="width=device-width, initial-scale=1.0">')
            html_lines.append(f'  <title>Message Log - #{channel.name}</title>')
            html_lines.append('  <style>')
            html_lines.append('    @keyframes twinkle1 { 0%, 100% { opacity: 0.3; } 50% { opacity: 1; } }')
            html_lines.append('    @keyframes twinkle2 { 0%, 100% { opacity: 0.4; } 50% { opacity: 0.9; } }')
            html_lines.append('    @keyframes twinkle3 { 0%, 100% { opacity: 0.2; } 50% { opacity: 0.8; } }')
            html_lines.append('    @keyframes twinkle4 { 0%, 100% { opacity: 0.5; } 50% { opacity: 1; } }')
            html_lines.append('    @keyframes twinkle5 { 0%, 100% { opacity: 0.3; } 50% { opacity: 0.95; } }')
            html_lines.append('    @keyframes glow { 0%, 100% { box-shadow: 0 0 10px rgba(124, 40, 235, 0.3), inset 0 0 10px rgba(124, 40, 235, 0.1); } 50% { box-shadow: 0 0 20px rgba(124, 40, 235, 0.6), inset 0 0 15px rgba(124, 40, 235, 0.2); } }')
            html_lines.append('    * { margin: 0; padding: 0; box-sizing: border-box; }')
            html_lines.append('    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; background: #000000; color: #e4e6eb; line-height: 1.5; position: relative; overflow-x: hidden; }')
            html_lines.append('    body::before { content: ""; position: fixed; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 1; box-shadow: 1px 1px 0 white, 5px 2px 0 white, 8px 5px 0 white, 12px 8px 0 white, 15px 3px 0 white, 22px 10px 0 white, 30px 6px 0 white, 35px 15px 0 white, 42px 9px 0 white, 50px 20px 0 white, 58px 5px 0 white, 65px 18px 0 white, 72px 12px 0 white, 80px 25px 0 white, 88px 8px 0 white, 95px 30px 0 white, 5% 30% 0 white, 15% 45% 0 white, 25% 35% 0 white, 35% 50% 0 white, 45% 42% 0 white, 55% 55% 0 white, 65% 48% 0 white, 75% 60% 0 white, 85% 52% 0 white, 92% 65% 0 white, 10% 70% 0 white, 30% 80% 0 white, 50% 85% 0 white, 70% 75% 0 white, 88% 88% 0 white; animation: twinkle1 3s ease-in-out infinite, twinkle2 4.5s ease-in-out infinite, twinkle3 2.5s ease-in-out infinite, twinkle4 5s ease-in-out infinite, twinkle5 3.5s ease-in-out infinite; }')
            html_lines.append('    .container { max-width: 950px; margin: 0 auto; padding: 20px; position: relative; z-index: 2; }')
            html_lines.append(f'    .header {{ background: rgba(26, 27, 30, 0.95); border-radius: 8px; padding: 24px; margin-bottom: 20px; border-left: 5px solid {primary_color}; }}')
            html_lines.append('    .header h1 { color: #ffffff; margin-bottom: 16px; font-size: 24px; }')
            html_lines.append('    .header-info { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; font-size: 14px; }')
            html_lines.append('    .header-info div { display: flex; flex-direction: column; }')
            html_lines.append(f'    .header-info label {{ color: {primary_color}; font-weight: 600; margin-bottom: 6px; }}')
            html_lines.append('    .header-info value { color: #e4e6eb; }')
            html_lines.append('    .messages { display: flex; flex-direction: column; gap: 8px; }')
            html_lines.append(f'    .message {{ background: rgba(42, 45, 49, 0.95); padding: 14px 16px; border-radius: 6px; margin-bottom: 8px; border: 2px solid {primary_color}; animation: glow 3s ease-in-out infinite; }}')
            html_lines.append('    .message:hover { border-color: #ff00ff; }')
            html_lines.append('    .message.bot { border-color: ' + primary_color + '; }')
            html_lines.append('    .message-header { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }')
            html_lines.append('    .avatar { width: 36px; height: 36px; border-radius: 50%; flex-shrink: 0; }')
            html_lines.append('    .author { font-weight: 600; color: #ffffff; }')
            html_lines.append('    .bot-badge { background: ' + primary_color + '; color: white; padding: 2px 6px; border-radius: 3px; font-size: 11px; font-weight: 600; margin-left: 6px; }')
            html_lines.append('    .timestamp { font-size: 12px; color: #949ba4; margin-left: auto; }')
            html_lines.append('    .message-content { color: #e4e6eb; word-wrap: break-word; white-space: pre-wrap; margin-top: 4px; }')
            html_lines.append('    .mention { color: ' + primary_color + '; font-weight: 500; background: rgba(124, 40, 235, 0.2); padding: 0 4px; border-radius: 3px; }')
            html_lines.append('    .attachments { margin-top: 12px; display: flex; flex-wrap: wrap; gap: 10px; }')
            html_lines.append('    .attachment { background: rgba(26, 27, 30, 0.95); border-radius: 6px; padding: 10px; border: 1px solid #404249; }')
            html_lines.append('    .attachment-link { color: #00b0f4; text-decoration: none; word-break: break-all; }')
            html_lines.append('    .attachment-link:hover { text-decoration: underline; }')
            html_lines.append('    .attachment-image { max-width: 100%; max-height: 400px; border-radius: 6px; cursor: pointer; }')
            html_lines.append('    .attachment-file { color: #949ba4; font-size: 12px; margin-top: 6px; }')
            html_lines.append('    .sticker { max-width: 200px; height: auto; margin: 8px 0; }')
            html_lines.append(f'    .embed {{ background: rgba(26, 27, 30, 0.95); border-left: 4px solid {primary_color}; border-radius: 6px; padding: 14px; margin-top: 10px; }}')
            html_lines.append('    .embed-title { color: #ffffff; font-weight: 700; font-size: 15px; margin-bottom: 8px; }')
            html_lines.append('    .embed-description { color: #e4e6eb; margin-bottom: 10px; }')
            html_lines.append('    .embed-field { margin-bottom: 8px; }')
            html_lines.append('    .embed-field-name { color: #ffffff; font-weight: 600; font-size: 13px; margin-bottom: 4px; }')
            html_lines.append('    .embed-field-value { color: #e4e6eb; font-size: 13px; }')
            html_lines.append('    .embed-image { max-width: 100%; border-radius: 4px; margin-top: 10px; }')
            html_lines.append('    .embed-thumbnail { max-width: 80px; border-radius: 4px; float: right; margin-left: 10px; }')
            html_lines.append('    .embed-footer { font-size: 12px; color: #949ba4; margin-top: 10px; padding-top: 8px; border-top: 1px solid #404249; }')
            html_lines.append('    .footer { text-align: center; padding: 20px; color: #949ba4; font-size: 12px; margin-top: 30px; }')
            html_lines.append('    .footer a { color: ' + primary_color + '; text-decoration: none; }')
            html_lines.append('    .deleted-badge { background: #ff4444; color: white; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 600; margin-left: 6px; }')
            html_lines.append('  </style>')
            html_lines.append('</head>')
            html_lines.append('<body>')
            html_lines.append('  <div class="container">')
            html_lines.append('    <div class="header">')
            
            if is_bulk:
                html_lines.append(f'      <h1>Bulk Message Deletion Log ({len(messages)} messages)</h1>')
            else:
                html_lines.append('      <h1>Message Deleted</h1>')
            
            html_lines.append('      <div class="header-info">')
            html_lines.append(f'        <div><label>Channel:</label><value>#{channel.name}</value></div>')
            html_lines.append(f'        <div><label>Server:</label><value>{channel.guild.name}</value></div>')
            html_lines.append(f'        <div><label>Deleted At:</label><value>{current_time_ist}</value></div>')
            
            if deleted_by:
                html_lines.append(f'        <div><label>Deleted By:</label><value>{deleted_by.display_name} | {deleted_by.name}</value></div>')
            else:
                html_lines.append('        <div><label>Deleted By:</label><value>Unknown (Author or Bot)</value></div>')
            
            html_lines.append(f'        <div><label>Messages:</label><value>{len(messages)}</value></div>')
            html_lines.append('      </div>')
            html_lines.append('    </div>')
            html_lines.append('    <div class="messages">')
            
            for message in messages:
                timestamp_ist = message.created_at.astimezone(ist).strftime('%H:%M:%S')
                content = message.content if message.content else ""
                
                content = self.process_message_content(content, message)
                
                is_bot = message.author.bot
                bot_class = ' bot' if is_bot else ''
                
                html_lines.append(f'      <div class="message{bot_class}">')
                html_lines.append('        <div class="message-header">')
                html_lines.append(f'          <img src="{message.author.display_avatar.url}" alt="{message.author.name}" class="avatar">')
                html_lines.append(f'          <span class="author">{message.author.display_name} | {message.author.name}</span>')
                if is_bot:
                    html_lines.append('          <span class="bot-badge">BOT</span>')
                html_lines.append('          <span class="deleted-badge">DELETED</span>')
                html_lines.append(f'          <span class="timestamp">{timestamp_ist}</span>')
                html_lines.append('        </div>')
                
                if content:
                    safe_content = content.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                    safe_content = safe_content.replace('&lt;img src=', '<img src=').replace('&lt;span class=', '<span class=').replace('&lt;/span&gt;', '</span>')
                    safe_content = re.sub(r'style=&quot;([^&]+)&quot;&gt;', r'style="\1">', safe_content)
                    html_lines.append(f'        <div class="message-content">{safe_content}</div>')
                
                if message.stickers:
                    for sticker in message.stickers:
                        if sticker.url:
                            html_lines.append(f'        <img src="{sticker.url}" alt="{sticker.name}" class="sticker" title="{sticker.name}">')
                
                if message.attachments:
                    html_lines.append('        <div class="attachments">')
                    for attachment in message.attachments:
                        html_lines.append('          <div class="attachment">')
                        
                        is_image = any(attachment.filename.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp'])
                        
                        if is_image:
                            base64_data = await self.download_attachment_as_base64(attachment.url)
                            if base64_data:
                                ext = attachment.filename.split('.')[-1].lower()
                                mime_types = {'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'gif': 'image/gif', 'webp': 'image/webp'}
                                mime_type = mime_types.get(ext, 'image/png')
                                html_lines.append(f'            <img src="data:{mime_type};base64,{base64_data}" alt="{attachment.filename}" class="attachment-image">')
                            else:
                                html_lines.append(f'            <a href="{attachment.url}" class="attachment-link">{attachment.filename}</a>')
                        else:
                            html_lines.append(f'            <a href="{attachment.url}" class="attachment-link">{attachment.filename}</a>')
                        
                        html_lines.append(f'            <div class="attachment-file">{attachment.size / 1024:.2f} KB</div>')
                        html_lines.append('          </div>')
                    html_lines.append('        </div>')
                
                if message.embeds:
                    for embed in message.embeds:
                        embed_color = embed.color.value if embed.color else int(primary_color.replace('#', ''), 16)
                        hex_color = f'#{embed_color:06x}' if isinstance(embed_color, int) else primary_color
                        
                        html_lines.append(f'        <div class="embed" style="border-left-color: {hex_color};">')
                        
                        if embed.thumbnail:
                            html_lines.append(f'          <img src="{embed.thumbnail.url}" class="embed-thumbnail" alt="thumbnail">')
                        
                        if embed.author:
                            html_lines.append(f'          <div class="embed-author" style="font-size: 13px; margin-bottom: 6px;">')
                            if embed.author.icon_url:
                                html_lines.append(f'            <img src="{embed.author.icon_url}" style="width: 20px; height: 20px; border-radius: 50%; vertical-align: middle; margin-right: 6px;">')
                            html_lines.append(f'            {embed.author.name}</div>')
                        
                        if embed.title:
                            html_lines.append(f'          <div class="embed-title">{embed.title}</div>')
                        
                        if embed.description:
                            html_lines.append(f'          <div class="embed-description">{embed.description}</div>')
                        
                        if embed.fields:
                            for field in embed.fields:
                                inline_style = 'display: inline-block; width: 45%; vertical-align: top;' if field.inline else ''
                                html_lines.append(f'          <div class="embed-field" style="{inline_style}">')
                                html_lines.append(f'            <div class="embed-field-name">{field.name}</div>')
                                html_lines.append(f'            <div class="embed-field-value">{field.value}</div>')
                                html_lines.append('          </div>')
                        
                        if embed.image:
                            html_lines.append(f'          <img src="{embed.image.url}" class="embed-image" alt="embed image">')
                        
                        if embed.footer or embed.timestamp:
                            footer_text = ""
                            if embed.footer and embed.footer.text:
                                footer_text = embed.footer.text
                            if embed.timestamp:
                                ts = embed.timestamp.strftime('%Y-%m-%d %H:%M:%S') if hasattr(embed.timestamp, 'strftime') else str(embed.timestamp)
                                footer_text += f" • {ts}" if footer_text else ts
                            if footer_text:
                                html_lines.append(f'          <div class="embed-footer">{footer_text}</div>')
                        
                        html_lines.append('        </div>')
                
                html_lines.append('      </div>')
            
            html_lines.append('    </div>')
            html_lines.append('    <div class="footer">')
            html_lines.append('      <p>Generated by <strong>Jo1nTrX</strong> Message Logging System</p>')
            html_lines.append('    </div>')
            html_lines.append('  </div>')
            html_lines.append('</body>')
            html_lines.append('</html>')
            
            html_content = '\n'.join(html_lines)
            timestamp_str = datetime.now(ist).strftime('%Y%m%d_%H%M%S')
            filename = f"message-log-{channel.name}-{timestamp_str}.html"
            
            return discord.File(io.BytesIO(html_content.encode('utf-8')), filename=filename)
        
        except Exception as e:
            print(f"Error generating message log HTML: {e}")
            import traceback
            traceback.print_exc()
            return None

    async def send_log(self, log_channel, view_or_embed, webhook_url=None, log_type=None, file=None):
        # Cache file data for retry purposes (discord.File can only be used once)
        file_data = None
        file_name = None
        
        # Try to cache file data if file exists and is readable
        if file:
            try:
                if hasattr(file, 'fp') and file.fp and not file.fp.closed:
                    file.fp.seek(0)
                    file_data = file.fp.read()
                    file_name = file.filename
                    file.fp.seek(0)  # Reset for original use
            except Exception as e:
                print(f"Error caching file data: {e}")
        
        def create_file():
            """Create a fresh File object from cached data"""
            if file_data and file_name:
                return discord.File(io.BytesIO(file_data), filename=file_name)
            return None
        
        try:
            if webhook_url:
                async with aiohttp.ClientSession() as session:
                    webhook = discord.Webhook.from_url(webhook_url, session=session)
                    webhook_name = f"Jo1nTrX | {LOG_TYPES.get(log_type, 'Logs')}" if log_type else "Jo1nTrX Logs"
                    avatar_url = self.bot.user.display_avatar.url if self.bot.user else None
                    
                    if isinstance(view_or_embed, ui.LayoutView):
                        # Send view first, then file separately if needed
                        await webhook.send(view=view_or_embed, username=webhook_name, avatar_url=avatar_url)
                        if file_data:
                            new_file = create_file()
                            if new_file:
                                await webhook.send(file=new_file, username=webhook_name, avatar_url=avatar_url)
                    else:
                        await webhook.send(embed=view_or_embed, file=file, username=webhook_name, avatar_url=avatar_url)
            else:
                if isinstance(view_or_embed, ui.LayoutView):
                    # Send view first, then file separately if needed
                    await log_channel.send(view=view_or_embed)
                    if file_data:
                        new_file = create_file()
                        if new_file:
                            await log_channel.send(file=new_file)
                else:
                    await log_channel.send(embed=view_or_embed, file=file)
        except Exception as e:
            print(f"Error sending log: {e}")
            try:
                # Fallback - try sending to channel directly
                if isinstance(view_or_embed, ui.LayoutView):
                    await log_channel.send(view=view_or_embed)
                    if file_data:
                        new_file = create_file()
                        if new_file:
                            await log_channel.send(file=new_file)
                else:
                    retry_file = create_file()
                    await log_channel.send(embed=view_or_embed, file=retry_file)
            except Exception as e2:
                print(f"Error in fallback log send: {e2}")

    def create_log_view(self, title: str, description: str, footer: str = None) -> ui.LayoutView:
        time_str = get_ist_time()
        content = f"## {LOGS_EMOJI} {title}\n\n{description}"
        if footer:
            content += f"\n\n> {footer} | {time_str}"
        else:
            content += f"\n\n> {time_str}"
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        return view

    @commands.group(name='logs', invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def logs_group(self, ctx):
        content = f"""## {LOGS_EMOJI} Logging System
> Manage server logging with Jo1nTrX

{SECTION} **__Available Commands__**

{ARROW} `+logs setup` - Setup logging system with all channels
{ARROW} `+logs reset` - Remove all logging channels
{ARROW} `+logschannel set <type> <#channel>` - Set custom log channel

{SECTION} **__Log Types__**

{ARROW} `message` - Message edits & deletions
{ARROW} `moderation` - Bans, kicks, timeouts
{ARROW} `voice` - Voice channel activity
{ARROW} `join_leave` - Member joins & leaves
{ARROW} `role` - Role updates
{ARROW} `emoji` - Emoji & sticker changes
{ARROW} `webhook` - Webhook modifications
{ARROW} `channel` - Channel management"""
        
        view = LoggingLayoutView(content, ctx.author)
        await ctx.send(view=view)

    @logs_group.command(name='setup')
    @commands.has_permissions(administrator=True)
    async def logs_setup(self, ctx):
        loading_msg = await send_loading_message(ctx, "Setting up logging system")
        
        try:
            guild = ctx.guild
            
            existing_category_id = await self.bot.db.get_logging_category(guild.id)
            if existing_category_id:
                existing_category = guild.get_channel(existing_category_id)
                if existing_category:
                    content = f"""## {CROSS} Already Setup
> Logging system is already configured

{SECTION} **__Current Setup__**
{ARROW} **Category:** {existing_category.mention}

{SECTION} **__Action Required__**
{ARROW} Use `+logs reset` to remove existing setup first"""
                    
                    view = LoggingLayoutView(content, ctx.author)
                    await loading_msg.edit(embed=None, view=view)
                    return
            
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_webhooks=True)
            }
            
            category = await guild.create_category(
                name="Jo1nTrX Logs",
                overwrites=overwrites,
                reason=f"Logging setup by {ctx.author}"
            )
            
            await self.bot.db.set_logging_category(guild.id, category.id)
            
            channels_created = []
            for log_type, channel_name in LOG_TYPES.items():
                try:
                    channel = await guild.create_text_channel(
                        name=channel_name.lower().replace(' ', '-'),
                        category=category,
                        overwrites=overwrites,
                        reason=f"Logging setup by {ctx.author}"
                    )
                    
                    webhook = await channel.create_webhook(
                        name=f"Jo1nTrX | {channel_name}",
                        avatar=await self.bot.user.display_avatar.read() if self.bot.user else None,
                        reason="Logging webhook"
                    )
                    
                    await self.bot.db.set_log_channel(guild.id, log_type, channel.id, webhook.url)
                    channels_created.append(f"{ARROW} {channel.mention} - `{log_type}`")
                    
                except Exception as e:
                    print(f"Error creating channel {channel_name}: {e}")
            
            channels_text = "\n".join(channels_created)
            content = f"""## {TICK} Logging Setup Complete
> All logging channels have been created

{SECTION} **__Category__**
{ARROW} {category.mention}

{SECTION} **__Channels Created__**
{channels_text}

{SECTION} **__Note__**
{ARROW} All channels are hidden from @everyone"""
            
            view = LoggingLayoutView(content, ctx.author)
            await loading_msg.edit(embed=None, view=view)
            
        except discord.Forbidden:
            content = f"""## {CROSS} Permission Error
> Missing required permissions

{SECTION} **__Required Permissions__**
{ARROW} Manage Channels
{ARROW} Manage Webhooks"""
            
            view = LoggingLayoutView(content, ctx.author)
            await loading_msg.edit(embed=None, view=view)
        except Exception as e:
            content = f"""## {CROSS} Error Occurred
> An unexpected error happened

{SECTION} **__Error Details__**
{ARROW} {str(e)}"""
            
            view = LoggingLayoutView(content, ctx.author)
            await loading_msg.edit(embed=None, view=view)

    @logs_group.command(name='reset')
    @commands.has_permissions(administrator=True)
    async def logs_reset(self, ctx):
        loading_msg = await send_loading_message(ctx, "Resetting logging system")
        
        try:
            guild = ctx.guild
            
            category_id = await self.bot.db.get_logging_category(guild.id)
            if not category_id:
                content = f"""## {CROSS} Not Setup
> No logging system found to reset

{SECTION} **__Action Required__**
{ARROW} Use `+logs setup` to create logging system"""
                
                view = LoggingLayoutView(content, ctx.author)
                await loading_msg.edit(embed=None, view=view)
                return
            
            category = guild.get_channel(category_id)
            channels_deleted = 0
            
            if category:
                for channel in category.channels:
                    try:
                        await channel.delete(reason=f"Logging reset by {ctx.author}")
                        channels_deleted += 1
                    except:
                        pass
                
                try:
                    await category.delete(reason=f"Logging reset by {ctx.author}")
                except:
                    pass
            
            await self.bot.db.clear_all_log_channels(guild.id)
            await self.bot.db.remove_logging_category(guild.id)
            
            content = f"""## {TICK} Logging Reset Complete
> All logging channels have been removed

{SECTION} **__Summary__**
{ARROW} **Channels Deleted:** {channels_deleted}
{ARROW} **Category Removed:** {TICK}"""
            
            view = LoggingLayoutView(content, ctx.author)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            content = f"""## {CROSS} Error Occurred
> An unexpected error happened

{SECTION} **__Error Details__**
{ARROW} {str(e)}"""
            
            view = LoggingLayoutView(content, ctx.author)
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='logschannel')
    @app_commands.describe(
        action="Set or remove log channel",
        log_type="Type of logs",
        channel="Channel to set for logging"
    )
    @commands.has_permissions(administrator=True)
    async def logschannel(self, ctx, action: Literal['set'], log_type: str, channel: discord.TextChannel):
        if action == 'set':
            await self.logschannel_set(ctx, log_type, channel)

    async def logschannel_set(self, ctx, log_type: str, channel: discord.TextChannel):
        loading_msg = await send_loading_message(ctx, f"Setting up {log_type} log channel")
        
        try:
            if log_type not in LOG_TYPES:
                valid_types = ", ".join([f"`{t}`" for t in LOG_TYPES.keys()])
                content = f"""## {CROSS} Invalid Log Type
> The specified log type doesn't exist

{SECTION} **__Provided Type__**
{ARROW} `{log_type}`

{SECTION} **__Valid Types__**
{ARROW} {valid_types}"""
                
                view = LoggingLayoutView(content, ctx.author)
                await loading_msg.edit(embed=None, view=view)
                return
            
            permissions = channel.permissions_for(ctx.guild.me)
            if not permissions.send_messages or not permissions.manage_webhooks:
                content = f"""## {CROSS} Missing Permissions
> Cannot setup logging in this channel

{SECTION} **__Channel__**
{ARROW} {channel.mention}

{SECTION} **__Required Permissions__**
{ARROW} Send Messages
{ARROW} Manage Webhooks"""
                
                view = LoggingLayoutView(content, ctx.author)
                await loading_msg.edit(embed=None, view=view)
                return
            
            existing = await self.bot.db.get_log_channel(ctx.guild.id, log_type)
            webhook_url = None
            
            if existing and existing[1]:
                webhook_url = existing[1]
            else:
                try:
                    webhook = await channel.create_webhook(
                        name=f"Jo1nTrX | {LOG_TYPES[log_type]}",
                        avatar=await self.bot.user.display_avatar.read() if self.bot.user else None,
                        reason=f"Logging webhook set by {ctx.author}"
                    )
                    webhook_url = webhook.url
                except:
                    pass
            
            await self.bot.db.set_log_channel(ctx.guild.id, log_type, channel.id, webhook_url)
            
            content = f"""## {TICK} Log Channel Set
> Successfully configured logging channel

{SECTION} **__Configuration__**
{ARROW} **Type:** {LOG_TYPES[log_type]} (`{log_type}`)
{ARROW} **Channel:** {channel.mention}
{ARROW} **Webhook:** {TICK if webhook_url else CROSS}"""
            
            view = LoggingLayoutView(content, ctx.author)
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            content = f"""## {CROSS} Error Occurred
> An unexpected error happened

{SECTION} **__Error Details__**
{ARROW} {str(e)}"""
            
            view = LoggingLayoutView(content, ctx.author)
            await loading_msg.edit(embed=None, view=view)

    @logschannel.autocomplete('log_type')
    async def logschannel_autocomplete(
        self,
        interaction: discord.Interaction,
        current: str,
    ) -> list[app_commands.Choice[str]]:
        return [
            app_commands.Choice(name=f"{name} ({key})", value=key)
            for key, name in LOG_TYPES.items()
            if current.lower() in key.lower() or current.lower() in name.lower()
        ][:25]

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if not message.guild:
            return
        
        log_data = await self.bot.db.get_log_channel(message.guild.id, 'message')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        deleted_by = None
        try:
            await asyncio.sleep(0.5)
            async for entry in message.guild.audit_logs(limit=3, action=discord.AuditLogAction.message_delete):
                if entry.target.id == message.author.id and entry.extra.channel.id == message.channel.id:
                    deleted_by = entry.user
                    break
        except:
            pass
        
        html_file = await self.generate_message_log_html([message], message.channel, deleted_by, is_bulk=False)
        
        deleted_by_text = f"{deleted_by.display_name}" if deleted_by else "Unknown (Author or Bot)"
        
        content = f"""## {LOGS_EMOJI} Message Deleted
> A message was deleted from the server

{SECTION} **__Message Details__**
{ARROW} **Author:** {message.author.display_name} | {message.author.name}
{ARROW} **Deleted By:** {deleted_by_text}
{ARROW} **Channel:** {message.channel.mention}

{SECTION} **__Attachment__**
{ARROW} Full log attached as HTML file

> Message ID: {message.id} | Author ID: {message.author.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        if html_file:
            await self.send_log(log_channel, view, webhook_url, 'message', html_file)
        else:
            msg_content = message.content[:500] if message.content else '*No content*'
            fallback_content = f"""## {LOGS_EMOJI} Message Deleted
> A message was deleted from the server

{SECTION} **__Message Details__**
{ARROW} **Author:** {message.author.mention} ({message.author})
{ARROW} **Deleted By:** {deleted_by_text}
{ARROW} **Channel:** {message.channel.mention}

{SECTION} **__Content__**
{msg_content}

> Message ID: {message.id} | Author ID: {message.author.id}"""
            
            fallback_view = ui.LayoutView(timeout=None)
            fallback_display = ui.TextDisplay(fallback_content)
            fallback_container = ui.Container(fallback_display)
            fallback_view.add_item(fallback_container)
            await self.send_log(log_channel, fallback_view, webhook_url, 'message')

    @commands.Cog.listener()
    async def on_bulk_message_delete(self, messages):
        if not messages:
            return
        
        first_message = messages[0]
        if not first_message.guild:
            return
        
        log_data = await self.bot.db.get_log_channel(first_message.guild.id, 'message')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        deleted_by = None
        try:
            await asyncio.sleep(0.5)
            async for entry in first_message.guild.audit_logs(limit=5, action=discord.AuditLogAction.message_bulk_delete):
                if entry.extra.channel.id == first_message.channel.id:
                    deleted_by = entry.user
                    break
        except:
            pass
        
        sorted_messages = sorted(messages, key=lambda m: m.created_at)
        
        unique_authors = list(set([m.author for m in sorted_messages]))
        authors_preview = ", ".join([f"{a.display_name}" for a in unique_authors[:5]])
        if len(unique_authors) > 5:
            authors_preview += f" +{len(unique_authors) - 5} more"
        
        html_file = await self.generate_message_log_html(sorted_messages, first_message.channel, deleted_by, is_bulk=True)
        
        deleted_by_text = f"{deleted_by.display_name}" if deleted_by else "Unknown"
        
        content = f"""## {LOGS_EMOJI} Bulk Message Deletion
> {len(messages)} messages were deleted

{SECTION} **__Deletion Details__**
{ARROW} **Channel:** {first_message.channel.mention}
{ARROW} **Deleted By:** {deleted_by_text}
{ARROW} **Message Count:** {len(messages)}

{SECTION} **__Authors__**
{ARROW} {authors_preview}

{SECTION} **__Attachment__**
{ARROW} Full log attached as HTML file

> Channel ID: {first_message.channel.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        if html_file:
            await self.send_log(log_channel, view, webhook_url, 'message', html_file)
        else:
            await self.send_log(log_channel, view, webhook_url, 'message')

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.author.bot or not before.guild or before.content == after.content:
            return
        
        log_data = await self.bot.db.get_log_channel(before.guild.id, 'message')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        before_content = escape_mentions(before.content[:400]) if before.content else '*No content*'
        after_content = escape_mentions(after.content[:400]) if after.content else '*No content*'
        
        content = f"""## {LOGS_EMOJI} Message Edited
> A message was edited in the server

{SECTION} **__Author__**
{ARROW} {before.author.display_name} | {before.author.name}

{SECTION} **__Channel__**
{ARROW} {before.channel.mention}

{SECTION} **__Before__**
{before_content}

{SECTION} **__After__**
{after_content}

> Message ID: {before.id} | User ID: {before.author.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'message')

    @commands.Cog.listener()
    async def on_member_join(self, member):
        log_data = await self.bot.db.get_log_channel(member.guild.id, 'join_leave')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        content = f"""## {LOGS_EMOJI} Member Joined
> A new member has joined the server

{SECTION} **__Member Details__**
{ARROW} **Member:** {member.display_name} | {member.name}
{ARROW} **Account Created:** <t:{int(member.created_at.timestamp())}:R>
{ARROW} **Member Count:** {member.guild.member_count}

> User ID: {member.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'join_leave')

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        was_kicked = False
        moderator = None
        kick_reason = None
        
        try:
            await asyncio.sleep(0.5)
            async for entry in member.guild.audit_logs(limit=3, action=discord.AuditLogAction.kick):
                if entry.target.id == member.id:
                    was_kicked = True
                    moderator = entry.user
                    kick_reason = entry.reason
                    break
        except:
            pass
        
        if was_kicked:
            log_data = await self.bot.db.get_log_channel(member.guild.id, 'moderation')
            if log_data:
                channel_id, webhook_url = log_data
                log_channel = self.bot.get_channel(channel_id)
                if log_channel:
                    reason_text = kick_reason if kick_reason else "No reason provided"
                    
                    content = f"""## {LOGS_EMOJI} Member Kicked
> A member was kicked from the server

{SECTION} **__Kick Details__**
{ARROW} **User:** {member.display_name} | {member.name}
{ARROW} **Moderator:** {moderator.display_name} | {moderator.name}
{ARROW} **Reason:** {reason_text}

> User ID: {member.id}"""
                    
                    view = ui.LayoutView(timeout=None)
                    text_display = ui.TextDisplay(content)
                    container = ui.Container(text_display)
                    view.add_item(container)
                    
                    await self.send_log(log_channel, view, webhook_url, 'moderation')
        
        log_data = await self.bot.db.get_log_channel(member.guild.id, 'join_leave')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        roles = [role.name for role in member.roles if role != member.guild.default_role]
        roles_text = ", ".join(roles[:10]) if roles else "None"
        
        content = f"""## {LOGS_EMOJI} Member Left
> A member has left the server

{SECTION} **__Member Details__**
{ARROW} **Member:** {member.display_name} | {member.name}
{ARROW} **Joined:** <t:{int(member.joined_at.timestamp())}:R>
{ARROW} **Member Count:** {member.guild.member_count}

{SECTION} **__Roles__**
{ARROW} {roles_text}

> User ID: {member.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'join_leave')

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.timed_out_until != after.timed_out_until:
            log_data = await self.bot.db.get_log_channel(after.guild.id, 'moderation')
            if log_data:
                channel_id, webhook_url = log_data
                log_channel = self.bot.get_channel(channel_id)
                if log_channel:
                    moderator = None
                    reason = None
                    try:
                        await asyncio.sleep(0.5)
                        async for entry in after.guild.audit_logs(limit=3, action=discord.AuditLogAction.member_update):
                            if entry.target.id == after.id:
                                moderator = entry.user
                                reason = entry.reason
                                break
                    except:
                        pass
                    
                    if after.timed_out_until:
                        mod_text = f"{moderator.display_name} | {moderator.name}" if moderator else "Unknown"
                        reason_text = reason if reason else "No reason provided"
                        
                        content = f"""## {LOGS_EMOJI} Member Timed Out
> A member was timed out

{SECTION} **__Timeout Details__**
{ARROW} **User:** {after.display_name} | {after.name}
{ARROW} **Moderator:** {mod_text}
{ARROW} **Until:** <t:{int(after.timed_out_until.timestamp())}:F>
{ARROW} **Reason:** {reason_text}

> User ID: {after.id}"""
                    else:
                        mod_text = f"{moderator.display_name} | {moderator.name}" if moderator else "Unknown"
                        
                        content = f"""## {LOGS_EMOJI} Timeout Removed
> A member's timeout was removed

{SECTION} **__Details__**
{ARROW} **User:** {after.display_name} | {after.name}
{ARROW} **Moderator:** {mod_text}

> User ID: {after.id}"""
                    
                    view = ui.LayoutView(timeout=None)
                    text_display = ui.TextDisplay(content)
                    container = ui.Container(text_display)
                    view.add_item(container)
                    
                    await self.send_log(log_channel, view, webhook_url, 'moderation')
        
        if before.roles == after.roles:
            return
        
        log_data = await self.bot.db.get_log_channel(before.guild.id, 'role')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        added_roles = [role for role in after.roles if role not in before.roles]
        removed_roles = [role for role in before.roles if role not in after.roles]
        
        if not added_roles and not removed_roles:
            return
        
        moderator = None
        try:
            await asyncio.sleep(0.5)
            async for entry in after.guild.audit_logs(limit=5, action=discord.AuditLogAction.member_role_update):
                if entry.target.id == after.id:
                    moderator = entry.user
                    break
        except:
            pass
        
        mod_text = f"{moderator.display_name} | {moderator.name}" if moderator else "Unknown"
        
        roles_section = ""
        if added_roles:
            added_list = "\n".join([f"{ARROW} {role.name}" for role in added_roles])
            roles_section += f"\n\n{SECTION} **__Roles Added__**\n{added_list}"
        if removed_roles:
            removed_list = "\n".join([f"{ARROW} {role.name}" for role in removed_roles])
            roles_section += f"\n\n{SECTION} **__Roles Removed__**\n{removed_list}"
        
        content = f"""## {LOGS_EMOJI} Member Roles Updated
> A member's roles were modified

{SECTION} **__Details__**
{ARROW} **Member:** {after.display_name} | {after.name}
{ARROW} **Moderator:** {mod_text}{roles_section}

> User ID: {after.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'role')

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        log_data = await self.bot.db.get_log_channel(member.guild.id, 'voice')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        if before.channel is None and after.channel is not None:
            content = f"""## {LOGS_EMOJI} Voice Channel Joined
> A member joined a voice channel

{SECTION} **__Details__**
{ARROW} **Member:** {member.display_name} | {member.name}
{ARROW} **Channel:** {after.channel.mention}

> User ID: {member.id}"""
        elif before.channel is not None and after.channel is None:
            content = f"""## {LOGS_EMOJI} Voice Channel Left
> A member left a voice channel

{SECTION} **__Details__**
{ARROW} **Member:** {member.display_name} | {member.name}
{ARROW} **Channel:** {before.channel.mention}

> User ID: {member.id}"""
        elif before.channel != after.channel:
            content = f"""## {LOGS_EMOJI} Voice Channel Moved
> A member moved between voice channels

{SECTION} **__Details__**
{ARROW} **Member:** {member.display_name} | {member.name}
{ARROW} **From:** {before.channel.mention}
{ARROW} **To:** {after.channel.mention}

> User ID: {member.id}"""
        else:
            return
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'voice')

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        log_data = await self.bot.db.get_log_channel(channel.guild.id, 'channel')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        category_name = channel.category.name if channel.category else "None"
        
        # Get who created the channel from audit logs
        created_by = None
        try:
            await asyncio.sleep(0.5)
            async for entry in channel.guild.audit_logs(limit=3, action=discord.AuditLogAction.channel_create):
                if entry.target.id == channel.id:
                    created_by = entry.user
                    break
        except:
            pass
        
        created_by_text = f"{created_by.display_name} | {created_by.name}" if created_by else "Unknown"
        
        content = f"""## {LOGS_EMOJI} Channel Created
> A new channel was created

{SECTION} **__Channel Details__**
{ARROW} **Channel:** {channel.mention}
{ARROW} **Type:** {channel.type}
{ARROW} **Category:** {category_name}
{ARROW} **Created By:** {created_by_text}

> Channel ID: {channel.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'channel')

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        log_data = await self.bot.db.get_log_channel(channel.guild.id, 'channel')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel or log_channel.id == channel.id:
            return
        
        category_name = channel.category.name if channel.category else "None"
        
        # Get who deleted the channel from audit logs
        deleted_by = None
        try:
            await asyncio.sleep(0.5)
            async for entry in channel.guild.audit_logs(limit=3, action=discord.AuditLogAction.channel_delete):
                if entry.target.id == channel.id:
                    deleted_by = entry.user
                    break
        except:
            pass
        
        deleted_by_text = f"{deleted_by.display_name} | {deleted_by.name}" if deleted_by else "Unknown"
        
        content = f"""## {LOGS_EMOJI} Channel Deleted
> A channel was deleted

{SECTION} **__Channel Details__**
{ARROW} **Channel:** #{channel.name}
{ARROW} **Type:** {channel.type}
{ARROW} **Category:** {category_name}
{ARROW} **Deleted By:** {deleted_by_text}

> Channel ID: {channel.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'channel')

    @commands.Cog.listener()
    async def on_guild_emojis_update(self, guild, before, after):
        log_data = await self.bot.db.get_log_channel(guild.id, 'emoji')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        added_emojis = [emoji for emoji in after if emoji not in before]
        removed_emojis = [emoji for emoji in before if emoji not in after]
        
        if not added_emojis and not removed_emojis:
            return
        
        moderator = None
        try:
            await asyncio.sleep(0.5)
            action = discord.AuditLogAction.emoji_create if added_emojis else discord.AuditLogAction.emoji_delete
            async for entry in guild.audit_logs(limit=3, action=action):
                moderator = entry.user
                break
        except:
            pass
        
        mod_text = f"{moderator.display_name} | {moderator.name}" if moderator else "Unknown"
        
        emoji_section = ""
        if added_emojis:
            added_list = "\n".join([f"{ARROW} {emoji} `:{emoji.name}:`" for emoji in added_emojis])
            emoji_section += f"\n\n{SECTION} **__Emojis Added__**\n{added_list}"
        if removed_emojis:
            removed_list = "\n".join([f"{ARROW} `:{emoji.name}:`" for emoji in removed_emojis])
            emoji_section += f"\n\n{SECTION} **__Emojis Removed__**\n{removed_list}"
        
        content = f"""## {LOGS_EMOJI} Server Emojis Updated
> Server emojis were modified

{SECTION} **__Moderator__**
{ARROW} {mod_text}{emoji_section}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'emoji')

    @commands.Cog.listener()
    async def on_guild_stickers_update(self, guild, before, after):
        log_data = await self.bot.db.get_log_channel(guild.id, 'emoji')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        before_ids = {s.id for s in before}
        after_ids = {s.id for s in after}
        
        added_stickers = [s for s in after if s.id not in before_ids]
        removed_stickers = [s for s in before if s.id not in after_ids]
        
        if not added_stickers and not removed_stickers:
            return
        
        moderator = None
        try:
            await asyncio.sleep(0.5)
            action = discord.AuditLogAction.sticker_create if added_stickers else discord.AuditLogAction.sticker_delete
            async for entry in guild.audit_logs(limit=3, action=action):
                moderator = entry.user
                break
        except:
            pass
        
        mod_text = f"{moderator.display_name} | {moderator.name}" if moderator else "Unknown"
        
        sticker_section = ""
        if added_stickers:
            added_list = "\n".join([f"{ARROW} `{sticker.name}` ({sticker.format.name})" for sticker in added_stickers])
            sticker_section += f"\n\n{SECTION} **__Stickers Added__**\n{added_list}"
        if removed_stickers:
            removed_list = "\n".join([f"{ARROW} `{sticker.name}` ({sticker.format.name})" for sticker in removed_stickers])
            sticker_section += f"\n\n{SECTION} **__Stickers Removed__**\n{removed_list}"
        
        content = f"""## {LOGS_EMOJI} Server Stickers Updated
> Server stickers were modified

{SECTION} **__Moderator__**
{ARROW} {mod_text}{sticker_section}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'emoji')

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        log_data = await self.bot.db.get_log_channel(channel.guild.id, 'webhook')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        moderator = None
        try:
            await asyncio.sleep(0.5)
            async for entry in channel.guild.audit_logs(limit=3):
                if entry.action in [discord.AuditLogAction.webhook_create, 
                                   discord.AuditLogAction.webhook_update, 
                                   discord.AuditLogAction.webhook_delete]:
                    moderator = entry.user
                    break
        except:
            pass
        
        mod_text = f"{moderator.display_name} | {moderator.name}" if moderator else "Unknown"
        
        content = f"""## {LOGS_EMOJI} Webhooks Updated
> Webhooks were modified in a channel

{SECTION} **__Details__**
{ARROW} **Channel:** {channel.mention}
{ARROW} **Moderator:** {mod_text}

{SECTION} **__Note__**
{ARROW} Webhooks in this channel have been modified

> Channel ID: {channel.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'webhook')

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        log_data = await self.bot.db.get_log_channel(guild.id, 'moderation')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        moderator = None
        reason = None
        try:
            await asyncio.sleep(0.5)
            async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.ban):
                if entry.target.id == user.id:
                    moderator = entry.user
                    reason = entry.reason
                    break
        except:
            pass
        
        mod_text = f"{moderator.display_name} | {moderator.name}" if moderator else "Unknown"
        reason_text = reason if reason else "No reason provided"
        
        content = f"""## {LOGS_EMOJI} Member Banned
> A member was banned from the server

{SECTION} **__Ban Details__**
{ARROW} **User:** {user.display_name if hasattr(user, 'display_name') else user.name} | {user.name}
{ARROW} **Moderator:** {mod_text}
{ARROW} **Reason:** {reason_text}

> User ID: {user.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'moderation')

    @commands.Cog.listener()
    async def on_member_unban(self, guild, user):
        log_data = await self.bot.db.get_log_channel(guild.id, 'moderation')
        if not log_data:
            return
        
        channel_id, webhook_url = log_data
        log_channel = self.bot.get_channel(channel_id)
        if not log_channel:
            return
        
        moderator = None
        try:
            await asyncio.sleep(0.5)
            async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.unban):
                if entry.target.id == user.id:
                    moderator = entry.user
                    break
        except:
            pass
        
        mod_text = f"{moderator.display_name} | {moderator.name}" if moderator else "Unknown"
        
        content = f"""## {LOGS_EMOJI} Member Unbanned
> A member was unbanned from the server

{SECTION} **__Unban Details__**
{ARROW} **User:** {user.display_name if hasattr(user, 'display_name') else user.name} | {user.name}
{ARROW} **Moderator:** {mod_text}

> User ID: {user.id}"""
        
        view = ui.LayoutView(timeout=None)
        text_display = ui.TextDisplay(content)
        container = ui.Container(text_display)
        view.add_item(container)
        
        await self.send_log(log_channel, view, webhook_url, 'moderation')


async def setup(bot):
    await bot.add_cog(LoggingCommands(bot))
