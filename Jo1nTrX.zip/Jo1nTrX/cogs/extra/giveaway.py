import discord
from discord.ext import commands, tasks
from discord import app_commands, ui
from Jo1nTrX.utils.embeds import create_embed
from Jo1nTrX.utils.helpers import send_loading_message, parse_time
from datetime import datetime, timedelta, timezone
import asyncio
import random
import re
import math
from Jo1nTrX.utils.component import bot_emoji, LayoutViewFactory

class GiveawayParticipantsPaginationLayoutView(ui.LayoutView):
    def __init__(self, participants, guild, author):
        super().__init__(timeout=300)
        self.participants = participants
        self.guild = guild
        self.author = author
        self.items_per_page = 10
        self.total_pages = max(1, math.ceil(len(participants) / self.items_per_page))
        self.current_page = 0
        self._setup_view()

    def _get_content(self, page):
        start = page * self.items_per_page
        end = start + self.items_per_page
        page_participants = self.participants[start:end]

        participant_list = []
        for i, user_id in enumerate(page_participants, start + 1):
            member = self.guild.get_member(user_id) if self.guild else None
            display_name = member.display_name if member else f"User {user_id}"
            participant_list.append(f"{i}. [{display_name}](https://discord.com/users/{user_id}) | {user_id}")

        content = f"""## {bot_emoji.giveaway} Giveaway Participants

{chr(10).join(participant_list)}

> Page {page + 1} of {self.total_pages} • Total: {len(self.participants)} participants"""
        return content

    def _rebuild_view(self):
        """Rebuild the view with current page state"""
        self.clear_items()
        
        content = self._get_content(self.current_page)
        text_display = ui.TextDisplay(content)

        first_btn = ui.Button(emoji=bot_emoji.double_left, style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=bot_emoji.left, style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=bot_emoji.delete, style=discord.ButtonStyle.red)
        next_btn = ui.Button(emoji=bot_emoji.right, style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=bot_emoji.double_right, style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)

        async def first_callback(inter: discord.Interaction):
            if self.author and inter.user.id != self.author.id:
                return await inter.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.current_page = 0
            self._rebuild_view()
            await inter.response.edit_message(view=self)

        async def prev_callback(inter: discord.Interaction):
            if self.author and inter.user.id != self.author.id:
                return await inter.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.current_page = max(0, self.current_page - 1)
            self._rebuild_view()
            await inter.response.edit_message(view=self)

        async def delete_callback(inter: discord.Interaction):
            if self.author and inter.user.id != self.author.id:
                return await inter.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await inter.response.defer()
            await inter.delete_original_response()

        async def next_callback(inter: discord.Interaction):
            if self.author and inter.user.id != self.author.id:
                return await inter.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.current_page = min(self.total_pages - 1, self.current_page + 1)
            self._rebuild_view()
            await inter.response.edit_message(view=self)

        async def last_callback(inter: discord.Interaction):
            if self.author and inter.user.id != self.author.id:
                return await inter.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            self.current_page = self.total_pages - 1
            self._rebuild_view()
            await inter.response.edit_message(view=self)

        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback

        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)

    def _setup_view(self):
        self._rebuild_view()

class EndedGiveawayLayoutView(ui.LayoutView):
    def __init__(self, giveaway_id, bot, giveaway_data=None, entry_count=0, winners=None, no_winner_reason=None):
        super().__init__(timeout=None)
        self.giveaway_id = giveaway_id
        self.bot = bot
        self.giveaway_data = giveaway_data
        self.entry_count = entry_count
        self.winners = winners or []
        self.no_winner_reason = no_winner_reason
        self._setup_view()

    def _get_content(self):
        if not self.giveaway_data:
            return f"## {bot_emoji.giveaway} Giveaway\n\n> Loading giveaway data..."
        
        giveaway = self.giveaway_data
        guild = self.bot.get_guild(giveaway['guild_id']) if self.bot else None
        host = guild.get_member(giveaway['host_id']) if guild and giveaway.get('host_id') else None
        
        arrow = "<:arw1_Jo1nTrX:1447806399697518593>"
        
        winner_mentions = []
        for winner_id in self.winners:
            winner_mentions.append(f"<@{winner_id}>")
        
        if len(winner_mentions) == 0:
            winner_text = f"No winners due to {self.no_winner_reason}" if self.no_winner_reason else "No winners"
            winner_label = "Winner"
        elif len(winner_mentions) == 1:
            winner_text = winner_mentions[0]
            winner_label = "Winner"
        else:
            winner_text = ", ".join(winner_mentions)
            winner_label = "Winners"
        
        parts = [f"## {bot_emoji.giveaway} **{giveaway['reward']}**"]
        parts.append("")
        parts.append(f"{arrow} **Entries**: {self.entry_count}")
        parts.append(f"{arrow} **Hosted by**: {host.mention if host else 'Unknown'}")
        parts.append(f"{arrow} **{winner_label}**: {winner_text}")
        parts.append("")
        parts.append("> Thanks for participating!")
        
        return "\n".join(parts)

    def _setup_view(self):
        content = self._get_content()
        text_display = ui.TextDisplay(content)
        gif_media = ui.MediaGallery(
            discord.MediaGalleryItem(media="https://cdn.discordapp.com/attachments/1441861254787633403/1447610996427325470/kuchtohoga.gif")
        )
        container = ui.Container(text_display, gif_media)
        self.add_item(container)


class GiveawayLayoutView(ui.LayoutView):
    def __init__(self, giveaway_id, bot, giveaway_data=None, entry_count=0):
        super().__init__(timeout=None)
        self.giveaway_id = giveaway_id
        self.bot = bot
        self.giveaway_data = giveaway_data
        self.entry_count = entry_count
        self._setup_view()

    def _get_content(self):
        if not self.giveaway_data:
            return f"## {bot_emoji.giveaway} Giveaway\n\n> Loading giveaway data..."
        
        giveaway = self.giveaway_data
        guild = self.bot.get_guild(giveaway['guild_id']) if self.bot else None
        host = guild.get_member(giveaway['host_id']) if guild and giveaway.get('host_id') else None
        
        now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
        end_time_utc = giveaway['end_time']
        if end_time_utc.tzinfo is None:
            end_time_utc = end_time_utc.replace(tzinfo=timezone.utc)
        else:
            end_time_utc = end_time_utc.astimezone(timezone.utc)
        
        if now_utc < end_time_utc and not giveaway['ended']:
            time_diff = end_time_utc - now_utc
            time_str = f"Ends in {self._format_time_delta(time_diff)}"
        else:
            time_diff = now_utc - end_time_utc
            time_str = f"Ended {self._format_time_delta(time_diff)} ago"

        parts = [f"## {bot_emoji.giveaway} **{giveaway['reward']}**"]
        parts.append("")
        parts.append(f"{bot_emoji.arrow} **Entries**: {self.entry_count}")
        parts.append(f"{bot_emoji.arrow} **Ends**: {time_str}")
        parts.append(f"{bot_emoji.arrow} **Hosted by**: {host.mention if host else 'Unknown'}")
        parts.append(f"{bot_emoji.arrow} **Winners**: {giveaway['winner_count']}")
        
        if giveaway.get('requirement_type'):
            req_type = giveaway['requirement_type']
            req_value = giveaway.get('requirement_value')
            if req_type == "message_count":
                parts.append(f"{bot_emoji.arrow} **Requirement**: {req_value}+ messages")
            elif req_type == "invite_count":
                parts.append(f"{bot_emoji.arrow} **Requirement**: {req_value}+ invites")
            elif req_type == "role_required":
                parts.append(f"{bot_emoji.arrow} **Requirement**: Required role")
            elif req_type == "must_be_in_vc":
                parts.append(f"{bot_emoji.arrow} **Requirement**: Must be in VC")
        
        if giveaway['ended']:
            parts.append("")
            parts.append("> Thanks for participating!")
        elif giveaway.get('paused'):
            parts.append("")
            parts.append("> ⏸️ **Status**: Paused")
        else:
            parts.append("")
            parts.append("> Click the join button below to participate!")
        
        return "\n".join(parts)

    def _format_time_delta(self, delta):
        days = delta.days
        hours, remainder = divmod(delta.seconds, 3600)
        minutes, _ = divmod(remainder, 60)
        if days > 0:
            return f"{days}d {hours}h {minutes}m"
        elif hours > 0:
            return f"{hours}h {minutes}m"
        else:
            return f"{minutes}m"

    def _setup_view(self):
        content = self._get_content()
        text_display = ui.TextDisplay(content)

        join_btn = ui.Button(
            label="Join",
            emoji=bot_emoji.giveaway_react,
            style=discord.ButtonStyle.green,
            custom_id=f"giveaway_join_{self.giveaway_id}"
        )
        participants_btn = ui.Button(
            label="Participants",
            emoji=bot_emoji.member,
            style=discord.ButtonStyle.secondary,
            custom_id=f"giveaway_participants_{self.giveaway_id}"
        )

        async def join_callback(interaction: discord.Interaction):
            await self._join_giveaway(interaction)

        async def participants_callback(interaction: discord.Interaction):
            await self._view_participants(interaction)

        join_btn.callback = join_callback
        participants_btn.callback = participants_callback

        button_row = ui.ActionRow(join_btn, participants_btn)
        gif_media = ui.MediaGallery(
            discord.MediaGalleryItem(media="https://cdn.discordapp.com/attachments/1441861254787633403/1447610996427325470/kuchtohoga.gif")
        )
        container = ui.Container(text_display, gif_media, button_row)
        self.add_item(container)

    async def _join_giveaway(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
        except discord.InteractionResponded:
            return
        except Exception as e:
            print(f"Failed to defer interaction: {e}")
            return

        try:
            giveaway = await self.bot.db.get_giveaway(self.giveaway_id)
            if not giveaway:
                await interaction.followup.send("This giveaway no longer exists.", ephemeral=True)
                return

            if giveaway['ended']:
                await interaction.followup.send("This giveaway has already ended.", ephemeral=True)
                return

            if giveaway['paused']:
                await interaction.followup.send("This giveaway is currently paused.", ephemeral=True)
                return

            if interaction.guild:
                is_user_blacklisted = await self.bot.db.is_user_giveaway_blacklisted(interaction.guild.id, interaction.user.id)
                is_role_blacklisted = False

                if isinstance(interaction.user, discord.Member) and interaction.user.roles:
                    for role in interaction.user.roles:
                        if role and hasattr(role, 'id'):
                            if await self.bot.db.is_role_giveaway_blacklisted(interaction.guild.id, role.id):
                                is_role_blacklisted = True
                                break

                if is_user_blacklisted or is_role_blacklisted:
                    await interaction.followup.send("You are blacklisted from participating in giveaways.", ephemeral=True)
                    return

            already_joined = await self.bot.db.has_joined_giveaway(self.giveaway_id, interaction.user.id)
            if already_joined:
                await interaction.followup.send("You have already joined this giveaway!", ephemeral=True)
                return

            if giveaway.get('requirement_type'):
                req_type = giveaway['requirement_type']
                req_value = giveaway.get('requirement_value')

                if req_type == "message_count":
                    try:
                        required_count = int(req_value)
                        user_stats = await self.bot.db.get_user_message_stats(interaction.guild.id, interaction.user.id)
                        user_message_count = user_stats.get('total', 0) if user_stats else 0
                        if user_message_count < required_count:
                            await interaction.followup.send(f"You need at least {required_count} messages. You have {user_message_count}.", ephemeral=True)
                            return
                    except (ValueError, TypeError):
                        await interaction.followup.send("Error validating message count requirement.", ephemeral=True)
                        return

                elif req_type == "invite_count":
                    try:
                        required_invites = int(req_value)
                        user_invites = await self.bot.db.get_user_invites(interaction.guild.id, interaction.user.id)
                        if user_invites:
                            total_joins = user_invites.get('total_joins', 0) or user_invites.get('joins', 0) or 0
                            rejoins = user_invites.get('rejoins', 0) or 0
                            fake = user_invites.get('fake', 0) or 0
                            left = user_invites.get('left', 0) or 0
                            actual_invites = max(0, total_joins - (rejoins + fake + left))
                        else:
                            actual_invites = 0
                        if actual_invites < required_invites:
                            await interaction.followup.send(f"You need at least {required_invites} invites. You have {actual_invites}.", ephemeral=True)
                            return
                    except (ValueError, TypeError):
                        await interaction.followup.send("Error validating invite count requirement.", ephemeral=True)
                        return

                elif req_type == "role_required":
                    try:
                        required_role_id = int(req_value)
                        required_role = interaction.guild.get_role(required_role_id)
                        if not required_role or required_role not in interaction.user.roles:
                            role_name = required_role.name if required_role else "required role"
                            await interaction.followup.send(f"You need the {role_name} role to join.", ephemeral=True)
                            return
                    except (ValueError, TypeError):
                        await interaction.followup.send("Error validating role requirement.", ephemeral=True)
                        return

                elif req_type == "must_be_in_vc":
                    if not interaction.user.voice:
                        await interaction.followup.send("You must be in a voice channel to join.", ephemeral=True)
                        return
                    required_channel_id = int(req_value)
                    if interaction.user.voice.channel.id != required_channel_id:
                        required_channel = interaction.guild.get_channel(required_channel_id)
                        channel_name = required_channel.name if required_channel else "Required VC"
                        await interaction.followup.send(f"You must be in the {channel_name} voice channel.", ephemeral=True)
                        return

            await self.bot.db.join_giveaway(self.giveaway_id, interaction.user.id)
            await interaction.followup.send("You have successfully joined the giveaway!", ephemeral=True)

            try:
                entry_count = await self.bot.db.get_giveaway_entries(self.giveaway_id)
                new_view = GiveawayLayoutView(self.giveaway_id, self.bot, giveaway, entry_count)
                if interaction.message:
                    await interaction.message.edit(view=new_view)
            except Exception as update_error:
                print(f"Error updating giveaway: {update_error}")

        except Exception as e:
            print(f"Error in giveaway join: {e}")
            try:
                await interaction.followup.send(f"Error joining giveaway: {str(e)}", ephemeral=True)
            except Exception as followup_error:
                print(f"Failed to send followup error: {followup_error}")

    async def _view_participants(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
        except discord.InteractionResponded:
            return
        except Exception as e:
            print(f"Failed to defer participants interaction: {e}")
            return

        try:
            participants = await self.bot.db.get_giveaway_participants(self.giveaway_id)

            if not participants:
                await interaction.followup.send("No participants yet!", ephemeral=True)
                return

            view = GiveawayParticipantsPaginationLayoutView(participants, interaction.guild, interaction.user)
            await interaction.followup.send(view=view, ephemeral=True)

        except Exception as e:
            print(f"Error in view participants: {e}")
            try:
                await interaction.followup.send(f"Error viewing participants: {str(e)}", ephemeral=True)
            except Exception as followup_error:
                print(f"Failed to send participants followup error: {followup_error}")


class GiveawayCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.check_giveaways.start()
        self.refresh_giveaway_embeds.start()  # Start the auto-refresh task

    async def cog_unload(self):
        self.check_giveaways.cancel()
        self.refresh_giveaway_embeds.cancel()  # Cancel the auto-refresh task

    async def has_giveaway_manager_permission(self, member, guild_id):
        """Check if user has permission to manage giveaways (manage_guild or giveaway manager role)"""
        # Check if user has manage_guild permission
        if member.guild_permissions.manage_guild:
            return True
        
        # Check if user has any giveaway manager roles
        manager_roles = await self.bot.db.get_giveaway_manager_roles(guild_id)
        user_role_ids = [role.id for role in member.roles]
        
        return any(role_id in manager_roles for role_id in user_role_ids)

    @tasks.loop(minutes=1)
    async def check_giveaways(self):
        """Check for ended giveaways"""
        try:
            ended_giveaways = await self.bot.db.get_ended_giveaways()
            for giveaway in ended_giveaways:
                await self.end_giveaway_automatically(giveaway)
        except Exception as e:
            print(f"Error checking giveaways: {e}")

    @check_giveaways.before_loop
    async def before_check_giveaways(self):
        await self.bot.wait_until_ready()

    @tasks.loop(minutes=5)
    async def refresh_giveaway_embeds(self):
        """Auto-refresh all ongoing giveaway embeds every 5 minutes to ensure time sync"""
        try:
            # Get all active giveaways (not ended)
            active_giveaways = await self.bot.db.get_all_active_giveaways()

            refreshed_count = 0
            for giveaway in active_giveaways:
                try:
                    # Skip if giveaway is already ended
                    if giveaway['ended']:
                        continue

                    guild = self.bot.get_guild(giveaway['guild_id'])
                    if not guild:
                        continue

                    channel = guild.get_channel(giveaway['channel_id'])
                    if not channel:
                        continue

                    if not giveaway.get('message_id'):
                        continue

                    try:
                        message = await channel.fetch_message(giveaway['message_id'])
                        # Get current entry count
                        entry_count = await self.bot.db.get_giveaway_entries(giveaway['id'])
                        
                        # Create the giveaway with component v2 styling
                        view = GiveawayLayoutView(giveaway['id'], self.bot, giveaway, entry_count)
                        
                        # Edit the message with component v2 view
                        await message.edit(view=view)
                        refreshed_count += 1
                    except discord.NotFound:
                        # Message was deleted
                        pass
                except Exception as e:
                    print(f"Error refreshing giveaway {giveaway['id']}: {e}")

            if refreshed_count > 0:
                print(f"Refreshed {refreshed_count} giveaway embeds")
        except Exception as e:
            print(f"Error in refresh giveaway embeds task: {e}")

    @refresh_giveaway_embeds.before_loop
    async def before_refresh_giveaway_embeds(self):
        await self.bot.wait_until_ready()

    async def end_giveaway_automatically(self, giveaway):
        """End a giveaway and select winners"""
        try:
            guild = self.bot.get_guild(giveaway['guild_id'])
            if not guild:
                return

            # Get all participants
            participants = await self.bot.db.get_giveaway_participants(giveaway['id'])

            if not participants:
                # No participants, mark as ended
                await self.bot.db.end_giveaway(giveaway['id'])
                
                # Update the giveaway message with no winners
                channel = guild.get_channel(giveaway['channel_id'])
                if channel and giveaway['message_id']:
                    try:
                        message = await channel.fetch_message(giveaway['message_id'])
                        giveaway['ended'] = True
                        view = EndedGiveawayLayoutView(giveaway['id'], self.bot, giveaway, 0, [], "no participants")
                        await message.edit(view=view)
                    except:
                        pass
                return

            # Select random winners
            winners_count = min(giveaway['winner_count'], len(participants))
            winners = random.sample(participants, winners_count)

            # Store winners in database
            await self.bot.db.set_giveaway_winners(giveaway['id'], winners)
            await self.bot.db.end_giveaway(giveaway['id'])

            # Update the giveaway with component v2 styling
            channel = guild.get_channel(giveaway['channel_id'])
            if channel and giveaway['message_id']:
                try:
                    message = await channel.fetch_message(giveaway['message_id'])

                    # Update with ended giveaway view (component v2)
                    entry_count = len(participants)
                    giveaway['ended'] = True
                    view = EndedGiveawayLayoutView(giveaway['id'], self.bot, giveaway, entry_count, winners)
                    await message.edit(view=view)

                    # Announce winners with enhanced message
                    winner_mentions = [f"<@{winner_id}>" for winner_id in winners]
                    host_mention = f"<@{giveaway['host_id']}>"

                    if len(winners) == 1:
                        await channel.send(f"🎉 Congratulations {winner_mentions[0]}, you won **{giveaway['reward']}** hosted by {host_mention}!")
                    else:
                        await channel.send(f"🎉 Congratulations {', '.join(winner_mentions)}, you won **{giveaway['reward']}** hosted by {host_mention}!")

                except:
                    pass

        except Exception as e:
            print(f"Error ending giveaway automatically: {e}")

    @commands.hybrid_command(name='gstart', aliases=['gwys', 'gwy'])
    @app_commands.describe(
        time='Duration of the giveaway (e.g., 1h, 30m, 1d)', 
        winners='Number of winners', 
        reward='The giveaway reward',
        requirements='[Optional] Requirement type (message_count, invite_count, role_required, must_be_in_vc)',
        value='[Optional] Value for the requirement (number for counts, role name/mention for role, VC channel ID for VC)'
    )
    @app_commands.choices(requirements=[
        app_commands.Choice(name="Message Count", value="message_count"),
        app_commands.Choice(name="Invite Count", value="invite_count"),
        app_commands.Choice(name="Role Required", value="role_required"),
        app_commands.Choice(name="Must be in VC", value="must_be_in_vc")
    ])
    async def gstart(self, ctx, time: str, winners: int, reward: str, requirements: str = None, value: str = None):
        """Start a new giveaway"""
        # Check permissions
        if not await self.has_giveaway_manager_permission(ctx.author, ctx.guild.id):
            view = LayoutViewFactory.create(
                title="Permission Denied",
                description="You need either **Manage Server** permission or a **Giveaway Manager** role to start giveaways."
            )
            await ctx.send(view=view)
            return
        
        loading_msg = await send_loading_message(ctx, "starting giveaway")

        # Schedule deletion of user's command message
        async def delete_command_message():
            import asyncio
            await asyncio.sleep(2)
            try:
                await ctx.message.delete()
            except:
                pass  # Ignore if message is already deleted or no permission

        import asyncio
        asyncio.create_task(delete_command_message())

        try:
            # Parse time
            duration = parse_time(time)
            if not duration:
                view = LayoutViewFactory.create(
                    title="Invalid Time Format",
                    description="Please use formats like: 1h, 30m, 1d, 2h30m"
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            if winners < 1:
                view = LayoutViewFactory.create(
                    title="Invalid Winner Count",
                    description="Winner count must be at least 1."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            # Validate requirements if provided
            requirement_value_processed = None
            if requirements:
                if requirements == "message_count" or requirements == "invite_count":
                    if not value or not value.isdigit():
                        view = LayoutViewFactory.create(
                            title="Invalid Requirement Value",
                            description=f"For {requirements.replace('_', ' ')}, please provide a valid number."
                        )
                        await loading_msg.edit(content=None, embed=None, view=view)
                        return
                    requirement_value_processed = value
                elif requirements == "role_required":
                    if not value:
                        view = LayoutViewFactory.create(
                            title="Missing Role",
                            description="Please specify a role name or mention for the role requirement."
                        )
                        await loading_msg.edit(content=None, embed=None, view=view)
                        return

                    # Try to find the role
                    role = None
                    if value.startswith('<@&') and value.endswith('>'):
                        # Role mention
                        role_id = int(value[3:-1])
                        role = ctx.guild.get_role(role_id)
                    else:
                        # Role name search
                        role = discord.utils.get(ctx.guild.roles, name=value)

                    if not role:
                        view = LayoutViewFactory.create(
                            title="Role Not Found",
                            description=f"Could not find role: {value}"
                        )
                        await loading_msg.edit(content=None, embed=None, view=view)
                        return
                    requirement_value_processed = str(role.id)
                elif requirements == "must_be_in_vc":
                    if not value:
                        view = LayoutViewFactory.create(
                            title="Missing VC Channel",
                            description="Please provide a voice channel ID for the VC requirement."
                        )
                        await loading_msg.edit(content=None, embed=None, view=view)
                        return

                    # Try to find the voice channel
                    try:
                        channel_id = int(value)
                        channel = ctx.guild.get_channel(channel_id)
                        if not channel or not isinstance(channel, discord.VoiceChannel):
                            view = LayoutViewFactory.create(
                                title="Voice Channel Not Found",
                                description=f"Could not find voice channel with ID: {value}"
                            )
                            await loading_msg.edit(content=None, embed=None, view=view)
                            return
                        requirement_value_processed = str(channel_id)
                    except ValueError:
                        view = LayoutViewFactory.create(
                            title="Invalid Channel ID",
                            description="Please provide a valid voice channel ID."
                        )
                        await loading_msg.edit(content=None, embed=None, view=view)
                        return

            # Create giveaway in database
            # IMPORTANT: Use UTC for end_time to match database timezone configuration ('+00:00')
            # This ensures consistent time comparisons with UTC_TIMESTAMP() in SQL queries
            end_time = datetime.utcnow() + timedelta(seconds=duration)
            giveaway_id = await self.bot.db.create_giveaway(
                guild_id=ctx.guild.id,
                channel_id=ctx.channel.id,
                host_id=ctx.author.id,
                reward=reward,
                winner_count=winners,
                end_time=end_time,
                requirement_type=requirements,
                requirement_value=requirement_value_processed
            )

            # Create component v2 view with buttons inside
            giveaway_data = {
                'guild_id': ctx.guild.id,
                'host_id': ctx.author.id,
                'reward': reward,
                'winner_count': winners,
                'end_time': end_time,
                'ended': False,
                'paused': False,
                'requirement_type': requirements,
                'requirement_value': requirement_value_processed
            }
            view = GiveawayLayoutView(giveaway_id, self.bot, giveaway_data, 0)

            # Send giveaway message (component v2 - view only)
            giveaway_message = await ctx.send(view=view)

            # Update database with message ID (preserve end_time to fix MySQL ON UPDATE trigger bug)
            await self.bot.db.update_giveaway_message_id(giveaway_id, giveaway_message.id, preserve_end_time=end_time)

            # Edit loading message
            view = LayoutViewFactory.create(
                title="<:Jo1nTrX_giveaway:1411471234922971298> Giveaway Started",
                description=f"Giveaway started successfully!\n[Jump to giveaway]({giveaway_message.jump_url})"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

            # Auto-delete success message after 2 seconds
            import asyncio
            await asyncio.sleep(2)
            try:
                await loading_msg.delete()
            except:
                pass  # Ignore if message is already deleted

        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to start giveaway: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @commands.hybrid_command(name='gend')
    @app_commands.describe(message_id='The message ID of the giveaway to end')
    async def gend(self, ctx, message_id: str):
        """End a giveaway early"""
        loading_msg = await send_loading_message(ctx, "ending giveaway")

        try:
            # Get giveaway by message ID
            giveaway = await self.bot.db.get_giveaway_by_message(ctx.guild.id, int(message_id))
            if not giveaway:
                view = LayoutViewFactory.create(
                    title="Giveaway Not Found",
                    description="No active giveaway found with that message ID."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            if giveaway['ended']:
                view = LayoutViewFactory.create(
                    title="Already Ended",
                    description="This giveaway has already ended."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            # Check permissions - user needs manage_guild OR (giveaway manager role AND is the host)
            has_manage = ctx.author.guild_permissions.manage_guild
            is_host = giveaway['host_id'] == ctx.author.id
            has_manager_role = await self.has_giveaway_manager_permission(ctx.author, ctx.guild.id)
            
            if not (has_manage or (has_manager_role and is_host)):
                view = LayoutViewFactory.create(
                    title="Permission Denied",
                    description="You need either **Manage Server** permission or be the **giveaway host** with a **Giveaway Manager** role to end this giveaway."
                )
                await ctx.send(view=view)
                return

            # End the giveaway
            await self.end_giveaway_automatically(giveaway)

            view = LayoutViewFactory.create(
                title="<:Jo1nTrX_giveaway:1411471234922971298> Giveaway Ended",
                description="Giveaway ended successfully!"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

        except ValueError:
            view = LayoutViewFactory.create(
                title="Invalid Message ID",
                description="Please provide a valid message ID."
            )
            await loading_msg.edit(content=None, embed=None, view=view)
        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to end giveaway: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @commands.hybrid_command(name='gbulk')
    @app_commands.describe(time='Duration of the giveaway', count='Number of giveaways to create', rewards='Comma-separated rewards (e.g., "nitro, robux, steam key")')
    async def gbulk(self, ctx, time: str, count: int, *, rewards: str):
        """Start multiple individual giveaways with separate rewards"""
        # Check permissions
        if not await self.has_giveaway_manager_permission(ctx.author, ctx.guild.id):
            view = LayoutViewFactory.create(
                title="Permission Denied",
                description="You need either **Manage Server** permission or a **Giveaway Manager** role to start giveaways."
            )
            await ctx.send(view=view)
            return
        
        loading_msg = await send_loading_message(ctx, "starting bulk giveaways")

        try:
            # Parse time
            duration = parse_time(time)
            if not duration:
                view = LayoutViewFactory.create(
                    title="Invalid Time Format",
                    description="Please use formats like: 1h, 30m, 1d, 2h30m"
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            # Split rewards by comma and strip whitespace
            reward_list = [reward.strip() for reward in rewards.split(',')]
            if len(reward_list) != count:
                view = LayoutViewFactory.create(
                    title="Reward Count Mismatch",
                    description=f"**Keep the reward count as same as giveaway count!\nUse comma `, ` to separate between rewards!**\n\nYou specified {count} giveaways but provided {len(reward_list)} rewards."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            end_time = datetime.utcnow() + timedelta(seconds=duration)
            giveaway_messages = []

            # Create individual giveaway for each reward
            for reward in reward_list:
                # Create giveaway in database
                giveaway_id = await self.bot.db.create_giveaway(
                    guild_id=ctx.guild.id,
                    channel_id=ctx.channel.id,
                    host_id=ctx.author.id,
                    reward=reward,
                    winner_count=1,  # Each individual giveaway has 1 winner
                    end_time=end_time
                )

                # Create component v2 view with buttons inside
                giveaway_data = {
                    'guild_id': ctx.guild.id,
                    'host_id': ctx.author.id,
                    'reward': reward,
                    'winner_count': 1,
                    'end_time': end_time,
                    'ended': False,
                    'paused': False
                }
                view = GiveawayLayoutView(giveaway_id, self.bot, giveaway_data, 0)

                # Send individual giveaway message (component v2 - view only)
                giveaway_message = await ctx.send(view=view)
                giveaway_messages.append(giveaway_message)

                # Update database with message ID (preserve end_time to fix MySQL ON UPDATE trigger bug)
                await self.bot.db.update_giveaway_message_id(giveaway_id, giveaway_message.id, preserve_end_time=end_time)

            # Create success message with links to all giveaways
            giveaway_links = [f"[{i+1}]({msg.jump_url})" for i, msg in enumerate(giveaway_messages)]
            links_text = " • ".join(giveaway_links)

            view = LayoutViewFactory.create(
                title="<:Jo1nTrX_giveaway:1411471234922971298> Bulk Giveaways Started",
                description=f"Created {len(reward_list)} individual giveaways successfully!\n\n**Jump to giveaways:** {links_text}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

            # Auto-delete success message after 2 seconds
            import asyncio
            await asyncio.sleep(2)
            try:
                await loading_msg.delete()
            except:
                pass  # Ignore if message is already deleted

        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to start bulk giveaways: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @commands.hybrid_command(name='greroll')
    @app_commands.describe(
        message_id='The message ID of the giveaway to reroll',
        user_id='[Optional] Specific user ID(s) to reroll (comma-separated for multiple)',
        reason='[Optional] Reason for the reroll'
    )
    async def greroll(self, ctx, message_id: str = None, user_id: str = None, *, reason: str = None):
        """Reroll a giveaway"""
        loading_msg = await send_loading_message(ctx, "rerolling giveaway")

        try:
            # Check if user replied to a giveaway message
            giveaway = None
            if message_id is None and ctx.message.reference:
                # User replied to a message, get that message ID
                replied_message = ctx.message.reference.resolved or await ctx.channel.fetch_message(ctx.message.reference.message_id)
                message_id = str(replied_message.id)
                giveaway = await self.bot.db.get_giveaway_by_message(ctx.guild.id, int(message_id))
                
                if not giveaway:
                    view = LayoutViewFactory.create(
                        title="Not a Giveaway",
                        description="The message you replied to is not a giveaway message."
                    )
                    await loading_msg.edit(content=None, embed=None, view=view)
                    return
            elif message_id is None:
                view = LayoutViewFactory.create(
                    title="Missing Message ID",
                    description="Please provide a giveaway message ID or reply to a giveaway message."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return
            else:
                giveaway = await self.bot.db.get_giveaway_by_message(ctx.guild.id, int(message_id))
            
            if not giveaway or not giveaway['ended']:
                view = LayoutViewFactory.create(
                    title="Giveaway Not Found",
                    description="No ended giveaway found with that message ID."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            # Check permissions - user needs manage_guild OR (giveaway manager role AND is the host)
            has_manage = ctx.author.guild_permissions.manage_guild
            is_host = giveaway['host_id'] == ctx.author.id
            has_manager_role = await self.has_giveaway_manager_permission(ctx.author, ctx.guild.id)
            
            if not (has_manage or (has_manager_role and is_host)):
                view = LayoutViewFactory.create(
                    title="Permission Denied",
                    description="You need either **Manage Server** permission or be the **giveaway host** with a **Giveaway Manager** role to reroll this giveaway."
                )
                await ctx.send(view=view)
                return

            # Get participants and current winners
            participants = await self.bot.db.get_giveaway_participants(giveaway['id'])
            current_winners = await self.bot.db.get_giveaway_winners(giveaway['id'])

            # Parse specific user IDs if provided
            users_to_reroll = []
            if user_id:
                try:
                    user_ids = [int(uid.strip()) for uid in user_id.split(',')]
                    # Validate that specified users are current winners
                    invalid_users = [uid for uid in user_ids if uid not in current_winners]
                    if invalid_users:
                        view = LayoutViewFactory.create(
                            title="Invalid Users",
                            description=f"The following user(s) are not current winners: {', '.join(f'<@{uid}>' for uid in invalid_users)}"
                        )
                        await loading_msg.edit(content=None, embed=None, view=view)
                        return
                    users_to_reroll = user_ids
                except ValueError:
                    view = LayoutViewFactory.create(
                        title="Invalid User IDs",
                        description="Please provide valid user IDs separated by commas."
                    )
                    await loading_msg.edit(content=None, embed=None, view=view)
                    return
            else:
                # If no specific users provided, reroll all winners
                users_to_reroll = current_winners

            # Get available participants (excluding current winners not being rerolled)
            available_participants = [p for p in participants if p not in current_winners]

            if len(available_participants) < len(users_to_reroll):
                view = LayoutViewFactory.create(
                    title="Insufficient Participants",
                    description=f"Not enough available participants to reroll {len(users_to_reroll)} winner(s). Available: {len(available_participants)}"
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            # Select new winners for users being rerolled
            new_selected_winners = random.sample(available_participants, len(users_to_reroll))

            # Create final winner list (keep non-rerolled winners + new winners)
            final_winners = [w for w in current_winners if w not in users_to_reroll] + new_selected_winners

            # Update winners
            await self.bot.db.set_giveaway_winners(giveaway['id'], final_winners)

            # Update giveaway message with component v2 styling
            channel = ctx.guild.get_channel(giveaway['channel_id'])
            if channel and giveaway['message_id']:
                try:
                    message = await channel.fetch_message(giveaway['message_id'])
                    entry_count = len(participants)
                    view = EndedGiveawayLayoutView(giveaway['id'], self.bot, giveaway, entry_count, final_winners)
                    await message.edit(view=view)
                except:
                    pass

            # Announce new winners with enhanced message
            new_winner_mentions = [f"<@{winner_id}>" for winner_id in new_selected_winners]
            host_mention = f"<@{giveaway['host_id']}>"

            # Create message based on whether specific users were rerolled
            if user_id:
                rerolled_mentions = [f"<@{uid}>" for uid in users_to_reroll]
                if len(new_selected_winners) == 1:
                    message_text = f"🔄 Reroll: {rerolled_mentions[0]} has been replaced by {new_winner_mentions[0]} for **{giveaway['reward']}** hosted by {host_mention}!"
                else:
                    message_text = f"🔄 Reroll: {', '.join(rerolled_mentions)} have been replaced by {', '.join(new_winner_mentions)} for **{giveaway['reward']}** hosted by {host_mention}!"
            else:
                if len(new_selected_winners) == 1:
                    message_text = f"🎉 New winner: Congratulations {new_winner_mentions[0]}, you won **{giveaway['reward']}** hosted by {host_mention}!"
                else:
                    message_text = f"🎉 New winners: Congratulations {', '.join(new_winner_mentions)}, you won **{giveaway['reward']}** hosted by {host_mention}!"

            # Add reason if provided
            if reason:
                message_text += f"\n**Reason:** {reason}"

            await ctx.send(message_text)

            view = LayoutViewFactory.create(
                title="<:Jo1nTrX_giveaway:1411471234922971298> Giveaway Rerolled",
                description="Giveaway rerolled successfully!"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

        except ValueError:
            view = LayoutViewFactory.create(
                title="Invalid Message ID",
                description="Please provide a valid message ID."
            )
            await loading_msg.edit(content=None, embed=None, view=view)
        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to reroll giveaway: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @commands.hybrid_command(name='gpause')
    @app_commands.describe(message_id='The message ID of the giveaway to pause/unpause')
    @commands.has_permissions(manage_guild=True)
    async def gpause(self, ctx, message_id: str):
        """Pause or unpause a giveaway"""
        loading_msg = await send_loading_message(ctx, "toggling giveaway pause")

        try:
            giveaway = await self.bot.db.get_giveaway_by_message(ctx.guild.id, int(message_id))
            if not giveaway:
                view = LayoutViewFactory.create(
                    title="Giveaway Not Found",
                    description="No giveaway found with that message ID."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            if giveaway['ended']:
                view = LayoutViewFactory.create(
                    title="Giveaway Ended",
                    description="Cannot pause an ended giveaway."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            # Toggle pause state
            new_state = not giveaway['paused']
            await self.bot.db.pause_giveaway(giveaway['id'], new_state)

            # Update giveaway message with component v2 styling
            channel = ctx.guild.get_channel(giveaway['channel_id'])
            if channel and giveaway['message_id']:
                try:
                    message = await channel.fetch_message(giveaway['message_id'])
                    entry_count = await self.bot.db.get_giveaway_entries(giveaway['id'])
                    giveaway['paused'] = new_state
                    giveaway_view = GiveawayLayoutView(giveaway['id'], self.bot, giveaway, entry_count)
                    await message.edit(view=giveaway_view)
                except:
                    pass

            action = "paused" if new_state else "resumed"
            view = LayoutViewFactory.create(
                title=f"<:Jo1nTrX_giveaway:1411471234922971298> Giveaway {action.title()}",
                description=f"Giveaway {action} successfully!"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

        except ValueError:
            view = LayoutViewFactory.create(
                title="Invalid Message ID",
                description="Please provide a valid message ID."
            )
            await loading_msg.edit(content=None, embed=None, view=view)
        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to pause giveaway: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @commands.hybrid_command(name='glist')
    async def glist(self, ctx):
        """List all active giveaways in the server"""
        loading_msg = await send_loading_message(ctx, "fetching active giveaways")

        try:
            giveaways = await self.bot.db.get_active_giveaways(ctx.guild.id)

            if not giveaways:
                view = LayoutViewFactory.create(
                    title="<:Jo1nTrX_giveaway:1411471234922971298> Active Giveaways",
                    description="No active giveaways in this server."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            # Create giveaway list
            giveaway_list = []
            for giveaway in giveaways[:10]:  # Show first 10
                channel = ctx.guild.get_channel(giveaway['channel_id'])
                channel_name = channel.name if channel else "Unknown Channel"

                status = ""
                if giveaway['paused']:
                    status = " (Paused)"
                elif giveaway['ended']:
                    status = " (Ended)"

                giveaway_list.append(
                    f"**{giveaway['reward']}** in #{channel_name}{status}\n"
                    f"ID: {giveaway['message_id']} • Winners: {giveaway['winner_count']}"
                )

            description = "\n\n".join(giveaway_list)
            if len(giveaways) > 10:
                description += f"\n\n> Showing 10 of {len(giveaways)} giveaways"

            view = LayoutViewFactory.create(
                title="<:Jo1nTrX_giveaway:1411471234922971298> Active Giveaways",
                description=description
            )

            await loading_msg.edit(content=None, embed=None, view=view)

        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to fetch giveaways: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @commands.hybrid_group(name='gblacklist')
    @commands.has_permissions(manage_guild=True)
    async def gblacklist(self, ctx):
        """Manage giveaway blacklist"""
        if ctx.invoked_subcommand is None:
            view = LayoutViewFactory.create(
                title="Giveaway Blacklist Commands",
                description="• `gblacklist add <user/role>` - Add user or role to blacklist\n"
                           "• `gblacklist remove <user/role>` - Remove user or role from blacklist\n"
                           "• `gblacklist list` - View blacklisted users and roles\n"
                           "• `gblacklist clear` - Clear all blacklisted users and roles"
            )
            await ctx.send(view=view)

    @gblacklist.command(name='add')
    @app_commands.describe(target='User or role to blacklist')
    async def gblacklist_add(self, ctx, target: str):
        """Add a user or role to the giveaway blacklist"""
        loading_msg = await send_loading_message(ctx, "adding to giveaway blacklist")

        try:
            # Try to parse as user mention or ID
            user_id = None
            role_id = None

            # Check if it's a user mention
            user_match = re.match(r'<@!?(\d+)>', target)
            if user_match:
                user_id = int(user_match.group(1))
                user = ctx.guild.get_member(user_id)
                if not user:
                    view = LayoutViewFactory.create(
                        title="User Not Found",
                        description="User not found in this server."
                    )
                    await loading_msg.edit(content=None, embed=None, view=view)
                    return
            else:
                # Check if it's a role mention
                role_match = re.match(r'<@&(\d+)>', target)
                if role_match:
                    role_id = int(role_match.group(1))
                    role = ctx.guild.get_role(role_id)
                    if not role:
                        view = LayoutViewFactory.create(
                            title="Role Not Found",
                            description="Role not found in this server."
                        )
                        await loading_msg.edit(content=None, embed=None, view=view)
                        return
                else:
                    # Try to parse as ID
                    try:
                        target_id = int(target)
                        user = ctx.guild.get_member(target_id)
                        role = ctx.guild.get_role(target_id)

                        if user:
                            user_id = target_id
                        elif role:
                            role_id = target_id
                        else:
                            view = LayoutViewFactory.create(
                                title="Invalid Target",
                                description="Please mention a user or role, or provide a valid ID."
                            )
                            await loading_msg.edit(content=None, embed=None, view=view)
                            return
                    except ValueError:
                        view = LayoutViewFactory.create(
                            title="Invalid Format",
                            description="Please mention a user or role, or provide a valid ID."
                        )
                        await loading_msg.edit(content=None, embed=None, view=view)
                        return

            # Add to blacklist
            if user_id:
                await self.bot.db.add_giveaway_blacklist(ctx.guild.id, user_id=user_id)
                user = ctx.guild.get_member(user_id)
                view = LayoutViewFactory.create(
                    title="User Blacklisted",
                    description=f"{user.mention if user else f'<@{user_id}>'} has been added to the giveaway blacklist."
                )
            else:
                await self.bot.db.add_giveaway_blacklist(ctx.guild.id, role_id=role_id)
                role = ctx.guild.get_role(role_id)
                view = LayoutViewFactory.create(
                    title="Role Blacklisted",
                    description=f"{role.mention if role else f'<@&{role_id}>'} has been added to the giveaway blacklist."
                )

            await loading_msg.edit(content=None, embed=None, view=view)

        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to add to blacklist: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @gblacklist.command(name='remove')
    @app_commands.describe(target='User or role to remove from blacklist')
    async def gblacklist_remove(self, ctx, target: str):
        """Remove a user or role from the giveaway blacklist"""
        loading_msg = await send_loading_message(ctx, "removing from giveaway blacklist")

        try:
            # Similar parsing logic as add command
            user_id = None
            role_id = None

            user_match = re.match(r'<@!?(\d+)>', target)
            if user_match:
                user_id = int(user_match.group(1))
            else:
                role_match = re.match(r'<@&(\d+)>', target)
                if role_match:
                    role_id = int(role_match.group(1))
                else:
                    try:
                        target_id = int(target)
                        # Check which type it is in blacklist
                        is_user_blacklisted = await self.bot.db.is_user_giveaway_blacklisted(ctx.guild.id, target_id)
                        is_role_blacklisted = await self.bot.db.is_role_giveaway_blacklisted(ctx.guild.id, target_id)

                        if is_user_blacklisted:
                            user_id = target_id
                        elif is_role_blacklisted:
                            role_id = target_id
                        else:
                            view = LayoutViewFactory.create(
                                title="Not Blacklisted",
                                description="This user or role is not in the blacklist."
                            )
                            await loading_msg.edit(content=None, embed=None, view=view)
                            return
                    except ValueError:
                        view = LayoutViewFactory.create(
                            title="Invalid Format",
                            description="Please mention a user or role, or provide a valid ID."
                        )
                        await loading_msg.edit(content=None, embed=None, view=view)
                        return

            # Remove from blacklist
            if user_id:
                removed = await self.bot.db.remove_giveaway_blacklist(ctx.guild.id, user_id=user_id)
                if removed:
                    user = ctx.guild.get_member(user_id)
                    view = LayoutViewFactory.create(
                        title="User Removed",
                        description=f"{user.mention if user else f'<@{user_id}>'} has been removed from the giveaway blacklist."
                    )
                else:
                    view = LayoutViewFactory.create(
                        title="Not Found",
                        description="User not found in blacklist."
                    )
            else:
                removed = await self.bot.db.remove_giveaway_blacklist(ctx.guild.id, role_id=role_id)
                if removed:
                    role = ctx.guild.get_role(role_id)
                    view = LayoutViewFactory.create(
                        title="Role Removed",
                        description=f"{role.mention if role else f'<@&{role_id}>'} has been removed from the giveaway blacklist."
                    )
                else:
                    view = LayoutViewFactory.create(
                        title="Not Found",
                        description="Role not found in blacklist."
                    )

            await loading_msg.edit(content=None, embed=None, view=view)

        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to remove from blacklist: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @gblacklist.command(name='list')
    async def gblacklist_list(self, ctx):
        """List all blacklisted users and roles"""
        loading_msg = await send_loading_message(ctx, "fetching giveaway blacklist")

        try:
            blacklist = await self.bot.db.get_giveaway_blacklist(ctx.guild.id)

            if not blacklist['users'] and not blacklist['roles']:
                view = LayoutViewFactory.create(
                    title="Giveaway Blacklist",
                    description="No users or roles are blacklisted from giveaways."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            description_parts = []

            if blacklist['users']:
                user_list = []
                for user_id in blacklist['users'][:10]:  # Show first 10
                    user = ctx.guild.get_member(user_id)
                    user_list.append(user.mention if user else f"<@{user_id}>")

                description_parts.append(f"**Blacklisted Users:**\n{', '.join(user_list)}")
                if len(blacklist['users']) > 10:
                    description_parts.append(f"... and {len(blacklist['users']) - 10} more users")

            if blacklist['roles']:
                role_list = []
                for role_id in blacklist['roles'][:10]:  # Show first 10
                    role = ctx.guild.get_role(role_id)
                    role_list.append(role.mention if role else f"<@&{role_id}>")

                description_parts.append(f"**Blacklisted Roles:**\n{', '.join(role_list)}")
                if len(blacklist['roles']) > 10:
                    description_parts.append(f"... and {len(blacklist['roles']) - 10} more roles")

            view = LayoutViewFactory.create(
                title="Giveaway Blacklist",
                description="\n\n".join(description_parts)
            )

            await loading_msg.edit(content=None, embed=None, view=view)

        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to fetch blacklist: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @gblacklist.command(name='clear')
    async def gblacklist_clear(self, ctx):
        """Clear all blacklisted users and roles"""
        loading_msg = await send_loading_message(ctx, "clearing giveaway blacklist")

        try:
            # Confirmation
            view = LayoutViewFactory.create(
                title="Confirmation Required",
                description="Are you sure you want to clear **ALL** blacklisted users and roles from giveaways?\n\nReact with ✅ to confirm or ❌ to cancel."
            )

            confirm_msg = await ctx.send(view=view)
            await confirm_msg.add_reaction('✅')
            await confirm_msg.add_reaction('❌')

            def check(reaction, user):
                return user == ctx.author and str(reaction.emoji) in ['✅', '❌'] and reaction.message.id == confirm_msg.id

            try:
                reaction, user = await self.bot.wait_for('reaction_add', timeout=30.0, check=check)

                if str(reaction.emoji) == '✅':
                    await self.bot.db.clear_giveaway_blacklist(ctx.guild.id)

                    view = LayoutViewFactory.create(
                        title="Blacklist Cleared",
                        description="All blacklisted users and roles have been cleared from giveaways."
                    )
                    await loading_msg.edit(content=None, embed=None, view=view)
                else:
                    view = LayoutViewFactory.create(
                        title="Cancelled",
                        description="Blacklist clear cancelled."
                    )
                    await loading_msg.edit(content=None, embed=None, view=view)

                await confirm_msg.delete()

            except asyncio.TimeoutError:
                view = LayoutViewFactory.create(
                    title="Timeout",
                    description="Confirmation timed out. Blacklist clear cancelled."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                await confirm_msg.delete()

        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to clear blacklist: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @commands.hybrid_group(name='gmanager')
    @commands.has_permissions(administrator=True)
    async def gmanager(self, ctx):
        """Manage giveaway manager roles"""
        if ctx.invoked_subcommand is None:
            view = LayoutViewFactory.create(
                title="Giveaway Manager Commands",
                description="• `gmanager add <role>` - Add a role as giveaway manager\n"
                           "• `gmanager remove <role>` - Remove a role from giveaway managers\n\n"
                           "**About Giveaway Managers:**\n"
                           "Users with giveaway manager role can create, end, and reroll giveaways (if they're the host)."
            )
            await ctx.send(view=view)

    @gmanager.command(name='add')
    @app_commands.describe(role='Role to add as giveaway manager')
    async def gmanager_add(self, ctx, role: discord.Role):
        """Add a role as giveaway manager"""
        loading_msg = await send_loading_message(ctx, "adding giveaway manager role")

        try:
            # Check if role already exists
            manager_roles = await self.bot.db.get_giveaway_manager_roles(ctx.guild.id)
            if role.id in manager_roles:
                view = LayoutViewFactory.create(
                    title="Already Set",
                    description=f"{role.mention} is already a giveaway manager role."
                )
                await loading_msg.edit(content=None, embed=None, view=view)
                return

            # Add the role
            added = await self.bot.db.set_giveaway_manager_role(ctx.guild.id, role.id)
            if added:
                view = LayoutViewFactory.create(
                    title="<:Jo1nTrX_giveaway:1411471234922971298> Giveaway Manager Added",
                    description=f"{role.mention} has been added as a giveaway manager role.\n\n"
                               f"Users with this role can now create, end, and reroll giveaways (if they're the host)."
                )
            else:
                view = LayoutViewFactory.create(
                    title="Already Set",
                    description=f"{role.mention} is already a giveaway manager role."
                )

            await loading_msg.edit(content=None, embed=None, view=view)

        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to add giveaway manager role: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

    @gmanager.command(name='remove')
    @app_commands.describe(role='Role to remove from giveaway managers')
    async def gmanager_remove(self, ctx, role: discord.Role):
        """Remove a role from giveaway managers"""
        loading_msg = await send_loading_message(ctx, "removing giveaway manager role")

        try:
            # Remove the role
            removed = await self.bot.db.remove_giveaway_manager_role(ctx.guild.id, role.id)
            if removed:
                view = LayoutViewFactory.create(
                    title="<:Jo1nTrX_giveaway:1411471234922971298> Giveaway Manager Removed",
                    description=f"{role.mention} has been removed from giveaway manager roles."
                )
            else:
                view = LayoutViewFactory.create(
                    title="Not Found",
                    description=f"{role.mention} is not a giveaway manager role."
                )

            await loading_msg.edit(content=None, embed=None, view=view)

        except Exception as e:
            view = LayoutViewFactory.create(
                title="Error",
                description=f"Failed to remove giveaway manager role: {str(e)}"
            )
            await loading_msg.edit(content=None, embed=None, view=view)

async def setup(bot):
    cog = GiveawayCommands(bot)
    await bot.add_cog(cog)

    # Register persistent views for existing giveaways (component v2)
    async def setup_persistent_views():
        try:
            active_giveaways = await bot.db.get_all_active_giveaways()
            for giveaway in active_giveaways:
                entry_count = await bot.db.get_giveaway_entries(giveaway['id'])
                view = GiveawayLayoutView(giveaway['id'], bot, giveaway, entry_count)
                bot.add_view(view)
        except Exception as e:
            print(f"Error setting up persistent giveaway views: {e}")

    # Schedule the setup after bot is ready
    bot.loop.create_task(setup_persistent_views())
