import discord
from discord.ext import commands
from discord import app_commands, ui
from typing import Optional
from Jo1nTrX.utils.component import bot_emoji


class HelpCategorySelect(ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(
                label="Index",
                description="Overview and getting started",
                emoji=discord.PartialEmoji.from_str(bot_emoji.index),
                value="index"
            ),
            discord.SelectOption(
                label="Anti-Nuke",
                description="Server protection and security system",
                emoji=discord.PartialEmoji.from_str(bot_emoji.antinuke),
                value="antinuke"
            ),
            discord.SelectOption(
                label="Automod",
                description="Automated moderation and content filtering",
                emoji=discord.PartialEmoji.from_str(bot_emoji.automod),
                value="automod"
            ),
            discord.SelectOption(
                label="Invite Tracking",
                description="Commands for tracking and viewing invites",
                emoji=discord.PartialEmoji.from_str(bot_emoji.invite),
                value="tracking"
            ),
            discord.SelectOption(
                label="Utility",
                description="Utility commands and tools",
                emoji=discord.PartialEmoji.from_str(bot_emoji.utility),
                value="utility"
            ),
            discord.SelectOption(
                label="Moderation",
                description="Administrative and moderation commands",
                emoji=discord.PartialEmoji.from_str(bot_emoji.moderation),
                value="moderation"
            ),
            discord.SelectOption(
                label="Channels Management",
                description="Channel & category related commands",
                emoji=discord.PartialEmoji.from_str(bot_emoji.channels),
                value="channels"
            ),
            discord.SelectOption(
                label="Welcome",
                description="Welcome/leave channel and message configuration",
                emoji=discord.PartialEmoji.from_str(bot_emoji.welcome),
                value="welcome"
            ),
            discord.SelectOption(
                label="Message",
                description="Message tracking commands and leaderboards",
                emoji=discord.PartialEmoji.from_str(bot_emoji.message),
                value="message"
            ),
            discord.SelectOption(
                label="Giveaway",
                description="Giveaway management and commands",
                emoji=discord.PartialEmoji.from_str(bot_emoji.giveaway),
                value="giveaway"
            ),
            discord.SelectOption(
                label="Custom Roles",
                description="Setup and manage custom role assignments",
                emoji=discord.PartialEmoji.from_str(bot_emoji.custom_role),
                value="custom_roles"
            ),
            discord.SelectOption(
                label="Embed Configuration",
                description="Create and manage custom embeds",
                emoji=discord.PartialEmoji.from_str(bot_emoji.embed),
                value="embed_config"
            ),
            discord.SelectOption(
                label="Auto Actions",
                description="Auto reactions and auto responses",
                emoji=discord.PartialEmoji.from_str(bot_emoji.autoaction),
                value="auto_actions"
            ),
            discord.SelectOption(
                label="Crypto & Currency",
                description="Currency exchange and calculator commands",
                emoji=discord.PartialEmoji.from_str(bot_emoji.currency),
                value="crypto"
            ),
            discord.SelectOption(
                label="Tickets",
                description="Create and manage support tickets",
                emoji=discord.PartialEmoji.from_str(bot_emoji.ticket),
                value="tickets"
            ),
            discord.SelectOption(
                label="Fun & Games",
                description="Fun commands including confessions",
                emoji=discord.PartialEmoji.from_str(bot_emoji.fun),
                value="fun"
            ),
            discord.SelectOption(
                label="Misc",
                description="Different type of commands",
                emoji=discord.PartialEmoji.from_str(bot_emoji.misc),
                value="misc"
            ),
            discord.SelectOption(
                label="Logging",
                description="Server activity logging system",
                emoji=discord.PartialEmoji.from_str(bot_emoji.logs),
                value="logging"
            ),
            discord.SelectOption(
                label="Contact",
                description="Support and contact information",
                emoji=discord.PartialEmoji.from_str(bot_emoji.support),
                value="contact"
            )
        ]
        super().__init__(
            placeholder="Choose a category...",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="help_category_select"
        )

    async def callback(self, interaction: discord.Interaction):
        try:
            current_view = self.view
            if current_view.requester and interaction.user.id != current_view.requester.id:  # type: ignore
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            category = self.values[0]
            new_view = HelpLayoutView(
                current_view.bot_instance,  # type: ignore
                category,
                current_view.requester,  # type: ignore
                current_view.prefix  # type: ignore
            )
            await interaction.response.edit_message(view=new_view)
        except Exception as e:
            await interaction.response.defer(ephemeral=True)


def get_help_content(category: str, prefix: Optional[str] = "+") -> str:
    dot = bot_emoji.arrow
    
    if category == "index":
        return f"""## {bot_emoji.index} Jo1nTrX Help Panel
Welcome to **Jo1nTrX** — your powerful Discord companion built for moderation, tracking, and server management.

{bot_emoji.antinuke} **Why Jo1nTrX?**
{dot} Advanced Anti-Nuke & Automod protection
{dot} Invite & message tracking with leaderboards
{dot} Giveaways, tickets, custom roles & more

> **Prefix:** `{prefix}`
> **Slash Commands:** `/`

**How to use**
1. Browse categories below for features & commands
2. Use `{prefix}help <category>` for detailed info
3. Need support? Click the buttons below

**Browse by Category:**"""
    
    elif category == "antinuke":
        return f"""## {bot_emoji.antinuke} Anti-Nuke Security
Protect your server from raids and malicious actions
*Use `{prefix}command` or `/command`*

{dot} `antinuke` — View anti-nuke settings
{dot} `antinuke enable` — Enable protection
{dot} `antinuke disable` — Disable protection
{dot} `antinuke status` — Check current status
{dot} `whitelist add` — Add user/role to whitelist
{dot} `whitelist remove` — Remove from whitelist
{dot} `whitelist show` — View whitelisted users
{dot} `whitelist reset` — Reset all whitelists

**Beastmode Protection:**
{dot} `beastmode enable/disable/config/status`

**Mainrole & Extra Owner:**
{dot} `mainrole add/remove/list`
{dot} `extraowner add/remove/show/reset`"""
    
    elif category == "automod":
        return f"""## {bot_emoji.automod} Automod System
Automated moderation and content filtering
*Use `{prefix}command` or `/command`*

{dot} `automod` — View automod settings
{dot} `automod enable` — Enable automod
{dot} `automod disable` — Disable automod
{dot} `automod status` — Check current status
{dot} `automod punishment <module>` — Set punishment
{dot} `automod logs set/remove` — Configure logs
{dot} `automod bypass add/remove/list` — Manage bypasses
{dot} `captcha setup` — Setup captcha verification
{dot} `spam protect` — Anti-spam protection

**Available Modules:**
Anti Spam • Anti Attachment Spam • Anti Emoji Spam
Anti Mention Spam • Anti Links • Anti Discord Invites • Anti Caps"""
    
    elif category == "tracking":
        return f"""## {bot_emoji.invite} Invite Tracking
Track and manage server invites
*Use `{prefix}command` or `/command`*

{dot} `invites` | `i` — Check your invites
{dot} `inviter` — See who invited a user
{dot} `invited` — See who a user invited
{dot} `inviteinfo` — Get invite details
{dot} `leaderboard invites` | `lbi` — Invite leaderboard
{dot} `resetmyinvites` | `rmi` — Reset your invites
{dot} `addinvites` — Add invites to user
{dot} `removeinvites` — Remove invites from user
{dot} `clearinvites` | `ci` — Clear user's invites
{dot} `setinvites` — Set invite count
{dot} `unsetinvites` — Unset invite count
{dot} `accountage` | `accage` — Check account age
{dot} `multipleaccountage` | `maccage` — Bulk check ages"""
    
    elif category == "utility":
        return f"""## {bot_emoji.utility} Utility
General utility commands and tools
*Use `{prefix}command` or `/command`*

{dot} `nuke` — Nuke a channel
{dot} `serverinfo` | `si` — Server information
{dot} `userinfo` | `ui` — User information
{dot} `roleinfo` | `ri` — Role information
{dot} `avatar` | `av` — Get user's avatar
{dot} `banner` — Get user's banner
{dot} `guildbanner` — Get server banner
{dot} `servericon` | `sicon` — Get server icon
{dot} `membercount` | `mc` — Member count
{dot} `uptime` — Bot uptime
{dot} `botinfo` | `bi` — Bot information
{dot} `ping` — Check latency
{dot} `setprefix` | `prefix` — Set server prefix
{dot} `snipe` — Snipe deleted messages
{dot} `afk` — Set AFK status
{dot} `steal` | `s` — Steal emojis
{dot} `timer` — Set a timer
{dot} `mytimers` — View your timers"""
    
    elif category == "moderation":
        return f"""## {bot_emoji.moderation} Moderation
Administrative and moderation commands
*Use `{prefix}command` or `/command`*

{dot} `dmuser` — DM a user
{dot} `warn` — Warn a user
{dot} `unwarn` — Remove a warning
{dot} `warnings` — View user warnings
{dot} `nick` — Change nickname
{dot} `clearnick` — Clear nickname
{dot} `ban` — Ban a user
{dot} `unban` — Unban a user
{dot} `kick` — Kick a user
{dot} `mute` — Mute a user
{dot} `unmute` — Unmute a user
{dot} `purge` — Delete messages
{dot} `role` — Manage roles
{dot} `modrole` — Set moderator role
{dot} `autokick` — Auto kick setup
{dot} `autoban` — Auto ban setup"""
    
    elif category == "channels":
        return f"""## {bot_emoji.channels} Channels Management
Channel and category related commands
*Use `{prefix}command` or `/command`*

**Channel Management:**
{dot} `lock` / `unlock` — Lock/unlock channel
{dot} `hide` / `unhide` — Hide/unhide channel
{dot} `nuke` — Recreate channel
{dot} `lockall` / `unlockall` — Lock/unlock all
{dot} `hideall` / `unhideall` — Hide/unhide all
{dot} `slowmode` — Set slowmode
{dot} `create channel` — Create a channel
{dot} `delete channel` — Delete a channel

**Category Management (Premium):**
{dot} `lockcat` / `unlockcat` — Lock/unlock category
{dot} `hidecat` / `unhidecat` — Hide/unhide category
{dot} `clearcat` — Clear category
{dot} `cat create` / `cat delete` — Manage categories"""
    
    elif category == "welcome":
        return f"""## {bot_emoji.welcome} Welcome/Leave Config
Configure welcome and leave messages
*Use `{prefix}command` or `/command`*

{dot} `setjoinmessage` — Set join message
{dot} `unsetjoinmessage` — Remove join message
{dot} `joinmessage delete` — Delete join config
{dot} `joinmessage-config` — View join config
{dot} `setleavemessage` — Set leave message
{dot} `unsetleavemessage` — Remove leave message
{dot} `resetwelcomeconfig` — Reset all config
{dot} `testmessage` — Test welcome message
{dot} `variables` — View available variables"""
    
    elif category == "message":
        return f"""## {bot_emoji.message} Message Tracking
Track and manage message counts
*Use `{prefix}command` or `/command`*

{dot} `messages` | `m` — Check message count
{dot} `leaderboard messages` | `lbm` — Message leaderboard
{dot} `leaderboard dailymessages` | `lbdm` — Daily leaderboard
{dot} `addmessages` | `addm` — Add messages
{dot} `removemessages` | `removem` — Remove messages
{dot} `clearmessages` | `cm` — Clear messages
{dot} `resetmymessages` | `rmm` — Reset your messages
{dot} `blacklistchannel` | `bl` — Blacklist channel
{dot} `unblacklistchannel` | `unbl` — Unblacklist channel
{dot} `blacklistedchannels` | `blc` — View blacklisted"""
    
    elif category == "giveaway":
        return f"""## {bot_emoji.giveaway} Giveaway
Create and manage giveaways
*Use `{prefix}command` or `/command`*

{dot} `gstart` — Start a giveaway
{dot} `gbulk` — Bulk giveaway
{dot} `gend` — End a giveaway
{dot} `greroll` — Reroll winner
{dot} `gpause` — Pause giveaway
{dot} `glist` — List active giveaways
{dot} `gblacklist add` — Blacklist user
{dot} `gblacklist remove` — Unblacklist user
{dot} `gblacklist list` — View blacklist
{dot} `gblacklist clear` — Clear blacklist
{dot} `gmanager add` — Add giveaway manager
{dot} `gmanager remove` — Remove manager"""
    
    elif category == "custom_roles":
        return f"""## {bot_emoji.custom_role} Custom Roles
Setup and manage custom role assignments
*Use `{prefix}command` or `/command`*

{dot} `setup help` — Setup help
{dot} `setup staff` — Setup staff role
{dot} `setup girl` — Setup girl role
{dot} `setup vip` — Setup VIP role
{dot} `setup friend` — Setup friend role
{dot} `setup guest` — Setup guest role
{dot} `setup create` — Create custom setup
{dot} `setup list` — List setups
{dot} `setup delete` — Delete setup
{dot} `reqrole add` — Add required role"""
    
    elif category == "embed_config":
        return f"""## {bot_emoji.embed} Embed Configuration
Create and manage custom embeds
*Use `{prefix}command` or `/command`*

{dot} `embed create` — Create a new embed
{dot} `embed send` — Send an embed
{dot} `embed list` — List saved embeds
{dot} `embed edit` — Edit an embed
{dot} `embed delete` — Delete an embed"""
    
    elif category == "auto_actions":
        return f"""## {bot_emoji.autoaction} Auto Actions
Auto reactions and auto responses
*Use `{prefix}command` or `/command`*

**Auto React:**
{dot} `autoreact add` — Add auto reaction
{dot} `autoreact delete` — Delete auto reaction
{dot} `autoreact list` — List auto reactions

**Auto Responder:**
{dot} `autoresponder add` — Add auto response
{dot} `autoresponder delete` — Delete auto response
{dot} `autoresponder list` — List auto responses

**Auto Role:**
{dot} `autorole` — View autorole settings
{dot} `autorole humans add` — Add human autorole
{dot} `autorole bots` — Set bot autorole"""
    
    elif category == "crypto":
        return f"""## {bot_emoji.currency} Crypto & Currency
Currency exchange and calculator
*Use `{prefix}command` or `/command`*

{dot} `calculate` | `calc` | `math` — Calculator
{dot} `exchange` | `currency` | `exch` — Exchange rates
{dot} `rates` — View current rates
{dot} `USD` / `INR` / `NPR` / `BDT` — Convert fiat
{dot} `BTC` / `ETH` / `LTC` / `SOL` — Convert crypto

**Supported Currencies:**
**Fiat:** INR • USD • NPR • BDT
**Crypto:** BTC • ETH • LTC • SOL"""
    
    elif category == "tickets":
        return f"""## {bot_emoji.ticket} Ticket System
Create and manage support tickets
*Use `{prefix}command` or `/command`*

**Panel Commands:**
{dot} `ticket panel setup` — Setup ticket panel
{dot} `ticket panel list` — List panels
{dot} `ticket panel edit` — Edit panel
{dot} `ticket panel send` — Send panel
{dot} `ticket panel delete` — Delete panel

**Ticket Commands:**
{dot} `ticket` — Create a ticket
{dot} `add` — Add user to ticket
{dot} `remove` — Remove user from ticket
{dot} `close` — Close ticket
{dot} `delete` — Delete ticket
{dot} `claim` — Claim ticket
{dot} `reopen` — Reopen ticket"""
    
    elif category == "fun":
        return f"""## {bot_emoji.fun} Fun & Games
Fun commands and games
*Use `{prefix}command` or `/command`*

{dot} `/confess` — Send anonymous confession
{dot} `/confessionlog channel set` — Set confession log
{dot} `/confessionlog channel remove` — Remove log channel"""
    
    elif category == "misc":
        return f"""## {bot_emoji.misc} Misc Commands
Various utility commands
*Use `{prefix}command` or `/command`*

**Reaction Roles:**
{dot} `reactionrole setup` — Setup reaction role
{dot} `reactionrole list` — List reaction roles
{dot} `reactionrole delete` — Delete reaction role

**Role Management:**
{dot} `massrole add` — Add role to all
{dot} `massrole remove` — Remove role from all
{dot} `temprole add` — Add temporary role

**Ignore Commands:**
{dot} `icadd` — Ignore channel add
{dot} `icremove` — Ignore channel remove
{dot} `iclist` — List ignored channels
{dot} `ibypass` — Ignore bypass"""
    
    elif category == "logging":
        return f"""## {bot_emoji.logs} Logging
Server activity logging system
*Use `{prefix}command` or `/command`*

{dot} `logs setup` — Setup logging
{dot} `logs reset` — Reset all logs
{dot} `logschannel set <type> <#channel>` — Set log channel

**Log Types:**
Message logs • Member logs • Voice logs
Role logs • Channel logs • Server logs"""
    
    elif category == "contact":
        return f"""## {bot_emoji.support} Support & Contact
Get help and support

{dot} Join our support server and open a ticket for help!

**Links:**
{dot} [Invite Jo1nTrX](https://discord.com/oauth2/authorize?client_id=1404011822700564520&permissions=8&integration_type=0&scope=bot+applications.commands)
{dot} [Support Server](https://discord.gg/PA6UhChxZY)"""
    
    else:
        return get_help_content("index", prefix)


class HelpLayoutView(ui.LayoutView):
    def __init__(self, bot_instance, category: str = "index", requester: Optional[discord.Member] = None, prefix: Optional[str] = "+"):
        super().__init__(timeout=180)
        self.bot_instance = bot_instance
        self.current_category = category
        self.requester = requester
        self.prefix = prefix
        self._setup_view()
    
    def _setup_view(self):
        content = get_help_content(self.current_category, self.prefix)
        
        select = HelpCategorySelect()
        select_row = ui.ActionRow(select)
        
        buttons = []
        buttons.append(ui.Button(
            label="Get Jo1nTrX",
            url="https://discord.com/oauth2/authorize?client_id=1404011822700564520&permissions=8&integration_type=0&scope=bot+applications.commands",
            style=discord.ButtonStyle.link
        ))
        buttons.append(ui.Button(
            label="Support Srv",
            url=self.bot_instance.config.SUPPORT_SERVER_URL,
            style=discord.ButtonStyle.link
        ))
        buttons.append(ui.Button(
            label="Dashboard",
            url=self.bot_instance.config.DASHBOARD_URL,
            style=discord.ButtonStyle.link
        ))
        
        button_row = ui.ActionRow(*buttons)
        
        container = ui.Container(
            ui.TextDisplay(content),
            select_row,
            button_row,
            accent_color=None
        )
        self.add_item(container)


class PremiumHelpCategorySelect(ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(
                label="Overview",
                description="Premium overview and benefits",
                emoji=discord.PartialEmoji.from_str(bot_emoji.index),
                value="overview"
            ),
            discord.SelectOption(
                label="Enhanced Limits",
                description="Higher limits for premium users",
                emoji=discord.PartialEmoji.from_str(bot_emoji.loading),
                value="limits"
            ),
            discord.SelectOption(
                label="Channel Management",
                description="Premium category management commands",
                emoji=discord.PartialEmoji.from_str(bot_emoji.channels),
                value="channels"
            ),
            discord.SelectOption(
                label="Custom Roles",
                description="Extended custom role setup (15 max)",
                emoji=discord.PartialEmoji.from_str(bot_emoji.custom_role),
                value="custom_roles"
            ),
            discord.SelectOption(
                label="Auto Actions",
                description="Enhanced auto reactions & responders",
                emoji=discord.PartialEmoji.from_str(bot_emoji.autoaction),
                value="auto_actions"
            ),
            discord.SelectOption(
                label="Utility Features",
                description="Premium utility commands and perks",
                emoji=discord.PartialEmoji.from_str(bot_emoji.utility),
                value="utilities"
            ),
            discord.SelectOption(
                label="Get Premium",
                description="How to get premium access",
                emoji=discord.PartialEmoji.from_str(bot_emoji.support),
                value="get_premium"
            )
        ]
        super().__init__(
            placeholder="Choose a premium category...",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="premium_help_category_select"
        )

    async def callback(self, interaction: discord.Interaction):
        try:
            current_view = self.view
            if current_view.requester and interaction.user.id != current_view.requester.id:  # type: ignore
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            
            category = self.values[0]
            new_view = PremiumHelpLayoutView(
                current_view.bot_instance,  # type: ignore
                category,
                current_view.requester,  # type: ignore
                current_view.prefix  # type: ignore
            )
            await interaction.response.edit_message(view=new_view)
        except Exception as e:
            await interaction.response.defer(ephemeral=True)


def get_premium_help_content(category: str, prefix: Optional[str] = "+") -> str:
    dot = bot_emoji.arrow
    
    if category == "overview":
        return f"""## {bot_emoji.index} Jo1nTrX Premium Help
Welcome to **Jo1nTrX Premium** — unlock enhanced features and exclusive commands!

{bot_emoji.tick} **What is Premium?**
{dot} Premium unlocks enhanced limits, exclusive commands, and advanced features to supercharge your server!

{dot} **3x Higher Limits** on all commands
{dot} **No Prefix Mode** — Use commands without prefix!
{dot} **Exclusive Commands** for advanced management
{dot} **Priority Support** from our team

> **Prefix:** `{prefix}`
> **Premium users can use commands without prefix!**

**Powered by:** [SRIYAN NODES™](https://discord.gg/PA6UhChxZY)

**Browse Premium Categories:**"""
    
    elif category == "limits":
        return f"""## {bot_emoji.loading} Enhanced Limits
Premium users enjoy **3x higher limits** on all features!

**Comparison:**
{dot} **Custom Roles:** `15` (Free: 5)
{dot} **Auto Reactions:** `15` (Free: 5)
{dot} **Auto Responders:** `15` (Free: 5)
{dot} **Steal Command:** `20 items` (Free: 10)

**Why Higher Limits?**
{dot} Create more custom role assignments
{dot} Setup more automation triggers
{dot} Manage larger servers efficiently"""
    
    elif category == "channels":
        return f"""## {bot_emoji.channels} Premium Channel Management
Advanced category and channel control features

**Category Hide/Unhide (Premium Only):**
{dot} `hidecat <category>` — Hide a category from @everyone
{dot} `unhidecat <category>` — Restore category visibility

**Category Lock/Unlock:**
{dot} `lockcat <category>` — Lock all channels in category
{dot} `unlockcat <category>` — Unlock all channels in category

**Other Category Commands:**
{dot} `clearcat <category>` — Clear messages in category
{dot} `cat create <name>` — Create a new category
{dot} `cat delete <category>` — Delete a category

**Use Cases:**
{dot} Create hidden staff categories
{dot} Temporary event channels
{dot} VIP-only sections
{dot} Emergency lockdowns"""
    
    elif category == "custom_roles":
        return f"""## {bot_emoji.custom_role} Premium Custom Roles
Setup up to **15 custom role assignments** (Free: 5)

{dot} Premium users can create **15 custom role setups** instead of 5
{dot} Assign roles like staff, girl, vip, friend, guest and more
{dot} Create custom role assignment commands
{dot} Perfect for managing VIP members and special roles

**Example Usage:**
```
{prefix}setup create @VIPMember vip
{prefix}reqrole add @Manager
{prefix}vip @User
```"""
    
    elif category == "auto_actions":
        return f"""## {bot_emoji.autoaction} Premium Auto Actions
Automate your server interactions with enhanced limits!

**Auto Reactions (15 max):**
{dot} Automatically react to messages containing triggers
{dot} Support for exact match or contains
{dot} Up to 5 emojis per trigger

{dot} `autoreact add <trigger> <emojis> <type>`
{dot} `autoreact delete <trigger>`
{dot} `autoreact list`

**Auto Responders (15 max):**
{dot} Automatically reply to messages with custom responses
{dot} Exact or contains matching
{dot} Perfect for FAQs and automated help

{dot} `autoresponder add <trigger> <response> <type>`
{dot} `autoresponder delete <trigger>`
{dot} `autoresponder list`

**Example Setup:**
```
{prefix}autoreact add hello 👋,😊 contains
{prefix}autoresponder add help Check our #faq channel! exact
```"""
    
    elif category == "utilities":
        return f"""## {bot_emoji.utility} Premium Utility Commands
Exclusive premium utility features for enhanced server management

**No Prefix Required:**
{dot} Premium users can use commands without the bot prefix
{dot} Simply type the command name directly!
{dot} Makes command usage faster and more convenient

**Enhanced Steal Command:**
{dot} `steal <emojis/stickers>` — Steal up to **20 items** at once
{dot} Free users limited to 10 items
{dot} Quickly import emojis and stickers to your server

**Advanced Account Checks:**
{dot} `multipleaccountage` — Check for alt accounts
{dot} Identify potential alternate accounts
{dot} Enhanced security for your server"""
    
    elif category == "get_premium":
        return f"""## {bot_emoji.support} Get Premium Access
Unlock all premium features and enhance your server experience!

**How to Get Premium:**
{dot} **Step 1:** Join our support server
{dot} **Step 2:** Open a ticket in the server
{dot} **Step 3:** Request premium access from the team
{dot} Our team will guide you through the process!

**Support Server:**
[Join SRIYAN NODES™](https://discord.gg/PA6UhChxZY)
Join the server and open a ticket to get premium access!

**What You Get:**
{dot} 3x higher limits on all commands
{dot} No prefix required for commands
{dot} Exclusive premium commands
{dot} Priority support
{dot} Early access to new features"""
    
    else:
        return get_premium_help_content("overview", prefix)


class PremiumHelpLayoutView(ui.LayoutView):
    def __init__(self, bot_instance, category: str = "overview", requester: Optional[discord.Member] = None, prefix: Optional[str] = "+"):
        super().__init__(timeout=180)
        self.bot_instance = bot_instance
        self.current_category = category
        self.requester = requester
        self.prefix = prefix
        self._setup_view()
    
    def _setup_view(self):
        content = get_premium_help_content(self.current_category, self.prefix)
        
        select = PremiumHelpCategorySelect()
        select_row = ui.ActionRow(select)
        
        buttons = []
        buttons.append(ui.Button(
            label="Invite Jo1nTrX",
            url="https://discord.com/oauth2/authorize?client_id=1404011822700564520&permissions=8&integration_type=0&scope=bot+applications.commands",
            style=discord.ButtonStyle.link
        ))
        buttons.append(ui.Button(
            label="Get Premium",
            url="https://discord.gg/PA6UhChxZY",
            style=discord.ButtonStyle.link
        ))
        
        button_row = ui.ActionRow(*buttons)
        
        container = ui.Container(
            ui.TextDisplay(content),
            select_row,
            button_row,
            accent_color=None
        )
        self.add_item(container)


class HelpCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="help", aliases=["h", "commands"], description="Show the help menu with all commands")
    async def help(self, ctx: commands.Context, *, category: str = None):
        server_prefix = "+"
        if ctx.guild:
            try:
                custom_prefix = await self.bot.db.get_guild_prefix(ctx.guild.id)
                if custom_prefix:
                    server_prefix = custom_prefix
            except:
                pass
        
        start_category = "index"
        if category:
            category_map = {
                "antinuke": "antinuke", "an": "antinuke", "anti": "antinuke",
                "automod": "automod", "am": "automod",
                "invite": "tracking", "invites": "tracking", "tracking": "tracking",
                "utility": "utility", "util": "utility",
                "moderation": "moderation", "mod": "moderation",
                "channels": "channels", "channel": "channels",
                "welcome": "welcome", "greet": "welcome",
                "message": "message", "messages": "message", "msg": "message",
                "giveaway": "giveaway", "gw": "giveaway",
                "custom": "custom_roles", "customroles": "custom_roles", "roles": "custom_roles",
                "embed": "embed_config", "embeds": "embed_config",
                "auto": "auto_actions", "autoaction": "auto_actions",
                "crypto": "crypto", "currency": "crypto",
                "ticket": "tickets", "tickets": "tickets",
                "fun": "fun", "games": "fun",
                "misc": "misc", "other": "misc",
                "logs": "logging", "logging": "logging", "log": "logging",
                "contact": "contact", "support": "contact"
            }
            start_category = category_map.get(category.lower(), "index")
        
        view = HelpLayoutView(self.bot, start_category, ctx.author if isinstance(ctx.author, discord.Member) else None, server_prefix)  # type: ignore
        await ctx.send(view=view)
    
    @commands.hybrid_command(name="phelp", aliases=["premiumhelp", "ph"], description="Show premium features help menu")
    async def phelp(self, ctx: commands.Context, *, category: str = None):
        """Display premium help menu with component v2 style"""
        server_prefix = "+"
        if ctx.guild:
            try:
                custom_prefix = await self.bot.db.get_guild_prefix(ctx.guild.id)
                if custom_prefix:
                    server_prefix = custom_prefix
            except:
                pass
        
        start_category = "overview"
        if category:
            category_map = {
                "overview": "overview", "index": "overview", "home": "overview",
                "limits": "limits", "limit": "limits", "enhanced": "limits",
                "channels": "channels", "channel": "channels", "category": "channels",
                "custom": "custom_roles", "customroles": "custom_roles", "roles": "custom_roles",
                "auto": "auto_actions", "autoaction": "auto_actions", "actions": "auto_actions",
                "utility": "utilities", "utilities": "utilities", "util": "utilities",
                "get": "get_premium", "getpremium": "get_premium", "buy": "get_premium", "premium": "get_premium"
            }
            start_category = category_map.get(category.lower(), "overview")
        
        view = PremiumHelpLayoutView(self.bot, start_category, ctx.author if isinstance(ctx.author, discord.Member) else None, server_prefix)  # type: ignore
        await ctx.send(view=view)


async def setup(bot):
    await bot.add_cog(HelpCommand(bot))
