import discord
from discord.ext import commands
from discord import app_commands, ui
from typing import Optional
import json
import asyncio
from datetime import datetime, timezone, timedelta
from Jo1nTrX.utils.embeds import create_embed, create_error_embed
from Jo1nTrX.utils.helpers import send_loading_message
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)

# Global JSON serializer to handle datetime objects and Discord objects
def json_serializer(obj):
    if isinstance(obj, datetime):
        return obj.isoformat()
    # Handle Discord objects that might contain datetime attributes
    elif hasattr(obj, '__dict__'):
        # Convert Discord objects to dictionaries, handling datetime attributes
        result = {}
        for key, value in obj.__dict__.items():
            if isinstance(value, datetime):
                result[key] = value.isoformat()
            elif isinstance(value, (str, int, float, bool, type(None))):
                result[key] = value
            else:
                # Skip complex nested objects to avoid recursion
                continue
        return result
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

async def create_embed_from_database_data(bot, guild_id, embed_name, member=None, invite=None, booster=None):
    """Create discord.Embed object and message from database embed data with variable replacement
    Returns tuple: (message_content, embed) where message_content can be None"""
    try:
        embed_data = await bot.db.get_custom_embed(guild_id, embed_name)
        if not embed_data:
            return None, None
        
        data = json.loads(embed_data)
        
        # Ensure all data is properly serializable by re-serializing with our custom serializer
        try:
            data = json.loads(json.dumps(data, default=json_serializer))
        except Exception as e:
            print(f"Error re-serializing embed data: {e}")
            return None, None
        
        # Replace variables in embed data if member is provided
        message_content = None
        if member:
            # Use the bot's replace_variables function for text fields
            for key in ['title', 'description', 'footer', 'author_name', 'message']:
                if data.get(key):
                    data[key] = await bot.replace_variables(data[key], member, invite, False, booster)
            
            # Replace variables in image fields (thumbnail, author_icon, footer_icon, image)
            for key in ['thumbnail', 'author_icon', 'footer_icon', 'image']:
                if data.get(key):
                    data[key] = await bot.replace_variables(data[key], member, invite, False, booster)
            
            # Replace variables in fields
            for field in data.get('fields', []):
                if field.get('name'):
                    field['name'] = await bot.replace_variables(field['name'], member, invite, False, booster)
                if field.get('value'):
                    field['value'] = await bot.replace_variables(field['value'], member, invite, False, booster)
        
        # Extract message content if it exists
        if data.get('message'):
            message_content = data['message']
        
        embed = discord.Embed()
        
        if data.get('title'):
            embed.title = data['title']
        if data.get('description'):
            embed.description = data['description']
        
        embed.color = data.get('color', 0x7c28eb)
        
        if data.get('author_name'):
            embed.set_author(
                name=data['author_name'],
                icon_url=data.get('author_icon') if data.get('author_icon') else None
            )
        
        if data.get('thumbnail'):
            embed.set_thumbnail(url=data['thumbnail'])
        
        if data.get('image'):
            embed.set_image(url=data['image'])
        
        for field in data.get('fields', []):
            embed.add_field(
                name=field['name'],
                value=field['value'],
                inline=field.get('inline', False)
            )
        
        if data.get('footer'):
            embed.set_footer(text=data['footer'], icon_url=data.get('footer_icon') if data.get('footer_icon') else None)
        
        return message_content, embed
    except Exception as e:
        print(f"Error creating embed from database data: {e}")
        return None, None


class EmbedBuilderLayoutView(ui.LayoutView):
    def __init__(self, bot, embed_name, author_id):
        super().__init__(timeout=300)
        self.bot = bot
        self.embed_name = embed_name
        self.author_id = author_id
        self.embed_data = {
            'title': None,
            'description': None,
            'color': 0x7c28eb,
            'footer': None,
            'footer_icon': None,
            'thumbnail': None,
            'image': None,
            'author_name': None,
            'author_icon': None,
            'fields': [],
            'message': None
        }
        self._setup_view()

    def _get_content(self):
        content = f"""## {bot_emoji.embed} Embed Creator: {self.embed_name}

Use the dropdown menu below to customize your embed!

**Available Options**
{bot_emoji.arrow} **Edit Title** - Set embed title
{bot_emoji.arrow} **Edit Description** - Set main content
{bot_emoji.arrow} **Change Color** - Set embed color
{bot_emoji.arrow} **Edit Footer** - Set footer text & icon
{bot_emoji.arrow} **Set Thumbnail** - Add small image
{bot_emoji.arrow} **Set Main Image** - Add large image
{bot_emoji.arrow} **Edit Author** - Set author info
{bot_emoji.arrow} **Add Field** - Add custom fields
{bot_emoji.arrow} **Add Message** - Add text above embed
{bot_emoji.arrow} **Preview Embed** - See current result
{bot_emoji.arrow} **Save Embed** - Save for later use

**Variables Support**
> For welcome/leave/boost embed setup, use `/variables` for variables list

**After Saving**
> Use `+embed send {self.embed_name}` to send this embed to any channel"""
        return content

    def _setup_view(self):
        content = self._get_content()
        text_display = ui.TextDisplay(content)

        select_options = [
            discord.SelectOption(label="Add Message", description="Add text above embed", value="message", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Edit Title", description="Set embed title", value="title", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Edit Description", description="Set main content", value="description", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Change Color", description="Set embed color", value="color", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Edit Footer", description="Set footer text & icon", value="footer", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Set Thumbnail", description="Add small image", value="thumbnail", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Set Main Image", description="Add large image", value="image", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Edit Author", description="Set author info", value="author", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Add Field", description="Add custom fields", value="field", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Preview Embed", description="See current result", value="preview", emoji=bot_emoji.arrow),
            discord.SelectOption(label="Save Embed", description="Save for later use", value="save", emoji=bot_emoji.tick),
        ]

        config_select = ui.Select(placeholder="Choose what to customize...", options=select_options, custom_id=f"embed_builder_{self.embed_name}")

        async def select_callback(interaction: discord.Interaction):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the embed creator can use this menu!", ephemeral=True)

            option = config_select.values[0]

            if option == "preview":
                await self._show_preview(interaction)
                return
            elif option == "save":
                await self._save_embed(interaction)
                return

            if option == "title":
                modal = TextInputModal("Edit Title", "Enter embed title:", "title", required=False, max_length=256)
            elif option == "description":
                modal = TextInputModal("Edit Description", "Enter embed description:", "description", required=False, max_length=4000, style=discord.TextStyle.paragraph)
            elif option == "footer":
                modal = FooterModal()
            elif option == "thumbnail":
                modal = TextInputModal("Set Thumbnail", "Enter thumbnail image URL:", "thumbnail", required=False, max_length=2048)
            elif option == "image":
                modal = TextInputModal("Set Main Image", "Enter main image URL:", "image", required=False, max_length=2048)
            elif option == "author":
                modal = AuthorModal()
            elif option == "field":
                modal = FieldModal()
            elif option == "message":
                modal = TextInputModal("Add Message", "Enter message text:", "message", required=False, max_length=2000, style=discord.TextStyle.paragraph)
            elif option == "color":
                modal = ColorModal()
            else:
                return

            modal.view = self
            await interaction.response.send_modal(modal)

        config_select.callback = select_callback

        select_row = ui.ActionRow(config_select)
        container = ui.Container(text_display, select_row)
        self.add_item(container)

    async def _show_preview(self, interaction):
        preview_embed = discord.Embed()
        if self.embed_data['title']:
            preview_embed.title = self.embed_data['title']
        if self.embed_data['description']:
            preview_embed.description = self.embed_data['description']
        preview_embed.color = self.embed_data['color']
        if self.embed_data['author_name']:
            preview_embed.set_author(name=self.embed_data['author_name'], icon_url=self.embed_data['author_icon'] if self.embed_data['author_icon'] else None)
        if self.embed_data['thumbnail']:
            preview_embed.set_thumbnail(url=self.embed_data['thumbnail'])
        if self.embed_data['image']:
            preview_embed.set_image(url=self.embed_data['image'])
        for field in self.embed_data['fields']:
            preview_embed.add_field(name=field['name'], value=field['value'], inline=field.get('inline', False))
        if self.embed_data['footer']:
            preview_embed.set_footer(text=self.embed_data['footer'], icon_url=self.embed_data.get('footer_icon') if self.embed_data.get('footer_icon') else None)

        preview_content = f"**Preview of embed '{self.embed_name}':**"
        if self.embed_data.get('message'):
            preview_content += f"\n\n**Message:** {self.embed_data['message']}"
        await interaction.response.send_message(content=preview_content, embed=preview_embed, ephemeral=True)

    async def _save_embed(self, interaction):
        try:
            embed_json = json.dumps(self.embed_data, default=json_serializer)
            await self.bot.db.save_custom_embed(interaction.guild.id, interaction.user.id, self.embed_name, embed_json)

            content = f"""## {bot_emoji.tick} Embed Saved

Embed **{self.embed_name}** has been saved successfully!

> Use `+embed send {self.embed_name}` to send this embed to any channel"""
            view = ui.LayoutView(timeout=60)
            container = ui.Container(ui.TextDisplay(content))
            view.add_item(container)
            await interaction.response.edit_message(view=view)
        except Exception as e:
            await interaction.response.send_message(f"{bot_emoji.cross} Failed to save embed: {str(e)}", ephemeral=True)


class EmbedSendLayoutView(ui.LayoutView):
    def __init__(self, bot, embed_name, embed_data, author_id):
        super().__init__(timeout=300)
        self.bot = bot
        self.embed_name = embed_name
        self.embed_data = embed_data
        self.author_id = author_id
        self._setup_view()

    def _get_content(self):
        return f"""## {bot_emoji.embed} {self.embed_name}

Choose the button below to send the embed however you like

{bot_emoji.arrow} **Send Directly** - Send embed to a channel
{bot_emoji.arrow} **Send As Webhook** - Send using a custom webhook identity
{bot_emoji.arrow} **Send with Buttons** - Add interactive buttons to your embed"""

    def _setup_view(self):
        content = self._get_content()
        text_display = ui.TextDisplay(content)

        direct_btn = ui.Button(label="Send Directly", style=discord.ButtonStyle.primary)
        webhook_btn = ui.Button(label="Send As Webhook", style=discord.ButtonStyle.secondary)
        buttons_btn = ui.Button(label="Send with Buttons", style=discord.ButtonStyle.success)

        async def direct_callback(interaction: discord.Interaction):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the embed creator can use this!", ephemeral=True)
            
            await interaction.response.send_message(
                "Please enter a channel ID or mention the channel (e.g., #general) in the chat.\n"
                "If you want to cancel the action, simply type `cancel`.",
                ephemeral=True
            )
            
            def check(message):
                return message.author.id == self.author_id and message.channel == interaction.channel
            
            try:
                message = await self.bot.wait_for('message', timeout=300.0, check=check)
                
                if message.content.lower() == 'cancel':
                    await message.reply(f"{bot_emoji.cross} Action cancelled.")
                    return
                
                channel = None
                if message.channel_mentions:
                    channel = message.channel_mentions[0]
                else:
                    try:
                        channel_id = int(message.content.strip('<>#'))
                        channel = self.bot.get_channel(channel_id)
                    except ValueError:
                        await message.reply(f"{bot_emoji.cross} Invalid channel format. Please use a channel mention or valid channel ID.")
                        return
                
                if not channel:
                    await message.reply(f"{bot_emoji.cross} Channel not found or I don't have access to it.")
                    return
                
                if not channel.permissions_for(interaction.guild.me).send_messages:
                    await message.reply(f"{bot_emoji.cross} I don't have permission to send messages in {channel.mention}.")
                    return
                
                message_content, embed = await self._create_embed_from_data()
                await channel.send(content=message_content, embed=embed)
                
                await message.reply(f"{bot_emoji.tick} Successfully sent embed **{self.embed_name}** to {channel.mention}!")
                
            except asyncio.TimeoutError:
                await interaction.followup.send(f"{bot_emoji.cross} Timeout! No channel was provided within 5 minutes.", ephemeral=True)
            except Exception as e:
                await interaction.followup.send(f"{bot_emoji.cross} Error sending embed: {str(e)}", ephemeral=True)

        async def webhook_callback(interaction: discord.Interaction):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the embed creator can use this!", ephemeral=True)
            
            await interaction.response.send_message(
                "Please enter a username for the webhook in the chat. You can also tag a user to use their username.\n"
                "If you want to cancel the action, simply type `cancel`.",
                ephemeral=True
            )
            
            def check(message):
                return message.author.id == self.author_id and message.channel == interaction.channel
            
            try:
                message = await self.bot.wait_for('message', timeout=300.0, check=check)
                
                if message.content.lower() == 'cancel':
                    await message.reply(f"{bot_emoji.cross} Action cancelled.")
                    return
                
                webhook_username = message.content
                if message.mentions:
                    webhook_username = message.mentions[0].display_name
                
                await message.reply(
                    "Please enter an avatar URL for the webhook in the chat. You can also tag a user to use their avatar.\n"
                    "If you do not have an avatar, you can type `skip` to continue or if you want to cancel the action, simply type `cancel`."
                )
                
                message = await self.bot.wait_for('message', timeout=300.0, check=check)
                
                if message.content.lower() == 'cancel':
                    await message.reply(f"{bot_emoji.cross} Action cancelled.")
                    return
                
                webhook_avatar = None
                if message.content.lower() != 'skip':
                    if message.mentions:
                        webhook_avatar = message.mentions[0].display_avatar.url
                    elif message.content.startswith(('http://', 'https://')):
                        webhook_avatar = message.content
                    else:
                        await message.reply(f"{bot_emoji.cross} Invalid avatar URL format. Please provide a valid URL or tag a user.")
                        return
                
                await message.reply(
                    "Give the channel ID or #channel you want this embed to be sent.\n"
                    "If you want the same channel, you can type `skip` to continue or if you want to cancel the action, simply type `cancel`."
                )
                
                message = await self.bot.wait_for('message', timeout=300.0, check=check)
                
                if message.content.lower() == 'cancel':
                    await message.reply(f"{bot_emoji.cross} Action cancelled.")
                    return
                
                target_channel = interaction.channel
                if message.content.lower() != 'skip':
                    if message.channel_mentions:
                        target_channel = message.channel_mentions[0]
                    else:
                        try:
                            channel_id = int(message.content.strip('<>#'))
                            target_channel = self.bot.get_channel(channel_id)
                        except ValueError:
                            await message.reply(f"{bot_emoji.cross} Invalid channel format. Please use a channel mention or valid channel ID.")
                            return
                
                if not target_channel:
                    await message.reply(f"{bot_emoji.cross} Channel not found or I don't have access to it.")
                    return
                
                if not target_channel.permissions_for(interaction.guild.me).manage_webhooks:
                    await message.reply(f"{bot_emoji.cross} I don't have permission to manage webhooks in {target_channel.mention}.")
                    return
                
                webhook = await target_channel.create_webhook(name=webhook_username[:80])
                msg_content, embed = await self._create_embed_from_data()
                
                await webhook.send(
                    content=msg_content,
                    embed=embed,
                    username=webhook_username,
                    avatar_url=webhook_avatar
                )
                
                await webhook.delete()
                await message.reply(f"{bot_emoji.tick} Successfully sent embed **{self.embed_name}** to {target_channel.mention} as **{webhook_username}**!")
                
            except asyncio.TimeoutError:
                await interaction.followup.send(f"{bot_emoji.cross} Timeout! The webhook setup was not completed within 5 minutes.", ephemeral=True)
            except Exception as e:
                await interaction.followup.send(f"{bot_emoji.cross} Error creating webhook: {str(e)}", ephemeral=True)

        async def buttons_callback(interaction: discord.Interaction):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the embed creator can use this!", ephemeral=True)
            
            try:
                button_config_view = EmbedButtonConfigLayoutView(
                    self.bot,
                    self.embed_name,
                    self.embed_data,
                    self.author_id,
                    interaction.guild.id
                )
                button_config_view.parent_send_view = self
                
                await interaction.response.edit_message(view=button_config_view)
                
                message = await interaction.original_response()
                button_config_view.message_id = message.id
                button_config_view.channel_id = interaction.channel.id
                
                self.bot.add_view(button_config_view, message_id=message.id)
            except Exception as e:
                print(f"Error in buttons_callback: {e}")
                import traceback
                traceback.print_exc()
                try:
                    await interaction.response.send_message(f"{bot_emoji.cross} An error occurred: {str(e)}", ephemeral=True)
                except:
                    await interaction.followup.send(f"{bot_emoji.cross} An error occurred: {str(e)}", ephemeral=True)

        direct_btn.callback = direct_callback
        webhook_btn.callback = webhook_callback
        buttons_btn.callback = buttons_callback

        button_row = ui.ActionRow(direct_btn, webhook_btn, buttons_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)

    async def _create_embed_from_data(self):
        """Create discord.Embed object and message from stored embed data"""
        data = json.loads(self.embed_data)
        message_content = data.get('message', None)
        
        embed = discord.Embed()
        
        if data.get('title'):
            embed.title = data['title']
        if data.get('description'):
            embed.description = data['description']
        
        embed.color = data.get('color', 0x7c28eb)
        
        if data.get('author_name'):
            embed.set_author(
                name=data['author_name'],
                icon_url=data.get('author_icon') if data.get('author_icon') else None
            )
        
        if data.get('thumbnail'):
            embed.set_thumbnail(url=data['thumbnail'])
        
        if data.get('image'):
            embed.set_image(url=data['image'])
        
        for field in data.get('fields', []):
            embed.add_field(
                name=field['name'],
                value=field['value'],
                inline=field.get('inline', False)
            )
        
        if data.get('footer'):
            embed.set_footer(text=data['footer'], icon_url=data.get('footer_icon') if data.get('footer_icon') else None)
        
        return message_content, embed


class EmbedButtonConfigLayoutView(ui.LayoutView):
    def __init__(self, bot, embed_name, embed_data, author_id, guild_id, embed_buttons=None, link_buttons=None, message_id=None, channel_id=None):
        super().__init__(timeout=None)
        self.bot = bot
        self.embed_name = embed_name
        self.embed_data = embed_data
        self.author_id = author_id
        self.guild_id = guild_id
        self.embed_buttons = embed_buttons or []
        self.link_buttons = link_buttons or []
        self.message_id = message_id
        self.channel_id = channel_id
        self.parent_send_view = None
        self._setup_view()

    def _get_content(self):
        total_buttons = len(self.embed_buttons) + len(self.link_buttons)
        return f"""## {bot_emoji.embed} Button Configuration: {self.embed_name}

Configure buttons for your embed!

**Current Buttons:** {total_buttons}/5

{bot_emoji.arrow} **Add Embed Button** - Button that shows another embed
{bot_emoji.arrow} **Add Link Button** - Button with external URL
{bot_emoji.arrow} **Send Embed** - Send embed with configured buttons"""

    def _setup_view(self):
        content = self._get_content()
        text_display = ui.TextDisplay(content)

        back_btn = ui.Button(label="Back", style=discord.ButtonStyle.gray)
        embed_btn = ui.Button(label="Add Embed Button", style=discord.ButtonStyle.secondary)
        link_btn = ui.Button(label="Add Link Button", style=discord.ButtonStyle.secondary)
        send_btn = ui.Button(label="Send Embed", style=discord.ButtonStyle.success)

        async def back_btn_callback(interaction: discord.Interaction):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the embed creator can use this!", ephemeral=True)
            if self.parent_send_view:
                await interaction.response.edit_message(view=self.parent_send_view)

        async def embed_btn_callback(interaction: discord.Interaction):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the embed creator can use this!", ephemeral=True)
            total_buttons = len(self.embed_buttons) + len(self.link_buttons)
            if total_buttons >= 5:
                return await interaction.response.send_message(f"{bot_emoji.cross} Maximum 5 buttons allowed!", ephemeral=True)
            
            await interaction.response.send_message(
                "**Adding Embed Button**\n\n"
                "**1.** Enter the label for the button (max 25 characters):\n"
                "Type `cancel` to cancel.",
                ephemeral=True
            )
            
            def check(m):
                return m.author.id == self.author_id and m.channel == interaction.channel
            
            try:
                msg = await self.bot.wait_for('message', check=check, timeout=300)
                
                if msg.content.lower() == 'cancel':
                    await msg.reply(f"{bot_emoji.cross} Action cancelled.")
                    return
                
                label = msg.content.strip()
                
                try:
                    await msg.delete()
                except:
                    pass
                
                if not label:
                    await interaction.followup.send(f"{bot_emoji.cross} Button label cannot be empty!", ephemeral=True)
                    return
                
                if len(label) > 25:
                    await interaction.followup.send(f"{bot_emoji.cross} Button label too long! Maximum 25 characters allowed.", ephemeral=True)
                    return
                
                await interaction.followup.send(
                    "**2.** Enter the emoji for the button (or type `none` to skip):",
                    ephemeral=True
                )
                
                msg2 = await self.bot.wait_for('message', check=check, timeout=300)
                
                if msg2.content.lower() == 'cancel':
                    await msg2.reply(f"{bot_emoji.cross} Action cancelled.")
                    return
                
                emoji_input = msg2.content.strip()
                
                try:
                    await msg2.delete()
                except:
                    pass
                
                button_emoji = None
                if emoji_input.lower() != 'none':
                    button_emoji = emoji_input
                
                embeds = await self.bot.db.get_guild_embeds(self.guild_id)
                
                if not embeds:
                    await interaction.followup.send(
                        f"{bot_emoji.cross} No embeds found in this server! Create some embeds first using `+embed create <name>`",
                        ephemeral=True
                    )
                    return
                
                embed_view = EmbedSelectForButtonView(
                    embeds,
                    self.guild_id,
                    self.bot,
                    self,
                    label,
                    button_emoji
                )
                
                select_embed = EmbedFactory.create(
                    title="Select Embed for Button",
                    description=f"Choose an embed for the button **{label}** from the dropdown below:",
                    timestamp=False
                )
                
                await interaction.followup.send(embed=select_embed, view=embed_view, ephemeral=True)
                
            except asyncio.TimeoutError:
                await interaction.followup.send(f"{bot_emoji.cross} Button addition timed out!", ephemeral=True)
            except Exception as e:
                print(f"Error in embed_btn_callback: {e}")
                import traceback
                traceback.print_exc()
                await interaction.followup.send(f"{bot_emoji.cross} An error occurred: {str(e)}", ephemeral=True)

        async def link_btn_callback(interaction: discord.Interaction):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the embed creator can use this!", ephemeral=True)
            total_buttons = len(self.embed_buttons) + len(self.link_buttons)
            if total_buttons >= 5:
                return await interaction.response.send_message(f"{bot_emoji.cross} Maximum 5 buttons allowed!", ephemeral=True)
            
            await interaction.response.send_message(
                "**Adding Link Button**\n\n"
                "**1.** Enter the label for the button (max 25 characters):\n"
                "Type `cancel` to cancel.",
                ephemeral=True
            )
            
            def check(m):
                return m.author.id == self.author_id and m.channel == interaction.channel
            
            try:
                msg = await self.bot.wait_for('message', check=check, timeout=300)
                
                if msg.content.lower() == 'cancel':
                    await msg.reply(f"{bot_emoji.cross} Action cancelled.")
                    return
                
                label = msg.content.strip()
                
                try:
                    await msg.delete()
                except:
                    pass
                
                if not label:
                    await interaction.followup.send(f"{bot_emoji.cross} Button label cannot be empty!", ephemeral=True)
                    return
                
                if len(label) > 25:
                    await interaction.followup.send(f"{bot_emoji.cross} Button label too long! Maximum 25 characters allowed.", ephemeral=True)
                    return
                
                await interaction.followup.send(
                    "**2.** Now enter the URL for the button:",
                    ephemeral=True
                )
                
                url = None
                url_attempts = 0
                while url_attempts < 3:
                    msg2 = await self.bot.wait_for('message', check=check, timeout=300)
                    
                    if msg2.content.lower() == 'cancel':
                        await msg2.reply(f"{bot_emoji.cross} Action cancelled.")
                        return
                    
                    url_input = msg2.content.strip()
                    
                    try:
                        await msg2.delete()
                    except:
                        pass
                    
                    if url_input.startswith(('http://', 'https://')):
                        url = url_input
                        break
                    else:
                        url_attempts += 1
                        if url_attempts < 3:
                            await interaction.followup.send(
                                f"{bot_emoji.cross} Invalid URL! URL must start with http:// or https://\n\n"
                                f"**Attempt {url_attempts}/3** - Please try again:",
                                ephemeral=True
                            )
                        else:
                            await interaction.followup.send(
                                f"{bot_emoji.cross} Too many invalid attempts! Link button addition cancelled.",
                                ephemeral=True
                            )
                            return
                
                self.link_buttons.append({
                    'label': label,
                    'url': url
                })
                
                await self._update_view(interaction)
                
                total_buttons = len(self.embed_buttons) + len(self.link_buttons)
                await interaction.followup.send(
                    f"{bot_emoji.tick} Successfully added link button **{label}** → {url}\n\n"
                    f"**Total Buttons:** {total_buttons}/5\n\n"
                    f"You can add more buttons or use `Send Embed` to send!",
                    ephemeral=True
                )
                
            except asyncio.TimeoutError:
                await interaction.followup.send(f"{bot_emoji.cross} Link button addition timed out!", ephemeral=True)
            except Exception as e:
                print(f"Error in link_btn_callback: {e}")
                import traceback
                traceback.print_exc()
                await interaction.followup.send(f"{bot_emoji.cross} An error occurred: {str(e)}", ephemeral=True)

        async def send_btn_callback(interaction: discord.Interaction):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the embed creator can use this!", ephemeral=True)
            total_buttons = len(self.embed_buttons) + len(self.link_buttons)
            if total_buttons == 0:
                return await interaction.response.send_message(f"{bot_emoji.cross} Please add at least one button before sending!", ephemeral=True)
            
            await interaction.response.send_message(
                "Please enter the channel ID or mention the channel (e.g., #general) in the chat.\n"
                "Type `cancel` to cancel.",
                ephemeral=True
            )
            
            def check(m):
                return m.author.id == self.author_id and m.channel == interaction.channel
            
            try:
                msg = await self.bot.wait_for('message', check=check, timeout=300)
                
                if msg.content.lower() == 'cancel':
                    await msg.reply(f"{bot_emoji.cross} Action cancelled.")
                    return
                
                channel = None
                if msg.channel_mentions:
                    channel = msg.channel_mentions[0]
                else:
                    try:
                        channel_id = int(msg.content.strip('<>#'))
                        channel = self.bot.get_channel(channel_id)
                    except ValueError:
                        await msg.reply(f"{bot_emoji.cross} Invalid channel format. Please use a channel mention or valid channel ID.")
                        return
                
                if not channel:
                    await msg.reply(f"{bot_emoji.cross} Channel not found or I don't have access to it.")
                    return
                
                if not channel.permissions_for(interaction.guild.me).send_messages:
                    await msg.reply(f"{bot_emoji.cross} I don't have permission to send messages in {channel.mention}.")
                    return
                
                message_content, embed = await create_embed_from_database_data(
                    self.bot,
                    self.guild_id,
                    self.embed_name
                )
                
                if not embed:
                    data = json.loads(self.embed_data)
                    message_content = data.get('message', None)
                    
                    embed = discord.Embed()
                    if data.get('title'):
                        embed.title = data['title']
                    if data.get('description'):
                        embed.description = data['description']
                    embed.color = data.get('color', 0x7c28eb)
                    if data.get('author_name'):
                        embed.set_author(name=data['author_name'], icon_url=data.get('author_icon') if data.get('author_icon') else None)
                    if data.get('thumbnail'):
                        embed.set_thumbnail(url=data['thumbnail'])
                    if data.get('image'):
                        embed.set_image(url=data['image'])
                    for field in data.get('fields', []):
                        embed.add_field(name=field['name'], value=field['value'], inline=field.get('inline', False))
                    if data.get('footer'):
                        embed.set_footer(text=data['footer'], icon_url=data.get('footer_icon') if data.get('footer_icon') else None)
                
                persistent_view = EmbedButtonPersistentView(
                    self.bot,
                    self.embed_buttons,
                    self.guild_id,
                    self.link_buttons
                )
                
                sent_message = await channel.send(content=message_content, embed=embed, view=persistent_view)
                
                self.bot.add_view(persistent_view, message_id=sent_message.id)
                
                await self.bot.db.save_embed_button_message(
                    self.guild_id,
                    channel.id,
                    sent_message.id,
                    self.embed_buttons,
                    self.link_buttons
                )
                
                if self.message_id:
                    try:
                        await self.bot.db.delete_embed_button_config_session(self.message_id)
                    except:
                        pass
                
                await msg.reply(f"{bot_emoji.tick} Successfully sent embed **{self.embed_name}** with {total_buttons} button(s) to {channel.mention}!")
                
            except asyncio.TimeoutError:
                await interaction.followup.send(f"{bot_emoji.cross} Timeout! No channel was provided within 5 minutes.", ephemeral=True)
            except Exception as e:
                print(f"Error in send_btn_callback: {e}")
                import traceback
                traceback.print_exc()
                await interaction.followup.send(f"{bot_emoji.cross} Error sending embed: {str(e)}", ephemeral=True)

        back_btn.callback = back_btn_callback
        embed_btn.callback = embed_btn_callback
        link_btn.callback = link_btn_callback
        send_btn.callback = send_btn_callback

        button_row = ui.ActionRow(back_btn, embed_btn, link_btn, send_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)

    async def _update_view(self, interaction):
        """Update the view to reflect current button count"""
        try:
            self.clear_items()
            self._setup_view()
            
            channel = self.bot.get_channel(self.channel_id)
            if channel and self.message_id:
                try:
                    message = await channel.fetch_message(self.message_id)
                    await message.edit(view=self)
                except:
                    pass
        except Exception as e:
            print(f"Error updating view: {e}")

    async def add_embed_button_to_list(self, label, embed_name, emoji=None):
        """Add an embed button to the list"""
        self.embed_buttons.append({
            'label': label,
            'embed_name': embed_name,
            'emoji': emoji
        })

    async def save_config_state(self):
        """Save the current configuration state to database for persistence"""
        if self.message_id and self.channel_id:
            try:
                await self.bot.db.save_embed_button_config_session(
                    self.guild_id,
                    self.channel_id,
                    self.message_id,
                    self.author_id,
                    self.embed_name,
                    self.embed_data,
                    self.embed_buttons,
                    self.link_buttons
                )
            except Exception as e:
                print(f"Failed to save config session: {e}")


class EmbedListPaginationLayoutView(ui.LayoutView):
    def __init__(self, embeds_data, current_page, total_pages, author):
        super().__init__(timeout=300)
        self.embeds_data = embeds_data
        self.current_page = current_page
        self.total_pages = max(1, total_pages)
        self.author = author
        self.items_per_page = 5
        self._setup_view()

    def _get_content(self):
        start = self.current_page * self.items_per_page
        end = start + self.items_per_page
        page_embeds = self.embeds_data[start:end]

        embed_list = []
        for embed_data in page_embeds:
            embed_name = embed_data['name']
            user_id = embed_data['user_id']
            created_at = embed_data['created_at']
            
            try:
                if isinstance(created_at, str):
                    created_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                else:
                    created_date = created_at
                
                ist_timezone = timezone(timedelta(hours=5, minutes=30))
                if created_date.tzinfo is None:
                    created_date = created_date.replace(tzinfo=timezone.utc)
                
                ist_time = created_date.astimezone(ist_timezone)
                formatted_date = ist_time.strftime("%B %d, %Y at %I:%M %p IST")
            except:
                formatted_date = str(created_at)
            
            embed_entry = f"""--------------------------------------------
{bot_emoji.arrow} **Embed Name** : {embed_name}
{bot_emoji.arrow} **Created on** : {formatted_date}
{bot_emoji.arrow} **Created by** : <@{user_id}>
--------------------------------------------"""
            embed_list.append(embed_entry)

        content = f"""## {bot_emoji.embed} Saved Embeds

{chr(10).join(embed_list) if embed_list else "No embeds found!"}

> Page {self.current_page + 1} of {self.total_pages} • Total: {len(self.embeds_data)} embeds"""
        return content

    def _setup_view(self):
        content = self._get_content()
        text_display = ui.TextDisplay(content)

        first_btn = ui.Button(emoji=bot_emoji.double_left, style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        prev_btn = ui.Button(emoji=bot_emoji.left, style=discord.ButtonStyle.gray, disabled=self.current_page == 0)
        delete_btn = ui.Button(emoji=bot_emoji.delete, style=discord.ButtonStyle.red)
        next_btn = ui.Button(emoji=bot_emoji.right, style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)
        last_btn = ui.Button(emoji=bot_emoji.double_right, style=discord.ButtonStyle.gray, disabled=self.current_page >= self.total_pages - 1)

        async def first_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = EmbedListPaginationLayoutView(self.embeds_data, 0, self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)

        async def prev_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = EmbedListPaginationLayoutView(self.embeds_data, max(0, self.current_page - 1), self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)

        async def delete_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            await interaction.message.delete()

        async def next_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = EmbedListPaginationLayoutView(self.embeds_data, min(self.total_pages - 1, self.current_page + 1), self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)

        async def last_callback(interaction: discord.Interaction):
            if self.author and interaction.user.id != self.author.id:
                return await interaction.response.send_message(f"{bot_emoji.cross} Only the command executor can use this menu!", ephemeral=True)
            new_view = EmbedListPaginationLayoutView(self.embeds_data, self.total_pages - 1, self.total_pages, self.author)
            await interaction.response.edit_message(view=new_view)

        first_btn.callback = first_callback
        prev_btn.callback = prev_callback
        delete_btn.callback = delete_callback
        next_btn.callback = next_callback
        last_btn.callback = last_callback

        button_row = ui.ActionRow(first_btn, prev_btn, delete_btn, next_btn, last_btn)
        container = ui.Container(text_display, button_row)
        self.add_item(container)


class EmbedBuilderView(BaseView):
    def __init__(self, bot, embed_name, author_id):
        super().__init__(timeout=300, author=None)
        self.bot = bot
        self.embed_name = embed_name
        self.author_id = author_id
        self.embed_data = {
            'title': None,
            'description': None,
            'color': 0x7c28eb,  # Default purple color
            'footer': None,
            'footer_icon': None,
            'thumbnail': None,
            'image': None,
            'author_name': None,
            'author_icon': None,
            'fields': [],
            'message': None  # Additional message to display above embed
        }
        self.add_item(EmbedOptionsSelect())
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("❌ Only the user who started this embed creator can use it.", ephemeral=True)
            return False
        return True

class EmbedOptionsSelect(BaseSelect):
    def __init__(self):
        options = [
            discord.SelectOption(
                label="➛ | Add Message",
                description="Add text above embed",
                value="message"
            ),
            discord.SelectOption(
                label="➛ | Edit Title",
                description="Set embed title",
                value="title"
            ),
            discord.SelectOption(
                label="➛ | Edit Description",
                description="Set main content",
                value="description"
            ),
            discord.SelectOption(
                label="➛ | Change Color",
                description="Set embed color",
                value="color"
            ),
            discord.SelectOption(
                label="➛ | Edit Footer",
                description="Set footer text & icon",
                value="footer"
            ),
            discord.SelectOption(
                label="➛ | Set Thumbnail",
                description="Add small image",
                value="thumbnail"
            ),
            discord.SelectOption(
                label="➛ | Set Main Image",
                description="Add large image",
                value="image"
            ),
            discord.SelectOption(
                label="➛ | Edit Author",
                description="Set author info",
                value="author"
            ),
            discord.SelectOption(
                label="➛ | Add Field",
                description="Add custom fields",
                value="field"
            ),
            discord.SelectOption(
                label="➛ | Preview Embed",
                description="See current result",
                value="preview"
            ),
            discord.SelectOption(
                label="➛ | Save Embed",
                description="Save for later use",
                value="save"
            )
        ]
        super().__init__(placeholder="Choose what to customize...", options=options)
    
    async def callback(self, interaction: discord.Interaction):
        view = self.view
        option = self.values[0]
        
        if option == "title":
            modal = TextInputModal("Edit Title", "Enter embed title:", "title", required=False, max_length=256)
        elif option == "description":
            modal = TextInputModal("Edit Description", "Enter embed description:", "description", required=False, max_length=4000, style=discord.TextStyle.paragraph)
        elif option == "footer":
            modal = FooterModal()
        elif option == "thumbnail":
            modal = TextInputModal("Set Thumbnail", "Enter thumbnail image URL:", "thumbnail", required=False, max_length=2048)
        elif option == "image":
            modal = TextInputModal("Set Main Image", "Enter main image URL:", "image", required=False, max_length=2048)
        elif option == "author":
            modal = AuthorModal()
        elif option == "field":
            modal = FieldModal()
        elif option == "message":
            modal = TextInputModal("Add Message", "Enter message text:", "message", required=False, max_length=2000, style=discord.TextStyle.paragraph)
        elif option == "color":
            modal = ColorModal()
        elif option == "preview":
            await self.show_preview(interaction)
            return
        elif option == "save":
            await self.save_embed(interaction)
            return
        
        modal.view = view
        await interaction.response.send_modal(modal)
    
    async def show_preview(self, interaction):
        view = self.view
        embed_data = view.embed_data
        
        preview_embed = discord.Embed()
        
        if embed_data['title']:
            preview_embed.title = embed_data['title']
        if embed_data['description']:
            preview_embed.description = embed_data['description']
        
        preview_embed.color = embed_data['color']
        
        if embed_data['author_name']:
            preview_embed.set_author(
                name=embed_data['author_name'],
                icon_url=embed_data['author_icon'] if embed_data['author_icon'] else None
            )
        
        if embed_data['thumbnail']:
            preview_embed.set_thumbnail(url=embed_data['thumbnail'])
        
        if embed_data['image']:
            preview_embed.set_image(url=embed_data['image'])
        
        for field in embed_data['fields']:
            preview_embed.add_field(
                name=field['name'],
                value=field['value'],
                inline=field.get('inline', False)
            )
        
        if embed_data['footer']:
            preview_embed.set_footer(text=embed_data['footer'], icon_url=embed_data.get('footer_icon') if embed_data.get('footer_icon') else None)
        
        # Prepare preview content with message if it exists
        preview_content = f"**🔍 Preview of embed '{view.embed_name}':**"
        if embed_data.get('message'):
            preview_content += f"\n\n**Message:** {embed_data['message']}"
        
        # Send ephemeral preview that only the user can see
        await interaction.response.send_message(content=preview_content, embed=preview_embed, ephemeral=True)
    
    async def save_embed(self, interaction):
        view = self.view
        
        try:
            # Use the global JSON serializer to handle datetime objects
            
            # Save embed to database
            embed_json = json.dumps(view.embed_data, default=json_serializer)
            await view.bot.db.save_custom_embed(interaction.guild.id, interaction.user.id, view.embed_name, embed_json)
            
            success_embed = EmbedFactory.create(
                title="✅ Embed Saved",
                description=f"Embed **{view.embed_name}** has been saved successfully!\n\n"
                           f"📋 Use `+embed send {view.embed_name}` to send this embed to any channel",
                color=0x00ff00
            )
            
            await interaction.response.edit_message(content=None, embed=success_embed, view=None)
        
        except Exception as e:
            error_embed = create_error_embed(
                f"Failed to save embed: {str(e)}",
                title="Save Error"
            )
            await interaction.response.edit_message(embed=error_embed, view=view)

class TextInputModal(discord.ui.Modal):
    def __init__(self, title, label, field_name, required=False, max_length=4000, style=discord.TextStyle.short):
        super().__init__(title=title)
        self.field_name = field_name
        
        self.text_input = discord.ui.TextInput(
            label=label,
            required=required,
            max_length=max_length,
            style=style,
            placeholder=f"Enter {field_name}..."
        )
        self.add_item(self.text_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            self.view.embed_data[self.field_name] = self.text_input.value if self.text_input.value else None
            field_display = self.field_name.replace('_', ' ').title()
            await interaction.response.send_message(
                f"{bot_emoji.tick} **{field_display}** has been updated!",
                ephemeral=True
            )
        except Exception as e:
            print(f"Error in TextInputModal.on_submit: {e}")
            import traceback
            traceback.print_exc()
            await interaction.response.send_message(f"{bot_emoji.cross} Error: {str(e)}", ephemeral=True)

class AuthorModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title="Edit Author")
        
        self.author_name = discord.ui.TextInput(
            label="Author Name",
            required=False,
            max_length=256,
            placeholder="Enter author name..."
        )
        self.author_icon = discord.ui.TextInput(
            label="Author Icon URL",
            required=False,
            max_length=2048,
            placeholder="Enter author icon URL..."
        )
        
        self.add_item(self.author_name)
        self.add_item(self.author_icon)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            self.view.embed_data['author_name'] = self.author_name.value if self.author_name.value else None
            self.view.embed_data['author_icon'] = self.author_icon.value if self.author_icon.value else None
            await interaction.response.send_message(
                f"{bot_emoji.tick} **Author** has been updated!",
                ephemeral=True
            )
        except Exception as e:
            print(f"Error in AuthorModal.on_submit: {e}")
            import traceback
            traceback.print_exc()
            await interaction.response.send_message(f"{bot_emoji.cross} Error: {str(e)}", ephemeral=True)

class FooterModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title="Edit Footer")
        
        self.footer_text = discord.ui.TextInput(
            label="Footer Text",
            required=False,
            max_length=2048,
            placeholder="Enter footer text..."
        )
        self.footer_icon = discord.ui.TextInput(
            label="Footer Icon URL",
            required=False,
            max_length=2048,
            placeholder="Enter footer icon URL (Discord CDN or variables supported)..."
        )
        
        self.add_item(self.footer_text)
        self.add_item(self.footer_icon)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            self.view.embed_data['footer'] = self.footer_text.value if self.footer_text.value else None
            self.view.embed_data['footer_icon'] = self.footer_icon.value if self.footer_icon.value else None
            await interaction.response.send_message(
                f"{bot_emoji.tick} **Footer** has been updated!",
                ephemeral=True
            )
        except Exception as e:
            print(f"Error in FooterModal.on_submit: {e}")
            import traceback
            traceback.print_exc()
            await interaction.response.send_message(f"{bot_emoji.cross} Error: {str(e)}", ephemeral=True)

class FieldModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title="Add Field")
        
        self.field_name = discord.ui.TextInput(
            label="Field Name",
            required=True,
            max_length=256,
            placeholder="Enter field name..."
        )
        self.field_value = discord.ui.TextInput(
            label="Field Value",
            required=True,
            max_length=1024,
            style=discord.TextStyle.paragraph,
            placeholder="Enter field value..."
        )
        self.field_inline = discord.ui.TextInput(
            label="Inline (true/false)",
            required=False,
            max_length=5,
            placeholder="true or false (default: false)"
        )
        
        self.add_item(self.field_name)
        self.add_item(self.field_value)
        self.add_item(self.field_inline)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            inline = self.field_inline.value.lower() == 'true' if self.field_inline.value else False
            
            field_data = {
                'name': self.field_name.value,
                'value': self.field_value.value,
                'inline': inline
            }
            
            self.view.embed_data['fields'].append(field_data)
            await interaction.response.send_message(
                f"{bot_emoji.tick} **Field** has been added!",
                ephemeral=True
            )
        except Exception as e:
            print(f"Error in FieldModal.on_submit: {e}")
            import traceback
            traceback.print_exc()
            await interaction.response.send_message(f"{bot_emoji.cross} Error: {str(e)}", ephemeral=True)

class ColorModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title="Change Color")
        
        self.color_input = discord.ui.TextInput(
            label="Embed Color",
            required=False,
            max_length=7,
            placeholder="Enter hex color (e.g., #ff0000) or leave empty for default"
        )
        
        self.add_item(self.color_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            color_value = self.color_input.value
            
            if color_value:
                try:
                    if color_value.startswith('#'):
                        color_value = color_value[1:]
                    color_int = int(color_value, 16)
                    self.view.embed_data['color'] = color_int
                except ValueError:
                    await interaction.response.send_message(f"{bot_emoji.cross} Invalid color format! Please use hex format like #ff0000", ephemeral=True)
                    return
            else:
                self.view.embed_data['color'] = 0x7c28eb
            
            await interaction.response.send_message(
                f"{bot_emoji.tick} **Color** has been updated!",
                ephemeral=True
            )
        except Exception as e:
            print(f"Error in ColorModal.on_submit: {e}")
            import traceback
            traceback.print_exc()
            await interaction.response.send_message(f"{bot_emoji.cross} Error: {str(e)}", ephemeral=True)

class EmbedSendView(BaseView):
    def __init__(self, bot, embed_name, embed_data, author_id):
        super().__init__(timeout=300, author=None)
        self.bot = bot
        self.embed_name = embed_name
        self.embed_data = embed_data
        self.author_id = author_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("❌ Only the user who started this embed send can use it.", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label='Send Directly', style=discord.ButtonStyle.primary)
    async def send_directly(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "Please enter a channel ID or mention the channel (e.g., #general) in the chat.\n"
            "If you want to cancel the action, simply type `cancel`.",
            ephemeral=True
        )
        
        def check(message):
            return message.author.id == self.author_id and message.channel == interaction.channel
        
        try:
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply("❌ Action cancelled.")
                return
            
            # Try to parse channel
            channel = None
            if message.channel_mentions:
                channel = message.channel_mentions[0]
            else:
                try:
                    channel_id = int(message.content.strip('<>#'))
                    channel = self.bot.get_channel(channel_id)
                except ValueError:
                    await message.reply("❌ Invalid channel format. Please use a channel mention or valid channel ID.")
                    return
            
            if not channel:
                await message.reply("❌ Channel not found or I don't have access to it.")
                return
            
            if not channel.permissions_for(interaction.guild.me).send_messages:
                await message.reply(f"❌ I don't have permission to send messages in {channel.mention}.")
                return
            
            # Create and send the embed
            message_content, embed = await self.create_embed_from_data()
            await channel.send(content=message_content, embed=embed)
            
            success_embed = EmbedFactory.create(
                title="✅ Embed Sent",
                description=f"Successfully sent embed **{self.embed_name}** to {channel.mention}!",
                color=0x00ff00
            )
            await message.reply(embed=success_embed)
            
        except asyncio.TimeoutError:
            await interaction.followup.send("⏰ Timeout! No channel was provided within 5 minutes.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Error sending embed: {str(e)}", ephemeral=True)
    
    @discord.ui.button(label='Send As Webhook', style=discord.ButtonStyle.secondary)
    async def send_as_webhook(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "Please enter a username for the webhook in the chat. You can also tag a user to use their username.\n"
            "If you want to cancel the action, simply type `cancel`.",
            ephemeral=True
        )
        
        def check(message):
            return message.author.id == self.author_id and message.channel == interaction.channel
        
        try:
            # Get username
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply("❌ Action cancelled.")
                return
            
            webhook_username = message.content
            if message.mentions:
                webhook_username = message.mentions[0].display_name
            
            # Get avatar URL
            await message.reply(
                "Please enter an avatar URL for the webhook in the chat. You can also tag a user to use their avatar.\n"
                "If you do not have an avatar, you can type `skip` to continue or if you want to cancel the action, simply type `cancel`."
            )
            
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply("❌ Action cancelled.")
                return
            
            webhook_avatar = None
            if message.content.lower() != 'skip':
                if message.mentions:
                    webhook_avatar = message.mentions[0].display_avatar.url
                elif message.content.startswith(('http://', 'https://')):
                    webhook_avatar = message.content
                else:
                    await message.reply("❌ Invalid avatar URL format. Please provide a valid URL or tag a user.")
                    return
            
            # Get channel
            await message.reply(
                "Give the channel ID or #channel you want this embed to be sent.\n"
                "If you want the same channel, you can type `skip` to continue or if you want to cancel the action, simply type `cancel`."
            )
            
            message = await self.bot.wait_for('message', timeout=300.0, check=check)
            
            if message.content.lower() == 'cancel':
                await message.reply("❌ Action cancelled.")
                return
            
            # Parse channel
            target_channel = interaction.channel
            if message.content.lower() != 'skip':
                if message.channel_mentions:
                    target_channel = message.channel_mentions[0]
                else:
                    try:
                        channel_id = int(message.content.strip('<>#'))
                        target_channel = self.bot.get_channel(channel_id)
                    except ValueError:
                        await message.reply("❌ Invalid channel format. Please use a channel mention or valid channel ID.")
                        return
            
            if not target_channel:
                await message.reply("❌ Channel not found or I don't have access to it.")
                return
            
            if not target_channel.permissions_for(interaction.guild.me).manage_webhooks:
                await message.reply(f"❌ I don't have permission to manage webhooks in {target_channel.mention}.")
                return
            
            # Create webhook and send embed
            webhook = await target_channel.create_webhook(name=webhook_username[:80])  # Discord limit
            message_content, embed = await self.create_embed_from_data()
            
            await webhook.send(
                content=message_content,
                embed=embed,
                username=webhook_username,
                avatar_url=webhook_avatar
            )
            
            # Clean up webhook
            await webhook.delete()
            
            success_embed = EmbedFactory.create(
                title="✅ Embed Sent via Webhook",
                description=f"Successfully sent embed **{self.embed_name}** to {target_channel.mention} as **{webhook_username}**!",
                color=0x00ff00
            )
            await message.reply(embed=success_embed)
            
        except asyncio.TimeoutError:
            await interaction.followup.send("⏰ Timeout! The webhook setup was not completed within 5 minutes.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Error creating webhook: {str(e)}", ephemeral=True)
    
    @discord.ui.button(label='Send with Buttons', style=discord.ButtonStyle.success)
    async def add_button_embeds(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = EmbedFactory.create(
            title=f"{bot_emoji.embed} Button Configuration: {self.embed_name}",
            description=f"Configure buttons for your embed!\n\n"
                       f"**Current Buttons:** 0/5\n\n"
                       f"{bot_emoji.arrow} **Add Embed Button** - Button that shows another embed\n"
                       f"{bot_emoji.arrow} **Add Link Button** - Button with external URL\n"
                       f"{bot_emoji.arrow} **Send Embed** - Send embed with configured buttons",
            timestamp=False
        )
        
        button_config_view = EmbedButtonConfigView(
            self.bot,
            self.embed_name,
            self.embed_data,
            self.author_id,
            interaction.guild.id
        )
        button_config_view.parent_send_view = self
        
        await interaction.response.edit_message(embed=embed, view=button_config_view)
        
        # Get the message that was just edited to capture the message ID
        message = await interaction.original_response()
        button_config_view.message_id = message.id
        button_config_view.channel_id = interaction.channel.id
        
        # Register the view with the bot for persistence
        self.bot.add_view(button_config_view, message_id=message.id)
        
        # Save initial configuration state
        await button_config_view.save_config_state()
    
    async def create_embed_from_data(self, member=None, invite=None, booster=None):
        """Create discord.Embed object and message from stored embed data with variable replacement
        Returns tuple: (message_content, embed) where message_content can be None"""
        data = json.loads(self.embed_data)
        
        # Replace variables in embed data if member is provided
        if member:
            data = await self.replace_variables_in_embed_data(data, member, invite, booster)
        
        # Extract message content if it exists
        message_content = data.get('message', None)
        
        embed = discord.Embed()
        
        if data.get('title'):
            embed.title = data['title']
        if data.get('description'):
            embed.description = data['description']
        
        embed.color = data.get('color', 0x7c28eb)
        
        if data.get('author_name'):
            embed.set_author(
                name=data['author_name'],
                icon_url=data.get('author_icon') if data.get('author_icon') else None
            )
        
        if data.get('thumbnail'):
            embed.set_thumbnail(url=data['thumbnail'])
        
        if data.get('image'):
            embed.set_image(url=data['image'])
        
        for field in data.get('fields', []):
            embed.add_field(
                name=field['name'],
                value=field['value'],
                inline=field.get('inline', False)
            )
        
        if data.get('footer'):
            embed.set_footer(text=data['footer'], icon_url=data.get('footer_icon') if data.get('footer_icon') else None)
        
        return message_content, embed
    
    async def replace_variables_in_embed_data(self, data, member, invite=None, booster=None):
        """Replace variables in embed data fields"""
        # Use the bot's replace_variables function
        for key in ['title', 'description', 'footer', 'author_name', 'message']:
            if data.get(key):
                data[key] = await self.bot.replace_variables(data[key], member, invite, False, booster)
        
        # Replace variables in image fields (including footer_icon)
        for key in ['thumbnail', 'author_icon', 'footer_icon', 'image']:
            if data.get(key):
                data[key] = await self.bot.replace_variables(data[key], member, invite, False, booster)
        
        # Replace variables in fields
        for field in data.get('fields', []):
            if field.get('name'):
                field['name'] = await self.bot.replace_variables(field['name'], member, invite, False, booster)
            if field.get('value'):
                field['value'] = await self.bot.replace_variables(field['value'], member, invite, False, booster)
        
        return data

class EmbedButtonConfigView(BaseView):
    def __init__(self, bot, embed_name, embed_data, author_id, guild_id, embed_buttons=None, link_buttons=None, message_id=None, channel_id=None):
        super().__init__(timeout=None)
        self.bot = bot
        self.embed_name = embed_name
        self.embed_data = embed_data
        self.author_id = author_id
        self.guild_id = guild_id
        self.embed_buttons = embed_buttons if embed_buttons is not None else []
        self.link_buttons = link_buttons if link_buttons is not None else []
        self.message_id = message_id
        self.channel_id = channel_id
        self.parent_send_view = None
    
    async def save_config_state(self):
        """Save the current configuration state to database for persistence"""
        if self.message_id and self.channel_id:
            try:
                await self.bot.db.save_embed_button_config_session(
                    self.guild_id,
                    self.channel_id,
                    self.message_id,
                    self.author_id,
                    self.embed_name,
                    self.embed_data,
                    self.embed_buttons,
                    self.link_buttons
                )
                print(f"💾 Saved embed button config session for message {self.message_id}")
            except Exception as e:
                print(f"⚠️ Failed to save config session: {e}")
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("❌ Only the user who started this embed send can use it.", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label='Back', style=discord.ButtonStyle.gray, row=0)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.parent_send_view:
            back_embed = EmbedFactory.create(
                title=f"{bot_emoji.embed} {self.embed_name}",
                description=f"Choose the button below to send the embed however you like\n\n"
                           f"{bot_emoji.arrow} **Send Directly** - Send embed to a channel\n"
                           f"{bot_emoji.arrow} **Send As Webhook** - Send using a custom webhook identity\n"
                           f"{bot_emoji.arrow} **Send with Buttons** - Add interactive buttons to your embed",
                timestamp=False
            )
            back_view = EmbedSendView(
                self.bot,
                self.embed_name,
                self.embed_data,
                self.author_id
            )
            await interaction.response.edit_message(embed=back_embed, view=back_view)
        else:
            await interaction.response.send_message(
                "<:jo1ntrx_cross:1405094904568483880> Cannot go back, please run the command again.",
                ephemeral=True
            )
    
    @discord.ui.button(label='Add Embed Buttons', style=discord.ButtonStyle.primary, row=0)
    async def add_embed_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        total_buttons = len(self.embed_buttons) + len(self.link_buttons)
        if total_buttons >= 5:
            await interaction.response.send_message(
                "<:jo1ntrx_cross:1405094904568483880> **You've reached the maximum button limit (5)!**\n\n"
                "Use `Send Embed` to send the embed with configured buttons!",
                ephemeral=True
            )
            return
        
        await interaction.response.send_message(
            "**Adding Embed Button**\n\n"
            "**1.** Enter the label for the button (max 25 characters):",
            ephemeral=True
        )
        
        def check(m):
            return m.author.id == self.author_id and m.channel == interaction.channel
        
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=300)
            label = msg.content.strip()
            
            try:
                await msg.delete()
            except:
                pass
            
            if not label:
                await interaction.followup.send(
                    "<:jo1ntrx_cross:1405094904568483880> Button label cannot be empty!",
                    ephemeral=True
                )
                return
            
            if len(label) > 25:
                await interaction.followup.send(
                    "<:jo1ntrx_cross:1405094904568483880> Button label too long! Maximum 25 characters allowed.",
                    ephemeral=True
                )
                return
            
            # Ask for emoji
            await interaction.followup.send(
                "**2.** Enter the emoji for the button (or type `none` to skip):",
                ephemeral=True
            )
            
            msg2 = await self.bot.wait_for('message', check=check, timeout=300)
            emoji_input = msg2.content.strip()
            
            try:
                await msg2.delete()
            except:
                pass
            
            # Handle emoji
            button_emoji = None
            if emoji_input.lower() != 'none':
                button_emoji = emoji_input
            
            embeds = await self.bot.db.get_guild_embeds(self.guild_id)
            
            if not embeds:
                await interaction.followup.send(
                    "<:jo1ntrx_cross:1405094904568483880> No embeds found in this server! Create some embeds first using `+embed create <name>`",
                    ephemeral=True
                )
                return
            
            embed_view = EmbedSelectForButtonView(
                embeds,
                self.guild_id,
                self.bot,
                self,
                label,
                button_emoji
            )
            
            select_embed = EmbedFactory.create(
                title="Select Embed for Button",
                description=f"Choose an embed for the button **{label}** from the dropdown below:",
                timestamp=False
            )
            
            await interaction.followup.send(embed=select_embed, view=embed_view, ephemeral=True)
            
        except asyncio.TimeoutError:
            await interaction.followup.send(
                "<:jo1ntrx_cross:1405094904568483880> Button addition timed out!",
                ephemeral=True
            )
        except Exception as e:
            print(f"Error in add_embed_button: {e}")
            import traceback
            traceback.print_exc()
            await interaction.followup.send(
                f"<:jo1ntrx_cross:1405094904568483880> An error occurred: {str(e)}",
                ephemeral=True
            )
    
    @discord.ui.button(label='Add Link Buttons', style=discord.ButtonStyle.primary, row=0)
    async def add_link_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        total_buttons = len(self.embed_buttons) + len(self.link_buttons)
        if total_buttons >= 5:
            await interaction.response.send_message(
                "<:jo1ntrx_cross:1405094904568483880> **You've reached the maximum button limit (5)!**\n\n"
                "Use `Send Embed` to send the embed with configured buttons!",
                ephemeral=True
            )
            return
        
        await interaction.response.send_message(
            "**Adding Link Button**\n\n"
            "**1.** Enter the label for the button (max 25 characters):",
            ephemeral=True
        )
        
        def check(m):
            return m.author.id == self.author_id and m.channel == interaction.channel
        
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=300)
            label = msg.content.strip()
            
            try:
                await msg.delete()
            except:
                pass
            
            if not label:
                await interaction.followup.send(
                    "<:jo1ntrx_cross:1405094904568483880> Button label cannot be empty!",
                    ephemeral=True
                )
                return
            
            if len(label) > 25:
                await interaction.followup.send(
                    "<:jo1ntrx_cross:1405094904568483880> Button label too long! Maximum 25 characters allowed.",
                    ephemeral=True
                )
                return
            
            await interaction.followup.send(
                "**2.** Now enter the URL for the button:",
                ephemeral=True
            )
            
            url = None
            url_attempts = 0
            while url_attempts < 3:
                msg = await self.bot.wait_for('message', check=check, timeout=300)
                url_input = msg.content.strip()
                
                try:
                    await msg.delete()
                except:
                    pass
                
                if url_input.startswith(('http://', 'https://')):
                    url = url_input
                    break
                else:
                    url_attempts += 1
                    if url_attempts < 3:
                        await interaction.followup.send(
                            f"<:jo1ntrx_cross:1405094904568483880> Invalid URL! URL must start with http:// or https://\n\n"
                            f"**Attempt {url_attempts}/3** - Please try again:",
                            ephemeral=True
                        )
                    else:
                        await interaction.followup.send(
                            "<:jo1ntrx_cross:1405094904568483880> Too many invalid attempts! Link button addition cancelled.",
                            ephemeral=True
                        )
                        return
            
            self.link_buttons.append({
                'label': label,
                'url': url
            })
            
            # Save configuration state for persistence
            await self.save_config_state()
            
            total_buttons = len(self.embed_buttons) + len(self.link_buttons)
            success_embed = EmbedFactory.create(
                title="<:jo1ntrx_tick:1405094884947267715> Link Button Added",
                description=f"Successfully added link button **{label}** → {url}\n\n"
                           f"**Total Buttons:** {total_buttons}/5\n\n"
                           f"You can add more buttons or use `Send Embed` to send the embed!",
                timestamp=False
            )
            await interaction.followup.send(embed=success_embed, ephemeral=True)
            
        except asyncio.TimeoutError:
            await interaction.followup.send(
                "<:jo1ntrx_cross:1405094904568483880> Link button addition timed out!",
                ephemeral=True
            )
        except Exception as e:
            print(f"Error in add_link_button: {e}")
            import traceback
            traceback.print_exc()
            await interaction.followup.send(
                f"<:jo1ntrx_cross:1405094904568483880> An error occurred: {str(e)}",
                ephemeral=True
            )
    
    @discord.ui.button(label='Send Embed', style=discord.ButtonStyle.success, row=0)
    async def send_embed(self, interaction: discord.Interaction, button: discord.ui.Button):
        total_buttons = len(self.embed_buttons) + len(self.link_buttons)
        if total_buttons == 0:
            await interaction.response.send_message(
                "<:jo1ntrx_cross:1405094904568483880> Please add at least one button (embed or link) before sending!",
                ephemeral=True
            )
            return
        
        await interaction.response.send_message(
            "**Send Embed**\n\n"
            "In which channel should the embed be sent? (mention or ID):",
            ephemeral=True
        )
        
        def check(m):
            return m.author.id == self.author_id and m.channel == interaction.channel
        
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=300)
            
            try:
                await msg.delete()
            except:
                pass
            
            channel = None
            if msg.channel_mentions:
                channel = msg.channel_mentions[0]
            else:
                try:
                    channel_id = int(msg.content.strip('<>#'))
                    channel = self.bot.get_channel(channel_id)
                except:
                    await interaction.followup.send(
                        "<:jo1ntrx_cross:1405094904568483880> Invalid channel!",
                        ephemeral=True
                    )
                    return
            
            if not channel:
                await interaction.followup.send(
                    "<:jo1ntrx_cross:1405094904568483880> Channel not found!",
                    ephemeral=True
                )
                return
            
            message_content, embed = await create_embed_from_database_data(
                self.bot,
                self.guild_id,
                self.embed_name
            )
            
            if not embed:
                await interaction.followup.send(
                    "<:jo1ntrx_cross:1405094904568483880> Failed to load embed!",
                    ephemeral=True
                )
                return
            
            persistent_view = EmbedButtonPersistentView(
                self.bot,
                self.embed_buttons,
                self.guild_id,
                self.link_buttons
            )
            
            sent_message = await channel.send(content=message_content, embed=embed, view=persistent_view)
            
            # Register the view with the bot for immediate persistence
            self.bot.add_view(persistent_view, message_id=sent_message.id)
            
            # Save to database for persistence across restarts
            await self.bot.db.save_embed_button_message(
                self.guild_id,
                channel.id,
                sent_message.id,
                self.embed_buttons,
                self.link_buttons
            )
            
            # Clean up the configuration session from database now that embed is sent
            if self.message_id:
                await self.bot.db.delete_embed_button_config_session(self.message_id)
                print(f"🧹 Cleaned up config session for message {self.message_id}")
            
            total_buttons = len(self.embed_buttons) + len(self.link_buttons)
            success_embed = EmbedFactory.create(
                title="<:jo1ntrx_tick:1405094884947267715> Embed Sent",
                description=f"Successfully sent embed **{self.embed_name}** to {channel.mention} with {total_buttons} button(s)!",
                color=0x00ff00
            )
            await interaction.followup.send(embed=success_embed, ephemeral=True)
            
        except asyncio.TimeoutError:
            await interaction.followup.send(
                "<:jo1ntrx_cross:1405094904568483880> Send embed timed out!",
                ephemeral=True
            )

class EmbedSelectForButtonView(BaseView):
    def __init__(self, embeds, guild_id, bot, parent_view, button_label, button_emoji=None):
        super().__init__(timeout=300, author=None)
        self.guild_id = guild_id
        self.bot = bot
        self.parent_view = parent_view
        self.button_label = button_label
        self.button_emoji = button_emoji
        
        options = []
        for embed in embeds[:25]:
            embed_name = embed['name']
            options.append(discord.SelectOption(
                label=embed_name,
                description=f"Use {embed_name} for this button",
                value=embed_name,
                emoji=bot_emoji.embed
            ))
        
        if options:
            select = EmbedSelectForButton(options, self.guild_id, self.bot, self.parent_view, self.button_label, self.button_emoji)
            self.add_item(select)

class EmbedSelectForButton(BaseSelect):
    def __init__(self, options, guild_id, bot, parent_view, button_label, button_emoji=None):
        super().__init__(
            placeholder="Choose an embed for this button...",
            options=options,
            min_values=1,
            max_values=1
        )
        self.guild_id = guild_id
        self.bot = bot
        self.parent_view = parent_view
        self.button_label = button_label
        self.button_emoji = button_emoji
    
    async def callback(self, interaction: discord.Interaction):
        embed_name = self.values[0]
        
        button_data = {
            'label': self.button_label,
            'embed_name': embed_name
        }
        if self.button_emoji:
            button_data['emoji'] = self.button_emoji
        
        self.parent_view.embed_buttons.append(button_data)
        
        # Save configuration state for persistence
        await self.parent_view.save_config_state()
        
        total_buttons = len(self.parent_view.embed_buttons) + len(self.parent_view.link_buttons)
        success_embed = EmbedFactory.create(
            title="<:jo1ntrx_tick:1405094884947267715> Embed Button Added",
            description=f"Successfully added button **{self.button_label}** → **{embed_name}**\n\n"
                       f"**Total Buttons:** {total_buttons}/5\n\n"
                       f"You can add more buttons or use `Send Embed` to send the embed!",
            timestamp=False
        )
        
        await interaction.response.edit_message(embed=success_embed, view=None)

class EmbedButtonPersistentView(BaseView):
    def __init__(self, bot, embed_buttons, guild_id, link_buttons=None):
        super().__init__(timeout=None)
        self.bot = bot
        self.embed_buttons = embed_buttons
        self.guild_id = guild_id
        self.link_buttons = link_buttons or []
        
        for idx, button_data in enumerate(embed_buttons):
            button_kwargs = {
                'label': button_data['label'],
                'style': discord.ButtonStyle.secondary,
                'custom_id': f"embed_button_{self.guild_id}_{button_data['embed_name']}_{idx}"
            }
            if button_data.get('emoji'):
                button_kwargs['emoji'] = button_data['emoji']
            
            button = discord.ui.Button(**button_kwargs)
            button.callback = self.create_button_callback(button_data['embed_name'])
            self.add_item(button)
        
        for idx, button_data in enumerate(self.link_buttons):
            button = discord.ui.Button(
                label=button_data['label'],
                style=discord.ButtonStyle.link,
                url=button_data['url']
            )
            self.add_item(button)
    
    def create_button_callback(self, embed_name):
        async def button_callback(interaction: discord.Interaction):
            message_content, embed = await create_embed_from_database_data(
                self.bot,
                self.guild_id,
                embed_name
            )
            
            if embed:
                await interaction.response.send_message(
                    content=message_content,
                    embed=embed,
                    ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    "<:jo1ntrx_cross:1405094904568483880> Failed to load embed!",
                    ephemeral=True
                )
        
        return button_callback

class EmbedListPaginationView(BaseView):
    def __init__(self, embeds_data, current_page, total_pages, create_embed_func, author):
        super().__init__(timeout=300, author=author)
        self.embeds_data = embeds_data
        self.current_page = current_page
        self.total_pages = total_pages
        self.create_embed = create_embed_func
        self.author = author
        
        # Update button states
        self.update_button_states()

    def update_button_states(self):
        """Update button disabled states based on current page"""
        # First page and previous page buttons
        self.first_page.disabled = self.current_page == 0
        self.previous_page.disabled = self.current_page == 0
        
        # Last page and next page buttons  
        self.next_page.disabled = self.current_page == self.total_pages - 1
        self.last_page.disabled = self.current_page == self.total_pages - 1

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message(
                "You cannot interact with this menu.", 
                ephemeral=True
            )
            return False
        return True

    @discord.ui.button(emoji=bot_emoji.double_left, style=discord.ButtonStyle.gray, row=0)
    async def first_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to first page"""
        self.current_page = 0
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.left, style=discord.ButtonStyle.gray, row=0)
    async def previous_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to previous page"""
        self.current_page -= 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.delete, style=discord.ButtonStyle.red, row=0)
    async def delete_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Delete the embed list message"""
        await interaction.response.edit_message(content="Embed list deleted.", embed=None, view=None)

    @discord.ui.button(emoji=bot_emoji.right, style=discord.ButtonStyle.gray, row=0)
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to next page"""
        self.current_page += 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(emoji=bot_emoji.double_right, style=discord.ButtonStyle.gray, row=0)
    async def last_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Go to last page"""
        self.current_page = self.total_pages - 1
        self.update_button_states()
        embed = self.create_embed(self.current_page)
        await interaction.response.edit_message(embed=embed, view=self)

class EmbedCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    async def cog_load(self):
        """Restore persistent embed button views when the cog is loaded"""
        await asyncio.sleep(10)
        
        try:
            restored_count = 0
            skipped_count = 0
            
            messages = await self.bot.db.get_all_embed_button_messages()
            
            for msg_data in messages:
                guild_id = msg_data['guild_id']
                channel_id = msg_data['channel_id']
                message_id = msg_data['message_id']
                embed_buttons = msg_data['embed_buttons']
                link_buttons = msg_data['link_buttons']
                
                try:
                    guild = self.bot.get_guild(guild_id)
                    
                    if not guild:
                        try:
                            guild = await self.bot.fetch_guild(guild_id)
                        except (discord.Forbidden, discord.NotFound):
                            skipped_count += 1
                            continue
                        except discord.HTTPException as e:
                            if e.code == 10004:
                                skipped_count += 1
                                continue
                            skipped_count += 1
                            continue
                        except Exception:
                            skipped_count += 1
                            continue
                    
                    channel = guild.get_channel(channel_id)
                    if not channel:
                        try:
                            channel = await self.bot.fetch_channel(channel_id)
                        except:
                            skipped_count += 1
                            continue
                    
                    try:
                        message = await channel.fetch_message(message_id)
                    except discord.NotFound:
                        skipped_count += 1
                        continue
                    except Exception:
                        skipped_count += 1
                        continue
                    
                    view = EmbedButtonPersistentView(
                        self.bot,
                        embed_buttons,
                        guild_id,
                        link_buttons
                    )
                    
                    self.bot.add_view(view, message_id=message.id)
                    restored_count += 1
                    
                except Exception as e:
                    skipped_count += 1
            
            config_restored_count = 0
            config_skipped_count = 0
            
            config_sessions = await self.bot.db.get_all_embed_button_config_sessions()
            
            for session in config_sessions:
                guild_id = session['guild_id']
                channel_id = session['channel_id']
                message_id = session['message_id']
                author_id = session['author_id']
                embed_name = session['embed_name']
                embed_data = session['embed_data']
                embed_buttons = session['embed_buttons']
                link_buttons = session['link_buttons']
                
                try:
                    guild = self.bot.get_guild(guild_id)
                    if not guild:
                        try:
                            guild = await self.bot.fetch_guild(guild_id)
                        except:
                            config_skipped_count += 1
                            continue
                    
                    channel = guild.get_channel(channel_id)
                    if not channel:
                        try:
                            channel = await self.bot.fetch_channel(channel_id)
                        except:
                            config_skipped_count += 1
                            continue
                    
                    try:
                        message = await channel.fetch_message(message_id)
                    except discord.NotFound:
                        config_skipped_count += 1
                        continue
                    except Exception:
                        config_skipped_count += 1
                        continue
                    
                    config_view = EmbedButtonConfigView(
                        self.bot,
                        embed_name,
                        embed_data,
                        author_id,
                        guild_id,
                        embed_buttons,
                        link_buttons,
                        message_id,
                        channel_id
                    )
                    
                    self.bot.add_view(config_view, message_id=message.id)
                    config_restored_count += 1
                    
                except Exception as e:
                    config_skipped_count += 1
            
        except Exception as e:
            print(f"❌ Critical error in embed button view restoration: {e}")
            import traceback
            traceback.print_exc()
    
    @commands.hybrid_command(name='embed')
    @app_commands.describe(
        action='Choose an action to perform',
        name='The name of the embed (optional for list)'
    )
    @app_commands.choices(action=[
        app_commands.Choice(name='Create', value='create'),
        app_commands.Choice(name='Send', value='send'),
        app_commands.Choice(name='List', value='list'),
        app_commands.Choice(name='Edit', value='edit')
    ])
    async def embed_main(self, ctx, action: app_commands.Choice[str], name: str = None):
        """Main embed command with subcommands"""
        action_value = action.value if isinstance(action, app_commands.Choice) else action
        
        if action_value == 'create':
            await self.create_embed(ctx, name)
        elif action_value == 'send':
            await self.send_embed(ctx, name)
        elif action_value == 'list':
            await self.list_embeds(ctx)
        elif action_value == 'edit':
            await self.edit_embed(ctx, name)
        else:
            embed = create_error_embed(
                f"Unknown action `{action_value}`. Please use one of the available options.",
                title="Invalid Action"
            )
            await ctx.send(embed=embed)
    
    async def create_embed(self, ctx, name):
        """Create a new embed with interactive builder"""
        # Check for manage guild permission
        if not ctx.author.guild_permissions.manage_guild:
            embed = create_error_embed(
                "You need the **Manage Server** permission to create embeds.",
                title="Permission Required"
            )
            await ctx.send(embed=embed)
            return
        
        if not name:
            embed = create_error_embed(
                "Please provide a name for your embed.\nUsage: `embed create <name>`",
                title="Name Required"
            )
            await ctx.send(embed=embed)
            return
        
        # Check if embed name already exists
        try:
            existing = await self.bot.db.get_custom_embed(ctx.guild.id, name)
            if existing:
                embed = create_error_embed(
                    f"An embed with the name `{name}` already exists. Use `+embed edit {name}` to edit it.",
                    title="Embed Already Exists"
                )
                await ctx.send(embed=embed)
                return
        except:
            pass  # Embed doesn't exist, which is what we want
        
        view = EmbedBuilderLayoutView(self.bot, name, ctx.author.id)
        await ctx.send(view=view)
    
    async def send_embed(self, ctx, name):
        """Send a saved embed with interactive menu"""
        if not name:
            embed = create_error_embed(
                "Please provide the name of the embed to send.\nUsage: `+embed send <name>`",
                title="Name Required"
            )
            await ctx.send(embed=embed)
            return
        
        try:
            embed_data = await self.bot.db.get_custom_embed(ctx.guild.id, name)
            if not embed_data:
                embed = create_error_embed(
                    f"No embed found with the name `{name}`. Use `+embed list` to see available embeds.",
                    title="Embed Not Found"
                )
                await ctx.send(embed=embed)
                return
            
            view = EmbedSendLayoutView(self.bot, name, embed_data, ctx.author.id)
            await ctx.send(view=view)
            
        except Exception as e:
            embed = create_error_embed(
                f"Failed to load embed: {str(e)}",
                title="Load Error"
            )
            await ctx.send(embed=embed)
    
    async def list_embeds(self, ctx):
        """List all saved embeds for the guild with pagination"""
        try:
            embeds = await self.bot.db.get_guild_embeds(ctx.guild.id)
            
            if not embeds:
                embed = EmbedFactory.create(
                    title="<:Jo1nTrX_embed:1410862725751509083> No Saved Embeds",
                    description="This server has no saved embeds yet.\nUse `embed create <name>` to create your first embed!",
                    color=self.bot.config.embed_color
                )
                await ctx.send(embed=embed)
                return
            
            items_per_page = 5
            total_pages = max(1, (len(embeds) + items_per_page - 1) // items_per_page)
            
            view = EmbedListPaginationLayoutView(embeds, 0, total_pages, ctx.author)
            await ctx.send(view=view)
            
        except Exception as e:
            embed = create_error_embed(
                f"Failed to list embeds: {str(e)}",
                title="List Error"
            )
            await ctx.send(embed=embed)
    
    async def edit_embed(self, ctx, name):
        """Edit an existing embed"""
        if not name:
            embed = create_error_embed(
                "Please provide the name of the embed to edit.\nUsage: `+embed edit <name>`",
                title="Name Required"
            )
            await ctx.send(embed=embed)
            return
        
        try:
            embed_data = await self.bot.db.get_custom_embed(ctx.guild.id, name)
            if not embed_data:
                embed = create_error_embed(
                    f"No embed found with the name `{name}`. Use `+embed list` to see available embeds.",
                    title="Embed Not Found"
                )
                await ctx.send(embed=embed)
                return
            
            view = EmbedBuilderLayoutView(self.bot, name, ctx.author.id)
            view.embed_data = json.loads(embed_data)
            await ctx.send(view=view)
            
        except Exception as e:
            embed = create_error_embed(
                f"Failed to load embed for editing: {str(e)}",
                title="Edit Error"
            )
            await ctx.send(embed=embed)
    
    async def delete_embed(self, ctx, name):
        """Delete a saved embed"""
        if not name:
            embed = create_error_embed(
                "Please provide the name of the embed to delete.\nUsage: `+embed delete <name>`",
                title="Name Required"
            )
            await ctx.send(embed=embed)
            return
        
        try:
            success = await self.bot.db.delete_custom_embed(ctx.guild.id, name)
            
            if success:
                embed = EmbedFactory.create(
                    title="✅ Embed Deleted",
                    description=f"Successfully deleted embed **{name}**!",
                    color=0x00ff00
                )
            else:
                embed = create_error_embed(
                    f"No embed found with the name `{name}`. Use `+embed list` to see available embeds.",
                    title="Embed Not Found"
                )
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            embed = create_error_embed(
                f"Failed to delete embed: {str(e)}",
                title="Delete Error"
            )
            await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(EmbedCommands(bot))