import discord
from discord.ext import commands, tasks
from discord import ui
from datetime import datetime, timezone, timedelta
import asyncio
import heapq
from dataclasses import dataclass
from typing import Optional
from Jo1nTrX.utils.embeds import create_embed, create_success_embed
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)

LOADING = "<a:jo1ntrx_loading:1405094057499295806>"
TICK = "<:Jo1nTrX_Yes:1408288995477159987>"
CROSS = "<:red_cross_Jo1nTrX:1438801479334101012>"
ARROW = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION = "<:jo1ntrx_right:1405095312456024127>"
TIMER = "<:Jo1nTrX_time:1419672663109927014>"

@dataclass
class TimerState:
    """Represents a timer's state for the scheduler"""
    timer_id: int
    guild_id: int
    user_id: int
    channel_id: int
    message_id: Optional[int]
    end_time: datetime
    reason: Optional[str]
    next_update_at: datetime
    last_visible_bucket: Optional[str] = None  # Track last displayed time to avoid redundant updates
    
    def __lt__(self, other):
        return self.next_update_at < other.next_update_at

class TimerSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.timer_heap = []  # Min-heap for timer scheduling
        self.scheduler_task = None
        self.discovery_task = None
        # Start the new scheduler system
        self.bot.loop.create_task(self.initialize_scheduler())
    
    async def cog_unload(self):
        """Clean up when the cog is unloaded"""
        if self.scheduler_task:
            self.scheduler_task.cancel()
        if self.discovery_task:
            self.discovery_task.cancel()
    
    async def initialize_scheduler(self):
        """Initialize the timer scheduler system"""
        await self.bot.wait_until_ready()
        
        # Load existing active timers into scheduler
        await self.load_active_timers()
        
        # Start the main scheduler task
        self.scheduler_task = self.bot.loop.create_task(self.scheduler_loop())
        
        # Start discovery task for new timers (fallback)
        self.discovery_task = self.bot.loop.create_task(self.discovery_loop())
        
        print("✅ Dynamic timer scheduler initialized")
    
    async def load_active_timers(self):
        """Load all active timers from database into scheduler"""
        try:
            timers = await self.bot.db.get_active_timers()
            current_time = datetime.now(timezone.utc)
            
            for timer in timers:
                timer_id, guild_id, user_id, channel_id, message_id, end_time, reason, created_at = timer
                
                # Convert end_time to datetime if it's a string
                if isinstance(end_time, str):
                    end_time = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
                
                # Ensure end_time has timezone info
                if end_time.tzinfo is None:
                    end_time = end_time.replace(tzinfo=timezone.utc)
                
                # Skip expired timers
                if end_time <= current_time:
                    continue
                
                # Calculate next update time
                remaining_seconds = (end_time - current_time).total_seconds()
                next_update = self.compute_next_update(current_time, remaining_seconds)
                
                timer_state = TimerState(
                    timer_id=timer_id,
                    guild_id=guild_id,
                    user_id=user_id,
                    channel_id=channel_id,
                    message_id=message_id,
                    end_time=end_time,
                    reason=reason,
                    next_update_at=next_update
                )
                
                heapq.heappush(self.timer_heap, timer_state)
            
            print(f"📥 Loaded {len(self.timer_heap)} active timers into scheduler")
        except Exception as e:
            print(f"Error loading active timers: {e}")
    
    def get_update_interval(self, remaining_seconds: float) -> int:
        """Get update interval based on remaining time"""
        if remaining_seconds < 3600:  # Less than 1 hour
            return 1  # Every second
        elif remaining_seconds <= 172800:  # Up to and including 48 hours
            return 60  # Every minute
        else:  # More than 48 hours
            return 86400  # Every day
    
    def compute_next_update(self, current_time: datetime, remaining_seconds: float) -> datetime:
        """Compute the next update time with boundary alignment"""
        # If timer is about to end (less than 1 second), schedule for end time
        if remaining_seconds <= 1:
            return current_time + timedelta(seconds=max(0.1, remaining_seconds))
        
        interval = self.get_update_interval(remaining_seconds)
        
        # For very short remaining time, don't wait longer than remaining
        interval = min(interval, int(remaining_seconds))
        
        # For minute and day intervals, align to boundaries for clean UX
        if interval == 60:  # Minute updates
            # Next minute boundary
            next_minute = current_time.replace(second=0, microsecond=0) + timedelta(minutes=1)
            return min(next_minute, current_time + timedelta(seconds=interval))
        elif interval == 86400:  # Day updates
            # Next day boundary
            next_day = current_time.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
            return min(next_day, current_time + timedelta(seconds=interval))
        else:
            # Second updates - just add the interval
            return current_time + timedelta(seconds=interval)
    
    async def scheduler_loop(self):
        """Main scheduler loop"""
        while True:
            try:
                if not self.timer_heap:
                    # No timers, wait a bit and check again
                    await asyncio.sleep(5)
                    continue
                
                current_time = datetime.now(timezone.utc)
                
                # Process all due timers
                while self.timer_heap and self.timer_heap[0].next_update_at <= current_time:
                    timer_state = heapq.heappop(self.timer_heap)
                    
                    # Calculate remaining time
                    remaining_seconds = (timer_state.end_time - current_time).total_seconds()
                    
                    if remaining_seconds <= 0:
                        # Timer completed - deactivate immediately to prevent discovery loop duplicate
                        # Only send completion if we actually deactivated (prevents duplicate notifications)
                        was_deactivated = await self.bot.db.deactivate_timer(timer_state.timer_id)
                        
                        if was_deactivated:
                            # Send completion notification only if we were the one to deactivate it
                            await self.handle_timer_completion(
                                timer_state.timer_id, timer_state.guild_id, timer_state.user_id,
                                timer_state.channel_id, timer_state.message_id, timer_state.reason
                            )
                    else:
                        # Update timer display
                        await self.update_timer_display(timer_state, remaining_seconds)
                        
                        # Reschedule for next update
                        timer_state.next_update_at = self.compute_next_update(current_time, remaining_seconds)
                        heapq.heappush(self.timer_heap, timer_state)
                
                # Sleep until next timer is due
                if self.timer_heap:
                    sleep_time = (self.timer_heap[0].next_update_at - current_time).total_seconds()
                    sleep_time = max(0.1, min(sleep_time, 5))  # Sleep at least 0.1s, max 5s
                    await asyncio.sleep(sleep_time)
                else:
                    await asyncio.sleep(1)
                    
            except Exception as e:
                print(f"Error in scheduler loop: {e}")
                await asyncio.sleep(1)
    
    async def discovery_loop(self):
        """Discovery loop to find new timers (fallback)"""
        await asyncio.sleep(30)  # Initial delay
        
        while True:
            try:
                # This is a fallback - normally register_timer should be called
                # Check for any new timers every 30 seconds
                timers = await self.bot.db.get_active_timers()
                current_timer_ids = {timer.timer_id for timer in self.timer_heap}
                
                for timer in timers:
                    timer_id = timer[0]
                    if timer_id not in current_timer_ids:
                        # Found new timer, add it
                        await self.register_timer_from_db(timer)
                        
                await asyncio.sleep(30)
            except Exception as e:
                print(f"Error in discovery loop: {e}")
                await asyncio.sleep(30)
    
    async def register_timer_from_db(self, timer_row):
        """Register a timer from database row"""
        try:
            timer_id, guild_id, user_id, channel_id, message_id, end_time, reason, created_at = timer_row
            
            # Convert end_time to datetime if it's a string
            if isinstance(end_time, str):
                end_time = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
            
            # Ensure end_time has timezone info
            if end_time.tzinfo is None:
                end_time = end_time.replace(tzinfo=timezone.utc)
            
            current_time = datetime.now(timezone.utc)
            
            # Skip expired timers
            if end_time <= current_time:
                return
            
            # Calculate next update time
            remaining_seconds = (end_time - current_time).total_seconds()
            next_update = self.compute_next_update(current_time, remaining_seconds)
            
            timer_state = TimerState(
                timer_id=timer_id,
                guild_id=guild_id,
                user_id=user_id,
                channel_id=channel_id,
                message_id=message_id,
                end_time=end_time,
                reason=reason,
                next_update_at=next_update
            )
            
            heapq.heappush(self.timer_heap, timer_state)
            print(f"📥 Registered new timer {timer_id} in scheduler")
            
        except Exception as e:
            print(f"Error registering timer: {e}")
    
    def register_timer(self, timer_id: int, guild_id: int, user_id: int, channel_id: int, 
                      message_id: Optional[int], end_time: datetime, reason: Optional[str]):
        """Register a new timer in the scheduler"""
        try:
            current_time = datetime.now(timezone.utc)
            remaining_seconds = (end_time - current_time).total_seconds()
            next_update = self.compute_next_update(current_time, remaining_seconds)
            
            timer_state = TimerState(
                timer_id=timer_id,
                guild_id=guild_id,
                user_id=user_id,
                channel_id=channel_id,
                message_id=message_id,
                end_time=end_time,
                reason=reason,
                next_update_at=next_update
            )
            
            heapq.heappush(self.timer_heap, timer_state)
            print(f"🆕 Registered timer {timer_id} for {remaining_seconds:.1f}s with {self.get_update_interval(remaining_seconds)}s interval")
            
        except Exception as e:
            print(f"Error registering timer: {e}")
    
    async def handle_timer_completion(self, timer_id, guild_id, user_id, channel_id, message_id, reason):
        """Handle when a timer completes"""
        try:
            channel = self.bot.get_channel(channel_id)
            if not channel:
                return
            
            user = self.bot.get_user(user_id)
            user_mention = user.mention if user else f"<@{user_id}>"
            
            from datetime import timezone, timedelta
            ist_timezone = timezone(timedelta(hours=5, minutes=30))
            current_time_ist = datetime.now(ist_timezone)
            completed_time_str = current_time_ist.strftime("%I:%M %p IST")
            
            user_name = user.display_name if user else f"User#{user_id}"
            
            content = f"""## {TIMER} Timer Completed
> <:Jo1nTrX_Bell:1419673781957296188> {user_mention} - Your timer is complete!

{SECTION} **__Timer Details__**
{ARROW} **Status:** {TICK} Completed
{ARROW} **Started by:** {user_name}
{ARROW} **Completed at:** {completed_time_str}"""
            
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            
            await channel.send(view=view)
            
            if message_id:
                try:
                    original_message = await channel.fetch_message(message_id)
                    await original_message.delete()
                except Exception as e:
                    print(f"Could not delete original timer message {message_id}: {e}")
                    
        except Exception as e:
            print(f"Error handling timer completion: {e}")
    
    async def update_timer_display(self, timer_state: TimerState, remaining_seconds: float):
        """Update timer display with smart frequency"""
        try:
            if not timer_state.message_id:
                return
            
            channel = self.bot.get_channel(timer_state.channel_id)
            if not channel:
                return
            
            # Format time remaining and create display bucket for change detection
            time_remaining = self.format_time_remaining(remaining_seconds)
            interval = self.get_update_interval(remaining_seconds)
            
            # Create a bucket key to avoid redundant updates
            if interval == 1:  # Second updates
                bucket_key = f"s:{int(remaining_seconds)}"
            elif interval == 60:  # Minute updates  
                bucket_key = f"m:{int(remaining_seconds // 60)}"
            else:  # Day updates
                bucket_key = f"d:{int(remaining_seconds // 86400)}"
            
            # Skip if this bucket was already displayed
            if timer_state.last_visible_bucket == bucket_key:
                return
            
            timer_state.last_visible_bucket = bucket_key
            
            user = self.bot.get_user(timer_state.user_id)
            user_mention = user.mention if user else f"<@{timer_state.user_id}>"
            
            # Format end time in IST
            from datetime import timezone, timedelta
            ist_timezone = timezone(timedelta(hours=5, minutes=30))
            end_time_ist = timer_state.end_time.astimezone(ist_timezone)
            end_time_str = end_time_ist.strftime("%I:%M %p IST")
            
            # Create component v2 content
            content = f"""## {TIMER} Timer Active
> Time remaining: **{time_remaining}**

{SECTION} **__Timer Details__**
{ARROW} **Started by:** {user_mention}
{ARROW} **Ends at:** {end_time_str}"""
            
            timer_view = ui.LayoutView(timeout=None)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            timer_view.add_item(container)
            
            # Use partial message edit to avoid fetch
            try:
                partial_message = channel.get_partial_message(timer_state.message_id)
                await partial_message.edit(embed=None, view=timer_view)
            except:
                # Fallback to fetch and edit
                try:
                    message = await channel.fetch_message(timer_state.message_id)
                    await message.edit(embed=None, view=timer_view)
                except:
                    pass  # Message deleted or not found
            
        except Exception as e:
            print(f"Error updating timer display: {e}")
    
    def format_time_remaining(self, seconds):
        """Format seconds into human readable time"""
        if seconds <= 0:
            return "Timer ended!"
        
        years = seconds // 31556952
        seconds %= 31556952
        months = seconds // 2629746
        seconds %= 2629746
        days = seconds // 86400
        seconds %= 86400
        hours = seconds // 3600
        seconds %= 3600
        minutes = seconds // 60
        seconds %= 60
        
        parts = []
        if years > 0:
            parts.append(f"{int(years)}y")
        if months > 0:
            parts.append(f"{int(months)}mo")
        if days > 0:
            parts.append(f"{int(days)}d")
        if hours > 0:
            parts.append(f"{int(hours)}h")
        if minutes > 0:
            parts.append(f"{int(minutes)}m")
        if seconds > 0:
            parts.append(f"{int(seconds)}s")
        
        return " ".join(parts[:3])  # Show max 3 units
    

async def setup(bot):
    await bot.add_cog(TimerSystem(bot))