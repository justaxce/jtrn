import discord
from discord.ext import commands, tasks
from discord import app_commands, ui
from datetime import datetime, timezone, timedelta
from Jo1nTrX.utils.embeds import create_embed
from Jo1nTrX.utils.helpers import send_loading_message
import asyncio
from typing import Optional
from Jo1nTrX.utils.component import (
    EmbedFactory, BaseView, BaseButton, BaseSelect, 
    ConfirmButton, CancelButton, DeleteButton,
    PaginationView, ConfirmationView, bot_emoji
)

LOADING = "<a:jo1ntrx_loading:1405094057499295806>"
TICK = "<:Jo1nTrX_Yes:1408288995477159987>"
CROSS = "<:red_cross_Jo1nTrX:1438801479334101012>"
ARROW = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION = "<:jo1ntrx_right:1405095312456024127>"

class VanityRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.vanity_checker.start()
    
    async def cog_unload(self):
        """Clean up when the cog is unloaded"""
        self.vanity_checker.cancel()
        
    @commands.hybrid_group(name='vanityrole', aliases=['vr'])
    async def vanityrole(self, ctx):
        """Vanity role management commands"""
        if ctx.invoked_subcommand is None:
            content = f"""## {TICK} Vanity Role Commands
> Manage vanity roles that are automatically assigned based on user bio/status

{SECTION} **__Setup Commands__**
{ARROW} `+vanityrole set <role> <vanity>` - Set up a vanity role
{ARROW} `+vanityrole remove <role>` - Remove a vanity role setup

{SECTION} **__Log Commands__**
{ARROW} `+vanitylog channel set <channel>` - Set vanity log channel
{ARROW} `+vanitylog channel remove` - Remove vanity log channel

{SECTION} **__Other Commands__**
{ARROW} `+vanity reset` - Reset all vanity role configurations"""
            
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await ctx.send(view=view)
    
    @vanityrole.command(name='set')
    @app_commands.describe(role='The role to assign', vanity='The vanity text to look for in bio/status')
    async def vanityrole_set(self, ctx, role: discord.Role, *, vanity: str):
        """Set up a vanity role that gets assigned when users have the vanity in their bio/status"""
        loading_msg = await send_loading_message(ctx, f"setting up vanity role for {role.mention}")
        
        try:
            if not ctx.author.guild_permissions.manage_roles:
                content = f"""## {CROSS} Permission Error
> You need the 'Manage Roles' permission to use this command."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            if role.position >= ctx.guild.me.top_role.position:
                content = f"""## {CROSS} Role Hierarchy Error
> I cannot manage {role.mention} because it's higher than or equal to my highest role."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            if role.id == ctx.guild.id:
                content = f"""## {CROSS} Invalid Role
> Cannot set vanity role for @everyone."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            await self.bot.db.set_vanity_role(ctx.guild.id, role.id, vanity.lower())
            
            content = f"""## {TICK} Vanity Role Setup Complete
> Successfully configured vanity role

{SECTION} **__Configuration__**
{ARROW} **Role:** {role.mention}
{ARROW} **Vanity Text:** `{vanity}`

{SECTION} **__Status__**
{ARROW} Users with `{vanity}` in their bio or status will automatically receive this role."""
            
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            
            await self._log_vanity_action(ctx.guild, f"Vanity role setup: {role.mention} for vanity `{vanity}` by {ctx.author.mention}")
            
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            content = f"""## {CROSS} Error
> Error setting up vanity role: {str(e)}"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await loading_msg.edit(embed=None, view=view)
    
    @vanityrole.command(name='remove')
    @app_commands.describe(role='The role to remove from vanity setup')
    async def vanityrole_remove(self, ctx, role: discord.Role):
        """Remove a vanity role setup"""
        loading_msg = await send_loading_message(ctx, f"removing vanity role setup for {role.mention}")
        
        try:
            if not ctx.author.guild_permissions.manage_roles:
                content = f"""## {CROSS} Permission Error
> You need the 'Manage Roles' permission to use this command."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            vanity_data = await self.bot.db.get_vanity_role(ctx.guild.id, role.id)
            if not vanity_data:
                content = f"""## {CROSS} Not Found
> {role.mention} is not set up as a vanity role."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            await self.bot.db.remove_vanity_role(ctx.guild.id, role.id)
            
            content = f"""## {TICK} Vanity Role Removed
> Successfully removed vanity role configuration

{SECTION} **__Details__**
{ARROW} **Role:** {role.mention}
{ARROW} **Status:** Users will no longer automatically receive this role."""
            
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            
            await self._log_vanity_action(ctx.guild, f"Vanity role removed: {role.mention} by {ctx.author.mention}")
            
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            content = f"""## {CROSS} Error
> Error removing vanity role: {str(e)}"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await loading_msg.edit(embed=None, view=view)
    
    @commands.hybrid_group(name='vanitylog', aliases=['vlog'])
    async def vanitylog(self, ctx):
        """Vanity log management commands"""
        if ctx.invoked_subcommand is None:
            await ctx.send_help(ctx.command)
    
    @vanitylog.group(name='channel')
    async def vanitylog_channel(self, ctx):
        """Vanity log channel management"""
        if ctx.invoked_subcommand is None:
            await ctx.send_help(ctx.command)
    
    @vanitylog_channel.command(name='set')
    @app_commands.describe(channel='The channel to set as vanity log channel')
    async def vanitylog_channel_set(self, ctx, channel: discord.TextChannel):
        """Set the vanity log channel"""
        loading_msg = await send_loading_message(ctx, f"setting vanity log channel to {channel.mention}")
        
        try:
            if not ctx.author.guild_permissions.manage_channels:
                content = f"""## {CROSS} Permission Error
> You need the 'Manage Channels' permission to use this command."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            if not channel.permissions_for(ctx.guild.me).send_messages:
                content = f"""## {CROSS} Permission Error
> I don't have permission to send messages in {channel.mention}."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            await self.bot.db.set_vanity_log_channel(ctx.guild.id, channel.id)
            
            content = f"""## {TICK} Vanity Log Channel Set
> Successfully configured log channel

{SECTION} **__Configuration__**
{ARROW} **Channel:** {channel.mention}
{ARROW} **Status:** Vanity role actions will now be logged here."""
            
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            content = f"""## {CROSS} Error
> Error setting vanity log channel: {str(e)}"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await loading_msg.edit(embed=None, view=view)
    
    @vanitylog_channel.command(name='remove')
    async def vanitylog_channel_remove(self, ctx):
        """Remove the vanity log channel"""
        loading_msg = await send_loading_message(ctx, "removing vanity log channel")
        
        try:
            if not ctx.author.guild_permissions.manage_channels:
                content = f"""## {CROSS} Permission Error
> You need the 'Manage Channels' permission to use this command."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            await self.bot.db.remove_vanity_log_channel(ctx.guild.id)
            
            content = f"""## {TICK} Vanity Log Channel Removed
> Successfully removed log channel

{SECTION} **__Status__**
{ARROW} Vanity role actions will no longer be logged."""
            
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            content = f"""## {CROSS} Error
> Error removing vanity log channel: {str(e)}"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await loading_msg.edit(embed=None, view=view)
    
    @commands.hybrid_command(name='vanity')
    async def vanity_command(self, ctx):
        """Show vanity role information and commands"""
        if ctx.invoked_subcommand is None:
            await ctx.send_help('vanityrole')
    
    @commands.hybrid_command(name='vanitycheck', aliases=['vcheck'])
    @app_commands.describe(member='The member to check vanity roles for (optional)')
    async def vanity_check(self, ctx, member: Optional[discord.Member] = None):
        """Manually check and assign vanity roles for a member"""
        loading_msg = await send_loading_message(ctx, "checking vanity roles")
        
        try:
            target_member = member if member is not None else ctx.author
            
            if target_member != ctx.author and not ctx.author.guild_permissions.manage_roles:
                content = f"""## {CROSS} Permission Error
> You need the 'Manage Roles' permission to check other members."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            result = await self.check_member_vanity(target_member)
            
            if result:
                content = f"""## {TICK} Vanity Check Complete
> Successfully checked vanity roles

{SECTION} **__Result__**
{ARROW} **Member:** {target_member.mention}
{ARROW} **Status:** Vanity roles have been checked and updated."""
            else:
                content = f"""## {TICK} Vanity Check Complete
> No changes needed

{SECTION} **__Result__**
{ARROW} **Member:** {target_member.mention}
{ARROW} **Status:** No vanity role changes were needed."""
            
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            content = f"""## {CROSS} Error
> Error checking vanity roles: {str(e)}"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await loading_msg.edit(embed=None, view=view)

    @commands.hybrid_command(name='vanityreset', aliases=['vreset'])
    async def vanity_reset(self, ctx):
        """Reset all vanity role configurations"""
        loading_msg = await send_loading_message(ctx, "resetting all vanity configurations")
        
        try:
            if not ctx.author.guild_permissions.manage_roles:
                content = f"""## {CROSS} Permission Error
> You need the 'Manage Roles' permission to use this command."""
                view = ui.LayoutView(timeout=300)
                text_display = ui.TextDisplay(content)
                container = ui.Container(text_display)
                view.add_item(container)
                await loading_msg.edit(embed=None, view=view)
                return
            
            vanity_roles = await self.bot.db.get_all_vanity_roles(ctx.guild.id)
            roles_count = len(vanity_roles) if vanity_roles else 0
            
            await self.bot.db.reset_vanity_config(ctx.guild.id)
            
            content = f"""## {TICK} Vanity Configuration Reset
> Successfully reset all configurations

{SECTION} **__Summary__**
{ARROW} **Removed:** {roles_count} vanity role(s)
{ARROW} **Log channel:** Removed"""
            
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            
            await self._log_vanity_action(ctx.guild, f"Vanity configuration reset by {ctx.author.mention}")
            
            await loading_msg.edit(embed=None, view=view)
            
        except Exception as e:
            content = f"""## {CROSS} Error
> Error resetting vanity configuration: {str(e)}"""
            view = ui.LayoutView(timeout=300)
            text_display = ui.TextDisplay(content)
            container = ui.Container(text_display)
            view.add_item(container)
            await loading_msg.edit(embed=None, view=view)
    
    async def _log_vanity_action(self, guild, message):
        """Log vanity actions to the configured log channel"""
        try:
            log_channel_id = await self.bot.db.get_vanity_log_channel(guild.id)
            if log_channel_id:
                log_channel = guild.get_channel(log_channel_id)
                if log_channel:
                    content = f"""## {TICK} Vanity Role Action
> {message}"""
                    view = ui.LayoutView(timeout=300)
                    text_display = ui.TextDisplay(content)
                    container = ui.Container(text_display)
                    view.add_item(container)
                    await log_channel.send(view=view)
        except:
            pass
    
    async def _log_vanity_action_with_ping(self, guild, member, role, vanity_text, action):
        """Log vanity actions with user ping and detailed embed"""
        try:
            log_channel_id = await self.bot.db.get_vanity_log_channel(guild.id)
            if log_channel_id:
                log_channel = guild.get_channel(log_channel_id)
                if log_channel:
                    if action == "added":
                        emoji = TICK
                        action_text = "added"
                    else:
                        emoji = CROSS
                        action_text = "removed"
                    
                    content = f"""## {emoji} Vanity Role {action_text.title()}
> Role assignment updated

{SECTION} **__Details__**
{ARROW} **Member:** {member.display_name}
{ARROW} **Role:** {role.mention}
{ARROW} **Vanity:** `{vanity_text}`
{ARROW} **Action:** Successfully {action_text} vanity role"""
                    
                    view = ui.LayoutView(timeout=300)
                    text_display = ui.TextDisplay(content)
                    container = ui.Container(text_display)
                    view.add_item(container)
                    
                    await log_channel.send(content=f"{member.mention}", view=view)
        except:
            pass
    
    @commands.Cog.listener()
    async def on_presence_update(self, before, after):
        """INSTANT detection when user adds/removes vanity to/from their custom status"""
        try:
            if after.bot:
                return
            
            guild = after.guild
            vanity_roles = await self.bot.db.get_all_vanity_roles(guild.id)
            
            if not vanity_roles:
                return
            
            member_text = ""
            
            for activity in after.activities:
                if isinstance(activity, discord.CustomActivity) and activity.name:
                    member_text += activity.name.lower() + " "
            
            if after.nick:
                member_text += after.nick.lower() + " "
            
            for role_id, vanity_text in vanity_roles:
                role = guild.get_role(role_id)
                if not role:
                    continue
                
                has_vanity = vanity_text.lower() in member_text
                has_role = role in after.roles
                
                if has_vanity and not has_role:
                    try:
                        await after.add_roles(role, reason=f"Vanity role: {vanity_text}")
                        await self._log_vanity_action_with_ping(guild, after, role, vanity_text, "added")
                    except discord.Forbidden:
                        pass
                    except Exception:
                        pass
                
                elif not has_vanity and has_role:
                    try:
                        await after.remove_roles(role, reason=f"Vanity role removed: {vanity_text}")
                        await self._log_vanity_action_with_ping(guild, after, role, vanity_text, "removed")
                    except discord.Forbidden:
                        pass
                    except Exception:
                        pass
        
        except Exception:
            pass
    
    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        """Check for vanity changes in member nickname changes"""
        try:
            if before.nick == after.nick:
                return
                
            guild = after.guild
            vanity_roles = await self.bot.db.get_all_vanity_roles(guild.id)
            
            if not vanity_roles:
                return
            
            member_text = ""
            
            for activity in after.activities:
                if isinstance(activity, discord.CustomActivity) and activity.name:
                    member_text += activity.name.lower() + " "
            
            try:
                user = await self.bot.fetch_user(after.id)
                if hasattr(user, 'bio') and user.bio:
                    member_text += user.bio.lower() + " "
            except:
                pass
            
            if after.nick:
                member_text += after.nick.lower() + " "
            
            for role_id, vanity_text in vanity_roles:
                role = guild.get_role(role_id)
                if not role:
                    continue
                
                has_vanity = vanity_text.lower() in member_text
                has_role = role in after.roles
                
                if has_vanity and not has_role:
                    try:
                        await after.add_roles(role, reason=f"Vanity role: {vanity_text}")
                        await self._log_vanity_action_with_ping(guild, after, role, vanity_text, "added")
                    except discord.Forbidden:
                        pass
                    except Exception:
                        pass
                
                elif not has_vanity and has_role:
                    try:
                        await after.remove_roles(role, reason=f"Vanity role removed: {vanity_text}")
                        await self._log_vanity_action_with_ping(guild, after, role, vanity_text, "removed")
                    except discord.Forbidden:
                        pass
                    except Exception:
                        pass
        
        except Exception:
            pass
    
    async def check_member_vanity(self, member):
        """Manually check and assign vanity roles for a specific member"""
        try:
            guild = member.guild
            vanity_roles = await self.bot.db.get_all_vanity_roles(guild.id)
            
            if not vanity_roles:
                return
            
            member_text = ""
            
            for activity in member.activities:
                if isinstance(activity, discord.CustomActivity) and activity.name:
                    member_text += activity.name.lower() + " "
            
            try:
                user = await self.bot.fetch_user(member.id)
                if hasattr(user, 'bio') and user.bio:
                    member_text += user.bio.lower() + " "
            except:
                pass
            
            try:
                guild_member = await guild.fetch_member(member.id)
                if hasattr(guild_member, 'nick') and guild_member.nick:
                    member_text += guild_member.nick.lower() + " "
            except:
                pass
            
            print(f"Manual check: {member.display_name}, member_text: '{member_text.strip()}'")
            
            for role_id, vanity_text in vanity_roles:
                role = guild.get_role(role_id)
                if not role:
                    continue
                
                has_vanity = vanity_text.lower() in member_text
                has_role = role in member.roles
                
                print(f"Manual check: Role {role.name}, vanity '{vanity_text}', has_vanity: {has_vanity}, has_role: {has_role}")
                
                if has_vanity and not has_role:
                    try:
                        await member.add_roles(role, reason=f"Vanity role: {vanity_text}")
                        await self._log_vanity_action_with_ping(guild, member, role, vanity_text, "added")
                        print(f"Added role {role.name} to {member.display_name}")
                        return True
                    except discord.Forbidden:
                        print(f"Forbidden: Cannot add role {role.name} to {member.display_name}")
                    except Exception as e:
                        print(f"Error adding role: {e}")
                
                elif not has_vanity and has_role:
                    try:
                        await member.remove_roles(role, reason=f"Vanity role removed: {vanity_text}")
                        await self._log_vanity_action_with_ping(guild, member, role, vanity_text, "removed")
                        print(f"Removed role {role.name} from {member.display_name}")
                        return True
                    except discord.Forbidden:
                        print(f"Forbidden: Cannot remove role {role.name} from {member.display_name}")
                    except Exception as e:
                        print(f"Error removing role: {e}")
            
            return False
        
        except Exception as e:
            print(f"Error in check_member_vanity: {e}")
            return False
    
    @tasks.loop(minutes=30)
    async def vanity_checker(self):
        """Background task to check and update vanity roles for all members"""
        try:
            for guild in self.bot.guilds:
                vanity_roles = await self.bot.db.get_all_vanity_roles(guild.id)
                
                if not vanity_roles:
                    continue
                
                for member in guild.members:
                    if member.bot:
                        continue
                    
                    await self.check_member_vanity_silent(member)
                    await asyncio.sleep(0.5)
                
                await asyncio.sleep(1)
        
        except Exception as e:
            print(f"Error in vanity_checker task: {e}")
    
    @vanity_checker.before_loop
    async def before_vanity_checker(self):
        """Wait until the bot is ready before starting the task"""
        await self.bot.wait_until_ready()
        await self.vanity_checker.coro(self)
    
    async def check_member_vanity_silent(self, member):
        """Check vanity roles for a member without any logging (for background task)"""
        try:
            guild = member.guild
            vanity_roles = await self.bot.db.get_all_vanity_roles(guild.id)
            
            if not vanity_roles:
                return
            
            member_text = ""
            
            for activity in member.activities:
                if isinstance(activity, discord.CustomActivity) and activity.name:
                    member_text += activity.name.lower() + " "
            
            try:
                user = await self.bot.fetch_user(member.id)
                if hasattr(user, 'bio') and user.bio:
                    member_text += user.bio.lower() + " "
            except:
                pass
            
            if member.nick:
                member_text += member.nick.lower() + " "
            
            for role_id, vanity_text in vanity_roles:
                role = guild.get_role(role_id)
                if not role:
                    continue
                
                has_vanity = vanity_text.lower() in member_text
                has_role = role in member.roles
                
                if has_vanity and not has_role:
                    try:
                        await member.add_roles(role, reason=f"Vanity role: {vanity_text}")
                        await self._log_vanity_action_with_ping(guild, member, role, vanity_text, "added")
                    except:
                        pass
                
                elif not has_vanity and has_role:
                    try:
                        await member.remove_roles(role, reason=f"Vanity role removed: {vanity_text}")
                        await self._log_vanity_action_with_ping(guild, member, role, vanity_text, "removed")
                    except:
                        pass
        
        except:
            pass


async def setup(bot):
    await bot.add_cog(VanityRoles(bot))
