import mysql.connector
from typing import Dict, List, Any, Optional
import json
import time


class TicketDatabaseHandler:
    def __init__(self, db):
        self.db = db
    
    def save_panel(self, guild_id: int, panel_id: str, panel_data: Dict[str, Any]):
        try:
            cursor = self.db.connection.cursor(dictionary=True, buffered=True)
            
            global_panel_id = panel_data.get('global_panel_id', 0)
            panel_channel = panel_data.get('panel_channel')
            log_channel = panel_data.get('log_channel')
            closed_category = panel_data.get('closed_category')
            ticket_embed = panel_data.get('ticket_embed')
            panel_type = panel_data.get('panel_type', 'menu')
            panel_message_id = panel_data.get('panel_message_id')
            created_at = panel_data.get('created_at')
            
            cursor.execute('''
                INSERT INTO ticket_panels 
                (guild_id, panel_id, global_panel_id, panel_channel, log_channel, 
                 closed_category, ticket_embed, panel_type, panel_message_id, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, IFNULL(%s, NOW()))
                ON DUPLICATE KEY UPDATE
                    panel_channel = VALUES(panel_channel),
                    log_channel = VALUES(log_channel),
                    closed_category = VALUES(closed_category),
                    ticket_embed = VALUES(ticket_embed),
                    panel_type = VALUES(panel_type),
                    panel_message_id = VALUES(panel_message_id),
                    created_at = VALUES(created_at)
            ''', (guild_id, panel_id, global_panel_id, panel_channel, log_channel,
                  closed_category, ticket_embed, panel_type, panel_message_id, created_at))
            
            cursor.execute('SELECT id FROM ticket_panels WHERE guild_id = %s AND global_panel_id = %s', (guild_id, global_panel_id))
            panel_row = cursor.fetchone()
            if not panel_row:
                raise Exception(f"Failed to get panel id for guild {guild_id}, global_panel_id {global_panel_id}")
            
            panel_db_id = panel_row['id']
            
            categories = panel_data.get('categories', [])
            if categories:
                cursor.execute(
                    'DELETE FROM ticket_categories WHERE panel_id = %s',
                    (panel_db_id,)
                )
                
                for category in categories:
                    cursor.execute('''
                        INSERT INTO ticket_categories
                        (panel_id, name, emoji, description, category_id, 
                         support_role_id, ping_support, category_order)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    ''', (
                        panel_db_id, category.get('name'), category.get('emoji'),
                        category.get('description'), category.get('category_id'),
                        category.get('support_role_id'), category.get('ping_support', True),
                        category.get('category_order', 0)
                    ))
            
            self.db.connection.commit()
            cursor.close()
            
        except Exception as e:
            print(f"Error saving panel to database: {e}")
            self.db.connection.rollback()
    
    def get_categories(self, guild_id: int, global_panel_id: int) -> List[Dict[str, Any]]:
        try:
            cursor = self.db.connection.cursor(dictionary=True, buffered=True)
            cursor.execute('''
                SELECT tc.name, tc.emoji, tc.description, tc.category_id, tc.support_role_id, 
                       tc.ping_support, tc.category_order
                FROM ticket_categories tc
                JOIN ticket_panels tp ON tc.panel_id = tp.id
                WHERE tp.guild_id = %s AND tp.global_panel_id = %s
                ORDER BY tc.category_order
            ''', (guild_id, global_panel_id))
            
            categories = cursor.fetchall()
            cursor.close()
            
            return categories or []
            
        except Exception as e:
            print(f"❌ Error loading categories for guild {guild_id}, global_panel {global_panel_id}: {e}")
            return []
    
    def save_categories(self, guild_id: int, panel_id: str, categories: List[Dict[str, Any]]):
        print(f"WARNING: save_categories is deprecated. Categories should be saved in panel data directly.")
        return
    
    def get_panels(self, guild_id: int) -> Dict[str, Any]:
        conn = None
        cursor = None
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor(dictionary=True, buffered=True)
            
            # Single optimized query to fetch panels and categories with LEFT JOIN
            cursor.execute('''
                SELECT 
                    tp.global_panel_id, tp.panel_channel, tp.log_channel, 
                    tp.closed_category, tp.ticket_embed, tp.panel_type, 
                    tp.panel_message_id, tp.created_at,
                    tc.name AS cat_name, tc.emoji AS cat_emoji, 
                    tc.description AS cat_description, tc.category_id AS cat_category_id,
                    tc.support_role_id AS cat_support_role_id, tc.ping_support AS cat_ping_support,
                    tc.category_order AS cat_order
                FROM ticket_panels tp
                LEFT JOIN ticket_categories tc ON tp.id = tc.panel_id
                WHERE tp.guild_id = %s
                ORDER BY tp.global_panel_id, tc.category_order
            ''', (guild_id,))
            
            rows = cursor.fetchall()
            
            # Group panels and their categories
            panels = {}
            for row in rows:
                global_panel_id = row['global_panel_id']
                panel_id = f"panel_{global_panel_id}"
                
                # Initialize panel if not seen before
                if panel_id not in panels:
                    panels[panel_id] = {
                        'panel_channel': row['panel_channel'],
                        'log_channel': row['log_channel'],
                        'closed_category': row['closed_category'],
                        'ticket_embed': row['ticket_embed'],
                        'panel_type': row['panel_type'],
                        'panel_message_id': row['panel_message_id'],
                        'guild_id': guild_id,
                        'global_panel_id': global_panel_id,
                        'created_at': str(row['created_at']) if row['created_at'] else None,
                        'categories': []
                    }
                
                # Add category if it exists (LEFT JOIN might have NULL categories)
                if row['cat_name']:
                    panels[panel_id]['categories'].append({
                        'name': row['cat_name'],
                        'emoji': row['cat_emoji'],
                        'description': row['cat_description'],
                        'category_id': row['cat_category_id'],
                        'support_role_id': row['cat_support_role_id'],
                        'ping_support': row['cat_ping_support'],
                        'category_order': row['cat_order']
                    })
            
            return panels
            
        except Exception as e:
            print(f"❌ Error getting panels for guild {guild_id}: {e}")
            import traceback
            traceback.print_exc()
            return {}
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
    
    def get_all_panels(self) -> Dict[str, Any]:
        conn = None
        cursor = None
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor(dictionary=True, buffered=True)
            cursor.execute('SELECT DISTINCT guild_id FROM ticket_panels')
            guilds = cursor.fetchall()
            
            print(f"🔍 Found {len(guilds)} guilds with ticket panels in database")
            
            all_panels = {}
            for idx, guild in enumerate(guilds, 1):
                guild_id = guild['guild_id']
                print(f"📦 Fetching panels for guild {guild_id} ({idx}/{len(guilds)})...")
                panels = self.get_panels(guild_id)
                all_panels[str(guild_id)] = panels
                print(f"✅ Guild {guild_id}: Found {len(panels)} panel(s)")
            
            print(f"🎉 Finished fetching all panels from database")
            return all_panels
            
        except Exception as e:
            print(f"❌ Error getting all panels: {e}")
            print(f"❌ Error type: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            return {}
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
    
    def delete_panel(self, guild_id: int, panel_id: str):
        try:
            cursor = self.db.connection.cursor(buffered=True)
            
            global_panel_id = int(panel_id.replace('panel_', ''))
            
            cursor.execute(
                'DELETE FROM ticket_panels WHERE guild_id = %s AND global_panel_id = %s',
                (guild_id, global_panel_id)
            )
            
            cursor.execute(
                'DELETE FROM ticket_stats WHERE guild_id = %s AND global_panel_id = %s',
                (guild_id, global_panel_id)
            )
            
            self.db.connection.commit()
            cursor.close()
            
        except Exception as e:
            print(f"Error deleting panel: {e}")
            self.db.connection.rollback()
    
    def get_ticket_stats(self, guild_id: int, panel_id: Optional[str] = None) -> Dict[str, Any]:
        try:
            cursor = self.db.connection.cursor(dictionary=True, buffered=True)
            
            if panel_id:
                global_panel_id = int(panel_id.replace('panel_', '')) if isinstance(panel_id, str) and panel_id.startswith('panel_') else int(panel_id)
                
                cursor.execute('''
                    SELECT total_active_tickets, total_closed_tickets
                    FROM ticket_stats
                    WHERE guild_id = %s AND global_panel_id = %s
                ''', (guild_id, global_panel_id))
                
                result = cursor.fetchone()
                cursor.close()
                
                if result:
                    return {
                        "total_active_tickets": result['total_active_tickets'],
                        "total_closed_tickets": result['total_closed_tickets']
                    }
                else:
                    return {"total_active_tickets": 0, "total_closed_tickets": 0}
            else:
                cursor.execute('''
                    SELECT SUM(total_active_tickets) as total_active, 
                           SUM(total_closed_tickets) as total_closed
                    FROM ticket_stats
                    WHERE guild_id = %s
                ''', (guild_id,))
                
                result = cursor.fetchone()
                cursor.close()
                
                return {
                    "total_active_tickets": result['total_active'] or 0,
                    "total_closed_tickets": result['total_closed'] or 0
                }
                
        except Exception as e:
            print(f"Error getting ticket stats: {e}")
            return {"total_active_tickets": 0, "total_closed_tickets": 0}
    
    def update_ticket_stats(self, guild_id: int, panel_id: Optional[str], active_change: int = 0, closed_change: int = 0):
        try:
            cursor = self.db.connection.cursor(buffered=True)
            
            # Use global_panel_id 0 for guild-level statistics
            global_panel_id = 0
            
            cursor.execute('''
                INSERT INTO ticket_stats (guild_id, global_panel_id, total_active_tickets, total_closed_tickets)
                VALUES (%s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    total_active_tickets = GREATEST(0, total_active_tickets + %s),
                    total_closed_tickets = GREATEST(0, total_closed_tickets + %s)
            ''', (guild_id, global_panel_id, active_change, closed_change, active_change, closed_change))
            
            self.db.connection.commit()
            cursor.close()
            
        except Exception as e:
            print(f"Error updating ticket stats: {e}")
            self.db.connection.rollback()
    
    def save_active_ticket(self, guild_id: int, channel_id: int, ticket_data: Dict[str, Any]):
        try:
            cursor = self.db.connection.cursor(buffered=True)
            
            default_ticket_data = {
                'user_id': None,
                'category_name': 'General',
                'claimed_by': None,
                'ticket_number': 1,
                'created_at': None,
                'status': 'open',
                'original_category_id': None,
                'original_channel_name': None,
                'support_role_id': None,
                'welcome_message_id': None,
                'claimed_at': None,
                'closed_by': None,
                'closed_at': None,
                'reopened_by': None,
                'reopened_at': None,
                'global_panel_id': None
            }
            default_ticket_data.update(ticket_data)
            
            global_panel_id = default_ticket_data.get('global_panel_id') or default_ticket_data.get('panel_id')
            
            cursor.execute('''
                INSERT INTO active_tickets 
                (guild_id, channel_id, user_id, category_name, claimed_by, 
                 ticket_number, status, original_category_id, original_channel_name,
                 support_role_id, welcome_message_id, claimed_at, closed_by, closed_at,
                 reopened_by, reopened_at, created_at, global_panel_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    user_id = VALUES(user_id),
                    category_name = VALUES(category_name),
                    claimed_by = VALUES(claimed_by),
                    ticket_number = VALUES(ticket_number),
                    status = VALUES(status),
                    original_category_id = VALUES(original_category_id),
                    original_channel_name = VALUES(original_channel_name),
                    support_role_id = VALUES(support_role_id),
                    welcome_message_id = VALUES(welcome_message_id),
                    claimed_at = VALUES(claimed_at),
                    closed_by = VALUES(closed_by),
                    closed_at = VALUES(closed_at),
                    reopened_by = VALUES(reopened_by),
                    reopened_at = VALUES(reopened_at),
                    global_panel_id = VALUES(global_panel_id)
            ''', (
                guild_id, channel_id, default_ticket_data['user_id'],
                default_ticket_data['category_name'], default_ticket_data['claimed_by'], 
                default_ticket_data['ticket_number'], default_ticket_data['status'], 
                default_ticket_data['original_category_id'], default_ticket_data['original_channel_name'], 
                default_ticket_data['support_role_id'], default_ticket_data['welcome_message_id'], 
                default_ticket_data['claimed_at'], default_ticket_data['closed_by'], 
                default_ticket_data['closed_at'], default_ticket_data['reopened_by'], 
                default_ticket_data['reopened_at'], default_ticket_data['created_at'],
                global_panel_id
            ))
            
            self.db.connection.commit()
            cursor.close()
            
        except Exception as e:
            print(f"Error saving active ticket: {e}")
            self.db.connection.rollback()
    
    def get_active_ticket(self, guild_id: int, channel_id: int) -> Dict[str, Any]:
        try:
            cursor = self.db.connection.cursor(dictionary=True, buffered=True)
            cursor.execute('''
                SELECT user_id, category_name, claimed_by, ticket_number,
                       status, original_category_id, original_channel_name, support_role_id,
                       welcome_message_id, claimed_at, closed_by, closed_at, reopened_by,
                       reopened_at, created_at, global_panel_id
                FROM active_tickets
                WHERE guild_id = %s AND channel_id = %s
            ''', (guild_id, channel_id))
            
            ticket = cursor.fetchone()
            
            if ticket:
                added_users = self.get_ticket_added_users(guild_id, channel_id)
                ticket['added_users'] = added_users
                ticket['guild_id'] = guild_id
                ticket['channel_id'] = channel_id
                
                if ticket.get('created_at'):
                    ticket['created_at'] = str(ticket['created_at'])
                if ticket.get('claimed_at'):
                    ticket['claimed_at'] = ticket['claimed_at'].timestamp()
                if ticket.get('closed_at'):
                    ticket['closed_at'] = ticket['closed_at'].timestamp()
                if ticket.get('reopened_at'):
                    ticket['reopened_at'] = ticket['reopened_at'].timestamp()
            
            cursor.close()
            return ticket or {}
            
        except Exception as e:
            print(f"Error getting active ticket: {e}")
            return {}
    
    def delete_active_ticket(self, guild_id: int, channel_id: int):
        try:
            cursor = self.db.connection.cursor(buffered=True)
            cursor.execute(
                'DELETE FROM active_tickets WHERE guild_id = %s AND channel_id = %s',
                (guild_id, channel_id)
            )
            self.db.connection.commit()
            cursor.close()
            
        except Exception as e:
            print(f"Error deleting active ticket: {e}")
            self.db.connection.rollback()
    
    def get_all_active_tickets(self) -> Dict[str, Any]:
        try:
            cursor = self.db.connection.cursor(dictionary=True, buffered=True)
            cursor.execute('SELECT guild_id, channel_id FROM active_tickets')
            tickets = cursor.fetchall()
            cursor.close()
            
            all_tickets = {}
            for ticket in tickets:
                guild_id = ticket['guild_id']
                channel_id = ticket['channel_id']
                
                if str(guild_id) not in all_tickets:
                    all_tickets[str(guild_id)] = {}
                
                ticket_data = self.get_active_ticket(guild_id, channel_id)
                all_tickets[str(guild_id)][str(channel_id)] = ticket_data
            
            return all_tickets
            
        except Exception as e:
            print(f"Error getting all active tickets: {e}")
            return {}
    
    def close_ticket(self, guild_id: int, channel_id: int, panel_id: Optional[str] = None):
        try:
            ticket_data = self.get_active_ticket(guild_id, channel_id)
            
            # Update guild-level stats
            self.update_ticket_stats(guild_id, None, active_change=-1, closed_change=1)
            
            if ticket_data:
                cursor = self.db.connection.cursor(buffered=True)
                
                cursor.execute('''
                    INSERT INTO closed_tickets
                    (guild_id, channel_id, user_id, category_name, claimed_by,
                     ticket_number, original_category_id, original_channel_name,
                     support_role_id, closed_by, closed_at, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ''', (
                    guild_id, channel_id, ticket_data.get('user_id'),
                    ticket_data.get('category_name'), ticket_data.get('claimed_by'), 
                    ticket_data.get('ticket_number'), ticket_data.get('original_category_id'), 
                    ticket_data.get('original_channel_name'), ticket_data.get('support_role_id'), 
                    ticket_data.get('closed_by'), ticket_data.get('closed_at'), 
                    ticket_data.get('created_at')
                ))
                
                cursor.close()
            
            self.delete_active_ticket(guild_id, channel_id)
            
        except Exception as e:
            print(f"Error closing ticket: {e}")
            self.db.connection.rollback()
    
    def reopen_ticket(self, guild_id: int, channel_id: int, panel_id: Optional[str] = None):
        try:
            ticket_data = self.get_active_ticket(guild_id, channel_id)
            
            if not ticket_data:
                cursor = self.db.connection.cursor(dictionary=True, buffered=True)
                cursor.execute('''
                    SELECT user_id, category_name, claimed_by, ticket_number,
                           original_category_id, original_channel_name, support_role_id,
                           closed_by, closed_at, created_at
                    FROM closed_tickets
                    WHERE guild_id = %s AND channel_id = %s
                ''', (guild_id, channel_id))
                
                closed_data = cursor.fetchone()
                
                if closed_data:
                    ticket_data = closed_data
                    
                    cursor.execute(
                        'DELETE FROM closed_tickets WHERE guild_id = %s AND channel_id = %s',
                        (guild_id, channel_id)
                    )
                
                cursor.close()
            
            if not ticket_data:
                ticket_data = {
                    'user_id': None,
                    'category_name': 'General',
                    'claimed_by': None,
                    'ticket_number': 1,
                    'created_at': None,
                    'status': 'open',
                    'original_category_id': None
                }
            else:
                ticket_data['status'] = 'open'
                ticket_data.pop('closed_at', None)
            
            self.save_active_ticket(guild_id, channel_id, ticket_data)
            
            # Update guild-level stats
            self.update_ticket_stats(guild_id, None, active_change=1, closed_change=-1)
            
        except Exception as e:
            print(f"Error reopening ticket: {e}")
            self.db.connection.rollback()
    
    def add_user_to_ticket(self, guild_id: int, channel_id: int, user_id: int):
        try:
            cursor = self.db.connection.cursor(buffered=True)
            cursor.execute('''
                INSERT IGNORE INTO ticket_added_users (guild_id, channel_id, user_id)
                VALUES (%s, %s, %s)
            ''', (guild_id, channel_id, user_id))
            
            self.db.connection.commit()
            cursor.close()
            
        except Exception as e:
            print(f"Error adding user to ticket: {e}")
            self.db.connection.rollback()
    
    def remove_user_from_ticket(self, guild_id: int, channel_id: int, user_id: int):
        try:
            cursor = self.db.connection.cursor(buffered=True)
            cursor.execute(
                'DELETE FROM ticket_added_users WHERE guild_id = %s AND channel_id = %s AND user_id = %s',
                (guild_id, channel_id, user_id)
            )
            self.db.connection.commit()
            cursor.close()
            
        except Exception as e:
            print(f"Error removing user from ticket: {e}")
            self.db.connection.rollback()
    
    def get_ticket_added_users(self, guild_id: int, channel_id: int) -> List[int]:
        try:
            cursor = self.db.connection.cursor(buffered=True)
            cursor.execute(
                'SELECT user_id FROM ticket_added_users WHERE guild_id = %s AND channel_id = %s',
                (guild_id, channel_id)
            )
            users = cursor.fetchall()
            cursor.close()
            
            return [user[0] for user in users]
            
        except Exception as e:
            print(f"Error getting ticket added users: {e}")
            return []
    
    def create_ticket(self, guild_id: int, channel_id: int, ticket_data: Dict[str, Any]):
        self.save_active_ticket(guild_id, channel_id, ticket_data)
        
        # Update guild-level stats
        self.update_ticket_stats(guild_id, None, active_change=1)
