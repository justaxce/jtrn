import os
import json

class Config:
    def __init__(self):
        self.prefix = '+'
        self.embed_color = 0x7c28eb
        self.success_color = 0x00ff00
        self.error_color = 0xff0000
        self.warning_color = 0xffff00
        
        self.BOT_OWNER_IDS = [1316335421394780262, 1417445368538333295, 1419767131423248415]
        
        self.DASHBOARD_URL = "https://jo1ntrx.pheonixdev.fun"
        self.SUPPORT_SERVER_URL = "https://discord.gg/6a9umBc7P4"
        
        # Load configuration from file if it exists
        self.load_config()
    
    def load_config(self):
        """Load configuration from config.json if it exists"""
        try:
            if os.path.exists('config.json'):
                with open('config.json', 'r') as f:
                    config_data = json.load(f)
                    self.prefix = config_data.get('prefix', self.prefix)
                    self.embed_color = config_data.get('embed_color', self.embed_color)
                    self.success_color = config_data.get('success_color', self.success_color)
                    self.error_color = config_data.get('error_color', self.error_color)
                    self.warning_color = config_data.get('warning_color', self.warning_color)
        except Exception as e:
            print(f'Error loading config: {e}')
    
    def save_config(self):
        """Save current configuration to config.json"""
        try:
            config_data = {
                'prefix': self.prefix,
                'embed_color': self.embed_color,
                'success_color': self.success_color,
                'error_color': self.error_color,
                'warning_color': self.warning_color
            }
            with open('config.json', 'w') as f:
                json.dump(config_data, f, indent=4)
        except Exception as e:
            print(f'Error saving config: {e}')
    
    @property
    def variables_list(self):
        """List of available variables for custom messages"""
        return [
            '**User Variables:**',
            '`{user}` - User display name',
            '`{user.mention}` - User mention',
            '`{user.tag}` - User tag (name#discriminator)',
            '`{user.id}` - User ID',
            '`{user.created}` - Account creation date',
            '`{user.joined}` - Date user joined the server',
            '`{user.nickname}` - User nickname (or display name if no nickname)',
            '`{user.avatar}` - User avatar URL',
            '`{user.status}` - User status (online, idle, dnd, offline)',
            '',
            '**Guild Variables:**',
            '`{guild}` - Guild name',
            '`{guild.name}` - Guild name',
            '`{guild.id}` - Guild ID',
            '`{guild.owner}` - Guild owner display name',
            '`{guild.owner.mention}` - Guild owner mention',
            '`{guild.created}` - Guild creation date',
            '`{guild.icon}` - Guild icon URL',
            '`{membercount}` - Current member count',
            '`{membercount.ordinal}` - Member count as ordinal (1st, 2nd, 10th, etc.)',
            '`{guild.boosts}` - Number of server boosts',
            '`{guild.boost_level}` - Server boost level',
            '',
            '**Time Variables:**',
            '`{time}` - Current time (24-hour format)',
            '`{time.12}` - Current time (12-hour format)',
            '`{date}` - Current date',
            '`{datetime}` - Current date and time',
            '',
            '**Invite Variables (Welcome only):**',
            '`{inviter}` - Inviter display name',
            '`{inviter.mention}` - Inviter mention',
            '`{inviter.tag}` - Inviter tag',
            '`{inviter.id}` - Inviter ID',
            '`{invite.code}` - Invite code used',
            '`{invite.uses}` - Number of times invite was used',
            '',
            '**Special Variables:**',
            '`{boost.count}` - Total guild boost count',
            '`{booster.mention}` - Booster mention who boosted',
            '`{booster.name}` - User display name of booster'
        ]
