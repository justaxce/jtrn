import mysql.connector
from mysql.connector import Error
from mysql.connector.pooling import MySQLConnectionPool
import os
import json
from datetime import datetime
import discord

class Database:
    def __init__(self):
        # MySQL connection details - NEW DATABASE
        # IMPORTANT: time_zone is set to '+00:00' (UTC) to ensure all TIMESTAMP columns
        # store and retrieve times in UTC. This is critical for features like giveaways
        # that compare end_time with UTC_TIMESTAMP() in SQL queries.
        self.mysql_config = {
            'host': os.getenv('MYSQL_HOST', 'panel.rexzbot.xyz'),
            'port': int(os.getenv('MYSQL_PORT', '3306')),
            'user': os.getenv('MYSQL_USER', 'u152_UX9CE8V5CU'),
            'password': os.getenv('MYSQL_PASSWORD', 'Ny=LRLYdJLigC3PR^EXrW=sP'),
            'database': os.getenv('MYSQL_DATABASE', 's152_jo1ntrx'),
            'charset': 'utf8mb4',
            'collation': 'utf8mb4_unicode_ci',
            'time_zone': '+00:00'  # Force UTC timezone for consistent timestamps
        }
        self.connection = None
        self.connection_pool = None
        self.connected = False

    @property
    def is_connected(self):
        """Check if database is connected and available"""
        return self.connected and self.connection_pool is not None

    def get_connection(self):
        """Get a connection from the pool for thread-safe operations"""
        if self.connection_pool:
            return self.connection_pool.get_connection()
        else:
            return mysql.connector.connect(**self.mysql_config)

    async def init_db(self):
        """Initialize the database connection and create tables"""
        try:
            self.connection = mysql.connector.connect(**self.mysql_config)

            self.connection_pool = MySQLConnectionPool(
                pool_name="main_pool",
                pool_size=10,
                **self.mysql_config
            )
            print("✅ MySQL connection pool created with 10 connections")

            cursor = self.connection.cursor()

            # Guild settings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS guild_settings (
                    guild_id BIGINT PRIMARY KEY,
                    welcome_channel_id BIGINT,
                    leave_channel_id BIGINT,
                    welcome_message TEXT,
                    leave_message TEXT,
                    modrole_id BIGINT,
                    prefix TEXT,
                    welcome_embed_name VARCHAR(255),
                    boost_embed_name VARCHAR(255)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Add the new columns if they don't exist (for existing databases)
            try:
                cursor.execute('ALTER TABLE guild_settings ADD COLUMN welcome_embed_name VARCHAR(255)')
            except mysql.connector.Error:
                pass  # Column already exists

            try:
                cursor.execute('ALTER TABLE guild_settings ADD COLUMN boost_embed_name VARCHAR(255)')
            except mysql.connector.Error:
                pass  # Column already exists

            try:
                cursor.execute('ALTER TABLE guild_settings ADD COLUMN confession_channel_id BIGINT')
            except mysql.connector.Error:
                pass  # Column already exists

            try:
                cursor.execute('ALTER TABLE guild_settings ADD COLUMN confession_count INT DEFAULT 0')
            except mysql.connector.Error:
                pass  # Column already exists

            try:
                cursor.execute('ALTER TABLE guild_settings ADD COLUMN noprefix_enabled BOOLEAN DEFAULT FALSE')
            except mysql.connector.Error:
                pass  # Column already exists

            try:
                cursor.execute('ALTER TABLE guild_settings ADD COLUMN noprefix_user_id BIGINT')
            except mysql.connector.Error:
                pass  # Column already exists

            try:
                cursor.execute("ALTER TABLE guild_settings ADD COLUMN noprefix_scope ENUM('global', 'guild')")
            except mysql.connector.Error:
                pass  # Column already exists

            # Multiple join channels table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS join_channels (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    message_type VARCHAR(50) NOT NULL DEFAULT 'join',
                    custom_message TEXT,
                    embed_name VARCHAR(255),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_guild_channel_type (guild_id, channel_id, message_type)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Add the embed_name column if it doesn't exist (for existing databases)
            try:
                cursor.execute('ALTER TABLE join_channels ADD COLUMN embed_name VARCHAR(255)')
            except mysql.connector.Error:
                pass  # Column already exists

            # Invite tracking table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS invites (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT,
                    user_id BIGINT,
                    inviter_id BIGINT,
                    invite_code TEXT,
                    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    left_at TIMESTAMP NULL,
                    is_fake BOOLEAN DEFAULT FALSE,
                    INDEX idx_guild_user (guild_id, user_id),
                    INDEX idx_guild_inviter (guild_id, inviter_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Cached invites table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS cached_invites (
                    guild_id BIGINT,
                    code TEXT,
                    uses INT,
                    inviter_id BIGINT,
                    created_at TIMESTAMP,
                    PRIMARY KEY (guild_id, code(191))
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Custom invite counts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS custom_invites (
                    guild_id BIGINT,
                    user_id BIGINT,
                    added_invites INT DEFAULT 0,
                    removed_invites INT DEFAULT 0,
                    PRIMARY KEY (guild_id, user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Message tracking table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_messages (
                    guild_id BIGINT,
                    user_id BIGINT,
                    message_count BIGINT DEFAULT 0,
                    daily_count BIGINT DEFAULT 0,
                    weekly_count BIGINT DEFAULT 0,
                    last_message_date DATE DEFAULT (CURRENT_DATE),
                    last_week_reset DATE DEFAULT (CURRENT_DATE),
                    PRIMARY KEY (guild_id, user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Add weekly_count and last_week_reset columns if they don't exist (migration)
            try:
                cursor.execute('ALTER TABLE user_messages ADD COLUMN weekly_count BIGINT DEFAULT 0')
            except:
                pass
            try:
                cursor.execute('ALTER TABLE user_messages ADD COLUMN last_week_reset DATE DEFAULT (CURRENT_DATE)')
            except:
                pass

            # Blacklisted channels table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS blacklisted_channels (
                    guild_id BIGINT,
                    channel_id BIGINT,
                    PRIMARY KEY (guild_id, channel_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Blacklisted categories table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS blacklisted_categories (
                    guild_id BIGINT,
                    category_id BIGINT,
                    PRIMARY KEY (guild_id, category_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Vanity roles table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS vanity_roles (
                    guild_id BIGINT,
                    role_id BIGINT,
                    vanity_text TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (guild_id, role_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Vanity log channels table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS vanity_log_channels (
                    guild_id BIGINT PRIMARY KEY,
                    channel_id BIGINT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Bot activity storage table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS bot_activity (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    activity_text TEXT,
                    activity_type VARCHAR(50) DEFAULT 'watching',
                    status VARCHAR(50) DEFAULT 'online',
                    custom_status TEXT DEFAULT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Add custom_status column if it doesn't exist (for existing databases)
            try:
                cursor.execute('ALTER TABLE bot_activity ADD COLUMN custom_status TEXT DEFAULT NULL')
            except mysql.connector.Error:
                pass  # Column already exists
            
            # Add activity_type column if it doesn't exist (for existing databases)
            try:
                cursor.execute("ALTER TABLE bot_activity ADD COLUMN activity_type VARCHAR(50) DEFAULT 'watching'")
            except mysql.connector.Error:
                pass  # Column already exists
            
            # Bot rotating statuses table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS bot_rotating_statuses (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    status_text TEXT NOT NULL,
                    activity_type VARCHAR(50) DEFAULT 'watching',
                    position INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Giveaways table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS giveaways (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    message_id BIGINT,
                    host_id BIGINT NOT NULL,
                    reward TEXT NOT NULL,
                    winner_count INT NOT NULL,
                    end_time TIMESTAMP NOT NULL,
                    ended BOOLEAN DEFAULT FALSE,
                    paused BOOLEAN DEFAULT FALSE,
                    requirement_type VARCHAR(50) DEFAULT NULL,
                    requirement_value TEXT DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Giveaway entries table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS giveaway_entries (
                    giveaway_id INT,
                    user_id BIGINT NOT NULL,
                    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (giveaway_id, user_id),
                    FOREIGN KEY (giveaway_id) REFERENCES giveaways(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Giveaway winners table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS giveaway_winners (
                    giveaway_id INT,
                    user_id BIGINT NOT NULL,
                    selected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (giveaway_id, user_id),
                    FOREIGN KEY (giveaway_id) REFERENCES giveaways(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Giveaway blacklist table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS giveaway_blacklist (
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT,
                    role_id BIGINT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    CHECK (user_id IS NOT NULL OR role_id IS NOT NULL)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Giveaway manager roles table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS giveaway_manager_roles (
                    guild_id BIGINT NOT NULL,
                    role_id BIGINT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (guild_id, role_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Reaction role panels table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS reaction_role_panels (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    panel_id INT NOT NULL,
                    panel_type VARCHAR(50) NOT NULL,
                    panel_embed VARCHAR(255),
                    channel_id BIGINT,
                    message_id BIGINT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_guild_panel (guild_id, panel_id),
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_message_id (message_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Reaction role options table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS reaction_role_options (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    panel_id INT NOT NULL,
                    guild_id BIGINT NOT NULL,
                    role_id BIGINT NOT NULL,
                    emoji TEXT NOT NULL,
                    description TEXT,
                    option_order INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_panel_id (panel_id),
                    INDEX idx_guild_id (guild_id),
                    FOREIGN KEY (panel_id) REFERENCES reaction_role_panels(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Add label column if it doesn't exist (for button/selective types)
            try:
                cursor.execute('ALTER TABLE reaction_role_options ADD COLUMN label VARCHAR(100) AFTER emoji')
            except mysql.connector.Error:
                pass  # Column already exists

            # Premium users table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS premium_users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id BIGINT NOT NULL,
                    guild_id BIGINT NULL,
                    premium_type ENUM('global', 'guild') NOT NULL,
                    expiry_date TIMESTAMP NOT NULL,
                    granted_by BIGINT NOT NULL,
                    granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_active BOOLEAN DEFAULT TRUE,
                    INDEX idx_user_id (user_id),
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_expiry (expiry_date),
                    UNIQUE KEY unique_user_guild_type (user_id, guild_id, premium_type)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # AFK status table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS afk_status (
                    user_id BIGINT PRIMARY KEY,
                    reason TEXT,
                    dm_mentions BOOLEAN DEFAULT FALSE,
                    scope VARCHAR(10) NOT NULL,
                    guild_id BIGINT NULL,
                    set_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Warnings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS warnings (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    moderator_id BIGINT NOT NULL,
                    reason TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    active BOOLEAN DEFAULT TRUE,
                    INDEX idx_guild_user (guild_id, user_id),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Custom embeds table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS custom_embeds (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    name VARCHAR(255) NOT NULL,
                    embed_data JSON NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_guild_embed_name (guild_id, name),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Embed button messages table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS embed_button_messages (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    message_id BIGINT NOT NULL,
                    embed_buttons JSON,
                    link_buttons JSON,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_message (message_id),
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_channel_id (channel_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Embed button config sessions table - for restoring active configuration views
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS embed_button_config_sessions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    message_id BIGINT NOT NULL,
                    author_id BIGINT NOT NULL,
                    embed_name VARCHAR(255) NOT NULL,
                    embed_data JSON NOT NULL,
                    embed_buttons JSON,
                    link_buttons JSON,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_config_message (message_id),
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_author_id (author_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Auto reactions table - updated for multiple emojis
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS autoreact (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    trigger_text TEXT NOT NULL,
                    emojis TEXT,
                    match_type ENUM('exact', 'contains') DEFAULT 'contains',
                    user_id BIGINT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_guild_user (guild_id, user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Auto responder table - updated for multiple reaction emojis
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS autoresponder (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    trigger_text TEXT NOT NULL,
                    reply_text TEXT NOT NULL,
                    match_type ENUM('exact', 'contains') DEFAULT 'contains',
                    required_role_id BIGINT,
                    reaction_emojis TEXT,
                    mode ENUM('reply', 'normal') DEFAULT 'normal',
                    user_id BIGINT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_guild_user (guild_id, user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Add mode column to existing tables if it doesn't exist
            cursor.execute('''
                ALTER TABLE autoresponder 
                ADD COLUMN IF NOT EXISTS mode ENUM('reply', 'normal') DEFAULT 'normal'
            ''')

            # Add user_id columns to existing tables for user limit tracking
            # Check if user_id column exists in autoreact table
            cursor.execute('''
                SELECT COUNT(*) FROM information_schema.columns 
                WHERE table_schema = DATABASE() 
                AND table_name = 'autoreact' 
                AND column_name = 'user_id'
            ''')
            if cursor.fetchone()[0] == 0:
                try:
                    cursor.execute('ALTER TABLE autoreact ADD COLUMN user_id BIGINT NULL')
                except Exception as e:
                    print(f"Warning: Could not add user_id column to autoreact table: {e}")

            # Check if user_id column exists in autoresponder table
            cursor.execute('''
                SELECT COUNT(*) FROM information_schema.columns 
                WHERE table_schema = DATABASE() 
                AND table_name = 'autoresponder' 
                AND column_name = 'user_id'
            ''')
            if cursor.fetchone()[0] == 0:
                try:
                    cursor.execute('ALTER TABLE autoresponder ADD COLUMN user_id BIGINT NULL')
                except Exception as e:
                    print(f"Warning: Could not add user_id column to autoresponder table: {e}")

            # Add indexes for user_id if they don't exist
            # Check for autoreact index
            cursor.execute('''
                SELECT COUNT(*) FROM information_schema.statistics 
                WHERE table_schema = DATABASE() 
                AND table_name = 'autoreact' 
                AND index_name = 'idx_guild_user'
            ''')
            if cursor.fetchone()[0] == 0:
                try:
                    cursor.execute('ALTER TABLE autoreact ADD INDEX idx_guild_user (guild_id, user_id)')
                except Exception as e:
                    print(f"Warning: Could not add index to autoreact table: {e}")

            # Check for autoresponder index
            cursor.execute('''
                SELECT COUNT(*) FROM information_schema.statistics 
                WHERE table_schema = DATABASE() 
                AND table_name = 'autoresponder' 
                AND index_name = 'idx_guild_user'
            ''')
            if cursor.fetchone()[0] == 0:
                try:
                    cursor.execute('ALTER TABLE autoresponder ADD INDEX idx_guild_user (guild_id, user_id)')
                except Exception as e:
                    print(f"Warning: Could not add index to autoresponder table: {e}")

            # Migrate existing auto action tables to new schema
            try:
                # Check if old columns exist and migrate data
                cursor.execute("SHOW COLUMNS FROM autoreact LIKE 'emoji_id'")
                if cursor.fetchone():
                    # Migrate autoreact table
                    cursor.execute('''
                        SELECT id, emoji_id, emoji_name 
                        FROM autoreact 
                        WHERE emoji_id IS NOT NULL OR emoji_name IS NOT NULL
                    ''')
                    old_autoreacts = cursor.fetchall()

                    # Add new emojis column if it doesn't exist
                    cursor.execute("ALTER TABLE autoreact ADD COLUMN IF NOT EXISTS emojis TEXT")

                    # Migrate data from old columns to new format
                    for row_id, emoji_id, emoji_name in old_autoreacts:
                        if emoji_id and emoji_name:
                            new_emoji = f"<:{emoji_name}:{emoji_id}>"
                        elif emoji_name:
                            new_emoji = emoji_name
                        else:
                            continue

                        cursor.execute(
                            "UPDATE autoreact SET emojis = %s WHERE id = %s",
                            (new_emoji, row_id)
                        )

                    # Drop old columns
                    cursor.execute("ALTER TABLE autoreact DROP COLUMN IF EXISTS emoji_id")
                    cursor.execute("ALTER TABLE autoreact DROP COLUMN IF EXISTS emoji_name")

                # Check if old autoresponder columns exist and migrate data
                cursor.execute("SHOW COLUMNS FROM autoresponder LIKE 'reaction_emoji_id'")
                if cursor.fetchone():
                    # Migrate autoresponder table
                    cursor.execute('''
                        SELECT id, reaction_emoji_id, reaction_emoji_name 
                        FROM autoresponder 
                        WHERE reaction_emoji_id IS NOT NULL OR reaction_emoji_name IS NOT NULL
                    ''')
                    old_autoresponders = cursor.fetchall()

                    # Add new reaction_emojis column if it doesn't exist
                    cursor.execute("ALTER TABLE autoresponder ADD COLUMN IF NOT EXISTS reaction_emojis TEXT")

                    # Migrate data from old columns to new format
                    for row_id, emoji_id, emoji_name in old_autoresponders:
                        if emoji_id and emoji_name:
                            new_emoji = f"<:{emoji_name}:{emoji_id}>"
                        elif emoji_name:
                            new_emoji = emoji_name
                        else:
                            continue

                        cursor.execute(
                            "UPDATE autoresponder SET reaction_emojis = %s WHERE id = %s",
                            (new_emoji, row_id)
                        )

                    # Drop old columns
                    cursor.execute("ALTER TABLE autoresponder DROP COLUMN IF EXISTS reaction_emoji_id")
                    cursor.execute("ALTER TABLE autoresponder DROP COLUMN IF EXISTS reaction_emoji_name")

            except Exception as e:
                print(f"Auto action table migration info: {e}")

            # Human autoroles table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS autoroles_humans (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    role_id BIGINT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_id (guild_id),
                    UNIQUE KEY unique_guild_role (guild_id, role_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Bot autoroles table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS autoroles_bots (
                    guild_id BIGINT PRIMARY KEY,
                    role_id BIGINT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Custom roles table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS custom_roles (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    role_id BIGINT NOT NULL,
                    alias VARCHAR(255) NOT NULL,
                    role_type ENUM('staff', 'girl', 'vip', 'friend', 'guest', 'custom') NOT NULL,
                    created_by BIGINT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_alias (guild_id, alias),
                    UNIQUE KEY unique_guild_alias (guild_id, alias)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Custom roles settings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS custom_roles_settings (
                    guild_id BIGINT PRIMARY KEY,
                    reqrole_id BIGINT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Active tickets table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS active_tickets (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    user_id BIGINT,
                    category_name VARCHAR(255),
                    global_panel_id INT,
                    claimed_by BIGINT,
                    ticket_number INT,
                    status VARCHAR(50) DEFAULT 'open',
                    original_category_id BIGINT,
                    original_channel_name VARCHAR(255),
                    support_role_id BIGINT,
                    welcome_message_id BIGINT,
                    claimed_at TIMESTAMP NULL,
                    closed_by BIGINT,
                    closed_at TIMESTAMP NULL,
                    reopened_by BIGINT,
                    reopened_at TIMESTAMP NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_guild_channel (guild_id, channel_id),
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_user_id (user_id),
                    INDEX idx_global_panel_id (global_panel_id),
                    INDEX idx_status (status)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Add missing columns to active_tickets if they don't exist (for existing databases)
            try:
                cursor.execute('ALTER TABLE active_tickets ADD COLUMN original_channel_name VARCHAR(255)')
                print("✅ Added original_channel_name column to active_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add original_channel_name to active_tickets: {e}")

            try:
                cursor.execute('ALTER TABLE active_tickets ADD COLUMN support_role_id BIGINT')
                print("✅ Added support_role_id column to active_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add support_role_id to active_tickets: {e}")

            try:
                cursor.execute('ALTER TABLE active_tickets ADD COLUMN welcome_message_id BIGINT')
                print("✅ Added welcome_message_id column to active_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add welcome_message_id to active_tickets: {e}")

            try:
                cursor.execute('ALTER TABLE active_tickets ADD COLUMN claimed_at TIMESTAMP NULL')
                print("✅ Added claimed_at column to active_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add claimed_at to active_tickets: {e}")

            try:
                cursor.execute('ALTER TABLE active_tickets ADD COLUMN closed_by BIGINT')
                print("✅ Added closed_by column to active_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add closed_by to active_tickets: {e}")

            try:
                cursor.execute('ALTER TABLE active_tickets ADD COLUMN closed_at TIMESTAMP NULL')
                print("✅ Added closed_at column to active_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add closed_at to active_tickets: {e}")

            try:
                cursor.execute('ALTER TABLE active_tickets ADD COLUMN reopened_by BIGINT')
                print("✅ Added reopened_by column to active_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add reopened_by to active_tickets: {e}")

            try:
                cursor.execute('ALTER TABLE active_tickets ADD COLUMN reopened_at TIMESTAMP NULL')
                print("✅ Added reopened_at column to active_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add reopened_at to active_tickets: {e}")

            # Ticket added users table - tracks manually added users to tickets
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ticket_added_users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_ticket_user (guild_id, channel_id, user_id),
                    INDEX idx_guild_channel (guild_id, channel_id),
                    FOREIGN KEY (guild_id, channel_id) REFERENCES active_tickets(guild_id, channel_id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Closed tickets table - for ticket history and reopening
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS closed_tickets (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    user_id BIGINT,
                    category_name VARCHAR(255),
                    global_panel_id INT,
                    claimed_by BIGINT,
                    ticket_number INT,
                    original_category_id BIGINT,
                    original_channel_name VARCHAR(255),
                    support_role_id BIGINT,
                    closed_by BIGINT,
                    closed_at TIMESTAMP NULL,
                    created_at TIMESTAMP NULL,
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_channel_id (channel_id),
                    INDEX idx_user_id (user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Add missing columns to closed_tickets if they don't exist (for existing databases)
            try:
                cursor.execute('ALTER TABLE closed_tickets ADD COLUMN original_channel_name VARCHAR(255)')
                print("✅ Added original_channel_name column to closed_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add original_channel_name to closed_tickets: {e}")

            try:
                cursor.execute('ALTER TABLE closed_tickets ADD COLUMN support_role_id BIGINT')
                print("✅ Added support_role_id column to closed_tickets")
            except mysql.connector.Error as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Could not add support_role_id to closed_tickets: {e}")


            # Add new columns to existing tables if they don't exist
            try:
                cursor.execute("ALTER TABLE giveaways ADD COLUMN requirement_type VARCHAR(50) DEFAULT NULL")
                print("✅ Added requirement_type column to giveaways table")
            except Exception as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Warning adding requirement_type column: {e}")

            try:
                cursor.execute("ALTER TABLE giveaways ADD COLUMN requirement_value TEXT DEFAULT NULL")
                print("✅ Added requirement_value column to giveaways table")
            except Exception as e:
                if "Duplicate column name" not in str(e):
                    print(f"⚠️  Warning adding requirement_value column: {e}")

            # Migration: Update existing invites table structure if needed
            try:
                # Check if the table has the old primary key structure
                cursor.execute("SHOW CREATE TABLE invites")
                table_structure = cursor.fetchone()[1]

                if "PRIMARY KEY (`guild_id`,`user_id`,`joined_at`)" in table_structure:
                    print("🔄 Migrating invites table to support proper rejoin tracking...")

                    # Create backup table
                    cursor.execute('''
                        CREATE TABLE IF NOT EXISTS invites_backup AS 
                        SELECT * FROM invites
                    ''')

                    # Drop the current table
                    cursor.execute('DROP TABLE invites')

                    # Recreate with the new structure
                    cursor.execute('''
                        CREATE TABLE invites (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            guild_id BIGINT,
                            user_id BIGINT,
                            inviter_id BIGINT,
                            invite_code TEXT,
                            joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            left_at TIMESTAMP NULL,
                            is_fake BOOLEAN DEFAULT FALSE,
                            INDEX idx_guild_user (guild_id, user_id),
                            INDEX idx_guild_inviter (guild_id, inviter_id)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ''')

                    # Restore data from backup
                    cursor.execute('''
                        INSERT INTO invites (guild_id, user_id, inviter_id, invite_code, joined_at, left_at, is_fake)
                        SELECT guild_id, user_id, inviter_id, invite_code, joined_at, left_at, is_fake
                        FROM invites_backup
                    ''')

                    # Drop backup table
                    cursor.execute('DROP TABLE invites_backup')

                    print("✅ Successfully migrated invites table for proper rejoin tracking!")

            except Exception as migration_error:
                print(f"⚠️ Migration warning (table might already be correct): {migration_error}")

            # Timers table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS timers (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    message_id BIGINT NULL,
                    end_time TIMESTAMP NOT NULL,
                    reason TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_active BOOLEAN DEFAULT TRUE,
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_user_id (user_id),
                    INDEX idx_active_end_time (is_active, end_time)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Permanent member history table - NEVER cleared by invite resets
            # This ensures rejoin detection works even after data resets
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS member_history (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    event_type ENUM('join', 'leave') NOT NULL,
                    event_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_user (guild_id, user_id),
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_event_time (event_time)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Logging channels table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS logging_channels (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    log_type VARCHAR(50) NOT NULL,
                    channel_id BIGINT NOT NULL,
                    webhook_url TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_guild_log_type (guild_id, log_type),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Logging category configuration table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS logging_config (
                    guild_id BIGINT PRIMARY KEY,
                    category_id BIGINT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Ticket panels table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ticket_panels (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    global_panel_id INT NOT NULL,
                    panel_channel BIGINT,
                    log_channel BIGINT,
                    closed_category BIGINT NULL,
                    ticket_embed TEXT,
                    panel_type ENUM('menu', 'buttons') DEFAULT 'menu',
                    panel_message_id BIGINT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_global_panel (global_panel_id),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Ticket categories table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ticket_categories (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    panel_id INT NOT NULL,
                    name VARCHAR(100) NOT NULL,
                    emoji VARCHAR(100),
                    description TEXT,
                    category_id BIGINT NULL,
                    support_role_id BIGINT NULL,
                    ping_support BOOLEAN DEFAULT FALSE,
                    category_order INT DEFAULT 0,
                    FOREIGN KEY (panel_id) REFERENCES ticket_panels(id) ON DELETE CASCADE,
                    INDEX idx_panel_id (panel_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Ticket statistics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ticket_stats (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    global_panel_id INT NOT NULL,
                    total_active_tickets INT DEFAULT 0,
                    total_closed_tickets INT DEFAULT 0,
                    UNIQUE KEY unique_guild_panel (guild_id, global_panel_id),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Ignored channels table - channels where commands are blocked
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ignored_channels (
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (guild_id, channel_id),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Ignore bypass table - roles/members that can bypass ignored channels
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ignore_bypass (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    entity_id BIGINT NOT NULL,
                    entity_type ENUM('role', 'member') NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_guild_entity (guild_id, entity_id, entity_type),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Anti-Nuke System Tables
            # Antinuke status and configuration table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS antinuke (
                    guild_id BIGINT PRIMARY KEY,
                    status TINYINT DEFAULT 0,
                    log_channel_id BIGINT DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Whitelisted users table with granular permissions
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS whitelisted_users (
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    ban TINYINT DEFAULT 0,
                    kick TINYINT DEFAULT 0,
                    chcr TINYINT DEFAULT 0,
                    chdl TINYINT DEFAULT 0,
                    chup TINYINT DEFAULT 0,
                    rlcr TINYINT DEFAULT 0,
                    rldl TINYINT DEFAULT 0,
                    rlup TINYINT DEFAULT 0,
                    botadd TINYINT DEFAULT 0,
                    mngweb TINYINT DEFAULT 0,
                    meneve TINYINT DEFAULT 0,
                    memup TINYINT DEFAULT 0,
                    serverup TINYINT DEFAULT 0,
                    prune TINYINT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (guild_id, user_id),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Extra owners table - users with full antinuke bypass
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS extraowners (
                    guild_id BIGINT NOT NULL,
                    owner_id BIGINT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (guild_id, owner_id),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Antinuke event logs table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS antinuke_logs (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    event_type VARCHAR(50) NOT NULL,
                    executor_id BIGINT NOT NULL,
                    target_id BIGINT,
                    action_taken VARCHAR(100),
                    reason TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_timestamp (timestamp)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Mainroles table - roles that trigger anti-mention protection
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS mainroles (
                    guild_id BIGINT NOT NULL,
                    role_id BIGINT NOT NULL,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (guild_id, role_id),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Beastmode configuration table - advanced threshold protection
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS beastmode_config (
                    guild_id BIGINT PRIMARY KEY,
                    enabled TINYINT DEFAULT 0,
                    max_ban_per_min INT DEFAULT 3,
                    max_kick_per_min INT DEFAULT 3,
                    max_channel_create_per_min INT DEFAULT 5,
                    max_channel_delete_per_min INT DEFAULT 3,
                    max_role_create_per_min INT DEFAULT 5,
                    max_role_delete_per_min INT DEFAULT 3,
                    max_webhook_create_per_min INT DEFAULT 5,
                    max_mention_per_min INT DEFAULT 3,
                    max_unverified_bot_per_week INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Beastmode tracking table - tracks actions per minute
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS beastmode_tracking (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    action_type VARCHAR(50) NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_user (guild_id, user_id),
                    INDEX idx_timestamp (timestamp),
                    INDEX idx_action_type (action_type)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Whitelisted roles table with granular permissions
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS whitelisted_roles (
                    guild_id BIGINT NOT NULL,
                    role_id BIGINT NOT NULL,
                    ban TINYINT DEFAULT 0,
                    kick TINYINT DEFAULT 0,
                    chcr TINYINT DEFAULT 0,
                    chdl TINYINT DEFAULT 0,
                    chup TINYINT DEFAULT 0,
                    rlcr TINYINT DEFAULT 0,
                    rldl TINYINT DEFAULT 0,
                    rlup TINYINT DEFAULT 0,
                    botadd TINYINT DEFAULT 0,
                    mngweb TINYINT DEFAULT 0,
                    meneve TINYINT DEFAULT 0,
                    memup TINYINT DEFAULT 0,
                    serverup TINYINT DEFAULT 0,
                    prune TINYINT DEFAULT 0,
                    emcr TINYINT DEFAULT 0,
                    emdl TINYINT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (guild_id, role_id),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Add new emoji permission columns to whitelisted_users if they don't exist
            try:
                cursor.execute('ALTER TABLE whitelisted_users ADD COLUMN emcr TINYINT DEFAULT 0')
            except mysql.connector.Error:
                pass

            try:
                cursor.execute('ALTER TABLE whitelisted_users ADD COLUMN emdl TINYINT DEFAULT 0')
            except mysql.connector.Error:
                pass

            # Add new emoji threshold columns to beastmode_config if they don't exist
            try:
                cursor.execute('ALTER TABLE beastmode_config ADD COLUMN max_emoji_create_per_min INT DEFAULT 5')
            except mysql.connector.Error:
                pass

            try:
                cursor.execute('ALTER TABLE beastmode_config ADD COLUMN max_emoji_delete_per_min INT DEFAULT 5')
            except mysql.connector.Error:
                pass

            # Add unverified bot limit column to beastmode_config if it doesn't exist
            try:
                cursor.execute('ALTER TABLE beastmode_config ADD COLUMN max_unverified_bot_per_week INT DEFAULT 0')
            except mysql.connector.Error:
                pass

            # Create unverified bot tracking table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS unverified_bot_tracking (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    bot_id BIGINT NOT NULL,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_user (guild_id, user_id),
                    INDEX idx_timestamp (added_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Automod System Tables
            # Automod main configuration table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS automod_config (
                    guild_id BIGINT PRIMARY KEY,
                    enabled TINYINT DEFAULT 0,
                    log_channel_id BIGINT DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Automod module configuration table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS automod_modules (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    module_name VARCHAR(50) NOT NULL,
                    enabled TINYINT DEFAULT 0,
                    punishment VARCHAR(20) DEFAULT NULL,
                    threshold_value INT DEFAULT NULL,
                    threshold_time INT DEFAULT 5,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_guild_module (guild_id, module_name),
                    INDEX idx_guild_id (guild_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')

            # Automod bypass table - users/roles/categories/channels that bypass automod per module
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS automod_bypass (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    entity_id BIGINT NOT NULL,
                    entity_type ENUM('user', 'role', 'category', 'channel') NOT NULL,
                    module_name VARCHAR(50) DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_guild_entity_module (guild_id, entity_id, entity_type, module_name),
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_module (module_name)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Extend entity_type ENUM if needed for existing tables
            try:
                cursor.execute('''
                    ALTER TABLE automod_bypass 
                    MODIFY COLUMN entity_type ENUM('user', 'role', 'category', 'channel') NOT NULL
                ''')
            except mysql.connector.Error:
                pass  # Already updated or table just created
            
            # Add module_name column if it doesn't exist
            try:
                cursor.execute('ALTER TABLE automod_bypass ADD COLUMN module_name VARCHAR(50) DEFAULT NULL')
            except mysql.connector.Error:
                pass  # Column already exists
            
            # Add mute_duration column to automod_modules if it doesn't exist
            try:
                cursor.execute('ALTER TABLE automod_modules ADD COLUMN mute_duration INT DEFAULT 5')
            except mysql.connector.Error:
                pass  # Column already exists
            
            # Update unique key to include module_name
            try:
                cursor.execute('ALTER TABLE automod_bypass DROP INDEX unique_guild_entity')
                cursor.execute('ALTER TABLE automod_bypass ADD UNIQUE KEY unique_guild_entity_module (guild_id, entity_id, entity_type, module_name)')
            except mysql.connector.Error:
                pass  # Already updated

            # Automod tracking table for rate limiting
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS automod_tracking (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    module_name VARCHAR(50) NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_user (guild_id, user_id),
                    INDEX idx_timestamp (timestamp),
                    INDEX idx_module (module_name)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Automod threshold configuration table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS automod_config_thresholds (
                    guild_id BIGINT PRIMARY KEY,
                    max_message_spam INT DEFAULT 5,
                    max_attachment_spam INT DEFAULT 4,
                    max_emoji_in_message INT DEFAULT 5,
                    max_emoji_spam INT DEFAULT 15,
                    max_mention_in_message INT DEFAULT 3,
                    max_mention_spam INT DEFAULT 5,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Autokick rules table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS autokick_rules (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    condition_type VARCHAR(50) NOT NULL,
                    condition_value VARCHAR(255),
                    added_by BIGINT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_condition_type (condition_type)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Autoban rules table (time-limited banning of all new joiners)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS autoban_rules (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    duration_hours INT NOT NULL,
                    added_by BIGINT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL,
                    INDEX idx_guild_id (guild_id),
                    INDEX idx_expires_at (expires_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # Migration: Add columns if table exists without them (for existing installations)
            try:
                cursor.execute("SELECT duration_hours FROM autoban_rules LIMIT 1")
                cursor.fetchall()
            except mysql.connector.Error:
                try:
                    cursor.execute('ALTER TABLE autoban_rules ADD COLUMN duration_hours INT NOT NULL DEFAULT 1')
                except mysql.connector.Error:
                    pass
            
            try:
                cursor.execute("SELECT expires_at FROM autoban_rules LIMIT 1")
                cursor.fetchall()
            except mysql.connector.Error:
                try:
                    cursor.execute('ALTER TABLE autoban_rules ADD COLUMN expires_at TIMESTAMP NULL')
                except mysql.connector.Error:
                    pass
            
            # Remove old 'hours' column if it exists (migration from old schema)
            try:
                cursor.execute("SELECT hours FROM autoban_rules LIMIT 1")
                cursor.fetchall()
                cursor.execute('ALTER TABLE autoban_rules DROP COLUMN hours')
            except mysql.connector.Error:
                pass
            
            # Add mute_duration column to automod_modules if it doesn't exist
            try:
                cursor.execute('ALTER TABLE automod_modules ADD COLUMN mute_duration INT DEFAULT NULL')
            except mysql.connector.Error:
                pass  # Column already exists

            self.connection.commit()
            cursor.close()

        except Error as e:
            print(f"Error initializing database: {e}")

    def reset_connection(self):
        """Reset database connection to clear any unread results"""
        try:
            if self.connection and self.connection.is_connected():
                self.connection.close()
        except:
            pass
        self.connection = None

    def get_cursor(self):
        """Get a cursor for database operations"""
        try:
            if not self.connection or not self.connection.is_connected():
                self.connection = mysql.connector.connect(**self.mysql_config)
            return self.connection.cursor(buffered=True)
        except mysql.connector.Error as e:
            if "Unread result found" in str(e):
                # Reset connection if unread results are found
                self.reset_connection()
                self.connection = mysql.connector.connect(**self.mysql_config)
                return self.connection.cursor(buffered=True)
            else:
                raise e

    async def get_antinuke_config(self, guild_id):
        """Get antinuke configuration for a guild"""
        cursor = self.get_cursor()
        cursor.execute('SELECT status, log_channel_id FROM antinuke WHERE guild_id = %s', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        if result:
            return {'status': bool(result[0]), 'log_channel_id': result[1]}
        return {'status': False, 'log_channel_id': None}

    async def set_antinuke_status(self, guild_id, status, log_channel_id=None):
        """Enable or disable antinuke for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO antinuke (guild_id, status, log_channel_id) 
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE status = %s, log_channel_id = %s
        ''', (guild_id, 1 if status else 0, log_channel_id, 1 if status else 0, log_channel_id))
        self.connection.commit()
        cursor.close()

    async def is_whitelisted(self, guild_id, user_id, permission, user_roles=None):
        """Check if a user or their roles are whitelisted for a specific permission"""
        cursor = self.get_cursor()
        query = f'SELECT {permission} FROM whitelisted_users WHERE guild_id = %s AND user_id = %s'
        cursor.execute(query, (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()

        if result and bool(result[0]):
            return True

        if user_roles:
            cursor = self.get_cursor()
            for role in user_roles:
                query = f'SELECT {permission} FROM whitelisted_roles WHERE guild_id = %s AND role_id = %s'
                cursor.execute(query, (guild_id, role.id))
                result = cursor.fetchone()
                if result and bool(result[0]):
                    cursor.close()
                    return True
            cursor.close()

        return False

    async def is_extra_owner(self, guild_id, user_id):
        """Check if a user is an extra owner"""
        cursor = self.get_cursor()
        cursor.execute('SELECT 1 FROM extraowners WHERE guild_id = %s AND owner_id = %s', (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    async def add_whitelist_user(self, guild_id, user_id, permissions_dict):
        """Add or update a whitelisted user with specific permissions"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO whitelisted_users 
            (guild_id, user_id, ban, kick, chcr, chdl, chup, rlcr, rldl, rlup, botadd, mngweb, meneve, memup, serverup, prune, emcr, emdl)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE 
            ban=%s, kick=%s, chcr=%s, chdl=%s, chup=%s, rlcr=%s, rldl=%s, rlup=%s, 
            botadd=%s, mngweb=%s, meneve=%s, memup=%s, serverup=%s, prune=%s, emcr=%s, emdl=%s
        ''', (
            guild_id, user_id,
            permissions_dict.get('ban', 0), permissions_dict.get('kick', 0),
            permissions_dict.get('chcr', 0), permissions_dict.get('chdl', 0),
            permissions_dict.get('chup', 0), permissions_dict.get('rlcr', 0),
            permissions_dict.get('rldl', 0), permissions_dict.get('rlup', 0),
            permissions_dict.get('botadd', 0), permissions_dict.get('mngweb', 0),
            permissions_dict.get('meneve', 0), permissions_dict.get('memup', 0),
            permissions_dict.get('serverup', 0), permissions_dict.get('prune', 0),
            permissions_dict.get('emcr', 0), permissions_dict.get('emdl', 0),
            permissions_dict.get('ban', 0), permissions_dict.get('kick', 0),
            permissions_dict.get('chcr', 0), permissions_dict.get('chdl', 0),
            permissions_dict.get('chup', 0), permissions_dict.get('rlcr', 0),
            permissions_dict.get('rldl', 0), permissions_dict.get('rlup', 0),
            permissions_dict.get('botadd', 0), permissions_dict.get('mngweb', 0),
            permissions_dict.get('meneve', 0), permissions_dict.get('memup', 0),
            permissions_dict.get('serverup', 0), permissions_dict.get('prune', 0),
            permissions_dict.get('emcr', 0), permissions_dict.get('emdl', 0)
        ))
        self.connection.commit()
        cursor.close()

    async def add_whitelist_role(self, guild_id, role_id, permissions_dict):
        """Add or update a whitelisted role with specific permissions"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO whitelisted_roles 
            (guild_id, role_id, ban, kick, chcr, chdl, chup, rlcr, rldl, rlup, botadd, mngweb, meneve, memup, serverup, prune, emcr, emdl)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE 
            ban=%s, kick=%s, chcr=%s, chdl=%s, chup=%s, rlcr=%s, rldl=%s, rlup=%s, 
            botadd=%s, mngweb=%s, meneve=%s, memup=%s, serverup=%s, prune=%s, emcr=%s, emdl=%s
        ''', (
            guild_id, role_id,
            permissions_dict.get('ban', 0), permissions_dict.get('kick', 0),
            permissions_dict.get('chcr', 0), permissions_dict.get('chdl', 0),
            permissions_dict.get('chup', 0), permissions_dict.get('rlcr', 0),
            permissions_dict.get('rldl', 0), permissions_dict.get('rlup', 0),
            permissions_dict.get('botadd', 0), permissions_dict.get('mngweb', 0),
            permissions_dict.get('meneve', 0), permissions_dict.get('memup', 0),
            permissions_dict.get('serverup', 0), permissions_dict.get('prune', 0),
            permissions_dict.get('emcr', 0), permissions_dict.get('emdl', 0),
            permissions_dict.get('ban', 0), permissions_dict.get('kick', 0),
            permissions_dict.get('chcr', 0), permissions_dict.get('chdl', 0),
            permissions_dict.get('chup', 0), permissions_dict.get('rlcr', 0),
            permissions_dict.get('rldl', 0), permissions_dict.get('rlup', 0),
            permissions_dict.get('botadd', 0), permissions_dict.get('mngweb', 0),
            permissions_dict.get('meneve', 0), permissions_dict.get('memup', 0),
            permissions_dict.get('serverup', 0), permissions_dict.get('prune', 0),
            permissions_dict.get('emcr', 0), permissions_dict.get('emdl', 0)
        ))
        self.connection.commit()
        cursor.close()

    async def remove_whitelist_user(self, guild_id, user_id):
        """Remove a user from the whitelist"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM whitelisted_users WHERE guild_id = %s AND user_id = %s', (guild_id, user_id))
        self.connection.commit()
        cursor.close()

    async def remove_whitelist_role(self, guild_id, role_id):
        """Remove a role from the whitelist"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM whitelisted_roles WHERE guild_id = %s AND role_id = %s', (guild_id, role_id))
        self.connection.commit()
        cursor.close()

    async def get_user_whitelist_permissions(self, guild_id, user_id):
        """Get a user's whitelist permissions"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT ban, kick, chcr, chdl, chup, rlcr, rldl, rlup, botadd, mngweb, meneve, memup, serverup, prune, emcr, emdl 
            FROM whitelisted_users 
            WHERE guild_id = %s AND user_id = %s
        ''', (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()

        if not result:
            return {}

        perms = ['ban', 'kick', 'chcr', 'chdl', 'chup', 'rlcr', 'rldl', 'rlup', 
                 'botadd', 'mngweb', 'meneve', 'memup', 'serverup', 'prune', 'emcr', 'emdl']
        return {perm: bool(result[i]) for i, perm in enumerate(perms)}

    async def get_role_whitelist_permissions(self, guild_id, role_id):
        """Get a role's whitelist permissions"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT ban, kick, chcr, chdl, chup, rlcr, rldl, rlup, botadd, mngweb, meneve, memup, serverup, prune, emcr, emdl 
            FROM whitelisted_roles 
            WHERE guild_id = %s AND role_id = %s
        ''', (guild_id, role_id))
        result = cursor.fetchone()
        cursor.close()

        if not result:
            return {}

        perms = ['ban', 'kick', 'chcr', 'chdl', 'chup', 'rlcr', 'rldl', 'rlup', 
                 'botadd', 'mngweb', 'meneve', 'memup', 'serverup', 'prune', 'emcr', 'emdl']
        return {perm: bool(result[i]) for i, perm in enumerate(perms)}

    async def get_whitelisted_users(self, guild_id):
        """Get all whitelisted users for a guild"""
        cursor = self.get_cursor()
        cursor.execute('SELECT user_id FROM whitelisted_users WHERE guild_id = %s', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    async def get_whitelisted_roles(self, guild_id):
        """Get all whitelisted roles for a guild"""
        cursor = self.get_cursor()
        cursor.execute('SELECT role_id FROM whitelisted_roles WHERE guild_id = %s', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    async def reset_whitelist(self, guild_id):
        """Remove all whitelisted users for a guild"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM whitelisted_users WHERE guild_id = %s', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def add_extra_owner(self, guild_id, owner_id):
        """Add an extra owner"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO extraowners (guild_id, owner_id) VALUES (%s, %s)
        ''', (guild_id, owner_id))
        self.connection.commit()
        cursor.close()

    async def remove_extra_owner(self, guild_id, owner_id):
        """Remove an extra owner"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM extraowners WHERE guild_id = %s AND owner_id = %s', (guild_id, owner_id))
        self.connection.commit()
        cursor.close()

    async def get_extra_owners(self, guild_id):
        """Get all extra owners for a guild"""
        cursor = self.get_cursor()
        cursor.execute('SELECT owner_id FROM extraowners WHERE guild_id = %s', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    async def reset_extra_owners(self, guild_id):
        """Remove all extra owners for a guild"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM extraowners WHERE guild_id = %s', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def log_antinuke_event(self, guild_id, event_type, executor_id, target_id=None, action_taken=None, reason=None):
        """Log an antinuke event to the database"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO antinuke_logs (guild_id, event_type, executor_id, target_id, action_taken, reason)
            VALUES (%s, %s, %s, %s, %s, %s)
        ''', (guild_id, event_type, executor_id, target_id, action_taken, reason))
        self.connection.commit()
        cursor.close()

    async def add_mainrole(self, guild_id, role_id):
        """Add a role to the mainroles list"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO mainroles (guild_id, role_id) VALUES (%s, %s)
        ''', (guild_id, role_id))
        self.connection.commit()
        cursor.close()

    async def remove_mainrole(self, guild_id, role_id):
        """Remove a role from the mainroles list"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM mainroles WHERE guild_id = %s AND role_id = %s', (guild_id, role_id))
        self.connection.commit()
        cursor.close()

    async def get_mainroles(self, guild_id):
        """Get all mainroles for a guild"""
        cursor = self.get_cursor()
        cursor.execute('SELECT role_id FROM mainroles WHERE guild_id = %s', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    async def is_mainrole(self, guild_id, role_id):
        """Check if a role is in the mainroles list"""
        cursor = self.get_cursor()
        cursor.execute('SELECT 1 FROM mainroles WHERE guild_id = %s AND role_id = %s', (guild_id, role_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    async def get_beastmode_config(self, guild_id):
        """Get beastmode configuration for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT enabled, max_ban_per_min, max_kick_per_min, max_channel_create_per_min,
                   max_channel_delete_per_min, max_role_create_per_min, max_role_delete_per_min,
                   max_webhook_create_per_min, max_mention_per_min, max_emoji_create_per_min, 
                   max_emoji_delete_per_min, max_unverified_bot_per_week
            FROM beastmode_config WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'enabled': bool(result[0]),
                'max_ban_per_min': result[1],
                'max_kick_per_min': result[2],
                'max_channel_create_per_min': result[3],
                'max_channel_delete_per_min': result[4],
                'max_role_create_per_min': result[5],
                'max_role_delete_per_min': result[6],
                'max_webhook_create_per_min': result[7],
                'max_mention_per_min': result[8],
                'max_emoji_create_per_min': result[9] if len(result) > 9 else 5,
                'max_emoji_delete_per_min': result[10] if len(result) > 10 else 5,
                'max_unverified_bot_per_week': result[11] if len(result) > 11 else 0
            }

        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO beastmode_config (guild_id, enabled) 
            VALUES (%s, 0)
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

        return {
            'enabled': False,
            'max_ban_per_min': 3,
            'max_kick_per_min': 3,
            'max_channel_create_per_min': 5,
            'max_channel_delete_per_min': 3,
            'max_role_create_per_min': 5,
            'max_role_delete_per_min': 3,
            'max_webhook_create_per_min': 5,
            'max_mention_per_min': 3,
            'max_emoji_create_per_min': 5,
            'max_emoji_delete_per_min': 5,
            'max_unverified_bot_per_week': 0
        }

    async def set_beastmode_status(self, guild_id, enabled):
        """Enable or disable beastmode for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO beastmode_config 
            (guild_id, enabled, max_ban_per_min, max_kick_per_min, max_channel_create_per_min,
             max_channel_delete_per_min, max_role_create_per_min, max_role_delete_per_min,
             max_webhook_create_per_min, max_mention_per_min, max_emoji_create_per_min,
             max_emoji_delete_per_min, max_unverified_bot_per_week)
            VALUES (%s, %s, 3, 3, 5, 3, 5, 3, 5, 3, 5, 5, 0)
            ON DUPLICATE KEY UPDATE enabled = %s
        ''', (guild_id, 1 if enabled else 0, 1 if enabled else 0))
        self.connection.commit()
        cursor.close()

    async def update_beastmode_config(self, guild_id, config_updates):
        """Update beastmode configuration thresholds"""
        cursor = self.get_cursor()

        # Build update query dynamically based on config_updates
        update_parts = []
        params = []

        for key, value in config_updates.items():
            update_parts.append(f"{key} = %s")
            params.append(value)

        params.append(guild_id)

        query = f'''
            UPDATE beastmode_config 
            SET {', '.join(update_parts)}
            WHERE guild_id = %s
        '''

        cursor.execute(query, params)
        affected = cursor.rowcount
        self.connection.commit()
        cursor.close()

        # If no rows were affected, insert default config first
        if affected == 0:
            cursor = self.get_cursor()
            cursor.execute('''
                INSERT INTO beastmode_config (guild_id, enabled) 
                VALUES (%s, 0)
            ''', (guild_id,))
            self.connection.commit()
            cursor.close()

            # Try update again
            cursor = self.get_cursor()
            cursor.execute(query, params)
            self.connection.commit()
            cursor.close()

    async def track_beastmode_action(self, guild_id, user_id, action_type):
        """Track an action for beastmode monitoring"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO beastmode_tracking (guild_id, user_id, action_type)
            VALUES (%s, %s, %s)
        ''', (guild_id, user_id, action_type))
        self.connection.commit()
        cursor.close()

    async def get_recent_beastmode_actions(self, guild_id, user_id, action_type, minutes=1):
        """Get count of recent actions by a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT COUNT(*) FROM beastmode_tracking
            WHERE guild_id = %s AND user_id = %s AND action_type = %s
            AND timestamp >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %s MINUTE)
        ''', (guild_id, user_id, action_type, minutes))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else 0

    async def cleanup_old_beastmode_tracking(self):
        """Clean up beastmode tracking data older than 2 minutes"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM beastmode_tracking
            WHERE timestamp < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 MINUTE)
        ''')
        self.connection.commit()
        cursor.close()

    async def track_unverified_bot_addition(self, guild_id, user_id, bot_id):
        """Track an unverified bot addition"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO unverified_bot_tracking (guild_id, user_id, bot_id)
            VALUES (%s, %s, %s)
        ''', (guild_id, user_id, bot_id))
        self.connection.commit()
        cursor.close()

    async def get_weekly_unverified_bot_additions(self, guild_id, user_id):
        """Get count of unverified bots added by a user in the last week"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT COUNT(*) FROM unverified_bot_tracking
            WHERE guild_id = %s AND user_id = %s
            AND added_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY)
        ''', (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else 0

    async def cleanup_old_unverified_bot_tracking(self):
        """Clean up unverified bot tracking data older than 7 days"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM unverified_bot_tracking
            WHERE added_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY)
        ''')
        self.connection.commit()
        cursor.close()

    async def cache_invites(self, guild_id, invites):
        """Cache current invite states"""
        cursor = self.get_cursor()

        # Clear existing cached invites for this guild
        cursor.execute(
            'DELETE FROM cached_invites WHERE guild_id = %s',
            (guild_id,)
        )

        # Insert current invites
        for invite in invites:
            cursor.execute('''
                INSERT INTO cached_invites 
                (guild_id, code, uses, inviter_id, created_at)
                VALUES (%s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE 
                uses = VALUES(uses), inviter_id = VALUES(inviter_id)
            ''', (
                guild_id,
                invite.code,
                invite.uses,
                invite.inviter.id if invite.inviter else None,
                invite.created_at.replace(tzinfo=None) if invite.created_at else None
            ))

        self.connection.commit()
        cursor.close()

    async def get_cached_invites(self, guild_id):
        """Get cached invites for a guild"""
        cursor = self.get_cursor()
        cursor.execute(
            'SELECT code, uses, inviter_id FROM cached_invites WHERE guild_id = %s',
            (guild_id,)
        )
        rows = cursor.fetchall()
        cursor.close()
        return [{'code': row[0], 'uses': row[1], 'inviter_id': row[2]} for row in rows]

    async def record_join(self, guild_id, user_id, inviter_id, invite_code, is_fake=False):
        """Record a member join with enhanced tracking - allows multiple joins (rejoins)"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                INSERT INTO invites (guild_id, user_id, inviter_id, invite_code, is_fake, joined_at)
                VALUES (%s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
            ''', (guild_id, user_id, inviter_id, invite_code, is_fake))

            # Also record in permanent member_history table (never cleared by resets)
            cursor.execute('''
                INSERT INTO member_history (guild_id, user_id, event_type, event_time)
                VALUES (%s, %s, 'join', CURRENT_TIMESTAMP)
            ''', (guild_id, user_id))

            self.connection.commit()
            print(f"DEBUG: Successfully recorded join for user {user_id} in guild {guild_id}")
        except Exception as e:
            print(f"Error recording join for user {user_id}: {e}")
            # Try with INSERT IGNORE as fallback
            try:
                cursor.execute('''
                    INSERT IGNORE INTO invites (guild_id, user_id, inviter_id, invite_code, is_fake, joined_at)
                    VALUES (%s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                ''', (guild_id, user_id, inviter_id, invite_code, is_fake))

                # Also record in permanent member_history table
                cursor.execute('''
                    INSERT INTO member_history (guild_id, user_id, event_type, event_time)
                    VALUES (%s, %s, 'join', CURRENT_TIMESTAMP)
                ''', (guild_id, user_id))

                self.connection.commit()
            except Exception as e2:
                print(f"Debug: Fallback insert also failed - {e2}")
        finally:
            cursor.close()

    async def update_inviter(self, guild_id, user_id, inviter_id, invite_code):
        """Update the inviter for an existing member"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE invites 
            SET inviter_id = %s, invite_code = %s
            WHERE guild_id = %s AND user_id = %s
              AND joined_at = (
                SELECT MAX(joined_at) FROM (SELECT * FROM invites) AS inv
                WHERE guild_id = %s AND user_id = %s
              )
        ''', (inviter_id, invite_code, guild_id, user_id, guild_id, user_id))
        self.connection.commit()
        cursor.close()

    async def add_invite_record(self, guild_id, user_id, inviter_id, invite_code, joined_at=None, is_fake=False):
        """Add an invite record manually with optional timestamp"""
        cursor = self.get_cursor()
        if joined_at:
            # Convert datetime to timestamp if needed
            if hasattr(joined_at, 'replace'):
                joined_at = joined_at.replace(tzinfo=None)

            cursor.execute('''
                INSERT IGNORE INTO invites (guild_id, user_id, inviter_id, invite_code, joined_at, is_fake)
                VALUES (%s, %s, %s, %s, %s, %s)
            ''', (guild_id, user_id, inviter_id, invite_code, joined_at, is_fake))
        else:
            cursor.execute('''
                INSERT INTO invites (guild_id, user_id, inviter_id, invite_code, is_fake)
                VALUES (%s, %s, %s, %s, %s)
            ''', (guild_id, user_id, inviter_id, invite_code, is_fake))
        self.connection.commit()
        cursor.close()

    async def record_leave(self, guild_id, user_id):
        """Record a member leave"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE invites 
            SET left_at = CURRENT_TIMESTAMP 
            WHERE guild_id = %s AND user_id = %s AND left_at IS NULL
        ''', (guild_id, user_id))

        # Also record in permanent member_history table (never cleared by resets)
        cursor.execute('''
            INSERT INTO member_history (guild_id, user_id, event_type, event_time)
            VALUES (%s, %s, 'leave', CURRENT_TIMESTAMP)
        ''', (guild_id, user_id))

        self.connection.commit()
        cursor.close()

    async def get_user_invites(self, guild_id, user_id):
        """Get invite statistics for a user"""
        cursor = self.get_cursor()

        # Get successful invites (people who joined and didn't leave)
        cursor.execute('''
            SELECT COUNT(*) FROM invites 
            WHERE guild_id = %s AND inviter_id = %s AND left_at IS NULL
        ''', (guild_id, user_id))
        successful = cursor.fetchone()[0] or 0

        # Get left invites (people who joined but left)
        cursor.execute('''
            SELECT COUNT(*) FROM invites 
            WHERE guild_id = %s AND inviter_id = %s AND left_at IS NOT NULL
        ''', (guild_id, user_id))
        left = cursor.fetchone()[0] or 0

        # Get fake invites
        cursor.execute('''
            SELECT COUNT(*) FROM invites 
            WHERE guild_id = %s AND inviter_id = %s AND is_fake = TRUE
        ''', (guild_id, user_id))
        fake = cursor.fetchone()[0] or 0

        # Get total lifetime joins (including rejoins)
        cursor.execute('''
            SELECT COUNT(*) FROM invites 
            WHERE guild_id = %s AND inviter_id = %s
        ''', (guild_id, user_id))
        total_joins = cursor.fetchone()[0] or 0

        # Get rejoins - count users invited by this inviter who have joined the guild multiple times (regardless of who invited them later)
        cursor.execute('''
            SELECT COUNT(DISTINCT i1.user_id) AS rejoins
            FROM invites i1
            INNER JOIN (
                SELECT user_id
                FROM invites
                WHERE guild_id = %s
                GROUP BY user_id
                HAVING COUNT(*) > 1
            ) AS rejoined_users ON i1.user_id = rejoined_users.user_id
            WHERE i1.guild_id = %s AND i1.inviter_id = %s
        ''', (guild_id, guild_id, user_id))
        rejoins = cursor.fetchone()[0] or 0

        # Get custom invites
        cursor.execute('''
            SELECT added_invites, removed_invites FROM custom_invites 
            WHERE guild_id = %s AND user_id = %s
        ''', (guild_id, user_id))
        custom_row = cursor.fetchone()

        added = custom_row[0] if custom_row else 0
        removed = custom_row[1] if custom_row else 0

        # Total should be only successful invites + custom adjustments
        total = successful + added - removed

        cursor.close()

        return {
            'total': total,
            'successful': successful,
            'left': left,
            'fake': fake,
            'rejoins': rejoins,
            'total_joins': total_joins,
            'added': added,
            'removed': removed
        }

    async def get_inviter(self, guild_id, user_id):
        """Get who invited a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT inviter_id, invite_code, joined_at 
            FROM invites 
            WHERE guild_id = %s AND user_id = %s 
            ORDER BY joined_at DESC LIMIT 1
        ''', (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'inviter_id': result[0],
                'invite_code': result[1],
                'joined_at': result[2]
            }
        return None

    async def get_last_nonnull_inviter(self, guild_id, user_id):
        """Get the most recent non-null inviter for a user (for rejoin tracking)"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT inviter_id, invite_code, joined_at 
            FROM invites 
            WHERE guild_id = %s AND user_id = %s AND inviter_id IS NOT NULL
            ORDER BY joined_at DESC LIMIT 1
        ''', (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'inviter_id': result[0],
                'invite_code': result[1],
                'joined_at': result[2]
            }
        return None

    async def get_invited_users(self, guild_id, user_id):
        """Get users invited by a specific user with rejoin detection"""
        cursor = self.get_cursor()

        # Get all invites for this inviter, with rejoin count for each user
        cursor.execute('''
            SELECT 
                i.user_id, 
                i.joined_at, 
                i.left_at, 
                i.is_fake,
                (SELECT COUNT(*) FROM invites i2 WHERE i2.guild_id = %s AND i2.inviter_id = %s AND i2.user_id = i.user_id) as join_count
            FROM invites i
            WHERE i.guild_id = %s AND i.inviter_id = %s 
            ORDER BY i.joined_at DESC
        ''', (guild_id, user_id, guild_id, user_id))
        results = cursor.fetchall()
        cursor.close()

        return [{'user_id': r[0], 'joined_at': r[1], 'left_at': r[2], 'is_fake': r[3], 'join_count': r[4]} for r in results]

    async def record_manual_join(self, guild_id, user_id, inviter_id, invite_code="MANUAL"):
        """Record a manual join with automatic fake/rejoin detection"""
        # Check if this is a rejoin first
        is_rejoin = await self.is_rejoin(guild_id, user_id)

        # Check if this is a fake invite based on account age (if we can get the user)
        is_fake = False
        try:
            # Try to get user from Discord to check account age
            import discord
            from Jo1nTrX.utils.helpers import is_fake_invite
            # This would need the bot instance, so we'll just mark as False for manual
            # The admin can manually mark as fake if needed
            is_fake = False
        except:
            is_fake = False

        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO invites (guild_id, user_id, inviter_id, invite_code, is_fake, joined_at)
            VALUES (%s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
        ''', (guild_id, user_id, inviter_id, invite_code, is_fake))
        self.connection.commit()
        cursor.close()

        return is_rejoin

    async def get_user_invites_info(self, guild_id, user_id):
        """Get active invite codes for a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT code, uses, inviter_id 
            FROM cached_invites 
            WHERE guild_id = %s AND inviter_id = %s
        ''', (guild_id, user_id))
        results = cursor.fetchall()
        cursor.close()

        return [{'code': r[0], 'uses': r[1], 'inviter_id': r[2]} for r in results]

    async def add_custom_invites(self, guild_id, user_id, amount):
        """Add custom invites to a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO custom_invites 
            (guild_id, user_id, added_invites, removed_invites)
            VALUES (%s, %s, %s, 0)
            ON DUPLICATE KEY UPDATE added_invites = added_invites + %s
        ''', (guild_id, user_id, amount, amount))
        self.connection.commit()
        cursor.close()

    async def remove_custom_invites(self, guild_id, user_id, amount):
        """Remove custom invites from a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO custom_invites 
            (guild_id, user_id, added_invites, removed_invites)
            VALUES (%s, %s, 0, %s)
            ON DUPLICATE KEY UPDATE removed_invites = removed_invites + %s
        ''', (guild_id, user_id, amount, amount))
        self.connection.commit()
        cursor.close()

    async def clear_user_invites(self, guild_id, user_id):
        """Clear all invites for a user"""
        cursor = self.get_cursor()
        cursor.execute(
            'DELETE FROM invites WHERE guild_id = %s AND user_id = %s',
            (guild_id, user_id)
        )
        cursor.execute(
            'DELETE FROM invites WHERE guild_id = %s AND inviter_id = %s',
            (guild_id, user_id)
        )
        cursor.execute(
            'DELETE FROM custom_invites WHERE guild_id = %s AND user_id = %s',
            (guild_id, user_id)
        )
        self.connection.commit()
        cursor.close()

    async def clear_guild_invites(self, guild_id):
        """Clear all invites for a guild"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM invites WHERE guild_id = %s', (guild_id,))
        cursor.execute('DELETE FROM custom_invites WHERE guild_id = %s', (guild_id,))
        cursor.execute('DELETE FROM cached_invites WHERE guild_id = %s', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def get_leaderboard(self, guild_id, limit=10):
        """Get invite leaderboard for a guild"""
        cursor = self.get_cursor()

        # Get all users with their invite counts including rejoins
        cursor.execute('''
            SELECT 
                i.inviter_id,
                COUNT(*) as total_joins,
                COUNT(CASE WHEN i.left_at IS NULL THEN 1 END) as successful,
                COUNT(CASE WHEN i.left_at IS NOT NULL THEN 1 END) as left_count,
                COUNT(CASE WHEN i.is_fake = TRUE THEN 1 END) as fake,
                IFNULL(r.rejoins, 0) as rejoins
            FROM invites i
            LEFT JOIN (
                SELECT inviter_id, SUM(cnt-1) as rejoins
                FROM (
                    SELECT inviter_id, user_id, COUNT(*) as cnt
                    FROM invites
                    WHERE guild_id = %s
                    GROUP BY inviter_id, user_id
                    HAVING COUNT(*) > 1
                ) x
                GROUP BY inviter_id
            ) r ON r.inviter_id = i.inviter_id
            WHERE i.guild_id = %s AND i.inviter_id IS NOT NULL
            GROUP BY i.inviter_id
        ''', (guild_id, guild_id))
        invite_counts = cursor.fetchall()

        # Get custom invites
        cursor.execute('''
            SELECT user_id, added_invites, removed_invites 
            FROM custom_invites 
            WHERE guild_id = %s
        ''', (guild_id,))
        custom_counts = cursor.fetchall()

        cursor.close()

        # Combine and calculate totals
        user_totals = {}

        for row in invite_counts:
            user_id = row[0]
            user_totals[user_id] = {
                'total': row[2],  # Only count successful invites
                'total_joins': row[1],  # Total joins including rejoins
                'successful': row[2],
                'left': row[3],
                'fake': row[4],
                'rejoins': row[5],
                'added': 0,
                'removed': 0
            }

        for row in custom_counts:
            user_id = row[0]
            if user_id not in user_totals:
                user_totals[user_id] = {
                    'total': 0,
                    'total_joins': 0,
                    'successful': 0,
                    'left': 0,
                    'fake': 0,
                    'rejoins': 0,
                    'added': 0,
                    'removed': 0
                }
            user_totals[user_id]['added'] = row[1]
            user_totals[user_id]['removed'] = row[2]
            user_totals[user_id]['total'] += row[1] - row[2]

        # Sort by total and return top users
        sorted_users = sorted(
            user_totals.items(), 
            key=lambda x: x[1]['total'], 
            reverse=True
        )

        return sorted_users[:limit]

    async def check_user_has_inviter(self, guild_id, user_id):
        """Check if a user already has an inviter assigned"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT inviter_id FROM invites 
            WHERE guild_id = %s AND user_id = %s AND left_at IS NULL
            ORDER BY joined_at DESC LIMIT 1
        ''', (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else None

    async def get_user_join_count(self, guild_id, user_id):
        """Get the total number of times a user has joined this guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT COUNT(*) FROM invites 
            WHERE guild_id = %s AND user_id = %s
        ''', (guild_id, user_id))
        count = cursor.fetchone()[0]
        cursor.close()
        return count or 0

    async def is_rejoin(self, guild_id, user_id):
        """Check if this is a rejoin (user has joined before) - uses permanent member_history"""
        cursor = self.get_cursor()
        # Check permanent member_history table which is never cleared by invite resets
        cursor.execute('''
            SELECT COUNT(*) FROM member_history 
            WHERE guild_id = %s AND user_id = %s AND event_type = 'join'
        ''', (guild_id, user_id))
        count = cursor.fetchone()[0]
        cursor.close()
        # Return True if they've joined at least once before (count > 0 means this is at least their 2nd join)
        return count > 0

    async def set_guild_prefix(self, guild_id, prefix):
        """Set custom prefix for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings 
            (guild_id, welcome_channel_id, leave_channel_id, welcome_message, leave_message, modrole_id, prefix)
            VALUES (%s, NULL, NULL, NULL, NULL, NULL, %s)
            ON DUPLICATE KEY UPDATE prefix = %s
        ''', (guild_id, prefix, prefix))
        self.connection.commit()
        cursor.close()

    async def get_guild_prefix(self, guild_id):
        """Get custom prefix for a guild"""
        cursor = self.get_cursor()
        cursor.execute('SELECT prefix FROM guild_settings WHERE guild_id = %s', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else '+'

    async def delete_guild_prefix(self, guild_id):
        """Delete custom prefix for a guild"""
        cursor = self.get_cursor()
        cursor.execute('UPDATE guild_settings SET prefix = NULL WHERE guild_id = %s', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def set_noprefix_status(self, guild_id, enabled, user_id=None, scope=None):
        """Set noprefix status for a guild and save the scope when enabling"""
        cursor = self.get_cursor()
        if enabled and user_id and scope:
            # When enabling, save the user_id and scope
            cursor.execute('''
                INSERT INTO guild_settings 
                (guild_id, noprefix_enabled, noprefix_user_id, noprefix_scope)
                VALUES (%s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE 
                noprefix_enabled = %s, 
                noprefix_user_id = %s, 
                noprefix_scope = %s
            ''', (guild_id, enabled, user_id, scope, enabled, user_id, scope))
        else:
            # When disabling, only update the enabled status but keep user_id and scope
            cursor.execute('''
                INSERT INTO guild_settings 
                (guild_id, noprefix_enabled)
                VALUES (%s, %s)
                ON DUPLICATE KEY UPDATE noprefix_enabled = %s
            ''', (guild_id, enabled, enabled))
        self.connection.commit()
        cursor.close()

    async def get_noprefix_status(self, guild_id):
        """Get noprefix status for a guild"""
        cursor = self.get_cursor()
        cursor.execute('SELECT noprefix_enabled FROM guild_settings WHERE guild_id = %s', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] is not None else False

    async def get_noprefix_data(self, guild_id):
        """Get noprefix data including enabled status, user_id, and scope"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT noprefix_enabled, noprefix_user_id, noprefix_scope 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        if result:
            return {
                'enabled': result[0] if result[0] is not None else False,
                'user_id': result[1],
                'scope': result[2]
            }
        return {'enabled': False, 'user_id': None, 'scope': None}

    async def clear_user_messages(self, guild_id, user_id):
        """Clear all messages for a specific user"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM user_messages WHERE guild_id = %s AND user_id = %s', (guild_id, user_id))
        self.connection.commit()
        cursor.close()


    async def increment_user_messages(self, guild_id, user_id):
        """Increment user message count (alias for track_message)"""
        await self.track_message(guild_id, user_id)

    async def mark_invite_fake(self, guild_id, user_id):
        """Mark an invite as fake"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE invites 
            SET is_fake = TRUE 
            WHERE guild_id = %s AND user_id = %s AND left_at IS NULL
        ''', (guild_id, user_id))
        self.connection.commit()
        cursor.close()

    async def unmark_invite_fake(self, guild_id, user_id):
        """Unmark an invite as fake"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE invites 
            SET is_fake = FALSE 
            WHERE guild_id = %s AND user_id = %s AND left_at IS NULL
        ''', (guild_id, user_id))
        self.connection.commit()
        cursor.close()

    # Message tracking methods
    async def track_message(self, guild_id, user_id):
        """Track a message for a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO user_messages (guild_id, user_id, message_count, daily_count, weekly_count, last_message_date, last_week_reset)
            VALUES (%s, %s, 1, 1, 1, CURRENT_DATE, CURRENT_DATE)
            ON DUPLICATE KEY UPDATE
                message_count = message_count + 1,
                daily_count = CASE 
                    WHEN last_message_date = CURRENT_DATE THEN daily_count + 1
                    ELSE 1
                END,
                weekly_count = CASE 
                    WHEN DATEDIFF(CURRENT_DATE, last_week_reset) >= 7 THEN 1
                    ELSE weekly_count + 1
                END,
                last_week_reset = CASE 
                    WHEN DATEDIFF(CURRENT_DATE, last_week_reset) >= 7 THEN CURRENT_DATE
                    ELSE last_week_reset
                END,
                last_message_date = CURRENT_DATE
        ''', (guild_id, user_id))
        self.connection.commit()
        cursor.close()

    async def get_user_messages(self, guild_id, user_id):
        """Get message count for a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT message_count, daily_count, last_message_date 
            FROM user_messages 
            WHERE guild_id = %s AND user_id = %s
        ''', (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'total': result[0],
                'daily': result[1],
                'last_date': result[2]
            }
        return {'total': 0, 'daily': 0, 'last_date': None}

    async def get_user_message_stats(self, guild_id, user_id):
        """Get detailed message statistics for a user"""
        from datetime import date, timedelta
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT message_count, daily_count, weekly_count, last_message_date, last_week_reset 
            FROM user_messages 
            WHERE guild_id = %s AND user_id = %s
        ''', (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()

        if result:
            today = date.today()
            message_count = result[0] or 0
            daily_count = result[1] or 0
            weekly_count = result[2] or 0
            last_message_date = result[3]
            last_week_reset = result[4]
            
            # Check if daily count should be reset (if last message was not today)
            if last_message_date != today:
                daily_count = 0
            
            # Check if weekly count should be reset (if more than 7 days since last reset)
            if last_week_reset and (today - last_week_reset).days >= 7:
                weekly_count = 0

            return {
                'total': message_count,
                'daily': daily_count,
                'weekly': weekly_count,
                'last_date': last_message_date
            }
        return {'total': 0, 'daily': 0, 'weekly': 0, 'last_date': None}

    async def get_messages_leaderboard(self, guild_id, period='all', limit=10):
        """Get message leaderboard for a guild"""
        cursor = self.get_cursor()

        if period == 'daily':
            cursor.execute('''
                SELECT user_id, daily_count 
                FROM user_messages 
                WHERE guild_id = %s AND last_message_date = CURRENT_DATE
                ORDER BY daily_count DESC 
                LIMIT %s
            ''', (guild_id, limit))
        else:  # all time
            cursor.execute('''
                SELECT user_id, message_count 
                FROM user_messages 
                WHERE guild_id = %s 
                ORDER BY message_count DESC 
                LIMIT %s
            ''', (guild_id, limit))

        results = cursor.fetchall()
        cursor.close()
        return results

    async def get_message_leaderboard(self, guild_id, period='all', limit=10):
        """Alias for get_messages_leaderboard - Get message leaderboard for a guild"""
        return await self.get_messages_leaderboard(guild_id, period, limit)

    async def get_daily_message_leaderboard(self, guild_id, limit=10):
        """Get daily message leaderboard for a guild"""
        return await self.get_messages_leaderboard(guild_id, 'daily', limit)

    # Welcome and Leave Channel Methods
    async def get_welcome_channel(self, guild_id):
        """Get the welcome channel ID for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT welcome_channel_id 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def get_leave_channel(self, guild_id):
        """Get the leave channel ID for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT leave_channel_id 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def set_welcome_channel(self, guild_id, channel_id):
        """Set the welcome channel for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, welcome_channel_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE welcome_channel_id = %s
        ''', (guild_id, channel_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def set_leave_channel(self, guild_id, channel_id):
        """Set the leave channel for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, leave_channel_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE leave_channel_id = %s
        ''', (guild_id, channel_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def get_welcome_message(self, guild_id):
        """Get the custom welcome message for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT welcome_message 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def get_leave_message(self, guild_id):
        """Get the custom leave message for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT leave_message 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def set_welcome_message(self, guild_id, message):
        """Set custom welcome message for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, welcome_message)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE welcome_message = %s
        ''', (guild_id, message, message))
        self.connection.commit()
        cursor.close()

    async def set_leave_message(self, guild_id, message):
        """Set custom leave message for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, leave_message)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE leave_message = %s
        ''', (guild_id, message, message))
        self.connection.commit()
        cursor.close()

    # Blacklist methods
    async def add_blacklisted_channel(self, guild_id, channel_id):
        """Add a channel to the blacklist"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO blacklisted_channels (guild_id, channel_id)
            VALUES (%s, %s)
        ''', (guild_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def blacklist_channel(self, guild_id, channel_id):
        """Alias for add_blacklisted_channel - Add a channel to the blacklist"""
        await self.add_blacklisted_channel(guild_id, channel_id)

    async def unblacklist_channel(self, guild_id, channel_id):
        """Alias for remove_blacklisted_channel - Remove a channel from the blacklist"""
        await self.remove_blacklisted_channel(guild_id, channel_id)

    async def remove_blacklisted_channel(self, guild_id, channel_id):
        """Remove a channel from the blacklist"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM blacklisted_channels 
            WHERE guild_id = %s AND channel_id = %s
        ''', (guild_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def is_channel_blacklisted(self, guild_id, channel_id):
        """Check if a channel is blacklisted"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT 1 FROM blacklisted_channels 
            WHERE guild_id = %s AND channel_id = %s
        ''', (guild_id, channel_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    async def get_blacklisted_channels(self, guild_id):
        """Get all blacklisted channels for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT channel_id FROM blacklisted_channels 
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    async def add_blacklisted_category(self, guild_id, category_id):
        """Add a category to the blacklist"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO blacklisted_categories (guild_id, category_id)
            VALUES (%s, %s)
        ''', (guild_id, category_id))
        self.connection.commit()
        cursor.close()

    async def remove_blacklisted_category(self, guild_id, category_id):
        """Remove a category from the blacklist"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM blacklisted_categories 
            WHERE guild_id = %s AND category_id = %s
        ''', (guild_id, category_id))
        self.connection.commit()
        cursor.close()

    async def is_category_blacklisted(self, guild_id, category_id):
        """Check if a category is blacklisted"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT 1 FROM blacklisted_categories 
            WHERE guild_id = %s AND category_id = %s
        ''', (guild_id, category_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    async def get_blacklisted_categories(self, guild_id):
        """Get all blacklisted categories for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT category_id FROM blacklisted_categories 
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    # Alias methods for category blacklisting (for compatibility)
    async def blacklist_category(self, guild_id, category_id):
        """Alias for add_blacklisted_category"""
        return await self.add_blacklisted_category(guild_id, category_id)

    async def unblacklist_category(self, guild_id, category_id):
        """Alias for remove_blacklisted_category"""
        return await self.remove_blacklisted_category(guild_id, category_id)

    # Ignored channels methods (command blocking)
    async def add_ignored_channel(self, guild_id, channel_id):
        """Add a channel to the ignored channels list"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO ignored_channels (guild_id, channel_id)
            VALUES (%s, %s)
        ''', (guild_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def remove_ignored_channel(self, guild_id, channel_id):
        """Remove a channel from the ignored channels list"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM ignored_channels 
            WHERE guild_id = %s AND channel_id = %s
        ''', (guild_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def is_channel_ignored(self, guild_id, channel_id):
        """Check if a channel is in the ignored channels list"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT 1 FROM ignored_channels 
            WHERE guild_id = %s AND channel_id = %s
        ''', (guild_id, channel_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    async def get_ignored_channels(self, guild_id):
        """Get all ignored channels for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT channel_id FROM ignored_channels 
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    # Ignore bypass methods (roles/members that can bypass ignored channels)
    async def add_ignore_bypass(self, guild_id, entity_id, entity_type):
        """Add a role or member to the ignore bypass list"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO ignore_bypass (guild_id, entity_id, entity_type)
            VALUES (%s, %s, %s)
        ''', (guild_id, entity_id, entity_type))
        self.connection.commit()
        cursor.close()

    async def remove_ignore_bypass(self, guild_id, entity_id, entity_type):
        """Remove a role or member from the ignore bypass list"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM ignore_bypass 
            WHERE guild_id = %s AND entity_id = %s AND entity_type = %s
        ''', (guild_id, entity_id, entity_type))
        self.connection.commit()
        cursor.close()

    async def get_ignore_bypass(self, guild_id):
        """Get all bypass roles and members for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT entity_id, entity_type FROM ignore_bypass 
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()

        roles = []
        members = []
        for row in results:
            if row[1] == 'role':
                roles.append(row[0])
            elif row[1] == 'member':
                members.append(row[0])

        return {'roles': roles, 'members': members}

    async def can_bypass_ignored_channel(self, guild_id, member):
        """Check if a member can bypass ignored channels"""
        bypass_data = await self.get_ignore_bypass(guild_id)

        # Check if member is directly in bypass list
        if member.id in bypass_data['members']:
            return True

        # Check if any of member's roles are in bypass list
        member_role_ids = [role.id for role in member.roles]
        for role_id in bypass_data['roles']:
            if role_id in member_role_ids:
                return True

        return False

    # Guild settings methods
    async def get_guild_settings(self, guild_id):
        """Get guild settings"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT welcome_channel_id, leave_channel_id, welcome_message, 
                   leave_message, modrole_id, prefix
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'welcome_channel_id': result[0],
                'leave_channel_id': result[1],
                'welcome_message': result[2],
                'leave_message': result[3],
                'modrole_id': result[4],
                'prefix': result[5]
            }
        return None

    async def set_guild_setting(self, guild_id, setting, value):
        """Set a guild setting"""
        cursor = self.get_cursor()
        cursor.execute(f'''
            INSERT INTO guild_settings (guild_id, {setting})
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE {setting} = VALUES({setting})
        ''', (guild_id, value))
        self.connection.commit()
        cursor.close()

    # Modrole management methods
    async def set_modrole(self, guild_id, role_id):
        """Set modrole for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, modrole_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE modrole_id = %s
        ''', (guild_id, role_id, role_id))
        self.connection.commit()
        cursor.close()

    async def get_modrole(self, guild_id):
        """Get modrole for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT modrole_id FROM guild_settings WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def unset_modrole(self, guild_id):
        """Unset modrole for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE guild_settings SET modrole_id = NULL WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    # Confession channel methods
    async def set_confession_channel(self, guild_id, channel_id):
        """Set confession channel for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, confession_channel_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE confession_channel_id = %s
        ''', (guild_id, channel_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def get_confession_channel(self, guild_id):
        """Get confession channel for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT confession_channel_id FROM guild_settings WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def remove_confession_channel(self, guild_id):
        """Remove confession channel for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE guild_settings SET confession_channel_id = NULL WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def get_next_confession_number(self, guild_id):
        """Get and increment the confession number for a guild"""
        cursor = self.get_cursor()

        cursor.execute('''
            INSERT INTO guild_settings (guild_id, confession_count)
            VALUES (%s, 1)
            ON DUPLICATE KEY UPDATE confession_count = confession_count + 1
        ''', (guild_id,))
        self.connection.commit()

        cursor.execute('''
            SELECT confession_count FROM guild_settings WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()

        return result[0] if result else 1

    # Bot activity methods
    async def save_bot_activity(self, activity_text, custom_status='', status='online', activity_type='watching'):
        """Save bot activity, custom status, presence status, and activity type"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO bot_activity (activity_text, status, custom_status, activity_type)
            VALUES (%s, %s, %s, %s)
        ''', (activity_text, status, custom_status, activity_type))
        self.connection.commit()
        cursor.close()

    async def get_bot_activity(self):
        """Get the latest bot activity with custom status, presence status, and activity type"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                SELECT activity_text, status, COALESCE(custom_status, '') as custom_status, COALESCE(activity_type, 'watching') as activity_type
                FROM bot_activity 
                ORDER BY id DESC 
                LIMIT 1
            ''')
        except:
            # Fallback for databases without new columns yet
            try:
                cursor.execute('''
                    SELECT activity_text, status, COALESCE(custom_status, '') as custom_status
                    FROM bot_activity 
                    ORDER BY id DESC 
                    LIMIT 1
                ''')
                result = cursor.fetchone()
                cursor.close()
                if result:
                    return {
                        'activity_text': result[0] or '',
                        'status': result[1] or 'online',
                        'custom_status': result[2] or '',
                        'activity_type': 'watching'
                    }
                return None
            except:
                cursor.execute('''
                    SELECT activity_text, status
                    FROM bot_activity 
                    ORDER BY id DESC 
                    LIMIT 1
                ''')
                result = cursor.fetchone()
                cursor.close()
                if result:
                    return {
                        'activity_text': result[0] or '',
                        'status': result[1] or 'online',
                        'custom_status': '',
                        'activity_type': 'watching'
                    }
                return None
        
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'activity_text': result[0] or '',
                'status': result[1] or 'online',
                'custom_status': result[2] or '',
                'activity_type': result[3] or 'watching'
            }
        return None

    # Bot rotating statuses methods
    async def add_rotating_status(self, status_text):
        """Add a new custom rotating status (max 5)"""
        cursor = self.get_cursor()
        
        # Check current count
        cursor.execute('SELECT COUNT(*) FROM bot_rotating_statuses')
        count = cursor.fetchone()[0]
        
        if count >= 5:
            cursor.close()
            return False, "Maximum 5 rotating statuses allowed"
        
        # Get next position
        cursor.execute('SELECT COALESCE(MAX(position), 0) + 1 FROM bot_rotating_statuses')
        next_position = cursor.fetchone()[0]
        
        cursor.execute('''
            INSERT INTO bot_rotating_statuses (status_text, position)
            VALUES (%s, %s)
        ''', (status_text, next_position))
        self.connection.commit()
        cursor.close()
        return True, "Status added successfully"

    async def get_rotating_statuses(self):
        """Get all rotating statuses ordered by position"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, status_text, position
            FROM bot_rotating_statuses
            ORDER BY position ASC
        ''')
        results = cursor.fetchall()
        cursor.close()
        
        return [
            {
                'id': row[0],
                'status_text': row[1],
                'position': row[2]
            }
            for row in results
        ]

    async def clear_rotating_statuses(self):
        """Clear all rotating statuses"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM bot_rotating_statuses')
        self.connection.commit()
        cursor.close()

    async def remove_rotating_status(self, status_id):
        """Remove a specific rotating status"""
        cursor = self.get_cursor()
        cursor.execute('DELETE FROM bot_rotating_statuses WHERE id = %s', (status_id,))
        self.connection.commit()
        cursor.close()

    # Reaction Role management methods
    async def get_next_reaction_role_panel_id(self, guild_id):
        """Get the next available panel ID for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT MAX(panel_id) FROM reaction_role_panels WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()

        max_id = result[0] if result and result[0] is not None else 0
        return max_id + 1

    async def save_reaction_role_panel(self, guild_id, panel_id, panel_type, panel_embed=None, channel_id=None, message_id=None):
        """Save or update a reaction role panel"""
        cursor = self.get_cursor()

        # Check if panel exists
        cursor.execute('''
            SELECT id FROM reaction_role_panels WHERE guild_id = %s AND panel_id = %s
        ''', (guild_id, panel_id))

        if cursor.fetchone():
            # Update existing panel
            cursor.execute('''
                UPDATE reaction_role_panels 
                SET panel_type = %s, panel_embed = %s, channel_id = %s, message_id = %s
                WHERE guild_id = %s AND panel_id = %s
            ''', (panel_type, panel_embed, channel_id, message_id, guild_id, panel_id))
        else:
            # Insert new panel
            cursor.execute('''
                INSERT INTO reaction_role_panels (guild_id, panel_id, panel_type, panel_embed, channel_id, message_id)
                VALUES (%s, %s, %s, %s, %s, %s)
            ''', (guild_id, panel_id, panel_type, panel_embed, channel_id, message_id))

        self.connection.commit()
        cursor.close()
        return panel_id

    async def get_reaction_role_panel(self, guild_id, panel_id):
        """Get a specific reaction role panel"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, panel_id, panel_type, panel_embed, channel_id, message_id, created_at
            FROM reaction_role_panels 
            WHERE guild_id = %s AND panel_id = %s
        ''', (guild_id, panel_id))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'id': result[0],
                'panel_id': result[1],
                'panel_type': result[2],
                'panel_embed': result[3],
                'channel_id': result[4],
                'message_id': result[5],
                'created_at': result[6]
            }
        return None

    async def get_all_reaction_role_panels(self, guild_id):
        """Get all reaction role panels for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, panel_id, panel_type, panel_embed, channel_id, message_id, created_at
            FROM reaction_role_panels 
            WHERE guild_id = %s
            ORDER BY panel_id
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()

        panels = []
        for result in results:
            panels.append({
                'id': result[0],
                'panel_id': result[1],
                'panel_type': result[2],
                'panel_embed': result[3],
                'channel_id': result[4],
                'message_id': result[5],
                'created_at': result[6]
            })
        return panels

    async def delete_reaction_role_panel(self, guild_id, panel_id):
        """Delete a reaction role panel and its options"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM reaction_role_panels WHERE guild_id = %s AND panel_id = %s
        ''', (guild_id, panel_id))
        self.connection.commit()
        cursor.close()
        return cursor.rowcount > 0

    async def save_reaction_role_option(self, panel_db_id, guild_id, role_id, emoji, description=None, option_order=0, label=None):
        """Save a reaction role option"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO reaction_role_options (panel_id, guild_id, role_id, emoji, label, description, option_order)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        ''', (panel_db_id, guild_id, role_id, emoji, label, description, option_order))
        self.connection.commit()
        option_id = cursor.lastrowid
        cursor.close()
        return option_id

    async def get_reaction_role_options(self, panel_db_id):
        """Get all options for a reaction role panel"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, role_id, emoji, label, description, option_order
            FROM reaction_role_options 
            WHERE panel_id = %s
            ORDER BY option_order
        ''', (panel_db_id,))
        results = cursor.fetchall()
        cursor.close()

        options = []
        for result in results:
            options.append({
                'id': result[0],
                'role_id': result[1],
                'emoji': result[2],
                'label': result[3],
                'description': result[4],
                'option_order': result[5]
            })
        return options

    async def delete_reaction_role_option(self, option_id):
        """Delete a reaction role option"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM reaction_role_options WHERE id = %s
        ''', (option_id,))
        self.connection.commit()
        cursor.close()
        return cursor.rowcount > 0

    async def get_reaction_role_panel_by_message(self, message_id):
        """Get reaction role panel by message ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, panel_id, panel_type, panel_embed, channel_id, message_id
            FROM reaction_role_panels 
            WHERE message_id = %s
        ''', (message_id,))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'id': result[0],
                'guild_id': result[1],
                'panel_id': result[2],
                'panel_type': result[3],
                'panel_embed': result[4],
                'channel_id': result[5],
                'message_id': result[6]
            }
        return None

    # Giveaway management methods
    async def get_all_active_giveaways(self):
        """Get all active giveaways"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, channel_id, message_id, host_id, reward, 
                   winner_count, end_time, ended, paused, created_at
            FROM giveaways 
            WHERE ended = FALSE
        ''')
        results = cursor.fetchall()
        cursor.close()

        giveaways = []
        for row in results:
            giveaways.append({
                'id': row[0], 'guild_id': row[1], 'channel_id': row[2],
                'message_id': row[3], 'host_id': row[4], 'reward': row[5],
                'winner_count': row[6], 'end_time': row[7], 'ended': row[8],
                'paused': row[9], 'created_at': row[10]
            })
        return giveaways

    async def get_ended_giveaways(self):
        """Get giveaways that have ended but not processed"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, channel_id, message_id, host_id, reward, 
                   winner_count, end_time, ended, paused, created_at
            FROM giveaways 
            WHERE end_time <= UTC_TIMESTAMP() AND ended = FALSE AND paused = FALSE
        ''')
        results = cursor.fetchall()
        cursor.close()

        giveaways = []
        for row in results:
            giveaways.append({
                'id': row[0], 'guild_id': row[1], 'channel_id': row[2],
                'message_id': row[3], 'host_id': row[4], 'reward': row[5],
                'winner_count': row[6], 'end_time': row[7], 'ended': row[8],
                'paused': row[9], 'created_at': row[10]
            })
        return giveaways

    async def create_giveaway(self, guild_id, channel_id, host_id, reward, winner_count, end_time, requirement_type=None, requirement_value=None):
        """Create a new giveaway"""
        cursor = self.get_cursor()
        # Convert datetime to string format to ensure MySQL interprets it correctly as UTC
        # This prevents timezone conversion issues when storing
        end_time_str = end_time.strftime('%Y-%m-%d %H:%M:%S') if isinstance(end_time, datetime) else end_time

        cursor.execute('''
            INSERT INTO giveaways (guild_id, channel_id, host_id, reward, winner_count, end_time, requirement_type, requirement_value)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ''', (guild_id, channel_id, host_id, reward, winner_count, end_time_str, requirement_type, requirement_value))
        giveaway_id = cursor.lastrowid
        self.connection.commit()
        cursor.close()
        return giveaway_id

    async def update_giveaway_message_id(self, giveaway_id, message_id, preserve_end_time=None):
        """Update giveaway message ID

        Args:
            giveaway_id: The ID of the giveaway to update
            message_id: The new message ID to set
            preserve_end_time: The end_time to preserve (fixes MySQL ON UPDATE trigger bug)
        """
        cursor = self.get_cursor()

        # If end_time provided, get it first before update (to preserve it from ON UPDATE trigger)
        if preserve_end_time is None:
            cursor.execute('SELECT end_time FROM giveaways WHERE id = %s', (giveaway_id,))
            result = cursor.fetchone()
            if result:
                preserve_end_time = result[0]

        # Update message_id
        cursor.execute('''
            UPDATE giveaways SET message_id = %s WHERE id = %s
        ''', (message_id, giveaway_id))
        self.connection.commit()

        # WORKAROUND: Fix end_time after update (MySQL ON UPDATE trigger corrupts it)
        if preserve_end_time:
            end_time_str = preserve_end_time.strftime('%Y-%m-%d %H:%M:%S') if isinstance(preserve_end_time, datetime) else str(preserve_end_time)
            cursor.execute('''
                UPDATE giveaways SET end_time = %s WHERE id = %s
            ''', (end_time_str, giveaway_id))
            self.connection.commit()
            print(f"🔧 WORKAROUND: Restored end_time to {end_time_str} for giveaway {giveaway_id}")

        cursor.close()

    async def end_giveaway(self, giveaway_id):
        """Mark giveaway as ended"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE giveaways SET ended = TRUE WHERE id = %s
        ''', (giveaway_id,))
        self.connection.commit()
        cursor.close()

    async def pause_giveaway(self, giveaway_id):
        """Pause a giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE giveaways SET paused = TRUE WHERE id = %s
        ''', (giveaway_id,))
        self.connection.commit()
        cursor.close()

    async def unpause_giveaway(self, giveaway_id):
        """Unpause a giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE giveaways SET paused = FALSE WHERE id = %s
        ''', (giveaway_id,))
        self.connection.commit()
        cursor.close()

    async def get_giveaway_entries(self, giveaway_id):
        """Get number of entries for a giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT COUNT(*) FROM giveaway_entries WHERE giveaway_id = %s
        ''', (giveaway_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else 0

    async def add_giveaway_entry(self, giveaway_id, user_id):
        """Add entry to giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO giveaway_entries (giveaway_id, user_id)
            VALUES (%s, %s)
        ''', (giveaway_id, user_id))
        self.connection.commit()
        cursor.close()

    async def remove_giveaway_entry(self, giveaway_id, user_id):
        """Remove entry from giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM giveaway_entries 
            WHERE giveaway_id = %s AND user_id = %s
        ''', (giveaway_id, user_id))
        self.connection.commit()
        cursor.close()

    async def add_giveaway_winner(self, giveaway_id, user_id):
        """Add winner to giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO giveaway_winners (giveaway_id, user_id)
            VALUES (%s, %s)
        ''', (giveaway_id, user_id))
        self.connection.commit()
        cursor.close()

    async def get_giveaway_winners(self, giveaway_id):
        """Get winners for a giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT user_id FROM giveaway_winners WHERE giveaway_id = %s
        ''', (giveaway_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    async def get_giveaway(self, giveaway_id):
        """Get a single giveaway by ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, channel_id, message_id, host_id, reward, 
                   winner_count, end_time, ended, paused, requirement_type, requirement_value, created_at
            FROM giveaways WHERE id = %s
        ''', (giveaway_id,))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'id': result[0], 'guild_id': result[1], 'channel_id': result[2],
                'message_id': result[3], 'host_id': result[4], 'reward': result[5],
                'winner_count': result[6], 'end_time': result[7], 'ended': result[8],
                'paused': result[9], 'requirement_type': result[10], 'requirement_value': result[11], 'created_at': result[12]
            }
        return None

    async def get_giveaway_by_message(self, guild_id, message_id):
        """Get giveaway by message ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, channel_id, message_id, host_id, reward, 
                   winner_count, end_time, ended, paused, created_at
            FROM giveaways WHERE guild_id = %s AND message_id = %s
        ''', (guild_id, message_id))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'id': result[0], 'guild_id': result[1], 'channel_id': result[2],
                'message_id': result[3], 'host_id': result[4], 'reward': result[5],
                'winner_count': result[6], 'end_time': result[7], 'ended': result[8],
                'paused': result[9], 'created_at': result[10]
            }
        return None

    async def get_giveaway_participants(self, giveaway_id):
        """Get all participants for a giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT user_id FROM giveaway_entries WHERE giveaway_id = %s
        ''', (giveaway_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    async def has_joined_giveaway(self, giveaway_id, user_id):
        """Check if user has joined a giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT 1 FROM giveaway_entries WHERE giveaway_id = %s AND user_id = %s
        ''', (giveaway_id, user_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    async def join_giveaway(self, giveaway_id, user_id):
        """Join a giveaway (alias for add_giveaway_entry)"""
        await self.add_giveaway_entry(giveaway_id, user_id)

    async def set_giveaway_winners(self, giveaway_id, winner_ids):
        """Set multiple winners for a giveaway"""
        cursor = self.get_cursor()
        try:
            # Clear existing winners
            cursor.execute('DELETE FROM giveaway_winners WHERE giveaway_id = %s', (giveaway_id,))

            # Add new winners
            for user_id in winner_ids:
                cursor.execute('''
                    INSERT INTO giveaway_winners (giveaway_id, user_id)
                    VALUES (%s, %s)
                ''', (giveaway_id, user_id))

            self.connection.commit()
        except Exception as e:
            self.connection.rollback()
            raise e
        finally:
            cursor.close()

    async def get_active_giveaways(self, guild_id):
        """Get active giveaways for a specific guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, channel_id, message_id, host_id, reward, 
                   winner_count, end_time, ended, paused, created_at
            FROM giveaways 
            WHERE guild_id = %s AND ended = FALSE
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()

        giveaways = []
        for row in results:
            giveaways.append({
                'id': row[0], 'guild_id': row[1], 'channel_id': row[2],
                'message_id': row[3], 'host_id': row[4], 'reward': row[5],
                'winner_count': row[6], 'end_time': row[7], 'ended': row[8],
                'paused': row[9], 'created_at': row[10]
            })
        return giveaways

    # Update pause_giveaway to accept state parameter
    async def pause_giveaway(self, giveaway_id, paused=True):
        """Pause or unpause a giveaway"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE giveaways SET paused = %s WHERE id = %s
        ''', (paused, giveaway_id))
        self.connection.commit()
        cursor.close()

    async def delete_giveaway(self, giveaway_id):
        """Delete a giveaway and all its related data when message is deleted"""
        cursor = self.get_cursor()
        try:
            # Delete giveaway entries first (foreign key constraint)
            cursor.execute('DELETE FROM giveaway_entries WHERE giveaway_id = %s', (giveaway_id,))

            # Delete giveaway winners
            cursor.execute('DELETE FROM giveaway_winners WHERE giveaway_id = %s', (giveaway_id,))

            # Delete the giveaway itself
            cursor.execute('DELETE FROM giveaways WHERE id = %s', (giveaway_id,))

            self.connection.commit()
            print(f"Successfully deleted giveaway {giveaway_id} and all related data")
        except Exception as e:
            self.connection.rollback()
            print(f"Error deleting giveaway {giveaway_id}: {e}")
        finally:
            cursor.close()

    # Giveaway blacklist methods
    async def is_user_giveaway_blacklisted(self, guild_id, user_id):
        """Check if user is blacklisted from giveaways"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT 1 FROM giveaway_blacklist 
            WHERE guild_id = %s AND user_id = %s
        ''', (guild_id, user_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    async def is_role_giveaway_blacklisted(self, guild_id, role_id):
        """Check if role is blacklisted from giveaways"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT 1 FROM giveaway_blacklist 
            WHERE guild_id = %s AND role_id = %s
        ''', (guild_id, role_id))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

    async def add_giveaway_blacklist(self, guild_id, user_id=None, role_id=None):
        """Add user or role to giveaway blacklist"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO giveaway_blacklist (guild_id, user_id, role_id)
            VALUES (%s, %s, %s)
        ''', (guild_id, user_id, role_id))
        self.connection.commit()
        cursor.close()

    async def remove_giveaway_blacklist(self, guild_id, user_id=None, role_id=None):
        """Remove user or role from giveaway blacklist"""
        cursor = self.get_cursor()
        if user_id:
            cursor.execute('''
                DELETE FROM giveaway_blacklist 
                WHERE guild_id = %s AND user_id = %s
            ''', (guild_id, user_id))
        elif role_id:
            cursor.execute('''
                DELETE FROM giveaway_blacklist 
                WHERE guild_id = %s AND role_id = %s
            ''', (guild_id, role_id))

        rows_affected = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return rows_affected > 0

    async def get_giveaway_blacklist(self, guild_id):
        """Get all blacklisted users and roles for giveaways"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT user_id, role_id FROM giveaway_blacklist 
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()

        users = []
        roles = []
        for row in results:
            if row[0]:  # user_id
                users.append(row[0])
            if row[1]:  # role_id
                roles.append(row[1])

        return {'users': users, 'roles': roles}

    async def clear_giveaway_blacklist(self, guild_id):
        """Clear all giveaway blacklist entries for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM giveaway_blacklist WHERE guild_id = %s
        ''', (guild_id,))
        rows_affected = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return rows_affected

    # Giveaway manager role methods
    async def set_giveaway_manager_role(self, guild_id, role_id):
        """Set a role as giveaway manager for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO giveaway_manager_roles (guild_id, role_id)
            VALUES (%s, %s)
        ''', (guild_id, role_id))
        rows_affected = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return rows_affected > 0

    async def remove_giveaway_manager_role(self, guild_id, role_id):
        """Remove a giveaway manager role for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM giveaway_manager_roles 
            WHERE guild_id = %s AND role_id = %s
        ''', (guild_id, role_id))
        rows_affected = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return rows_affected > 0

    async def get_giveaway_manager_roles(self, guild_id):
        """Get all giveaway manager roles for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT role_id FROM giveaway_manager_roles 
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return [row[0] for row in results]

    # Welcome/Leave Channel and Message Methods
    async def add_join_channel(self, guild_id, channel_id, message_type):
        """Add a join/leave channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO join_channels (guild_id, channel_id, message_type)
            VALUES (%s, %s, %s)
        ''', (guild_id, channel_id, message_type))
        self.connection.commit()
        cursor.close()

    async def unset_welcome_channel(self, guild_id):
        """Remove all join channels for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM join_channels WHERE guild_id = %s AND message_type = 'join'
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def set_leave_channel(self, guild_id, channel_id):
        """Set leave channel (add as leave type)"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT IGNORE INTO join_channels (guild_id, channel_id, message_type)
            VALUES (%s, %s, 'leave')
        ''', (guild_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def unset_leave_channel(self, guild_id):
        """Remove all leave channels for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM join_channels WHERE guild_id = %s AND message_type = 'leave'
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def get_join_channels(self, guild_id, message_type=None):
        """Get join/leave channels for a guild"""
        cursor = self.get_cursor()

        # First check if delete_time column exists and add it if it doesn't
        try:
            cursor.execute("SHOW COLUMNS FROM join_channels LIKE 'delete_time'")
            if not cursor.fetchone():
                cursor.execute("ALTER TABLE join_channels ADD COLUMN delete_time INT DEFAULT NULL")
                self.connection.commit()
                print("Added delete_time column to join_channels table")
        except Exception as e:
            print(f"Error checking/adding delete_time column: {e}")

        if message_type:
            cursor.execute('''
                SELECT channel_id, message_type, custom_message, embed_name, delete_time FROM join_channels 
                WHERE guild_id = %s AND message_type = %s
            ''', (guild_id, message_type))
        else:
            cursor.execute('''
                SELECT channel_id, message_type, custom_message, embed_name, delete_time FROM join_channels 
                WHERE guild_id = %s
            ''', (guild_id,))

        results = cursor.fetchall()
        cursor.close()

        # Convert tuples to dictionaries for easier access
        channels = []
        for result in results:
            channel_data = {
                'channel_id': result[0],
                'message_type': result[1], 
                'custom_message': result[2],
                'embed_name': result[3],
                'delete_time': result[4] if len(result) > 4 else None
            }
            channels.append(channel_data)
        return channels

    async def set_join_channel_message(self, guild_id, channel_id, message_type, message):
        """Set custom message for a join/leave channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE join_channels 
            SET custom_message = %s 
            WHERE guild_id = %s AND channel_id = %s AND message_type = %s
        ''', (message, guild_id, channel_id, message_type))
        self.connection.commit()
        cursor.close()

    async def set_join_channel_embed(self, guild_id, channel_id, message_type, embed_name):
        """Set custom embed for a join/leave channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE join_channels 
            SET embed_name = %s 
            WHERE guild_id = %s AND channel_id = %s AND message_type = %s
        ''', (embed_name, guild_id, channel_id, message_type))
        self.connection.commit()
        cursor.close()

    async def unset_join_channel_message(self, guild_id, channel_id, message_type):
        """Remove a specific join/leave channel entirely"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM join_channels 
            WHERE guild_id = %s AND channel_id = %s AND message_type = %s
        ''', (guild_id, channel_id, message_type))
        self.connection.commit()
        cursor.close()

    async def clear_all_join_channels(self, guild_id):
        """Remove all join/leave channels for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM join_channels WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def unset_welcome_message(self, guild_id):
        """Remove custom welcome message for all join channels"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE join_channels 
            SET custom_message = NULL 
            WHERE guild_id = %s AND message_type = 'join'
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def set_leave_message(self, guild_id, message):
        """Set custom leave message for all leave channels"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE join_channels 
            SET custom_message = %s 
            WHERE guild_id = %s AND message_type = 'leave'
        ''', (message, guild_id))
        self.connection.commit()
        cursor.close()

    async def set_join_message_delete_timer(self, guild_id, channel_id, delete_time_seconds):
        """Set delete timer for join messages in a specific channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE join_channels 
            SET delete_time = %s 
            WHERE guild_id = %s AND channel_id = %s AND message_type = 'join'
        ''', (delete_time_seconds, guild_id, channel_id))

        # Check if any rows were actually updated
        rows_affected = cursor.rowcount
        self.connection.commit()
        cursor.close()

        if rows_affected == 0:
            raise Exception(f"No join channel configuration found for channel {channel_id} in guild {guild_id}")

        return rows_affected

    async def get_join_message_delete_timer(self, guild_id, channel_id):
        """Get delete timer for join messages in a specific channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT delete_time FROM join_channels 
            WHERE guild_id = %s AND channel_id = %s AND message_type = 'join'
        ''', (guild_id, channel_id))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else None

    async def remove_join_message_delete_timer(self, guild_id, channel_id):
        """Remove delete timer for join messages in a specific channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE join_channels 
            SET delete_time = NULL 
            WHERE guild_id = %s AND channel_id = %s AND message_type = 'join'
        ''', (guild_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def unset_leave_message(self, guild_id):
        """Remove custom leave message for all leave channels"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE join_channels 
            SET custom_message = NULL 
            WHERE guild_id = %s AND message_type = 'leave'
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    # Embed configuration functions
    async def set_welcome_embed(self, guild_id, embed_name):
        """Set the welcome embed for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, welcome_embed_name)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE welcome_embed_name = %s
        ''', (guild_id, embed_name, embed_name))
        self.connection.commit()
        cursor.close()

    async def get_welcome_embed(self, guild_id):
        """Get the welcome embed name for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT welcome_embed_name 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def unset_welcome_embed(self, guild_id):
        """Remove welcome embed for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE guild_settings 
            SET welcome_embed_name = NULL 
            WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def set_boost_embed(self, guild_id, embed_name):
        """Set the boost embed for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, boost_embed_name)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE boost_embed_name = %s
        ''', (guild_id, embed_name, embed_name))
        self.connection.commit()
        cursor.close()

    async def get_boost_embed(self, guild_id):
        """Get the boost embed name for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT boost_embed_name 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def unset_boost_embed(self, guild_id):
        """Remove boost embed for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE guild_settings 
            SET boost_embed_name = NULL 
            WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def set_boost_channel(self, guild_id, channel_id):
        """Set the boost channel for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, boost_channel_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE boost_channel_id = %s
        ''', (guild_id, channel_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def get_boost_channel(self, guild_id):
        """Get the boost channel for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT boost_channel_id 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def set_boost_message(self, guild_id, message):
        """Set the boost message for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, boost_message)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE boost_message = %s
        ''', (guild_id, message, message))
        self.connection.commit()
        cursor.close()

    async def get_boost_message(self, guild_id):
        """Get the boost message for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT boost_message 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def set_boost_emoji(self, guild_id, emoji):
        """Set the boost emoji for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO guild_settings (guild_id, boost_emoji)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE boost_emoji = %s
        ''', (guild_id, emoji, emoji))
        self.connection.commit()
        cursor.close()

    async def get_boost_emoji(self, guild_id):
        """Get the boost emoji for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT boost_emoji 
            FROM guild_settings 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result and result[0] else None

    async def unset_boost_config(self, guild_id):
        """Remove all boost configuration for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE guild_settings 
            SET boost_channel_id = NULL, boost_message = NULL, boost_embed_name = NULL, boost_emoji = NULL 
            WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def get_welcome_settings(self, guild_id):
        """Get welcome settings for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT channel_id, message_type, custom_message 
            FROM join_channels 
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()

        settings = {
            'join_channels': [],
            'leave_channels': []
        }

        for row in results:
            channel_data = {
                'channel_id': row[0],
                'custom_message': row[2]
            }

            if row[1] == 'join':
                settings['join_channels'].append(channel_data)
            elif row[1] == 'leave':
                settings['leave_channels'].append(channel_data)

        return settings

    # Missing Message Methods
    async def add_user_messages(self, guild_id, user_id, amount):
        """Add messages to a user's count"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO user_messages (guild_id, user_id, message_count, daily_count, weekly_count, last_message_date, last_week_reset)
            VALUES (%s, %s, %s, %s, %s, CURRENT_DATE, CURRENT_DATE)
            ON DUPLICATE KEY UPDATE 
                message_count = message_count + %s,
                daily_count = CASE 
                    WHEN last_message_date = CURRENT_DATE THEN daily_count + %s
                    ELSE %s
                END,
                weekly_count = CASE 
                    WHEN DATEDIFF(CURRENT_DATE, last_week_reset) >= 7 THEN %s
                    ELSE weekly_count + %s
                END,
                last_week_reset = CASE 
                    WHEN DATEDIFF(CURRENT_DATE, last_week_reset) >= 7 THEN CURRENT_DATE
                    ELSE last_week_reset
                END,
                last_message_date = CURRENT_DATE
        ''', (guild_id, user_id, amount, amount, amount, amount, amount, amount, amount, amount))
        self.connection.commit()
        cursor.close()

    async def remove_user_messages(self, guild_id, user_id, amount):
        """Remove messages from a user's count"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE user_messages 
            SET message_count = GREATEST(0, message_count - %s),
                daily_count = CASE 
                    WHEN last_message_date = CURRENT_DATE THEN GREATEST(0, daily_count - %s)
                    ELSE daily_count
                END,
                weekly_count = CASE 
                    WHEN DATEDIFF(CURRENT_DATE, last_week_reset) < 7 THEN GREATEST(0, weekly_count - %s)
                    ELSE weekly_count
                END
            WHERE guild_id = %s AND user_id = %s
        ''', (amount, amount, amount, guild_id, user_id))
        self.connection.commit()
        cursor.close()

    async def clear_guild_messages(self, guild_id):
        """Clear all message data for a guild"""
        cursor = self.get_cursor()
        # Clear from user_messages table (contains daily_count and message_count)
        cursor.execute('''
            DELETE FROM user_messages WHERE guild_id = %s
        ''', (guild_id,))
        # Clear from messages table if it exists
        cursor.execute('''
            DELETE FROM messages WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    # Missing Invite Method
    async def remove_user_from_inviter(self, guild_id, user_id, inviter_id):
        """Remove a user from an inviter's record"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE invites 
            SET left_at = UTC_TIMESTAMP() 
            WHERE guild_id = %s AND user_id = %s AND inviter_id = %s AND left_at IS NULL
        ''', (guild_id, user_id, inviter_id))
        rows_affected = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return rows_affected > 0

    # Vanity Roles Methods
    async def set_vanity_role(self, guild_id, role_id, vanity_text):
        """Set up a vanity role"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO vanity_roles (guild_id, role_id, vanity_text)
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE vanity_text = VALUES(vanity_text)
        ''', (guild_id, role_id, vanity_text))
        self.connection.commit()
        cursor.close()

    async def get_vanity_role(self, guild_id, role_id):
        """Get vanity role data for a specific role"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT vanity_text FROM vanity_roles 
            WHERE guild_id = %s AND role_id = %s
        ''', (guild_id, role_id))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else None

    async def get_all_vanity_roles(self, guild_id):
        """Get all vanity roles for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT role_id, vanity_text FROM vanity_roles 
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return results

    async def remove_vanity_role(self, guild_id, role_id):
        """Remove a vanity role setup"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM vanity_roles 
            WHERE guild_id = %s AND role_id = %s
        ''', (guild_id, role_id))
        self.connection.commit()
        cursor.close()

    async def set_vanity_log_channel(self, guild_id, channel_id):
        """Set vanity log channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO vanity_log_channels (guild_id, channel_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE channel_id = VALUES(channel_id)
        ''', (guild_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def get_vanity_log_channel(self, guild_id):
        """Get vanity log channel for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT channel_id FROM vanity_log_channels 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else None

    async def remove_vanity_log_channel(self, guild_id):
        """Remove vanity log channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM vanity_log_channels 
            WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def reset_vanity_config(self, guild_id):
        """Reset all vanity configurations for a guild"""
        cursor = self.get_cursor()
        # Remove all vanity roles
        cursor.execute('''
            DELETE FROM vanity_roles 
            WHERE guild_id = %s
        ''', (guild_id,))
        # Remove vanity log channel
        cursor.execute('''
            DELETE FROM vanity_log_channels 
            WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def create_vanity_tables(self):
        """Create vanity-related tables if they don't exist"""
        cursor = self.get_cursor()

        # Create vanity_roles table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS vanity_roles (
                id INT PRIMARY KEY AUTO_INCREMENT,
                guild_id BIGINT NOT NULL,
                role_id BIGINT NOT NULL,
                vanity_text VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_guild_role (guild_id, role_id)
            )
        ''')

        # Create vanity_log_channels table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS vanity_log_channels (
                id INT PRIMARY KEY AUTO_INCREMENT,
                guild_id BIGINT NOT NULL UNIQUE,
                channel_id BIGINT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        self.connection.commit()
        cursor.close()
        print("✅ Vanity tables created/verified successfully")

    # AFK Status Methods
    async def set_afk(self, user_id, reason, dm_mentions, scope, guild_id=None):
        """Set user as AFK"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO afk_status (user_id, reason, dm_mentions, scope, guild_id)
            VALUES (%s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE 
            reason = VALUES(reason), 
            dm_mentions = VALUES(dm_mentions), 
            scope = VALUES(scope), 
            guild_id = VALUES(guild_id),
            set_at = UTC_TIMESTAMP()
        ''', (user_id, reason, dm_mentions, scope, guild_id))
        self.connection.commit()
        cursor.close()

    async def get_afk_status(self, user_id, guild_id=None):
        """Get user's AFK status - checks for global AFK or server-specific AFK for current guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT reason, dm_mentions, scope, guild_id, set_at 
            FROM afk_status 
            WHERE user_id = %s AND (scope = 'global' OR (scope = 'server' AND guild_id = %s))
        ''', (user_id, guild_id))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'reason': result[0],
                'dm_mentions': result[1],
                'scope': result[2],
                'guild_id': result[3],
                'set_at': result[4]
            }
        return None

    async def remove_afk(self, user_id, guild_id=None, scope=None):
        """Remove user's AFK status based on scope"""
        cursor = self.get_cursor()

        if scope == 'global':
            # Remove global AFK status when user sends message in any server
            cursor.execute('DELETE FROM afk_status WHERE user_id = %s AND scope = %s', (user_id, 'global'))
        elif scope == 'server' and guild_id:
            # Remove server-specific AFK status when user sends message in that specific server
            cursor.execute('DELETE FROM afk_status WHERE user_id = %s AND scope = %s AND guild_id = %s', (user_id, 'server', guild_id))
        else:
            # Fallback: remove all AFK statuses (for backward compatibility)
            cursor.execute('DELETE FROM afk_status WHERE user_id = %s', (user_id,))

        affected_rows = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return affected_rows

    async def close(self):
        """Close database connection"""
        if self.connection and self.connection.is_connected():
            self.connection.close()

    # Warning System Methods
    async def add_warning(self, guild_id, user_id, moderator_id, reason):
        """Add a warning to a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO warnings (guild_id, user_id, moderator_id, reason)
            VALUES (%s, %s, %s, %s)
        ''', (guild_id, user_id, moderator_id, reason))
        self.connection.commit()
        cursor.close()

    async def remove_warning(self, guild_id, user_id, warning_id=None):
        """Remove a warning from a user"""
        cursor = self.get_cursor()

        if warning_id:
            # Remove specific warning
            cursor.execute('''
                UPDATE warnings 
                SET active = FALSE 
                WHERE guild_id = %s AND user_id = %s AND id = %s AND active = TRUE
            ''', (guild_id, user_id, warning_id))
        else:
            # Remove most recent warning
            cursor.execute('''
                UPDATE warnings 
                SET active = FALSE 
                WHERE guild_id = %s AND user_id = %s AND active = TRUE 
                ORDER BY created_at DESC 
                LIMIT 1
            ''', (guild_id, user_id))

        affected_rows = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return affected_rows > 0

    async def get_warnings(self, guild_id, user_id):
        """Get all active warnings for a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, moderator_id, reason, created_at 
            FROM warnings 
            WHERE guild_id = %s AND user_id = %s AND active = TRUE 
            ORDER BY created_at DESC
        ''', (guild_id, user_id))

        warnings = []
        for row in cursor.fetchall():
            warnings.append({
                'id': row[0],
                'moderator_id': row[1],
                'reason': row[2],
                'created_at': row[3]
            })

        cursor.close()
        return warnings

    async def get_warning_count(self, guild_id, user_id):
        """Get the number of active warnings for a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT COUNT(*) 
            FROM warnings 
            WHERE guild_id = %s AND user_id = %s AND active = TRUE
        ''', (guild_id, user_id))

        count = cursor.fetchone()[0]
        cursor.close()
        return count

    # Custom Embed Methods
    async def save_custom_embed(self, guild_id, user_id, name, embed_data):
        """Save or update a custom embed"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO custom_embeds 
            (guild_id, user_id, name, embed_data)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE 
                embed_data = VALUES(embed_data)
        ''', (guild_id, user_id, name, embed_data))
        self.connection.commit()
        cursor.close()

    async def get_custom_embed(self, guild_id, name):
        """Get a custom embed by name"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT embed_data 
            FROM custom_embeds 
            WHERE guild_id = %s AND name = %s
        ''', (guild_id, name))

        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else None

    async def get_guild_embeds(self, guild_id):
        """Get all custom embeds for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT name, user_id, created_at 
            FROM custom_embeds 
            WHERE guild_id = %s 
            ORDER BY created_at DESC
        ''', (guild_id,))

        results = cursor.fetchall()
        cursor.close()

        embeds = []
        for row in results:
            embeds.append({
                'name': row[0],
                'user_id': row[1],
                'creator_name': f"User {row[1]}",  # Simple fallback since we don't have user lookup here
                'created_at': row[2].isoformat() if row[2] else None
            })
        return embeds

    async def get_all_custom_embeds(self, guild_id):
        """Get all custom embeds for a guild (alias for get_guild_embeds)"""
        return await self.get_guild_embeds(guild_id)

    async def delete_custom_embed(self, guild_id, name):
        """Delete a custom embed"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM custom_embeds 
            WHERE guild_id = %s AND name = %s
        ''', (guild_id, name))

        affected_rows = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return affected_rows > 0

    # Embed Button Messages Methods
    async def save_embed_button_message(self, guild_id, channel_id, message_id, embed_buttons, link_buttons):
        """Save an embed button message for persistence"""
        import json
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO embed_button_messages 
            (guild_id, channel_id, message_id, embed_buttons, link_buttons)
            VALUES (%s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
            embed_buttons = VALUES(embed_buttons),
            link_buttons = VALUES(link_buttons)
        ''', (guild_id, channel_id, message_id, json.dumps(embed_buttons), json.dumps(link_buttons)))
        self.connection.commit()
        cursor.close()

    async def get_all_embed_button_messages(self):
        """Get all embed button messages for restoration"""
        import json
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT guild_id, channel_id, message_id, embed_buttons, link_buttons
            FROM embed_button_messages
            ORDER BY created_at DESC
        ''')

        results = cursor.fetchall()
        cursor.close()

        messages = []
        for row in results:
            messages.append({
                'guild_id': row[0],
                'channel_id': row[1],
                'message_id': row[2],
                'embed_buttons': json.loads(row[3]) if row[3] else [],
                'link_buttons': json.loads(row[4]) if row[4] else []
            })
        return messages

    async def delete_embed_button_message(self, message_id):
        """Delete an embed button message"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM embed_button_messages 
            WHERE message_id = %s
        ''', (message_id,))

        affected_rows = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return affected_rows > 0

    # Embed Button Config Sessions Methods
    async def save_embed_button_config_session(self, guild_id, channel_id, message_id, author_id, embed_name, embed_data, embed_buttons, link_buttons):
        """Save an active embed button configuration session for persistence"""
        import json
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO embed_button_config_sessions 
            (guild_id, channel_id, message_id, author_id, embed_name, embed_data, embed_buttons, link_buttons)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
            embed_data = VALUES(embed_data),
            embed_buttons = VALUES(embed_buttons),
            link_buttons = VALUES(link_buttons)
        ''', (guild_id, channel_id, message_id, author_id, embed_name, json.dumps(embed_data), json.dumps(embed_buttons), json.dumps(link_buttons)))
        self.connection.commit()
        cursor.close()

    async def get_all_embed_button_config_sessions(self):
        """Get all active embed button configuration sessions for restoration"""
        import json
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT guild_id, channel_id, message_id, author_id, embed_name, embed_data, embed_buttons, link_buttons
            FROM embed_button_config_sessions
            ORDER BY created_at DESC
        ''')

        results = cursor.fetchall()
        cursor.close()

        sessions = []
        for row in results:
            sessions.append({
                'guild_id': row[0],
                'channel_id': row[1],
                'message_id': row[2],
                'author_id': row[3],
                'embed_name': row[4],
                'embed_data': json.loads(row[5]) if row[5] else {},
                'embed_buttons': json.loads(row[6]) if row[6] else [],
                'link_buttons': json.loads(row[7]) if row[7] else []
            })
        return sessions

    async def delete_embed_button_config_session(self, message_id):
        """Delete an embed button configuration session"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM embed_button_config_sessions 
            WHERE message_id = %s
        ''', (message_id,))

        affected_rows = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return affected_rows > 0

    # Auto React Methods
    async def add_autoreact(self, guild_id, trigger_text, emojis, match_type='contains', user_id=None):
        """Add a new auto reaction with multiple emojis"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO autoreact 
            (guild_id, trigger_text, emojis, match_type, user_id)
            VALUES (%s, %s, %s, %s, %s)
        ''', (guild_id, trigger_text, emojis, match_type, user_id))
        self.connection.commit()
        cursor.close()

    async def delete_autoreact(self, guild_id, trigger_text):
        """Delete an auto reaction by trigger"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM autoreact 
            WHERE guild_id = %s AND trigger_text = %s
        ''', (guild_id, trigger_text))

        affected_rows = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return affected_rows > 0

    async def get_guild_autoreacts(self, guild_id):
        """Get all auto reactions for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT trigger_text, emojis, match_type, created_at 
            FROM autoreact 
            WHERE guild_id = %s 
            ORDER BY created_at DESC
        ''', (guild_id,))

        autoreacts = cursor.fetchall()
        cursor.close()
        return autoreacts

    async def get_all_autoreacts(self):
        """Get all auto reactions for event processing"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT guild_id, trigger_text, emojis, match_type 
            FROM autoreact
        ''')

        autoreacts = cursor.fetchall()
        cursor.close()
        return autoreacts

    # Auto Responder Methods
    async def add_autoresponder(self, guild_id, trigger_text, reply_text, match_type='contains', required_role_id=None, reaction_emojis=None, mode='normal', user_id=None):
        """Add a new auto responder with multiple reaction emojis and response mode"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO autoresponder 
            (guild_id, trigger_text, reply_text, match_type, required_role_id, reaction_emojis, mode, user_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ''', (guild_id, trigger_text, reply_text, match_type, required_role_id, reaction_emojis, mode, user_id))
        self.connection.commit()
        cursor.close()

    async def delete_autoresponder(self, guild_id, trigger_text):
        """Delete an auto responder by trigger"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM autoresponder 
            WHERE guild_id = %s AND trigger_text = %s
        ''', (guild_id, trigger_text))

        affected_rows = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return affected_rows > 0

    async def get_guild_autoresponders(self, guild_id):
        """Get all auto responders for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT trigger_text, reply_text, match_type, required_role_id, reaction_emojis, mode, created_at 
            FROM autoresponder 
            WHERE guild_id = %s 
            ORDER BY created_at DESC
        ''', (guild_id,))

        autoresponders = cursor.fetchall()
        cursor.close()
        return autoresponders

    async def get_all_autoresponders(self):
        """Get all auto responders for event processing"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT guild_id, trigger_text, reply_text, match_type, required_role_id, reaction_emojis, mode 
            FROM autoresponder
        ''')

        autoresponders = cursor.fetchall()
        cursor.close()
        return autoresponders

    # User limit counting methods
    async def get_user_autoreact_count(self, user_id, guild_id):
        """Get count of autoreacts created by a specific user in a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT COUNT(*) FROM autoreact 
            WHERE guild_id = %s AND user_id = %s AND user_id IS NOT NULL
        ''', (guild_id, user_id))

        count = cursor.fetchone()[0]
        cursor.close()
        return count

    async def get_user_autoresponder_count(self, user_id, guild_id):
        """Get count of autoresponders created by a specific user in a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT COUNT(*) FROM autoresponder 
            WHERE guild_id = %s AND user_id = %s AND user_id IS NOT NULL
        ''', (guild_id, user_id))

        count = cursor.fetchone()[0]
        cursor.close()
        return count

    # Premium User Management Methods
    async def add_premium_user(self, user_id, premium_type, expiry_date, granted_by, guild_id=None):
        """Add a premium user"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                INSERT INTO premium_users 
                (user_id, guild_id, premium_type, expiry_date, granted_by, is_active)
                VALUES (%s, %s, %s, %s, %s, TRUE)
                ON DUPLICATE KEY UPDATE
                expiry_date = VALUES(expiry_date),
                granted_by = VALUES(granted_by),
                is_active = TRUE
            ''', (user_id, guild_id, premium_type, expiry_date, granted_by))
            self.connection.commit()
            cursor.close()
            return True
        except Exception as e:
            print(f"Error adding premium user: {e}")
            cursor.close()
            return False

    async def remove_premium_user(self, user_id, guild_id=None, premium_type=None):
        """Remove premium access for a user"""
        cursor = self.get_cursor()
        try:
            if premium_type and guild_id:
                cursor.execute('''
                    UPDATE premium_users 
                    SET is_active = FALSE 
                    WHERE user_id = %s AND guild_id = %s AND premium_type = %s
                ''', (user_id, guild_id, premium_type))
            elif premium_type:
                cursor.execute('''
                    UPDATE premium_users 
                    SET is_active = FALSE 
                    WHERE user_id = %s AND premium_type = %s
                ''', (user_id, premium_type))
            else:
                cursor.execute('''
                    UPDATE premium_users 
                    SET is_active = FALSE 
                    WHERE user_id = %s
                ''', (user_id,))

            affected_rows = cursor.rowcount
            self.connection.commit()
            cursor.close()
            return affected_rows > 0
        except Exception as e:
            print(f"Error removing premium user: {e}")
            cursor.close()
            return False

    async def check_premium_user(self, user_id, guild_id=None):
        """Check if user has premium access"""
        cursor = self.get_cursor()
        try:
            # Single query to check both global and guild premium
            if guild_id:
                cursor.execute('''
                    SELECT premium_type, expiry_date 
                    FROM premium_users 
                    WHERE user_id = %s 
                    AND (premium_type = 'global' OR (premium_type = 'guild' AND guild_id = %s))
                    AND is_active = TRUE AND expiry_date > UTC_TIMESTAMP()
                    ORDER BY premium_type DESC
                    LIMIT 1
                ''', (user_id, guild_id))
            else:
                cursor.execute('''
                    SELECT premium_type, expiry_date 
                    FROM premium_users 
                    WHERE user_id = %s AND premium_type = 'global'
                    AND is_active = TRUE AND expiry_date > UTC_TIMESTAMP()
                    LIMIT 1
                ''', (user_id,))

            premium_data = cursor.fetchone()
            cursor.close()

            if premium_data:
                return {
                    'has_premium': True,
                    'type': premium_data[0],
                    'expiry': premium_data[1]
                }
            else:
                return {'has_premium': False, 'type': None, 'expiry': None}

        except Exception as e:
            print(f"Error checking premium user: {e}")
            cursor.close()
            return {'has_premium': False, 'type': None, 'expiry': None}

    async def list_premium_users(self, guild_id=None):
        """List all premium users"""
        cursor = self.get_cursor()
        try:
            if guild_id:
                cursor.execute('''
                    SELECT user_id, guild_id, premium_type, expiry_date, granted_by, granted_at
                    FROM premium_users 
                    WHERE (guild_id = %s OR premium_type = 'global') 
                    AND is_active = TRUE AND expiry_date > UTC_TIMESTAMP()
                    ORDER BY granted_at DESC
                ''', (guild_id,))
            else:
                cursor.execute('''
                    SELECT user_id, guild_id, premium_type, expiry_date, granted_by, granted_at
                    FROM premium_users 
                    WHERE is_active = TRUE AND expiry_date > UTC_TIMESTAMP()
                    ORDER BY granted_at DESC
                ''')

            premium_users = cursor.fetchall()
            cursor.close()
            return premium_users
        except Exception as e:
            print(f"Error listing premium users: {e}")
            cursor.close()
            return []

    async def cleanup_expired_premium(self):
        """Clean up expired premium users"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                SELECT user_id, premium_type, expiry_date
                FROM premium_users 
                WHERE is_active = TRUE AND expiry_date <= UTC_TIMESTAMP()
            ''')
            expired_users = cursor.fetchall()

            cursor.execute('''
                UPDATE premium_users 
                SET is_active = FALSE 
                WHERE is_active = TRUE AND expiry_date <= UTC_TIMESTAMP()
            ''')

            self.connection.commit()
            cursor.close()
            return expired_users
        except Exception as e:
            print(f"Error cleaning up expired premium: {e}")
            cursor.close()
            return []

    # Autoroles Methods
    async def add_human_autorole(self, guild_id, role_id):
        """Add a human autorole for a guild"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                INSERT INTO autoroles_humans (guild_id, role_id)
                VALUES (%s, %s)
            ''', (guild_id, role_id))
            self.connection.commit()
            return True
        except Exception as e:
            print(f"Error adding human autorole: {e}")
            return False
        finally:
            cursor.close()

    async def get_human_autoroles(self, guild_id):
        """Get all human autoroles for a guild"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                SELECT role_id, created_at
                FROM autoroles_humans 
                WHERE guild_id = %s
                ORDER BY created_at ASC
            ''', (guild_id,))
            result = cursor.fetchall()
            return result
        except Exception as e:
            print(f"Error getting human autoroles: {e}")
            return []
        finally:
            cursor.close()

    async def remove_human_autorole(self, guild_id, role_id):
        """Remove a human autorole from a guild"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                DELETE FROM autoroles_humans 
                WHERE guild_id = %s AND role_id = %s
            ''', (guild_id, role_id))
            affected_rows = cursor.rowcount
            self.connection.commit()
            return affected_rows > 0
        except Exception as e:
            print(f"Error removing human autorole: {e}")
            return False
        finally:
            cursor.close()

    async def clear_human_autoroles(self, guild_id):
        """Clear all human autoroles for a guild"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                DELETE FROM autoroles_humans 
                WHERE guild_id = %s
            ''', (guild_id,))
            affected_rows = cursor.rowcount
            self.connection.commit()
            return affected_rows
        except Exception as e:
            print(f"Error clearing human autoroles: {e}")
            return 0
        finally:
            cursor.close()

    async def set_bot_autorole(self, guild_id, role_id):
        """Set bot autorole for a guild"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                INSERT INTO autoroles_bots (guild_id, role_id)
                VALUES (%s, %s)
                ON DUPLICATE KEY UPDATE 
                role_id = VALUES(role_id),
                updated_at = CURRENT_TIMESTAMP
            ''', (guild_id, role_id))
            self.connection.commit()
            return True
        except Exception as e:
            print(f"Error setting bot autorole: {e}")
            return False
        finally:
            cursor.close()

    async def get_bot_autorole(self, guild_id):
        """Get bot autorole for a guild"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                SELECT role_id, created_at, updated_at
                FROM autoroles_bots 
                WHERE guild_id = %s
            ''', (guild_id,))
            result = cursor.fetchone()
            return result
        except Exception as e:
            print(f"Error getting bot autorole: {e}")
            return None
        finally:
            cursor.close()

    async def remove_bot_autorole(self, guild_id):
        """Remove bot autorole from a guild"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                DELETE FROM autoroles_bots 
                WHERE guild_id = %s
            ''', (guild_id,))
            affected_rows = cursor.rowcount
            self.connection.commit()
            return affected_rows > 0
        except Exception as e:
            print(f"Error removing bot autorole: {e}")
            return False
        finally:
            cursor.close()

    # Custom Roles Methods
    async def set_reqrole(self, guild_id, role_id):
        """Set the request role for custom roles"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO custom_roles_settings (guild_id, reqrole_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE reqrole_id = %s
        ''', (guild_id, role_id, role_id))
        self.connection.commit()
        cursor.close()

    async def get_reqrole(self, guild_id):
        """Get the request role for a guild"""
        cursor = self.get_cursor()
        cursor.execute('SELECT reqrole_id FROM custom_roles_settings WHERE guild_id = %s', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else None

    async def add_custom_role(self, guild_id, role_id, alias, role_type, created_by):
        """Add a custom role setup"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO custom_roles (guild_id, role_id, alias, role_type, created_by)
            VALUES (%s, %s, %s, %s, %s)
        ''', (guild_id, role_id, alias, role_type, created_by))
        self.connection.commit()
        cursor.close()

    async def get_custom_role(self, guild_id, alias):
        """Get a custom role by alias"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT role_id, role_type FROM custom_roles 
            WHERE guild_id = %s AND alias = %s
        ''', (guild_id, alias))
        result = cursor.fetchone()
        cursor.close()
        return result if result else None

    async def get_all_custom_roles(self, guild_id):
        """Get all custom roles for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT alias, role_id, role_type FROM custom_roles 
            WHERE guild_id = %s ORDER BY role_type, alias
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return results

    async def delete_custom_role(self, guild_id, alias):
        """Delete a custom role"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM custom_roles 
            WHERE guild_id = %s AND alias = %s
        ''', (guild_id, alias))
        self.connection.commit()
        affected_rows = cursor.rowcount
        cursor.close()
        return affected_rows > 0

    async def get_custom_role_count(self, guild_id, user_id=None):
        """Get the count of custom roles for a guild or created by a specific user"""
        cursor = self.get_cursor()
        if user_id:
            cursor.execute('''
                SELECT COUNT(*) FROM custom_roles 
                WHERE guild_id = %s AND created_by = %s AND role_type = 'custom'
            ''', (guild_id, user_id))
        else:
            cursor.execute('''
                SELECT COUNT(*) FROM custom_roles 
                WHERE guild_id = %s
            ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else 0

    async def update_custom_role(self, guild_id, old_alias, new_alias=None, new_role_id=None):
        """Update a custom role's alias or role_id"""
        cursor = self.get_cursor()
        if new_alias and new_role_id:
            cursor.execute('''
                UPDATE custom_roles 
                SET alias = %s, role_id = %s 
                WHERE guild_id = %s AND alias = %s
            ''', (new_alias, new_role_id, guild_id, old_alias))
        elif new_alias:
            cursor.execute('''
                UPDATE custom_roles 
                SET alias = %s 
                WHERE guild_id = %s AND alias = %s
            ''', (new_alias, guild_id, old_alias))
        elif new_role_id:
            cursor.execute('''
                UPDATE custom_roles 
                SET role_id = %s 
                WHERE guild_id = %s AND alias = %s
            ''', (new_role_id, guild_id, old_alias))
        self.connection.commit()
        affected_rows = cursor.rowcount
        cursor.close()
        return affected_rows > 0

    # Timer methods
    async def create_timer(self, guild_id, user_id, channel_id, end_time, reason=None):
        """Create a new timer"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO timers (guild_id, user_id, channel_id, end_time, reason)
            VALUES (%s, %s, %s, %s, %s)
        ''', (guild_id, user_id, channel_id, end_time, reason))
        timer_id = cursor.lastrowid
        self.connection.commit()
        cursor.close()
        return timer_id

    async def get_active_timers(self):
        """Get all active timers"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, user_id, channel_id, message_id, end_time, reason, created_at
            FROM timers 
            WHERE is_active = TRUE
            ORDER BY end_time ASC
        ''')
        result = cursor.fetchall()
        cursor.close()
        return result

    async def get_user_timers(self, guild_id, user_id):
        """Get active timers for a specific user in a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, channel_id, message_id, end_time, reason, created_at
            FROM timers 
            WHERE guild_id = %s AND user_id = %s AND is_active = TRUE
            ORDER BY end_time ASC
        ''', (guild_id, user_id))
        result = cursor.fetchall()
        cursor.close()
        return result

    async def update_timer_message_id(self, timer_id, message_id):
        """Update the message_id for a timer"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE timers 
            SET message_id = %s 
            WHERE id = %s
        ''', (message_id, timer_id))
        self.connection.commit()
        cursor.close()

    async def deactivate_timer(self, timer_id):
        """Mark a timer as inactive"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE timers 
            SET is_active = FALSE 
            WHERE id = %s
        ''', (timer_id,))
        self.connection.commit()
        affected_rows = cursor.rowcount
        cursor.close()
        return affected_rows > 0

    async def delete_user_timers(self, guild_id, user_id):
        """Delete all timers for a specific user in a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            UPDATE timers 
            SET is_active = FALSE 
            WHERE guild_id = %s AND user_id = %s AND is_active = TRUE
        ''', (guild_id, user_id))
        self.connection.commit()
        affected_rows = cursor.rowcount
        cursor.close()
        return affected_rows

    # Logging methods
    async def set_log_channel(self, guild_id, log_type, channel_id, webhook_url=None):
        """Set a log channel for a specific type"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO logging_channels (guild_id, log_type, channel_id, webhook_url)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE channel_id = VALUES(channel_id), webhook_url = VALUES(webhook_url)
        ''', (guild_id, log_type, channel_id, webhook_url))
        self.connection.commit()
        cursor.close()

    async def get_log_channel(self, guild_id, log_type):
        """Get a log channel for a specific type"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT channel_id, webhook_url FROM logging_channels 
            WHERE guild_id = %s AND log_type = %s
        ''', (guild_id, log_type))
        result = cursor.fetchone()
        cursor.close()
        return result if result else None

    async def get_all_log_channels(self, guild_id):
        """Get all log channels for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT log_type, channel_id, webhook_url FROM logging_channels 
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        return results

    async def remove_log_channel(self, guild_id, log_type):
        """Remove a specific log channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM logging_channels 
            WHERE guild_id = %s AND log_type = %s
        ''', (guild_id, log_type))
        self.connection.commit()
        cursor.close()

    async def clear_all_log_channels(self, guild_id):
        """Remove all log channels for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM logging_channels 
            WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    async def set_logging_category(self, guild_id, category_id):
        """Set the logging category ID for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO logging_config (guild_id, category_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE category_id = VALUES(category_id)
        ''', (guild_id, category_id))
        self.connection.commit()
        cursor.close()

    async def get_logging_category(self, guild_id):
        """Get the logging category ID for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT category_id FROM logging_config 
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else None

    async def remove_logging_category(self, guild_id):
        """Remove the logging category configuration"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM logging_config 
            WHERE guild_id = %s
        ''', (guild_id,))
        self.connection.commit()
        cursor.close()

    # Ticket System Methods

    # Panel operations
    async def save_ticket_panel(self, guild_id, global_panel_id, panel_data):
        """Save or update a ticket panel and its categories"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO ticket_panels (
                guild_id, global_panel_id, panel_channel, log_channel, 
                closed_category, ticket_embed, panel_type, panel_message_id
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                panel_channel = VALUES(panel_channel),
                log_channel = VALUES(log_channel),
                closed_category = VALUES(closed_category),
                ticket_embed = VALUES(ticket_embed),
                panel_type = VALUES(panel_type),
                panel_message_id = VALUES(panel_message_id)
        ''', (
            guild_id,
            global_panel_id,
            panel_data.get('panel_channel'),
            panel_data.get('log_channel'),
            panel_data.get('closed_category'),
            panel_data.get('ticket_embed'),
            panel_data.get('panel_type', 'menu'),
            panel_data.get('panel_message_id')
        ))
        self.connection.commit()

        # Get the panel's database ID
        cursor.execute('SELECT id FROM ticket_panels WHERE guild_id = %s AND global_panel_id = %s', (guild_id, global_panel_id))
        panel_row = cursor.fetchone()
        if not panel_row:
            cursor.close()
            raise Exception(f"Failed to get panel id for guild {guild_id}, global_panel_id {global_panel_id}")

        panel_db_id = panel_row[0]

        # Save categories if provided
        categories = panel_data.get('categories', [])
        if categories:
            # Delete existing categories first
            cursor.execute('DELETE FROM ticket_categories WHERE panel_id = %s', (panel_db_id,))

            # Insert new categories
            for category in categories:
                cursor.execute('''
                    INSERT INTO ticket_categories 
                    (panel_id, name, emoji, description, category_id, support_role_id, ping_support, category_order)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                ''', (
                    panel_db_id,
                    category.get('name'),
                    category.get('emoji'),
                    category.get('description'),
                    category.get('category_id'),
                    category.get('support_role_id'),
                    category.get('ping_support', False),
                    category.get('category_order', 0)
                ))
            self.connection.commit()

        cursor.close()
        return global_panel_id

    async def get_ticket_panel(self, global_panel_id):
        """Get a ticket panel by global panel ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, global_panel_id, panel_channel, log_channel, 
                   closed_category, ticket_embed, panel_type, panel_message_id, created_at
            FROM ticket_panels
            WHERE global_panel_id = %s
        ''', (global_panel_id,))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'id': result[0],
                'guild_id': result[1],
                'global_panel_id': result[2],
                'panel_channel': result[3],
                'log_channel': result[4],
                'closed_category': result[5],
                'ticket_embed': result[6],
                'panel_type': result[7],
                'panel_message_id': result[8],
                'created_at': result[9].isoformat() if result[9] else None
            }
        return None

    async def get_panels_by_guild(self, guild_id):
        """Get all ticket panels for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, global_panel_id, panel_channel, log_channel, 
                   closed_category, ticket_embed, panel_type, panel_message_id, created_at
            FROM ticket_panels
            WHERE guild_id = %s
            ORDER BY global_panel_id DESC
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()

        panels = []
        for result in results:
            panels.append({
                'id': result[0],
                'guild_id': result[1],
                'global_panel_id': result[2],
                'panel_channel': result[3],
                'log_channel': result[4],
                'closed_category': result[5],
                'ticket_embed': result[6],
                'panel_type': result[7],
                'panel_message_id': result[8],
                'created_at': result[9].isoformat() if result[9] else None
            })
        return panels

    async def get_all_ticket_panels(self):
        """Get all ticket panels"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, guild_id, global_panel_id, panel_channel, log_channel, 
                   closed_category, ticket_embed, panel_type, panel_message_id, created_at
            FROM ticket_panels
            ORDER BY global_panel_id DESC
        ''')
        results = cursor.fetchall()
        cursor.close()

        panels = []
        for result in results:
            panels.append({
                'id': result[0],
                'guild_id': result[1],
                'global_panel_id': result[2],
                'panel_channel': result[3],
                'log_channel': result[4],
                'closed_category': result[5],
                'ticket_embed': result[6],
                'panel_type': result[7],
                'panel_message_id': result[8],
                'created_at': result[9].isoformat() if result[9] else None
            })
        return panels

    async def delete_ticket_panel(self, global_panel_id):
        """Delete a ticket panel by global panel ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM ticket_panels
            WHERE global_panel_id = %s
        ''', (global_panel_id,))
        self.connection.commit()
        affected_rows = cursor.rowcount
        cursor.close()
        return affected_rows > 0

    async def get_next_global_panel_id(self):
        """Get the next available global panel ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT MAX(global_panel_id) FROM ticket_panels
        ''')
        result = cursor.fetchone()
        cursor.close()
        return (result[0] + 1) if result and result[0] else 1

    # Category operations
    async def save_ticket_categories(self, panel_id, categories):
        """Save ticket categories for a panel (replaces all existing categories)"""
        cursor = self.get_cursor()

        # First, delete existing categories for this panel
        cursor.execute('''
            DELETE FROM ticket_categories WHERE panel_id = %s
        ''', (panel_id,))

        # Then insert new categories
        for i, category in enumerate(categories):
            cursor.execute('''
                INSERT INTO ticket_categories (
                    panel_id, name, emoji, description, category_id, 
                    support_role_id, ping_support, category_order
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            ''', (
                panel_id,
                category['name'],
                category.get('emoji'),
                category.get('description'),
                category.get('category_id'),
                category.get('support_role_id'),
                category.get('ping_support', False),
                i
            ))

        self.connection.commit()
        cursor.close()

    async def get_ticket_categories(self, panel_id):
        """Get all categories for a panel"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT name, emoji, description, category_id, support_role_id, ping_support, category_order
            FROM ticket_categories
            WHERE panel_id = %s
            ORDER BY category_order ASC
        ''', (panel_id,))
        results = cursor.fetchall()
        cursor.close()

        categories = []
        for result in results:
            categories.append({
                'name': result[0],
                'emoji': result[1],
                'description': result[2],
                'category_id': result[3],
                'support_role_id': result[4],
                'ping_support': bool(result[5]),
                'category_order': result[6]
            })
        return categories

    # Active ticket operations
    async def create_ticket(self, guild_id, channel_id, ticket_data):
        """Create a new ticket"""
        cursor = self.get_cursor()

        # Convert added_users list to JSON string if present
        added_users_json = json.dumps(ticket_data.get('added_users', []))

        cursor.execute('''
            INSERT INTO active_tickets (
                guild_id, channel_id, user_id, category_name,
                ticket_number, status, original_category_id, original_channel_name,
                support_role_id, welcome_message_id, added_users
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ''', (
            guild_id,
            channel_id,
            ticket_data.get('user_id'),
            ticket_data.get('category_name', 'General'),
            ticket_data.get('ticket_number', 1),
            ticket_data.get('status', 'open'),
            ticket_data.get('original_category_id'),
            ticket_data.get('original_channel_name'),
            ticket_data.get('support_role_id'),
            ticket_data.get('welcome_message_id'),
            added_users_json
        ))
        self.connection.commit()
        cursor.close()

    async def get_active_ticket(self, guild_id, channel_id):
        """Get active ticket data by channel ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT guild_id, channel_id, user_id, category_name,
                   claimed_by, ticket_number, status, created_at, closed_at, closed_by,
                   reopened_at, reopened_by, claimed_at, original_category_id,
                   original_channel_name, support_role_id, welcome_message_id, added_users
            FROM active_tickets
            WHERE guild_id = %s AND channel_id = %s
        ''', (guild_id, channel_id))
        result = cursor.fetchone()
        cursor.close()

        if result:
            return {
                'guild_id': result[0],
                'channel_id': result[1],
                'user_id': result[2],
                'category_name': result[3],
                'claimed_by': result[4],
                'ticket_number': result[5],
                'status': result[6],
                'created_at': result[7].isoformat() if result[7] else None,
                'closed_at': result[8].timestamp() if result[8] else None,
                'closed_by': result[9],
                'reopened_at': result[10].timestamp() if result[10] else None,
                'reopened_by': result[11],
                'claimed_at': result[12].timestamp() if result[12] else None,
                'original_category_id': result[13],
                'original_channel_name': result[14],
                'support_role_id': result[15],
                'welcome_message_id': result[16],
                'added_users': json.loads(result[17]) if result[17] else []
            }
        return {}

    async def get_all_active_tickets(self):
        """Get all active tickets"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT guild_id, channel_id, user_id, category_name,
                   claimed_by, ticket_number, status, added_users
            FROM active_tickets
        ''')
        results = cursor.fetchall()
        cursor.close()

        tickets = {}
        for result in results:
            guild_id = str(result[0])
            channel_id = str(result[1])

            if guild_id not in tickets:
                tickets[guild_id] = {}

            tickets[guild_id][channel_id] = {
                'user_id': result[2],
                'category_name': result[3],
                'claimed_by': result[4],
                'ticket_number': result[5],
                'status': result[6],
                'added_users': json.loads(result[7]) if result[7] else []
            }

        return tickets

    async def update_ticket(self, guild_id, channel_id, update_data):
        """Update ticket data"""
        cursor = self.get_cursor()

        set_parts = []
        params = []

        for key, value in update_data.items():
            if key == 'added_users':
                value = json.dumps(value)
            set_parts.append(f"{key} = %s")
            params.append(value)

        params.extend([guild_id, channel_id])

        cursor.execute(f'''
            UPDATE active_tickets
            SET {', '.join(set_parts)}
            WHERE guild_id = %s AND channel_id = %s
        ''', params)
        self.connection.commit()
        cursor.close()

    async def close_ticket(self, guild_id, channel_id, closed_by, panel_id=None):
        """Close a ticket"""
        cursor = self.get_cursor()

        # Get the ticket data before closing
        ticket_data = await self.get_active_ticket(guild_id, channel_id)

        # Update ticket status to closed
        cursor.execute('''
            UPDATE active_tickets
            SET status = 'closed', closed_at = UTC_TIMESTAMP(), closed_by = %s
            WHERE guild_id = %s AND channel_id = %s
        ''', (closed_by, guild_id, channel_id))

        # Copy to closed_tickets table for reopening
        if ticket_data:
            cursor.execute('''
                INSERT INTO closed_tickets (
                    guild_id, channel_id, user_id, category_name,
                    ticket_number, created_at, closed_at, closed_by,
                    original_category_id, original_channel_name, support_role_id, added_users
                )
                VALUES (%s, %s, %s, %s, %s, %s, UTC_TIMESTAMP(), %s, %s, %s, %s, %s)
            ''', (
                guild_id,
                channel_id,
                ticket_data.get('user_id'),
                ticket_data.get('category_name'),
                ticket_data.get('ticket_number'),
                datetime.fromisoformat(ticket_data.get('created_at')) if ticket_data.get('created_at') else None,
                closed_by,
                ticket_data.get('original_category_id'),
                ticket_data.get('original_channel_name'),
                ticket_data.get('support_role_id'),
                json.dumps(ticket_data.get('added_users', []))
            ))

        self.connection.commit()
        cursor.close()

        # Update guild-level stats
        await self.update_ticket_stats(guild_id, None, active_change=-1, closed_change=1)

    async def reopen_ticket(self, guild_id, channel_id, reopened_by, panel_id=None):
        """Reopen a closed ticket"""
        cursor = self.get_cursor()

        # Try to get from closed_tickets
        cursor.execute('''
            SELECT user_id, category_name, ticket_number, 
                   original_category_id, original_channel_name, support_role_id, added_users
            FROM closed_tickets
            WHERE guild_id = %s AND channel_id = %s
        ''', (guild_id, channel_id))
        closed_ticket = cursor.fetchone()

        if closed_ticket:
            # Remove from closed_tickets
            cursor.execute('''
                DELETE FROM closed_tickets
                WHERE guild_id = %s AND channel_id = %s
            ''', (guild_id, channel_id))

        # Update or restore the ticket in active_tickets
        cursor.execute('''
            UPDATE active_tickets
            SET status = 'open', reopened_at = UTC_TIMESTAMP(), reopened_by = %s, closed_at = NULL
            WHERE guild_id = %s AND channel_id = %s
        ''', (reopened_by, guild_id, channel_id))

        self.connection.commit()
        cursor.close()

        # Update guild-level stats
        await self.update_ticket_stats(guild_id, None, active_change=1, closed_change=-1)

    async def delete_active_ticket(self, guild_id, channel_id):
        """Delete a ticket from active_tickets"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM active_tickets
            WHERE guild_id = %s AND channel_id = %s
        ''', (guild_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def add_user_to_ticket(self, guild_id, channel_id, user_id):
        """Add a user to ticket's added_users list"""
        ticket_data = await self.get_active_ticket(guild_id, channel_id)
        if ticket_data:
            added_users = ticket_data.get('added_users', [])
            if user_id not in added_users:
                added_users.append(user_id)
                await self.update_ticket({'added_users': added_users}, guild_id, channel_id)

    async def remove_user_from_ticket(self, guild_id, channel_id, user_id):
        """Remove a user from ticket's added_users list"""
        ticket_data = await self.get_active_ticket(guild_id, channel_id)
        if ticket_data:
            added_users = ticket_data.get('added_users', [])
            if user_id in added_users:
                added_users.remove(user_id)
                await self.update_ticket({'added_users': added_users}, guild_id, channel_id)

    async def get_ticket_added_users(self, guild_id, channel_id):
        """Get the list of manually added users for a ticket"""
        ticket_data = await self.get_active_ticket(guild_id, channel_id)
        return ticket_data.get('added_users', [])

    # Ticket statistics operations
    async def get_ticket_stats(self, guild_id, panel_id=None):
        """Get ticket statistics"""
        cursor = self.get_cursor()

        if panel_id:
            cursor.execute('''
                SELECT total_active_tickets, total_closed_tickets
                FROM ticket_stats
                WHERE guild_id = %s AND global_panel_id = %s
            ''', (guild_id, panel_id))
            result = cursor.fetchone()
            cursor.close()

            if result:
                return {
                    'total_active_tickets': result[0],
                    'total_closed_tickets': result[1]
                }
            return {'total_active_tickets': 0, 'total_closed_tickets': 0}
        else:
            # Get combined stats for entire guild
            cursor.execute('''
                SELECT SUM(total_active_tickets), SUM(total_closed_tickets)
                FROM ticket_stats
                WHERE guild_id = %s
            ''', (guild_id,))
            result = cursor.fetchone()
            cursor.close()

            if result:
                return {
                    'total_active_tickets': result[0] or 0,
                    'total_closed_tickets': result[1] or 0
                }
            return {'total_active_tickets': 0, 'total_closed_tickets': 0}

    async def update_ticket_stats(self, guild_id, panel_id, active_change=0, closed_change=0):
        """Update ticket statistics - uses global_panel_id 0 for guild-level stats"""
        cursor = self.get_cursor()

        # Use global_panel_id 0 for guild-level statistics
        global_panel_id = 0 if panel_id is None else panel_id

        cursor.execute('''
            INSERT INTO ticket_stats (guild_id, global_panel_id, total_active_tickets, total_closed_tickets)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                total_active_tickets = GREATEST(0, total_active_tickets + %s),
                total_closed_tickets = GREATEST(0, total_closed_tickets + %s)
        ''', (guild_id, global_panel_id, max(0, active_change), max(0, closed_change), active_change, closed_change))

        self.connection.commit()
        cursor.close()

    # Automod Database Methods
    async def is_automod_enabled(self, guild_id):
        """Check if automod is enabled for a guild"""
        cursor = self.get_cursor()
        cursor.execute('SELECT enabled FROM automod_config WHERE guild_id = %s', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return bool(result[0]) if result else False

    async def set_automod_enabled(self, guild_id, enabled):
        """Enable or disable automod for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO automod_config (guild_id, enabled)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE enabled = %s
        ''', (guild_id, 1 if enabled else 0, 1 if enabled else 0))
        self.connection.commit()
        cursor.close()

    async def set_automod_log_channel(self, guild_id, channel_id):
        """Set automod log channel"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO automod_config (guild_id, log_channel_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE log_channel_id = %s
        ''', (guild_id, channel_id, channel_id))
        self.connection.commit()
        cursor.close()

    async def get_automod_log_channel(self, guild_id):
        """Get automod log channel"""
        cursor = self.get_cursor()
        cursor.execute('SELECT log_channel_id FROM automod_config WHERE guild_id = %s', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else None

    async def get_automod_module_config(self, guild_id, module_name):
        """Get configuration for a specific automod module"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT enabled, punishment, threshold_value, threshold_time, mute_duration
            FROM automod_modules
            WHERE guild_id = %s AND module_name = %s
        ''', (guild_id, module_name))
        result = cursor.fetchone()
        cursor.close()
        if result:
            return {
                'enabled': bool(result[0]),
                'punishment': result[1],
                'threshold_value': result[2],
                'threshold_time': result[3],
                'mute_duration': result[4]
            }
        return None

    async def set_automod_module(self, guild_id, module_name, enabled=None, punishment=None, threshold_value=None, mute_duration=None):
        """Set configuration for a specific automod module"""
        cursor = self.get_cursor()
        
        existing = await self.get_automod_module_config(guild_id, module_name)
        
        if existing:
            updates = []
            params = []
            if enabled is not None:
                updates.append('enabled = %s')
                params.append(1 if enabled else 0)
            if punishment is not None:
                updates.append('punishment = %s')
                params.append(punishment)
            if threshold_value is not None:
                updates.append('threshold_value = %s')
                params.append(threshold_value)
            if mute_duration is not None:
                updates.append('mute_duration = %s')
                params.append(mute_duration)
            
            if updates:
                params.extend([guild_id, module_name])
                cursor.execute(f'''
                    UPDATE automod_modules
                    SET {', '.join(updates)}
                    WHERE guild_id = %s AND module_name = %s
                ''', params)
        else:
            cursor.execute('''
                INSERT INTO automod_modules (guild_id, module_name, enabled, punishment, threshold_value, mute_duration)
                VALUES (%s, %s, %s, %s, %s, %s)
            ''', (guild_id, module_name, 1 if enabled else 0, punishment, threshold_value, mute_duration))
        
        self.connection.commit()
        cursor.close()

    async def get_all_automod_modules(self, guild_id):
        """Get all automod module configurations for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT module_name, enabled, punishment, threshold_value, threshold_time, mute_duration
            FROM automod_modules
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        
        modules = {}
        for row in results:
            modules[row[0]] = {
                'enabled': bool(row[1]),
                'punishment': row[2],
                'threshold_value': row[3],
                'threshold_time': row[4],
                'mute_duration': row[5]
            }
        return modules

    async def is_automod_bypassed(self, guild_id, user_id, role_ids, module_name=None):
        """Check if user or any of their roles bypasses automod for a specific module"""
        cursor = self.get_cursor()
        
        if module_name:
            cursor.execute('''
                SELECT COUNT(*) FROM automod_bypass
                WHERE guild_id = %s AND entity_id = %s AND entity_type = 'user' 
                AND (module_name = %s OR module_name IS NULL)
            ''', (guild_id, user_id, module_name))
        else:
            cursor.execute('''
                SELECT COUNT(*) FROM automod_bypass
                WHERE guild_id = %s AND entity_id = %s AND entity_type = 'user'
            ''', (guild_id, user_id))
        
        if cursor.fetchone()[0] > 0:
            cursor.close()
            return True
        
        if role_ids:
            placeholders = ','.join(['%s'] * len(role_ids))
            if module_name:
                cursor.execute(f'''
                    SELECT COUNT(*) FROM automod_bypass
                    WHERE guild_id = %s AND entity_id IN ({placeholders}) AND entity_type = 'role'
                    AND (module_name = %s OR module_name IS NULL)
                ''', (guild_id, *role_ids, module_name))
            else:
                cursor.execute(f'''
                    SELECT COUNT(*) FROM automod_bypass
                    WHERE guild_id = %s AND entity_id IN ({placeholders}) AND entity_type = 'role'
                ''', (guild_id, *role_ids))
            
            if cursor.fetchone()[0] > 0:
                cursor.close()
                return True
        
        cursor.close()
        return False

    async def add_automod_bypass(self, guild_id, entity_id, entity_type, module_name=None):
        """Add entity to automod bypass for a specific module or all modules"""
        cursor = self.get_cursor()
        try:
            cursor.execute('''
                INSERT INTO automod_bypass (guild_id, entity_id, entity_type, module_name)
                VALUES (%s, %s, %s, %s)
            ''', (guild_id, entity_id, entity_type, module_name))
            self.connection.commit()
            cursor.close()
            return True
        except mysql.connector.IntegrityError:
            cursor.close()
            return False

    async def remove_automod_bypass(self, guild_id, entity_id, entity_type, module_name=None):
        """Remove entity from automod bypass for a specific module or all modules"""
        cursor = self.get_cursor()
        if module_name:
            cursor.execute('''
                DELETE FROM automod_bypass
                WHERE guild_id = %s AND entity_id = %s AND entity_type = %s AND module_name = %s
            ''', (guild_id, entity_id, entity_type, module_name))
        else:
            cursor.execute('''
                DELETE FROM automod_bypass
                WHERE guild_id = %s AND entity_id = %s AND entity_type = %s
            ''', (guild_id, entity_id, entity_type))
        affected = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return affected > 0

    async def get_automod_bypassed_list(self, guild_id):
        """Get list of all users and roles that bypass automod"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT entity_id, entity_type, module_name FROM automod_bypass
            WHERE guild_id = %s
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        
        bypassed = {'users': [], 'roles': []}
        for row in results:
            if row[1] == 'user':
                bypassed['users'].append(row[0])
            else:
                bypassed['roles'].append(row[0])
        return bypassed

    async def track_automod_action(self, guild_id, user_id, module_name):
        """Track an automod action for rate limiting"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO automod_tracking (guild_id, user_id, module_name)
            VALUES (%s, %s, %s)
        ''', (guild_id, user_id, module_name))
        self.connection.commit()
        cursor.close()

    async def get_recent_automod_actions(self, guild_id, user_id, module_name, seconds=5):
        """Get count of recent automod actions for a user"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT COUNT(*) FROM automod_tracking
            WHERE guild_id = %s AND user_id = %s AND module_name = %s
            AND timestamp > DATE_SUB(NOW(), INTERVAL %s SECOND)
        ''', (guild_id, user_id, module_name, seconds))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else 0

    async def cleanup_automod_tracking(self, minutes=10):
        """Clean up old automod tracking entries"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM automod_tracking
            WHERE timestamp < DATE_SUB(NOW(), INTERVAL %s MINUTE)
        ''', (minutes,))
        self.connection.commit()
        cursor.close()
    
    async def get_automod_thresholds(self, guild_id):
        """Get automod threshold configuration with defaults"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT max_message_spam, max_attachment_spam, max_emoji_in_message,
                   max_emoji_spam, max_mention_in_message, max_mention_spam
            FROM automod_config_thresholds
            WHERE guild_id = %s
        ''', (guild_id,))
        result = cursor.fetchone()
        cursor.close()
        
        if result:
            return {
                'max_message_spam': result[0] or 5,
                'max_attachment_spam': result[1] or 4,
                'max_emoji_in_message': result[2] or 5,
                'max_emoji_spam': result[3] or 15,
                'max_mention_in_message': result[4] or 3,
                'max_mention_spam': result[5] or 5
            }
        else:
            return {
                'max_message_spam': 5,
                'max_attachment_spam': 4,
                'max_emoji_in_message': 5,
                'max_emoji_spam': 15,
                'max_mention_in_message': 3,
                'max_mention_spam': 5
            }
    
    async def update_automod_thresholds(self, guild_id, threshold_updates):
        """Update automod threshold configuration"""
        cursor = self.get_cursor()
        
        columns = []
        values = []
        for key, value in threshold_updates.items():
            columns.append(f'{key} = %s')
            values.append(value)
        
        if not columns:
            cursor.close()
            return
        
        values.append(guild_id)
        
        cursor.execute(f'''
            INSERT INTO automod_config_thresholds (guild_id, {', '.join(threshold_updates.keys())})
            VALUES (%s, {', '.join(['%s'] * len(threshold_updates))})
            ON DUPLICATE KEY UPDATE {', '.join(columns)}
        ''', (guild_id, *threshold_updates.values(), *values))
        
        self.connection.commit()
        cursor.close()
    
    async def get_automod_bypass_counts(self, guild_id):
        """Get count of unique bypassed entities by type"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT entity_type, COUNT(DISTINCT entity_id) as count
            FROM automod_bypass
            WHERE guild_id = %s
            GROUP BY entity_type
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        
        counts = {
            'user': 0,
            'role': 0,
            'category': 0,
            'channel': 0
        }
        
        for row in results:
            counts[row[0]] = row[1]
        
        return counts
    
    async def is_automod_bypassed_extended(self, guild_id, user_id, role_ids, channel_id=None, category_id=None):
        """Check if user/role/channel/category bypasses automod"""
        cursor = self.get_cursor()
        
        cursor.execute('''
            SELECT COUNT(*) FROM automod_bypass
            WHERE guild_id = %s AND entity_id = %s AND entity_type = 'user'
        ''', (guild_id, user_id))
        if cursor.fetchone()[0] > 0:
            cursor.close()
            return True
        
        if role_ids:
            placeholders = ','.join(['%s'] * len(role_ids))
            cursor.execute(f'''
                SELECT COUNT(*) FROM automod_bypass
                WHERE guild_id = %s AND entity_id IN ({placeholders}) AND entity_type = 'role'
            ''', (guild_id, *role_ids))
            if cursor.fetchone()[0] > 0:
                cursor.close()
                return True
        
        if channel_id:
            cursor.execute('''
                SELECT COUNT(*) FROM automod_bypass
                WHERE guild_id = %s AND entity_id = %s AND entity_type = 'channel'
            ''', (guild_id, channel_id))
            if cursor.fetchone()[0] > 0:
                cursor.close()
                return True
        
        if category_id:
            cursor.execute('''
                SELECT COUNT(*) FROM automod_bypass
                WHERE guild_id = %s AND entity_id = %s AND entity_type = 'category'
            ''', (guild_id, category_id))
            if cursor.fetchone()[0] > 0:
                cursor.close()
                return True
        
        cursor.close()
        return False
    
    async def get_automod_bypassed_list_extended(self, guild_id):
        """Get list of all users, roles, categories, and channels that bypass automod with module information"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT entity_id, entity_type, module_name FROM automod_bypass
            WHERE guild_id = %s
            ORDER BY entity_type, entity_id
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        
        # Return list of dictionaries with entity_id, entity_type, and module_name
        bypasses = []
        for row in results:
            bypasses.append({
                'entity_id': row[0],
                'entity_type': row[1],
                'module_name': row[2]
            })
        
        return bypasses
    
    # ============= AUTOKICK METHODS =============
    
    async def add_autokick_rule(self, guild_id, condition_type, condition_value, added_by):
        """Add a new autokick rule and return its ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO autokick_rules (guild_id, condition_type, condition_value, added_by)
            VALUES (%s, %s, %s, %s)
        ''', (guild_id, condition_type, condition_value, added_by))
        self.connection.commit()
        rule_id = cursor.lastrowid
        cursor.close()
        return rule_id
    
    async def remove_autokick_rule(self, guild_id, rule_id):
        """Remove an autokick rule by ID, returns True if removed"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM autokick_rules WHERE id = %s AND guild_id = %s
        ''', (rule_id, guild_id))
        self.connection.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    async def get_autokick_rules(self, guild_id):
        """Get all autokick rules for a guild"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, condition_type, condition_value, added_by, created_at
            FROM autokick_rules
            WHERE guild_id = %s
            ORDER BY created_at ASC
        ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        
        rules = []
        for row in results:
            rules.append({
                'id': row[0],
                'condition_type': row[1],
                'condition_value': row[2],
                'added_by': row[3],
                'created_at': row[4]
            })
        return rules
    
    async def get_autokick_rule_by_id(self, guild_id, rule_id):
        """Get a specific autokick rule by ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, condition_type, condition_value, added_by, created_at
            FROM autokick_rules
            WHERE id = %s AND guild_id = %s
        ''', (rule_id, guild_id))
        result = cursor.fetchone()
        cursor.close()
        
        if result:
            return {
                'id': result[0],
                'condition_type': result[1],
                'condition_value': result[2],
                'added_by': result[3],
                'created_at': result[4]
            }
        return None
    
    # ============= AUTOBAN METHODS =============
    
    async def add_autoban_rule(self, guild_id, hours, added_by):
        """Add a new autoban rule with expiry time and return its ID and expiry"""
        cursor = self.get_cursor()
        cursor.execute('''
            INSERT INTO autoban_rules (guild_id, duration_hours, added_by, expires_at)
            VALUES (%s, %s, %s, DATE_ADD(NOW(), INTERVAL %s HOUR))
        ''', (guild_id, hours, added_by, hours))
        self.connection.commit()
        rule_id = cursor.lastrowid
        
        cursor.execute('SELECT created_at, expires_at FROM autoban_rules WHERE id = %s', (rule_id,))
        times = cursor.fetchone()
        cursor.close()
        
        return {
            'id': rule_id,
            'created_at': times[0] if times else None,
            'expires_at': times[1] if times else None
        }
    
    async def remove_autoban_rule(self, guild_id, rule_id):
        """Remove an autoban rule by ID, returns True if removed"""
        cursor = self.get_cursor()
        cursor.execute('''
            DELETE FROM autoban_rules WHERE id = %s AND guild_id = %s
        ''', (rule_id, guild_id))
        self.connection.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    async def get_autoban_rules(self, guild_id, active_only=True):
        """Get autoban rules for a guild (active only by default)"""
        cursor = self.get_cursor()
        if active_only:
            cursor.execute('''
                SELECT id, duration_hours, added_by, created_at, expires_at
                FROM autoban_rules
                WHERE guild_id = %s AND expires_at > NOW()
                ORDER BY created_at ASC
            ''', (guild_id,))
        else:
            cursor.execute('''
                SELECT id, duration_hours, added_by, created_at, expires_at
                FROM autoban_rules
                WHERE guild_id = %s
                ORDER BY created_at ASC
            ''', (guild_id,))
        results = cursor.fetchall()
        cursor.close()
        
        rules = []
        for row in results:
            rules.append({
                'id': row[0],
                'duration_hours': row[1],
                'added_by': row[2],
                'created_at': row[3],
                'expires_at': row[4]
            })
        return rules
    
    async def get_active_autoban_rules(self, guild_id):
        """Get only active (non-expired) autoban rules for a guild"""
        return await self.get_autoban_rules(guild_id, active_only=True)
    
    async def get_autoban_rule_by_id(self, guild_id, rule_id):
        """Get a specific autoban rule by ID"""
        cursor = self.get_cursor()
        cursor.execute('''
            SELECT id, duration_hours, added_by, created_at, expires_at
            FROM autoban_rules
            WHERE id = %s AND guild_id = %s
        ''', (rule_id, guild_id))
        result = cursor.fetchone()
        cursor.close()
        
        if result:
            return {
                'id': result[0],
                'duration_hours': result[1],
                'added_by': result[2],
                'created_at': result[3],
                'expires_at': result[4]
            }
        return None
    
    async def cleanup_expired_autoban_rules(self, guild_id=None):
        """Remove expired autoban rules (optionally for a specific guild)"""
        cursor = self.get_cursor()
        if guild_id:
            cursor.execute('DELETE FROM autoban_rules WHERE guild_id = %s AND expires_at <= NOW()', (guild_id,))
        else:
            cursor.execute('DELETE FROM autoban_rules WHERE expires_at <= NOW()')
        self.connection.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected