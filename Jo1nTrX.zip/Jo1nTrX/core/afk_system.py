"""
Complete AFK System - No external dependencies
Handles all AFK functionality including status removal, welcome messages, and mentions
"""

import discord
from discord import ui
from datetime import datetime, timezone, timedelta

# Emojis
ARROW = "<a:Jo1nTrX_stylisharrow:1408288940842156033>"
SECTION = "<:jo1ntrx_right:1405095312456024127>"
TICK = "<:jo1ntrx_tick:1405094884947267715>"
AFK_EMOJI = "<:Jo1nTrX_afk:1411471227973009548>"

class AFKSystem:
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
        
    async def handle_message_for_afk(self, message):
        """Handle incoming message to check for AFK status removal"""
        if message.author.bot or not message.guild:
            return
            
        # Check if user is AFK and remove status if they send a message
        afk_status = await self.db.get_afk_status(message.author.id, message.guild.id)
        if afk_status:
            print(f"AFK user {message.author.id} sent message in guild {message.guild.id}")
            print(f"AFK Status: {afk_status['scope']} - {afk_status['reason']}")
            
            # Calculate AFK duration
            duration_str = self.calculate_afk_duration(afk_status['set_at'])
            
            # Remove AFK status based on scope
            await self.db.remove_afk(message.author.id, message.guild.id, afk_status['scope'])
            print(f"Removed AFK status for user {message.author.id}")
            
            # Try to remove [AFK] from the user's nickname
            try:
                member = message.guild.get_member(message.author.id)
                if member and member.nick and member.nick.startswith('[AFK]'):
                    # Remove [AFK] prefix and extra space
                    base_nick = member.nick[6:].strip()
                    try:
                        # If base nickname equals username, clear the nickname (set to None)
                        # Otherwise, restore the base nickname
                        new_nick = None if base_nick == member.name else base_nick
                        await member.edit(nick=new_nick)
                        print(f"✅ Removed [AFK] from {member.display_name}'s nickname")
                    except discord.Forbidden:
                        print(f"⚠️  No permission to change nickname for {member.display_name}")
                        try:
                            await message.channel.send(
                                f"{message.author.mention} Welcome back! I couldn't remove the [AFK] tag from your nickname due to missing permissions.",
                                delete_after=15
                            )
                        except:
                            pass
                    except Exception as e:
                        print(f"❌ Error changing nickname: {e}")
            except Exception as e:
                print(f"❌ Error in nickname restoration process: {e}")
            
            # Send welcome back message
            await self.send_welcome_back_message(message, afk_status, duration_str)
            
        # Handle mentions of AFK users
        await self.handle_afk_mentions(message)
    
    def calculate_afk_duration(self, afk_since):
        """Calculate how long the user was AFK"""
        # Get current time in UTC
        now_utc = datetime.now(timezone.utc)
        
        # Handle AFK timestamp
        if afk_since.tzinfo is None:
            afk_since_utc = afk_since.replace(tzinfo=timezone.utc)
        else:
            afk_since_utc = afk_since
        
        # Calculate duration
        duration = now_utc - afk_since_utc
        return self.format_duration(duration)
    
    def format_duration(self, duration):
        """Format duration into human readable string"""
        total_seconds = int(duration.total_seconds())
        days = total_seconds // 86400
        hours = (total_seconds % 86400) // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        
        parts = []
        if days > 0:
            parts.append(f"{days} day{'s' if days != 1 else ''}")
        if hours > 0:
            parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
        if minutes > 0:
            parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
        elif seconds > 0 and len(parts) == 0:
            parts.append(f"{seconds} second{'s' if seconds != 1 else ''}")
        
        if not parts:
            return "just now"
        elif len(parts) == 1:
            return parts[0]
        else:
            return ", ".join(parts[:-1]) + " and " + parts[-1]
    
    async def send_welcome_back_message(self, message, afk_status, duration_str):
        """Send welcome back message to the user"""
        scope_text = "Global" if afk_status['scope'] == 'global' else f"Server ({message.guild.name})"
        
        content = f"""## {TICK} Welcome Back, {message.author.display_name}!

{SECTION} **__AFK Status Removed__**

{ARROW} **Scope:** {scope_text}
{ARROW} **Duration:** {duration_str}

> Your AFK status has been removed."""
        
        print(f"Sending welcome back message to {message.channel.name}")
        try:
            welcome_view = ui.LayoutView(timeout=None)
            welcome_view.add_item(ui.Container(ui.TextDisplay(content)))
            await message.channel.send(view=welcome_view, delete_after=10)
            print("Welcome back message sent successfully")
        except discord.Forbidden:
            print("Permission error - trying without auto-delete")
            try:
                welcome_view = ui.LayoutView(timeout=None)
                welcome_view.add_item(ui.Container(ui.TextDisplay(content)))
                await message.channel.send(view=welcome_view)
                print("Welcome back message sent (without auto-delete)")
            except Exception as e:
                print(f"Failed to send welcome back message: {e}")
        except Exception as e:
            print(f"Error sending AFK welcome back message: {e}")
    
    async def handle_afk_mentions(self, message):
        """Handle mentions of AFK users"""
        if not message.mentions:
            return
            
        for mentioned_user in message.mentions:
            if mentioned_user.bot:
                continue
                
            afk_status = await self.db.get_afk_status(mentioned_user.id, message.guild.id)
            if afk_status:
                # Ensure set_at is timezone-aware for proper timestamp display
                set_at = afk_status['set_at']
                # MySQL returns UTC datetime, explicitly set UTC timezone
                if set_at.tzinfo is None:
                    set_at = set_at.replace(tzinfo=timezone.utc)
                
                # Create component v2 view for AFK notification
                content = f"""## {AFK_EMOJI} {mentioned_user.display_name} is AFK

{SECTION} **__AFK Details__**

{ARROW} **Reason:** {afk_status['reason']}
{ARROW} **Since:** <t:{int(set_at.timestamp())}:R>"""
                
                try:
                    afk_view = ui.LayoutView(timeout=None)
                    afk_view.add_item(ui.Container(ui.TextDisplay(content)))
                    await message.channel.send(view=afk_view, delete_after=15)
                    print(f"Sent AFK notification for {mentioned_user.display_name}")
                    
                    # Send DM if enabled
                    if afk_status['dm_mentions']:
                        await self.send_afk_dm(mentioned_user, message)
                        
                except Exception as e:
                    print(f"Error sending AFK mention notification: {e}")
    
    async def send_afk_dm(self, mentioned_user, message):
        """Send DM to AFK user when mentioned"""
        try:
            truncated_content = message.content[:500] + ('...' if len(message.content) > 500 else '')
            
            content = f"""## {AFK_EMOJI} You were mentioned while AFK

{SECTION} **__Mention Details__**

{ARROW} **Server:** {message.guild.name}
{ARROW} **Channel:** #{message.channel.name}
{ARROW} **Mentioned by:** {message.author.display_name}
{ARROW} **Jump:** [Click Here To Jump To The Message]({message.jump_url})

{SECTION} **__Message__**

> {truncated_content}"""
            
            dm_view = ui.LayoutView(timeout=None)
            dm_view.add_item(ui.Container(ui.TextDisplay(content)))
            await mentioned_user.send(view=dm_view)
            print(f"Sent AFK mention DM to {mentioned_user.display_name}")
        except Exception as e:
            print(f"Error sending AFK mention DM: {e}")